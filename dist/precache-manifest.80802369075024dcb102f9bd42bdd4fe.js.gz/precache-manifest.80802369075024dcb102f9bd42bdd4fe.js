self.__precacheManifest = [
  {
    "revision": "96f21a6eb56586c39beb",
    "url": "/js/refundRules.41e0b355.js"
  },
  {
    "revision": "735ab4f94fbcd57074377afca324c813",
    "url": "/robots.txt"
  },
  {
    "revision": "0ef8917090a7b5515527",
    "url": "/css/refund_applying.0bf01bcb.css"
  },
  {
    "revision": "78214ba34c5f1df936aa",
    "url": "/js/Layout~card_usage~eqReplaceMent~esim_plan_list~esim_usage~mifi_order~mifi_plan_list~mifi_plan_usage~~c6f87c36.6241bd21.js"
  },
  {
    "revision": "a9d5bc20f555d7939531",
    "url": "/js/Not_fund.c250ee03.js"
  },
  {
    "revision": "3cee3e6bea41316cffb8",
    "url": "/js/whiteSearch.bbcf1201.js"
  },
  {
    "revision": "4463c825581bd1325459",
    "url": "/js/app.15215c80.js"
  },
  {
    "revision": "495de02c76895009f832",
    "url": "/js/whiteNewlist.ce7bcd03.js"
  },
  {
    "revision": "829ebf67667ccc9d2371",
    "url": "/js/authority_middle.55749900.js"
  },
  {
    "revision": "3a089487da1935a1f131",
    "url": "/js/whiteListsWrapper.becc5457.js"
  },
  {
    "revision": "07765cf97c5ddb301f45",
    "url": "/js/balanceIndex.301972c0.js"
  },
  {
    "revision": "94465077f4ab236aaad1",
    "url": "/js/userCenterWrap.9f838891.js"
  },
  {
    "revision": "f45f89de03a19df78555",
    "url": "/js/balanceRefund.7e574236.js"
  },
  {
    "revision": "9bb328a1c4c3f6b462eb",
    "url": "/js/userCenter.9c09ba33.js"
  },
  {
    "revision": "2f2509445d157598c83a",
    "url": "/js/cardPackage.299ac816.js"
  },
  {
    "revision": "4f14dd2e3be2947aa2eb",
    "url": "/js/transfer_url.5e1d7be9.js"
  },
  {
    "revision": "bb23e83988f6465c4326",
    "url": "/js/card_check.2459331f.js"
  },
  {
    "revision": "d6c998af7b7b3e3e5146",
    "url": "/js/to_tb.d38d20a7.js"
  },
  {
    "revision": "39457f60bbb16c07fc25",
    "url": "/js/card_connection.a97c70c6.js"
  },
  {
    "revision": "85f31d5e81f0c13ea443",
    "url": "/js/speedup_wrapper.22e41fc6.js"
  },
  {
    "revision": "e3d6bd1b238ac2b40935",
    "url": "/js/card_lookup.d7f51c03.js"
  },
  {
    "revision": "36efb4cbc1776fcf4eae",
    "url": "/js/speedup_80.154e4ab2.js"
  },
  {
    "revision": "e6c49bde64e07efd94ab",
    "url": "/js/card_lookup_notice.5f46ac7e.js"
  },
  {
    "revision": "8aa9b2b230363d6d68af",
    "url": "/js/speedup_500.1542d6ea.js"
  },
  {
    "revision": "af09bb346e061cc700ba",
    "url": "/js/card_lookup~card_lookup_notice.02ff088a.js"
  },
  {
    "revision": "9c356e5c2ee94da71406",
    "url": "/js/revoke_plan.2782bed5.js"
  },
  {
    "revision": "ff300cb5bc364cb96201",
    "url": "/js/card_more_flow.c33406db.js"
  },
  {
    "revision": "a289ac17887cb0dc8179",
    "url": "/js/repeatRecharge.a9f72de4.js"
  },
  {
    "revision": "62dfa5f3baebd6fbc478",
    "url": "/js/card_usage.66b8c15b.js"
  },
  {
    "revision": "2ca34cc16baf7f965b41",
    "url": "/js/refund_wrapper.67359b04.js"
  },
  {
    "revision": "713a74cc0cbb2726d38d",
    "url": "/js/card_usage~plan_list.f6ea843a.js"
  },
  {
    "revision": "0a8ca48abe36e42bd93e",
    "url": "/js/refund_plan.124df056.js"
  },
  {
    "revision": "563ad4b6dd88a2029691",
    "url": "/js/card_wrapper.70e7a53d.js"
  },
  {
    "revision": "a760219c584aaadcb3f7",
    "url": "/js/refund_argument.91a52f16.js"
  },
  {
    "revision": "93cd71708f01b01501a9",
    "url": "/js/children_card.c5476fc5.js"
  },
  {
    "revision": "0ef8917090a7b5515527",
    "url": "/js/refund_applying.4dd81427.js"
  },
  {
    "revision": "214d72f63c0fe099c81d",
    "url": "/js/chunk-7c88e131.e7b60769.js"
  },
  {
    "revision": "5ac8f52ed7c4e24f2334",
    "url": "/js/recharge_wrapper.59006b35.js"
  },
  {
    "revision": "7a9ddc7a29786c257c6a",
    "url": "/js/chunk-9a5f5058.6095d6b6.js"
  },
  {
    "revision": "aa2321c141b976e97a34",
    "url": "/js/recharge_callback.ba56fbc7.js"
  },
  {
    "revision": "2fa8d67a06c77fea899d",
    "url": "/js/chunk-vendors.4ec2dc53.js"
  },
  {
    "revision": "cec85b0d51efb670d572",
    "url": "/js/recharge_balance.521ce7e6.js"
  },
  {
    "revision": "0c5c50b5fd0d4667ec61",
    "url": "/js/commonProblem.206ddf31.js"
  },
  {
    "revision": "7347720b27e03576c1ec",
    "url": "/js/rechargeOrder~whiteSearch.3c368b80.js"
  },
  {
    "revision": "11505f790467edbf0aad",
    "url": "/js/commonQuestion.496c2754.js"
  },
  {
    "revision": "d86c68f20f45bef6b24a",
    "url": "/js/rechargeOrder.d5825e6a.js"
  },
  {
    "revision": "e5803e14cf29a325637c",
    "url": "/js/consumerRecord.27eef7a4.js"
  },
  {
    "revision": "da8386407f23784edeb9",
    "url": "/js/recharge.0ede9184.js"
  },
  {
    "revision": "65c7234747beeb08d015",
    "url": "/js/coupon_normal.3da94a2b.js"
  },
  {
    "revision": "68a8f18743d51ce82cef",
    "url": "/js/real_name.8ea42a00.js"
  },
  {
    "revision": "903739a6905e36f4bae2",
    "url": "/js/coupon_telcom.9d147440.js"
  },
  {
    "revision": "28854ae7a5ea58bdc0e1",
    "url": "/js/realNameCourse.5f8b41bc.js"
  },
  {
    "revision": "ea86c232f987bad0d36a",
    "url": "/js/coupon_wrapper.866bca42.js"
  },
  {
    "revision": "d6499d6e94c18bd57498",
    "url": "/js/question_wrapper.1990293a.js"
  },
  {
    "revision": "7065a66e35d3bb7d69f7",
    "url": "/js/currencyConversion.77eac294.js"
  },
  {
    "revision": "c495cd52a5528e4a2876",
    "url": "/js/question.79d059e5.js"
  },
  {
    "revision": "27a9001c14fbf5e5ac8a",
    "url": "/js/customerFeedback.69187b2b.js"
  },
  {
    "revision": "4f6de62d24da6ac1c6ba",
    "url": "/js/plan_list.3c3e556f.js"
  },
  {
    "revision": "4d24a56e4831fd99f6c4",
    "url": "/js/eqReplaceMent.dcf95ab4.js"
  },
  {
    "revision": "8ebea8f0ea0695b23a6d",
    "url": "/js/orderRecord.d356c7d9.js"
  },
  {
    "revision": "a2ac358b5ba0d37e1f75",
    "url": "/js/eqReplaceMent~recharge.0c032fb1.js"
  },
  {
    "revision": "c416916ea74c2ad88431",
    "url": "/js/official_accounts.82f57264.js"
  },
  {
    "revision": "3273d1a4a09a873c017d",
    "url": "/js/esim_plan_list.f9864c43.js"
  },
  {
    "revision": "62c6dcaa32d363b1bbc9",
    "url": "/js/new_card_wrapper.646a6a02.js"
  },
  {
    "revision": "6b339a0eef8e4f46a1e4",
    "url": "/js/esim_usage.11c0a081.js"
  },
  {
    "revision": "61f0902b4cb913b3891a",
    "url": "/js/mifi_plan_wrapper.d98dd323.js"
  },
  {
    "revision": "eca40fff11e5d7220d33",
    "url": "/js/find_plan.d9e23e30.js"
  },
  {
    "revision": "f2acb17dad8f253adf2c",
    "url": "/js/mifi_plan_usage.efec9299.js"
  },
  {
    "revision": "03cf4b8be078209bdcc1",
    "url": "/js/guardian.ada82020.js"
  },
  {
    "revision": "f537be35f6e54f13e599",
    "url": "/js/mifi_plan_list.2a586c96.js"
  },
  {
    "revision": "769d653c06e13e8971aa",
    "url": "/js/logical_page.49d7f9a3.js"
  },
  {
    "revision": "607d4b4e68e4c123bab1",
    "url": "/js/mifi_plan_group.85040ebd.js"
  },
  {
    "revision": "e68f7739b6bcb994d17b",
    "url": "/js/login.f4a464bb.js"
  },
  {
    "revision": "067213dfd29008ce7333",
    "url": "/js/mifi_order_wrapper.0198ca07.js"
  },
  {
    "revision": "07a24b97f68bdfa4c7c2",
    "url": "/js/lookup.46a0ecd6.js"
  },
  {
    "revision": "2019c3190daad325fcb5",
    "url": "/js/mifi_order.382f13ca.js"
  },
  {
    "revision": "993ab5cae036e2c8f7f8",
    "url": "/js/mifi_binding.474008d1.js"
  },
  {
    "revision": "a0dee83b89ccca6d747f",
    "url": "/js/mifi_layout.c6700ed9.js"
  },
  {
    "revision": "f913bdac6771dce6af16",
    "url": "/js/mifi_card_info.29a750c5.js"
  },
  {
    "revision": "f469dc53487cd572b31b",
    "url": "/js/mifi_index.6dd94633.js"
  },
  {
    "revision": "6b650d0917b8d12cc9cc",
    "url": "/js/mifi_card_lookup.1d70f42d.js"
  },
  {
    "revision": "45bb589851d83db76bb9",
    "url": "/js/mifi_coupon_wrapper.ef927f53.js"
  },
  {
    "revision": "41b19c8747c6d0bba161",
    "url": "/js/mifi_card_wrapper.dcdf9dda.js"
  },
  {
    "revision": "75ca3f24f09f895ed62a",
    "url": "/js/mifi_coupon_index.38daa45a.js"
  },
  {
    "revision": "38d8ee1edb157a52d195",
    "url": "/js/mifi_change_network.32f290cf.js"
  },
  {
    "revision": "cfab3305957c9205c7e7",
    "url": "/js/mifi_change_network_explanation.27a8d4b4.js"
  },
  {
    "revision": "f5f322478286641bd9887a155e35f222",
    "url": "/img/btn.f5f32247.png"
  },
  {
    "revision": "cfab3305957c9205c7e7",
    "url": "/css/mifi_change_network_explanation.e965877f.css"
  },
  {
    "revision": "ecd426a99fc943228867be0f320102a6",
    "url": "/index.html"
  },
  {
    "revision": "45bb589851d83db76bb9",
    "url": "/css/mifi_coupon_wrapper.dffc91fe.css"
  },
  {
    "revision": "999589aae784a460b5e7c6ae9bbaa3d8",
    "url": "/img/06.999589aa.png"
  },
  {
    "revision": "f469dc53487cd572b31b",
    "url": "/css/mifi_index.113f5a65.css"
  },
  {
    "revision": "39d9e849fc1c724525f166646932a24d",
    "url": "/img/safari.39d9e849.png"
  },
  {
    "revision": "a0dee83b89ccca6d747f",
    "url": "/css/mifi_layout.c437464c.css"
  },
  {
    "revision": "eacba58f9acf2b87cd801858146b2ba9",
    "url": "/img/02.eacba58f.png"
  },
  {
    "revision": "2019c3190daad325fcb5",
    "url": "/css/mifi_order.44c822d1.css"
  },
  {
    "revision": "a610420eab741be28278e60bc06387aa",
    "url": "/img/box-deco@3x.a610420e.png"
  },
  {
    "revision": "067213dfd29008ce7333",
    "url": "/css/mifi_order_wrapper.0b3e62e0.css"
  },
  {
    "revision": "687b6ce03f134f21173c949d79002960",
    "url": "/img/tip.687b6ce0.png"
  },
  {
    "revision": "607d4b4e68e4c123bab1",
    "url": "/css/mifi_plan_group.e78fad78.css"
  },
  {
    "revision": "daa86b540bb9c2a6453ceac9bed77961",
    "url": "/img/07.daa86b54.png"
  },
  {
    "revision": "f537be35f6e54f13e599",
    "url": "/css/mifi_plan_list.317a1c1e.css"
  },
  {
    "revision": "a8272d2d742d9d50257e23dfac577def",
    "url": "/img/01.a8272d2d.png"
  },
  {
    "revision": "f2acb17dad8f253adf2c",
    "url": "/css/mifi_plan_usage.d830044d.css"
  },
  {
    "revision": "f23d9d1f76147bc89b48902c36818f1e",
    "url": "/img/bg_no_plan.f23d9d1f.svg"
  },
  {
    "revision": "61f0902b4cb913b3891a",
    "url": "/css/mifi_plan_wrapper.d95486e0.css"
  },
  {
    "revision": "9e8ecc7f7b760b55c56bddfab886da10",
    "url": "/img/3.9e8ecc7f.png"
  },
  {
    "revision": "62c6dcaa32d363b1bbc9",
    "url": "/css/new_card_wrapper.7421536f.css"
  },
  {
    "revision": "96fab583abd57f2e7118324858fa3080",
    "url": "/img/05.96fab583.png"
  },
  {
    "revision": "c416916ea74c2ad88431",
    "url": "/css/official_accounts.c224bf43.css"
  },
  {
    "revision": "b0ffa4a0fd195a110ee4d4dabce3bc32",
    "url": "/img/08.b0ffa4a0.png"
  },
  {
    "revision": "8ebea8f0ea0695b23a6d",
    "url": "/css/orderRecord.a0e6c71b.css"
  },
  {
    "revision": "34c67f6dfdb0ecc17c7a221aec74706f",
    "url": "/img/bg_no_recharge.34c67f6d.svg"
  },
  {
    "revision": "4f6de62d24da6ac1c6ba",
    "url": "/css/plan_list.a15bbcc5.css"
  },
  {
    "revision": "3e217df4202e41ad9b030aafc8cfcc24",
    "url": "/img/4.3e217df4.png"
  },
  {
    "revision": "c495cd52a5528e4a2876",
    "url": "/css/question.a1200dc9.css"
  },
  {
    "revision": "0b3c3297decbd1152a314cce115f9632",
    "url": "/img/09.0b3c3297.png"
  },
  {
    "revision": "d6499d6e94c18bd57498",
    "url": "/css/question_wrapper.b777319b.css"
  },
  {
    "revision": "89b99d16dd8a4a56746323a0ffbd754c",
    "url": "/img/migu.89b99d16.png"
  },
  {
    "revision": "28854ae7a5ea58bdc0e1",
    "url": "/css/realNameCourse.6bb28150.css"
  },
  {
    "revision": "f7a51f1c554585b11d61499fd0a7520f",
    "url": "/img/only-box@3x.f7a51f1c.png"
  },
  {
    "revision": "68a8f18743d51ce82cef",
    "url": "/css/real_name.713a55ee.css"
  },
  {
    "revision": "8c605ac88ca50357355da465f322d10a",
    "url": "/img/telecom-logo.8c605ac8.svg"
  },
  {
    "revision": "da8386407f23784edeb9",
    "url": "/css/recharge.2b7d0556.css"
  },
  {
    "revision": "165beb68d8ba0d2b70df0fbb3769787a",
    "url": "/img/03.165beb68.png"
  },
  {
    "revision": "d86c68f20f45bef6b24a",
    "url": "/css/rechargeOrder.1dd1d5aa.css"
  },
  {
    "revision": "55d3f2f09efe17db6485d4c9f8f0c3b1",
    "url": "/img/icon-recharge_20181001.55d3f2f0.svg"
  },
  {
    "revision": "7347720b27e03576c1ec",
    "url": "/css/rechargeOrder~whiteSearch.e8b237a0.css"
  },
  {
    "revision": "27158aa79eb0d4b89f317d076a801ca3",
    "url": "/img/coupon-log.27158aa7.png"
  },
  {
    "revision": "cec85b0d51efb670d572",
    "url": "/css/recharge_balance.4e7d2281.css"
  },
  {
    "revision": "0cba868fa977e09806638b9000636a36",
    "url": "/img/avatar.0cba868f.jpeg"
  },
  {
    "revision": "aa2321c141b976e97a34",
    "url": "/css/recharge_callback.26309190.css"
  },
  {
    "revision": "113f99e2189c2ca49db2168754fc2eb5",
    "url": "/img/mobile-logo.113f99e2.png"
  },
  {
    "revision": "5ac8f52ed7c4e24f2334",
    "url": "/css/recharge_wrapper.5a54ff6c.css"
  },
  {
    "revision": "0b9e0b5f4f28c68416f916ddce3fc7ef",
    "url": "/img/unicom-logo.0b9e0b5f.svg"
  },
  {
    "revision": "96f21a6eb56586c39beb",
    "url": "/css/refundRules.f7ecd5d2.css"
  },
  {
    "revision": "68aa0a83ed0eebb34a5c",
    "url": "/js/Layout.8d7a1797.js"
  },
  {
    "revision": "5a3428653945c17e1c146efeee81c987",
    "url": "/img/scanTop.5a342865.png"
  },
  {
    "revision": "7c28431d304fa4f58f5070c59720683a",
    "url": "/img/2.7c28431d.png"
  },
  {
    "revision": "a760219c584aaadcb3f7",
    "url": "/css/refund_argument.5b219cc1.css"
  },
  {
    "revision": "541375e6bb7db2fba9e415be8045f5fb",
    "url": "/img/1.541375e6.png"
  },
  {
    "revision": "0a8ca48abe36e42bd93e",
    "url": "/css/refund_plan.fad16d65.css"
  },
  {
    "revision": "58a560568b7291ea926c2c7438035308",
    "url": "/img/subscribe@3x.58a56056.png"
  },
  {
    "revision": "2ca34cc16baf7f965b41",
    "url": "/css/refund_wrapper.10042735.css"
  },
  {
    "revision": "05775dd69c53d7273b27aaa7c6c523f7",
    "url": "/img/04.05775dd6.png"
  },
  {
    "revision": "a289ac17887cb0dc8179",
    "url": "/css/repeatRecharge.06f2c158.css"
  },
  {
    "revision": "3603a35a49dbb8ad94ec1e57c4dad229",
    "url": "/img/scanTop2.3603a35a.png"
  },
  {
    "revision": "9c356e5c2ee94da71406",
    "url": "/css/revoke_plan.b541b4bc.css"
  },
  {
    "revision": "be0f1e33b2553e71b117d3d3f838d32f",
    "url": "/img/invaildedOrder@2x.be0f1e33.png"
  },
  {
    "revision": "8aa9b2b230363d6d68af",
    "url": "/css/speedup_500.8f563437.css"
  },
  {
    "revision": "0d5a5158e67bcb7a4604124715ed6fbf",
    "url": "/img/usedOrder@3x.0d5a5158.png"
  },
  {
    "revision": "36efb4cbc1776fcf4eae",
    "url": "/css/speedup_80.c6366a0b.css"
  },
  {
    "revision": "4a5b90f8076955f289b3dcda6a5af6ff",
    "url": "/img/invaildedOrder@3x.4a5b90f8.png"
  },
  {
    "revision": "85f31d5e81f0c13ea443",
    "url": "/css/speedup_wrapper.bdf706e3.css"
  },
  {
    "revision": "d9e14058d30dd312519fcf2de38d742b",
    "url": "/img/unUsedOrder@3x.d9e14058.png"
  },
  {
    "revision": "d6c998af7b7b3e3e5146",
    "url": "/css/to_tb.356f90af.css"
  },
  {
    "revision": "c0170ec299b2418256fd515ee7849055",
    "url": "/img/unUsedOrder@2x.c0170ec2.png"
  },
  {
    "revision": "4f14dd2e3be2947aa2eb",
    "url": "/css/transfer_url.ec530465.css"
  },
  {
    "revision": "6e5cee7393060b0ec3dcd587c2518b94",
    "url": "/img/bg_test@2x.6e5cee73.png"
  },
  {
    "revision": "9bb328a1c4c3f6b462eb",
    "url": "/css/userCenter.57abfbf6.css"
  },
  {
    "revision": "114a6e12b42b9b48586dd341105188fe",
    "url": "/img/usedOrder@2x.114a6e12.png"
  },
  {
    "revision": "94465077f4ab236aaad1",
    "url": "/css/userCenterWrap.45f67839.css"
  },
  {
    "revision": "6e5cee7393060b0ec3dcd587c2518b94",
    "url": "/img/bg_test@3x.6e5cee73.png"
  },
  {
    "revision": "3a089487da1935a1f131",
    "url": "/css/whiteListsWrapper.ec23584e.css"
  },
  {
    "revision": "32d70c8fc305e3647098f3de0c71b618",
    "url": "/img/bg_network@2x.32d70c8f.png"
  },
  {
    "revision": "495de02c76895009f832",
    "url": "/css/whiteNewlist.8777adaa.css"
  },
  {
    "revision": "2c51a1e53c1ea0b35086d8d7261b4933",
    "url": "/img/bg_network@3x.2c51a1e5.png"
  },
  {
    "revision": "3cee3e6bea41316cffb8",
    "url": "/css/whiteSearch.0811c59f.css"
  },
  {
    "revision": "fff5af4325410621aeec4e60b3b92d9b",
    "url": "/img/mifi_binding_bg@2x.fff5af43.png"
  },
  {
    "revision": "e4b411644706c29765eea3ffdd85ae39",
    "url": "/fonts/SourceHanSansCNRegular.e4b41164.woff"
  },
  {
    "revision": "834b022ab9ab0e6063904af32274e777",
    "url": "/fonts/SourceHanSansCNRegular.834b022a.eot"
  },
  {
    "revision": "f9509c5a10be7daaf1fa01922a7c6bc2",
    "url": "/fonts/SourceHanSansCNRegular.f9509c5a.ttf"
  },
  {
    "revision": "da0808e9fe85be160aab69c82dd8de1c",
    "url": "/img/SourceHanSansCNRegular.da0808e9.svg"
  },
  {
    "revision": "732389ded34cb9c52dd88271f1345af9",
    "url": "/fonts/element-icons.732389de.ttf"
  },
  {
    "revision": "535877f50039c0cb49a6196a5b7517cd",
    "url": "/fonts/element-icons.535877f5.woff"
  },
  {
    "revision": "0f16389ec218c90cf8f657e233b745f2",
    "url": "/img/balanceBg1.0f16389e.png"
  },
  {
    "revision": "565459ef2ee8b71db421144ad21c23e3",
    "url": "/img/balanceBg2.565459ef.png"
  },
  {
    "revision": "af3ed0b3236bbfdbc3ad61b8d41c3dec",
    "url": "/img/changeBg.af3ed0b3.png"
  },
  {
    "revision": "8cb139e0169560e725d23c2ab8d8310e",
    "url": "/img/advert.8cb139e0.gif"
  },
  {
    "revision": "75ca3f24f09f895ed62a",
    "url": "/css/mifi_coupon_index.376916f3.css"
  },
  {
    "revision": "d140650fa64e0f1fc771610dba62aed7",
    "url": "/img/bg.d140650f.png"
  },
  {
    "revision": "e625229e32d9deeb5f2909c314d8e609",
    "url": "/img/ios@2x.e625229e.png"
  },
  {
    "revision": "af8bbdfa0a90c4eed4563f8c06ce5ff8",
    "url": "/img/android@2x.af8bbdfa.png"
  },
  {
    "revision": "cc0636ca2944024fd3ebf33a5412ff35",
    "url": "/img/icon-right@3x.cc0636ca.png"
  },
  {
    "revision": "1b983020cfed6b7a8ca5c300c24ca186",
    "url": "/img/icon-left@3x.1b983020.png"
  },
  {
    "revision": "d796d97eb9ebb2e89bb966343e2362e9",
    "url": "/img/icon-left@2x.d796d97e.png"
  },
  {
    "revision": "ccb9865dadbc642b8c4dd0a1abc8e570",
    "url": "/img/recharge-word@2x.ccb9865d.png"
  },
  {
    "revision": "ccb9865dadbc642b8c4dd0a1abc8e570",
    "url": "/img/recharge-word@3x.ccb9865d.png"
  },
  {
    "revision": "41a8c268f703fe646d5d08099eb778ae",
    "url": "/img/icon-right@2x.41a8c268.png"
  },
  {
    "revision": "2d6d06f4da15fc1a748677c49c5f1854",
    "url": "/img/bg.2d6d06f4.png"
  },
  {
    "revision": "3f342771b9b81ab929e0fbcbcd0e6533",
    "url": "/img/bg-check-wrap@3x.3f342771.png"
  },
  {
    "revision": "9713b21819c4019befecd095069977df",
    "url": "/img/bg-check-wrap@2x.9713b218.png"
  },
  {
    "revision": "fa855242805b87da42c65763acd64ac0",
    "url": "/img/bg-plan-type@2x.fa855242.png"
  },
  {
    "revision": "4a9ca192485effa8b8f4b5b2df5b9caf",
    "url": "/img/bg-plan-type@3x.4a9ca192.png"
  },
  {
    "revision": "1d7515ee61c3f659227318b4050955ed",
    "url": "/img/mobile_sim@2x.1d7515ee.png"
  },
  {
    "revision": "0f980b79d9a52702004de9f652a68835",
    "url": "/img/telcom_sim@2x.0f980b79.png"
  },
  {
    "revision": "98141226a7e992e3072a280746a259c4",
    "url": "/img/mobile_sim@3x.98141226.png"
  },
  {
    "revision": "0c88168b284b92c37f3a873f26a97d69",
    "url": "/img/bg.0c88168b.jpg"
  },
  {
    "revision": "9e02095f31a07b972244f1c714c1dfe7",
    "url": "/img/telcom_sim@3x.9e02095f.png"
  },
  {
    "revision": "e93b8c03293c5b6a311da784f9c19c8f",
    "url": "/img/bg.e93b8c03.jpeg"
  },
  {
    "revision": "ffb1612d9660e2ecd9d3872d57a8a2f9",
    "url": "/img/bar.ffb1612d.png"
  },
  {
    "revision": "3d0fc424b703032ca595090e99f8354b",
    "url": "/img/login_bg@2x.3d0fc424.png"
  },
  {
    "revision": "11000d4e510a6df565eb69ba6f2c1dfc",
    "url": "/img/login_bg@3x.11000d4e.png"
  },
  {
    "revision": "014d354b9b25b67ae95857ba17e2f4cc",
    "url": "/img/activityPage.014d354b.png"
  },
  {
    "revision": "f40c7e0b20fe25eb78a7658c3ae56312",
    "url": "/img/noData@3x.f40c7e0b.png"
  },
  {
    "revision": "644e6e3cf5f33943747b116316694e28",
    "url": "/img/noData@2x.644e6e3c.png"
  },
  {
    "revision": "2a67b73145562669220aa4639e1ad58f",
    "url": "/img/icon3.2a67b731.png"
  },
  {
    "revision": "813b5319e378dafdda952c16ad89906b",
    "url": "/img/icon2.813b5319.png"
  },
  {
    "revision": "0078f03c08066d51d64b92a13e194ebb",
    "url": "/img/balanceRefund.0078f03c.png"
  },
  {
    "revision": "91e1d2771efacd45e5e465d9a001f197",
    "url": "/img/liantong.91e1d277.png"
  },
  {
    "revision": "4a0cab0f33beb48ea985714d1b91fef7",
    "url": "/img/dianxin.4a0cab0f.png"
  },
  {
    "revision": "657033323334e91efb0011bbc18f8c04",
    "url": "/img/yidong.65703332.png"
  },
  {
    "revision": "8da3b83b73e44e54d6be4b2522bcb1f2",
    "url": "/img/pkgBg2.8da3b83b.png"
  },
  {
    "revision": "d3b42651f9f5048baeffb50c800913ec",
    "url": "/img/pkgBg1.d3b42651.png"
  },
  {
    "revision": "d461d18e42a310bd709b2ce97d159153",
    "url": "/img/pkgBg3.d461d18e.png"
  },
  {
    "revision": "01355f175bd20423ce45a838c1a998a9",
    "url": "/img/bg.01355f17.png"
  },
  {
    "revision": "6e5cee7393060b0ec3dcd587c2518b94",
    "url": "/img/bg_test.6e5cee73.png"
  },
  {
    "revision": "6dedd4943e4c5848638196fb6f0c4145",
    "url": "/img/bg.6dedd494.png"
  },
  {
    "revision": "42c0fbd4915870e5e60452fd0ef2cbec",
    "url": "/img/orderTopBg@3x.42c0fbd4.png"
  },
  {
    "revision": "42c0fbd4915870e5e60452fd0ef2cbec",
    "url": "/img/orderTopBg@2x.42c0fbd4.png"
  },
  {
    "revision": "d0ccbc8a35180bb40e027b44dd26035a",
    "url": "/img/youku.d0ccbc8a.png"
  },
  {
    "revision": "a859e9ca4606d567c42b9c7bcd4fdce9",
    "url": "/img/iccid_bg@2x.a859e9ca.png"
  },
  {
    "revision": "fa9050c4e9870e8fc0cd184f8515af4a",
    "url": "/img/iccid_bg@3x.fa9050c4.png"
  },
  {
    "revision": "b899232b79ad9962c5ab5572775a0400",
    "url": "/img/card_index_bg@3x.b899232b.png"
  },
  {
    "revision": "b899232b79ad9962c5ab5572775a0400",
    "url": "/img/card_index_bg@2x.b899232b.png"
  },
  {
    "revision": "fff5af4325410621aeec4e60b3b92d9b",
    "url": "/img/mifi_binding_bg@3x.fff5af43.png"
  },
  {
    "revision": "903739a6905e36f4bae2",
    "url": "/css/coupon_telcom.b9ac90b4.css"
  },
  {
    "revision": "4463c825581bd1325459",
    "url": "/css/app.d1d8428f.css"
  },
  {
    "revision": "07765cf97c5ddb301f45",
    "url": "/css/balanceIndex.0e3565ad.css"
  },
  {
    "revision": "f45f89de03a19df78555",
    "url": "/css/balanceRefund.9e63ba8b.css"
  },
  {
    "revision": "2f2509445d157598c83a",
    "url": "/css/cardPackage.372cb85a.css"
  },
  {
    "revision": "bb23e83988f6465c4326",
    "url": "/css/card_check.2e68075e.css"
  },
  {
    "revision": "39457f60bbb16c07fc25",
    "url": "/css/card_connection.b63a6651.css"
  },
  {
    "revision": "e3d6bd1b238ac2b40935",
    "url": "/css/card_lookup.929ff3ea.css"
  },
  {
    "revision": "e6c49bde64e07efd94ab",
    "url": "/css/card_lookup_notice.f7729b35.css"
  },
  {
    "revision": "af09bb346e061cc700ba",
    "url": "/css/card_lookup~card_lookup_notice.1672d43e.css"
  },
  {
    "revision": "ff300cb5bc364cb96201",
    "url": "/css/card_more_flow.bd351fa4.css"
  },
  {
    "revision": "62dfa5f3baebd6fbc478",
    "url": "/css/card_usage.1b597e1d.css"
  },
  {
    "revision": "713a74cc0cbb2726d38d",
    "url": "/css/card_usage~plan_list.5b5b3e22.css"
  },
  {
    "revision": "563ad4b6dd88a2029691",
    "url": "/css/card_wrapper.8c1debb9.css"
  },
  {
    "revision": "93cd71708f01b01501a9",
    "url": "/css/children_card.016ce2dd.css"
  },
  {
    "revision": "214d72f63c0fe099c81d",
    "url": "/css/chunk-7c88e131.6a06df47.css"
  },
  {
    "revision": "38d8ee1edb157a52d195",
    "url": "/css/mifi_change_network.017d44e8.css"
  },
  {
    "revision": "7a9ddc7a29786c257c6a",
    "url": "/css/chunk-9a5f5058.b4fd50be.css"
  },
  {
    "revision": "2fa8d67a06c77fea899d",
    "url": "/css/chunk-vendors.b8da327d.css"
  },
  {
    "revision": "0c5c50b5fd0d4667ec61",
    "url": "/css/commonProblem.88f7be54.css"
  },
  {
    "revision": "11505f790467edbf0aad",
    "url": "/css/commonQuestion.c700e9fc.css"
  },
  {
    "revision": "e5803e14cf29a325637c",
    "url": "/css/consumerRecord.b84cece9.css"
  },
  {
    "revision": "65c7234747beeb08d015",
    "url": "/css/coupon_normal.4910a9a6.css"
  },
  {
    "revision": "829ebf67667ccc9d2371",
    "url": "/css/authority_middle.7a51adcf.css"
  },
  {
    "revision": "ea86c232f987bad0d36a",
    "url": "/css/coupon_wrapper.38318263.css"
  },
  {
    "revision": "7065a66e35d3bb7d69f7",
    "url": "/css/currencyConversion.c011ac24.css"
  },
  {
    "revision": "27a9001c14fbf5e5ac8a",
    "url": "/css/customerFeedback.4f06dafb.css"
  },
  {
    "revision": "4d24a56e4831fd99f6c4",
    "url": "/css/eqReplaceMent.a107f0ce.css"
  },
  {
    "revision": "a2ac358b5ba0d37e1f75",
    "url": "/css/eqReplaceMent~recharge.f6bbdfeb.css"
  },
  {
    "revision": "3273d1a4a09a873c017d",
    "url": "/css/esim_plan_list.cccc7d81.css"
  },
  {
    "revision": "6b339a0eef8e4f46a1e4",
    "url": "/css/esim_usage.54dfaf7f.css"
  },
  {
    "revision": "eca40fff11e5d7220d33",
    "url": "/css/find_plan.37ff9a23.css"
  },
  {
    "revision": "03cf4b8be078209bdcc1",
    "url": "/css/guardian.3c4cca3e.css"
  },
  {
    "revision": "769d653c06e13e8971aa",
    "url": "/css/logical_page.4524faf8.css"
  },
  {
    "revision": "e68f7739b6bcb994d17b",
    "url": "/css/login.d576640e.css"
  },
  {
    "revision": "07a24b97f68bdfa4c7c2",
    "url": "/css/lookup.62cf37f1.css"
  },
  {
    "revision": "993ab5cae036e2c8f7f8",
    "url": "/css/mifi_binding.6aa3be88.css"
  },
  {
    "revision": "f913bdac6771dce6af16",
    "url": "/css/mifi_card_info.d60eff84.css"
  },
  {
    "revision": "6b650d0917b8d12cc9cc",
    "url": "/css/mifi_card_lookup.d75e7541.css"
  },
  {
    "revision": "41b19c8747c6d0bba161",
    "url": "/css/mifi_card_wrapper.e7857e6f.css"
  },
  {
    "revision": "a9d5bc20f555d7939531",
    "url": "/css/Not_fund.825f3ed9.css"
  },
  {
    "revision": "68aa0a83ed0eebb34a5c",
    "url": "/css/Layout.ce14b775.css"
  },
  {
    "revision": "9ce16f441b39b493af8b96d7e97cce22",
    "url": "/MP_verify_dkzAKjxyVyJvsHMS.txt"
  },
  {
    "revision": "86c422d8c98b247235d04b49fb1c4b05",
    "url": "/MP_verify_bKSdn2qZlUSULliu.txt"
  },
  {
    "revision": "652317b098ca24e4511926c7fd57cbbe",
    "url": "/MP_verify_8JoCCldW78DygS5c.txt"
  },
  {
    "revision": "00bbf6b458bf7ea6bd01f443eb3045d9",
    "url": "/MP_verify_4r3DVk3KUjgWsQsG.txt"
  }
];