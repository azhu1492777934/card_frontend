self.__precacheManifest = [
  {
    "revision": "464fa59b932c2bbc75bc",
    "url": "/css/refund_applying.42084dda.css"
  },
  {
    "revision": "b6216d61c03e6ce0c9aea6ca7808f7ca",
    "url": "/robots.txt"
  },
  {
    "revision": "464fa59b932c2bbc75bc",
    "url": "/js/refund_applying.58d4c0b3.js"
  },
  {
    "revision": "a0ad43f8adb57a3fb79f",
    "url": "/css/Layout~card_usage.99e2555d.css"
  },
  {
    "revision": "f6fe50ccd582c459975e",
    "url": "/js/Layout~card_usage~eqReplaceMent~esim_plan_list~esim_usage~mifi_order~mifi_plan_list~mifi_plan_usage~~3166b5eb.91e2eec6.js"
  },
  {
    "revision": "29fa2271cd631de4db88",
    "url": "/css/Not_fund.e2fd00c5.css"
  },
  {
    "revision": "29fa2271cd631de4db88",
    "url": "/js/Not_fund.15ff5217.js"
  },
  {
    "revision": "5714741514c2ee1c1856",
    "url": "/css/app.b8bef460.css"
  },
  {
    "revision": "5714741514c2ee1c1856",
    "url": "/js/app.f8fdf2d5.js"
  },
  {
    "revision": "8602df347e260426f2c2",
    "url": "/css/authority_middle.aaa01b3c.css"
  },
  {
    "revision": "8602df347e260426f2c2",
    "url": "/js/authority_middle.23b0aae4.js"
  },
  {
    "revision": "a63072d90a7bb97d6d53",
    "url": "/css/balanceIndex.8c9e1000.css"
  },
  {
    "revision": "a63072d90a7bb97d6d53",
    "url": "/js/balanceIndex.76884404.js"
  },
  {
    "revision": "1995fb962d749ebf17c9",
    "url": "/css/balanceRefund.ced5af09.css"
  },
  {
    "revision": "1995fb962d749ebf17c9",
    "url": "/js/balanceRefund.c1796cc1.js"
  },
  {
    "revision": "d06bb6b5f6aba88179c1",
    "url": "/css/cardPackage.4f4a7e59.css"
  },
  {
    "revision": "d06bb6b5f6aba88179c1",
    "url": "/js/cardPackage.6a514695.js"
  },
  {
    "revision": "98d52daa70c7b287bf36",
    "url": "/css/card_check.e0383461.css"
  },
  {
    "revision": "98d52daa70c7b287bf36",
    "url": "/js/card_check.90f3943b.js"
  },
  {
    "revision": "73d93829f5fe2e15f2a6",
    "url": "/css/card_connection.b576c6c3.css"
  },
  {
    "revision": "73d93829f5fe2e15f2a6",
    "url": "/js/card_connection.09187d30.js"
  },
  {
    "revision": "39c101ebb0eea1ba4b13",
    "url": "/css/card_lookup.d01f8643.css"
  },
  {
    "revision": "39c101ebb0eea1ba4b13",
    "url": "/js/card_lookup.378c9054.js"
  },
  {
    "revision": "1bc1628a103caab9e4af",
    "url": "/css/card_more_flow.d5d2708c.css"
  },
  {
    "revision": "1bc1628a103caab9e4af",
    "url": "/js/card_more_flow.c8c0cb60.js"
  },
  {
    "revision": "d73d42e1a77212f21c29",
    "url": "/css/card_usage.3139af90.css"
  },
  {
    "revision": "d73d42e1a77212f21c29",
    "url": "/js/card_usage.03780566.js"
  },
  {
    "revision": "57ea04cf4ea9f2d42499",
    "url": "/css/card_wrapper.5a54ff6c.css"
  },
  {
    "revision": "57ea04cf4ea9f2d42499",
    "url": "/js/card_wrapper.6e83ac25.js"
  },
  {
    "revision": "8f904db9b924a5f023fa",
    "url": "/css/children_card.487a8a4c.css"
  },
  {
    "revision": "8f904db9b924a5f023fa",
    "url": "/js/children_card.d65d6ff2.js"
  },
  {
    "revision": "2a29d9d5d8f4bafe1c65",
    "url": "/css/chunk-3ec6cd98.b2facc3b.css"
  },
  {
    "revision": "2a29d9d5d8f4bafe1c65",
    "url": "/js/chunk-3ec6cd98.a172f5c5.js"
  },
  {
    "revision": "ccc7fbe3f4e25ca56b0c",
    "url": "/css/chunk-dc6c1c16.4acfaafb.css"
  },
  {
    "revision": "ccc7fbe3f4e25ca56b0c",
    "url": "/js/chunk-dc6c1c16.417de04b.js"
  },
  {
    "revision": "7e27d8868ece2582b2cf",
    "url": "/css/chunk-vendors.e468316b.css"
  },
  {
    "revision": "7e27d8868ece2582b2cf",
    "url": "/js/chunk-vendors.29fd83a0.js"
  },
  {
    "revision": "2d122bddff2d901e1df6",
    "url": "/css/commonProblem.16934f1e.css"
  },
  {
    "revision": "2d122bddff2d901e1df6",
    "url": "/js/commonProblem.87bd6b07.js"
  },
  {
    "revision": "8a55c84220e497715299",
    "url": "/css/consumerRecord.b028126b.css"
  },
  {
    "revision": "8a55c84220e497715299",
    "url": "/js/consumerRecord.b821daf8.js"
  },
  {
    "revision": "fabe0f273d2dcbc018c0",
    "url": "/css/coupon_normal.1a9a5f5b.css"
  },
  {
    "revision": "fabe0f273d2dcbc018c0",
    "url": "/js/coupon_normal.aecbbd50.js"
  },
  {
    "revision": "ea1606489920e3fe0c5a",
    "url": "/css/coupon_telcom.3e944761.css"
  },
  {
    "revision": "ea1606489920e3fe0c5a",
    "url": "/js/coupon_telcom.285d2189.js"
  },
  {
    "revision": "7038396d09f71fff5727",
    "url": "/css/coupon_wrapper.ab43c2ce.css"
  },
  {
    "revision": "7038396d09f71fff5727",
    "url": "/js/coupon_wrapper.d9947991.js"
  },
  {
    "revision": "8e63e7c7fc3689947e16",
    "url": "/css/currencyConversion.96200d28.css"
  },
  {
    "revision": "8e63e7c7fc3689947e16",
    "url": "/js/currencyConversion.9d4f1e16.js"
  },
  {
    "revision": "64047b359c834a401fd5",
    "url": "/css/eqReplaceMent.58744d9b.css"
  },
  {
    "revision": "64047b359c834a401fd5",
    "url": "/js/eqReplaceMent.7c23b293.js"
  },
  {
    "revision": "cde0f2ed63946085699b",
    "url": "/css/eqReplaceMent~recharge.047f5f22.css"
  },
  {
    "revision": "cde0f2ed63946085699b",
    "url": "/js/eqReplaceMent~recharge.32f854bd.js"
  },
  {
    "revision": "f4e77fda050b3346d6d4",
    "url": "/css/esim_plan_list.45fabc9f.css"
  },
  {
    "revision": "f4e77fda050b3346d6d4",
    "url": "/js/esim_plan_list.6c81a466.js"
  },
  {
    "revision": "8492022041c024306edb",
    "url": "/css/esim_usage.8ce1c437.css"
  },
  {
    "revision": "8492022041c024306edb",
    "url": "/js/esim_usage.794f34d8.js"
  },
  {
    "revision": "48a3e8ef5bee5d7df7a5",
    "url": "/css/find_plan.efdbe4c1.css"
  },
  {
    "revision": "48a3e8ef5bee5d7df7a5",
    "url": "/js/find_plan.96b6088b.js"
  },
  {
    "revision": "63e3062b0000a27e2bdd",
    "url": "/css/logical_page.412cdcf5.css"
  },
  {
    "revision": "63e3062b0000a27e2bdd",
    "url": "/js/logical_page.1f7c33ad.js"
  },
  {
    "revision": "f2b5798ed72481494e57",
    "url": "/css/login.db6eac3f.css"
  },
  {
    "revision": "f2b5798ed72481494e57",
    "url": "/js/login.312fc030.js"
  },
  {
    "revision": "6eb35db5c8070bad4b54",
    "url": "/css/lookup.a84a91e8.css"
  },
  {
    "revision": "6eb35db5c8070bad4b54",
    "url": "/js/lookup.c564a84e.js"
  },
  {
    "revision": "5679f15c45ddd6d9e3b9",
    "url": "/css/mifi_binding.24b68c5f.css"
  },
  {
    "revision": "5679f15c45ddd6d9e3b9",
    "url": "/js/mifi_binding.cfa7c147.js"
  },
  {
    "revision": "339da2361538cfa6d82b",
    "url": "/css/mifi_card_info.1b40b76b.css"
  },
  {
    "revision": "339da2361538cfa6d82b",
    "url": "/js/mifi_card_info.e12a413b.js"
  },
  {
    "revision": "c17f3dd5f2c2c32f8482",
    "url": "/css/mifi_card_lookup.0ae69d55.css"
  },
  {
    "revision": "c17f3dd5f2c2c32f8482",
    "url": "/js/mifi_card_lookup.0620744d.js"
  },
  {
    "revision": "ee876501682c4a2ec35a",
    "url": "/css/mifi_card_wrapper.d572d9dd.css"
  },
  {
    "revision": "ee876501682c4a2ec35a",
    "url": "/js/mifi_card_wrapper.a3e5eb15.js"
  },
  {
    "revision": "6538ba8df538f30fbf55",
    "url": "/css/mifi_change_network.4eca7f49.css"
  },
  {
    "revision": "6538ba8df538f30fbf55",
    "url": "/js/mifi_change_network.0350df7a.js"
  },
  {
    "revision": "d1d05371a44a6a5a75e6",
    "url": "/css/mifi_change_network_explanation.70e4946d.css"
  },
  {
    "revision": "d1d05371a44a6a5a75e6",
    "url": "/js/mifi_change_network_explanation.d9bb3866.js"
  },
  {
    "revision": "06ce7ab2e30f0766af36",
    "url": "/css/mifi_coupon_index.6dcb0715.css"
  },
  {
    "revision": "06ce7ab2e30f0766af36",
    "url": "/js/mifi_coupon_index.36dd9ab2.js"
  },
  {
    "revision": "a815840aacaed64d1b3b",
    "url": "/css/mifi_coupon_wrapper.85e2e6da.css"
  },
  {
    "revision": "a815840aacaed64d1b3b",
    "url": "/js/mifi_coupon_wrapper.1dcde4f8.js"
  },
  {
    "revision": "a769e1f7f99f5598e936",
    "url": "/css/mifi_index.ba5c3ed6.css"
  },
  {
    "revision": "a769e1f7f99f5598e936",
    "url": "/js/mifi_index.18443ecc.js"
  },
  {
    "revision": "b9c099ffea94754f1bde",
    "url": "/css/mifi_layout.c8790a0c.css"
  },
  {
    "revision": "b9c099ffea94754f1bde",
    "url": "/js/mifi_layout.2ae002e1.js"
  },
  {
    "revision": "9b4700b0b51458969016",
    "url": "/css/mifi_order.941fd3b5.css"
  },
  {
    "revision": "9b4700b0b51458969016",
    "url": "/js/mifi_order.5e562481.js"
  },
  {
    "revision": "e96276206e48270d0f1b",
    "url": "/css/mifi_order_wrapper.c537a243.css"
  },
  {
    "revision": "e96276206e48270d0f1b",
    "url": "/js/mifi_order_wrapper.45f1229c.js"
  },
  {
    "revision": "c3589bc58b4f1d64e716",
    "url": "/css/mifi_plan_group.d99d8028.css"
  },
  {
    "revision": "c3589bc58b4f1d64e716",
    "url": "/js/mifi_plan_group.6f3a20e7.js"
  },
  {
    "revision": "ea937943ad1b575f2014",
    "url": "/css/mifi_plan_list.39618581.css"
  },
  {
    "revision": "ea937943ad1b575f2014",
    "url": "/js/mifi_plan_list.f4f6efae.js"
  },
  {
    "revision": "c3353202906329321198",
    "url": "/css/mifi_plan_usage.2780e862.css"
  },
  {
    "revision": "c3353202906329321198",
    "url": "/js/mifi_plan_usage.78f16cef.js"
  },
  {
    "revision": "4611a7071a5347669966",
    "url": "/css/mifi_plan_wrapper.8b393e56.css"
  },
  {
    "revision": "4611a7071a5347669966",
    "url": "/js/mifi_plan_wrapper.1355dd31.js"
  },
  {
    "revision": "2904cc856e9d9c7f0ad0",
    "url": "/css/new_card_wrapper.06a280b2.css"
  },
  {
    "revision": "2904cc856e9d9c7f0ad0",
    "url": "/js/new_card_wrapper.d31483c4.js"
  },
  {
    "revision": "c414c1fe471b4708c54a",
    "url": "/css/orderRecord.668814dc.css"
  },
  {
    "revision": "c414c1fe471b4708c54a",
    "url": "/js/orderRecord.f9ee23aa.js"
  },
  {
    "revision": "937a63b544f14a47fbb1",
    "url": "/css/plan_list.4caf7fb9.css"
  },
  {
    "revision": "937a63b544f14a47fbb1",
    "url": "/js/plan_list.35a77a10.js"
  },
  {
    "revision": "6a0f1cd3ccb351650b77",
    "url": "/css/question.0c207b04.css"
  },
  {
    "revision": "6a0f1cd3ccb351650b77",
    "url": "/js/question.c277a90c.js"
  },
  {
    "revision": "ce60d24fa749a307f15c",
    "url": "/css/question_wrapper.8ab9a0db.css"
  },
  {
    "revision": "ce60d24fa749a307f15c",
    "url": "/js/question_wrapper.133d9ef0.js"
  },
  {
    "revision": "f1b54ea5ce25447fde80",
    "url": "/css/realNameCourse.6bd3a228.css"
  },
  {
    "revision": "f1b54ea5ce25447fde80",
    "url": "/js/realNameCourse.6c4bd1dc.js"
  },
  {
    "revision": "f743f58e786f6d2865c8",
    "url": "/css/real_name.2fd595b9.css"
  },
  {
    "revision": "f743f58e786f6d2865c8",
    "url": "/js/real_name.3a6f8a11.js"
  },
  {
    "revision": "455bfa0872808fb502ae",
    "url": "/css/recharge.32ae6af0.css"
  },
  {
    "revision": "455bfa0872808fb502ae",
    "url": "/js/recharge.120b70bc.js"
  },
  {
    "revision": "ca33a6a9c428d4a86702",
    "url": "/css/rechargeOrder.15c668d7.css"
  },
  {
    "revision": "ca33a6a9c428d4a86702",
    "url": "/js/rechargeOrder.1903ad2a.js"
  },
  {
    "revision": "6673fb994c9136712b45",
    "url": "/css/recharge_balance.e0146f7c.css"
  },
  {
    "revision": "6673fb994c9136712b45",
    "url": "/js/recharge_balance.c1de4b8f.js"
  },
  {
    "revision": "23fbd5de25c56b9bfb19",
    "url": "/css/recharge_callback.c33c36e5.css"
  },
  {
    "revision": "23fbd5de25c56b9bfb19",
    "url": "/js/recharge_callback.df8958f9.js"
  },
  {
    "revision": "90e9338c3deb5fd373b6",
    "url": "/css/recharge_wrapper.e8ef40fd.css"
  },
  {
    "revision": "90e9338c3deb5fd373b6",
    "url": "/js/recharge_wrapper.83f14224.js"
  },
  {
    "revision": "da1be45fd64832fc2913",
    "url": "/css/refundRules.e8f23458.css"
  },
  {
    "revision": "da1be45fd64832fc2913",
    "url": "/js/refundRules.f0f22a4d.js"
  },
  {
    "revision": "76e02788e2d388b2d935",
    "url": "/js/Layout.4810746d.js"
  },
  {
    "revision": "a0ad43f8adb57a3fb79f",
    "url": "/js/Layout~card_usage.ec74f452.js"
  },
  {
    "revision": "365b36d42032e92298c0",
    "url": "/css/refund_argument.134128d7.css"
  },
  {
    "revision": "365b36d42032e92298c0",
    "url": "/js/refund_argument.e3cb2f52.js"
  },
  {
    "revision": "50f8b18abb40e5ba61ea",
    "url": "/css/refund_plan.75360215.css"
  },
  {
    "revision": "50f8b18abb40e5ba61ea",
    "url": "/js/refund_plan.597524a3.js"
  },
  {
    "revision": "19884767f8436f6be3e9",
    "url": "/css/refund_wrapper.f2324655.css"
  },
  {
    "revision": "19884767f8436f6be3e9",
    "url": "/js/refund_wrapper.c1c2bda7.js"
  },
  {
    "revision": "a082577863da2fededd9",
    "url": "/css/repeatRecharge.db951850.css"
  },
  {
    "revision": "a082577863da2fededd9",
    "url": "/js/repeatRecharge.3631643a.js"
  },
  {
    "revision": "810eefa0ef24cb2da4d7",
    "url": "/css/revoke_plan.4e99098d.css"
  },
  {
    "revision": "810eefa0ef24cb2da4d7",
    "url": "/js/revoke_plan.c5f331d2.js"
  },
  {
    "revision": "bcf74f54812c44ceb589",
    "url": "/css/speedup_500.653f81f5.css"
  },
  {
    "revision": "bcf74f54812c44ceb589",
    "url": "/js/speedup_500.4da17a9a.js"
  },
  {
    "revision": "f74127cbced6976197cc",
    "url": "/css/speedup_80.0b0c3ab6.css"
  },
  {
    "revision": "f74127cbced6976197cc",
    "url": "/js/speedup_80.0a8993b6.js"
  },
  {
    "revision": "c4b5be14c484e98e12e1",
    "url": "/css/speedup_wrapper.707898e1.css"
  },
  {
    "revision": "c4b5be14c484e98e12e1",
    "url": "/js/speedup_wrapper.b4674906.js"
  },
  {
    "revision": "6aa956322965b3891f4d",
    "url": "/css/to_tb.03eb33ae.css"
  },
  {
    "revision": "6aa956322965b3891f4d",
    "url": "/js/to_tb.2e36301a.js"
  },
  {
    "revision": "b3f3350ee460727af417",
    "url": "/css/transfer_url.ac5e66a6.css"
  },
  {
    "revision": "b3f3350ee460727af417",
    "url": "/js/transfer_url.f4199e0c.js"
  },
  {
    "revision": "de6bac5edf57046c66c7",
    "url": "/css/userCenter.40a62a6e.css"
  },
  {
    "revision": "de6bac5edf57046c66c7",
    "url": "/js/userCenter.2bf50c02.js"
  },
  {
    "revision": "58e8f76be9099cc3b629",
    "url": "/css/userCenterWrap.38541705.css"
  },
  {
    "revision": "58e8f76be9099cc3b629",
    "url": "/js/userCenterWrap.b1c6e958.js"
  },
  {
    "revision": "e4b411644706c29765eea3ffdd85ae39",
    "url": "/fonts/SourceHanSansCNRegular.e4b41164.woff"
  },
  {
    "revision": "834b022ab9ab0e6063904af32274e777",
    "url": "/fonts/SourceHanSansCNRegular.834b022a.eot"
  },
  {
    "revision": "f9509c5a10be7daaf1fa01922a7c6bc2",
    "url": "/fonts/SourceHanSansCNRegular.f9509c5a.ttf"
  },
  {
    "revision": "da0808e9fe85be160aab69c82dd8de1c",
    "url": "/img/SourceHanSansCNRegular.da0808e9.svg"
  },
  {
    "revision": "732389ded34cb9c52dd88271f1345af9",
    "url": "/fonts/element-icons.732389de.ttf"
  },
  {
    "revision": "535877f50039c0cb49a6196a5b7517cd",
    "url": "/fonts/element-icons.535877f5.woff"
  },
  {
    "revision": "6dedd4943e4c5848638196fb6f0c4145",
    "url": "/img/bg.6dedd494.png"
  },
  {
    "revision": "4ecd943eb3a2c5c0890145b943c1c659",
    "url": "/img/85.4ecd943e.png"
  },
  {
    "revision": "6e5cee7393060b0ec3dcd587c2518b94",
    "url": "/img/bg_test.6e5cee73.png"
  },
  {
    "revision": "d0ccbc8a35180bb40e027b44dd26035a",
    "url": "/img/youku.d0ccbc8a.png"
  },
  {
    "revision": "42c0fbd4915870e5e60452fd0ef2cbec",
    "url": "/img/orderTopBg@3x.42c0fbd4.png"
  },
  {
    "revision": "42c0fbd4915870e5e60452fd0ef2cbec",
    "url": "/img/orderTopBg@2x.42c0fbd4.png"
  },
  {
    "revision": "cc0636ca2944024fd3ebf33a5412ff35",
    "url": "/img/icon-right@3x.cc0636ca.png"
  },
  {
    "revision": "1b983020cfed6b7a8ca5c300c24ca186",
    "url": "/img/icon-left@3x.1b983020.png"
  },
  {
    "revision": "d796d97eb9ebb2e89bb966343e2362e9",
    "url": "/img/icon-left@2x.d796d97e.png"
  },
  {
    "revision": "ccb9865dadbc642b8c4dd0a1abc8e570",
    "url": "/img/recharge-word@2x.ccb9865d.png"
  },
  {
    "revision": "ccb9865dadbc642b8c4dd0a1abc8e570",
    "url": "/img/recharge-word@3x.ccb9865d.png"
  },
  {
    "revision": "41a8c268f703fe646d5d08099eb778ae",
    "url": "/img/icon-right@2x.41a8c268.png"
  },
  {
    "revision": "2d6d06f4da15fc1a748677c49c5f1854",
    "url": "/img/bg.2d6d06f4.png"
  },
  {
    "revision": "b899232b79ad9962c5ab5572775a0400",
    "url": "/img/card_index_bg@3x.b899232b.png"
  },
  {
    "revision": "b899232b79ad9962c5ab5572775a0400",
    "url": "/img/card_index_bg@2x.b899232b.png"
  },
  {
    "revision": "fa855242805b87da42c65763acd64ac0",
    "url": "/img/bg-plan-type@2x.fa855242.png"
  },
  {
    "revision": "4a9ca192485effa8b8f4b5b2df5b9caf",
    "url": "/img/bg-plan-type@3x.4a9ca192.png"
  },
  {
    "revision": "91e1d2771efacd45e5e465d9a001f197",
    "url": "/img/liantong.91e1d277.png"
  },
  {
    "revision": "4a0cab0f33beb48ea985714d1b91fef7",
    "url": "/img/dianxin.4a0cab0f.png"
  },
  {
    "revision": "657033323334e91efb0011bbc18f8c04",
    "url": "/img/yidong.65703332.png"
  },
  {
    "revision": "8da3b83b73e44e54d6be4b2522bcb1f2",
    "url": "/img/pkgBg2.8da3b83b.png"
  },
  {
    "revision": "d3b42651f9f5048baeffb50c800913ec",
    "url": "/img/pkgBg1.d3b42651.png"
  },
  {
    "revision": "d461d18e42a310bd709b2ce97d159153",
    "url": "/img/pkgBg3.d461d18e.png"
  },
  {
    "revision": "0f16389ec218c90cf8f657e233b745f2",
    "url": "/img/balanceBg1.0f16389e.png"
  },
  {
    "revision": "565459ef2ee8b71db421144ad21c23e3",
    "url": "/img/balanceBg2.565459ef.png"
  },
  {
    "revision": "2c51a1e53c1ea0b35086d8d7261b4933",
    "url": "/img/bg_network@3x.2c51a1e5.png"
  },
  {
    "revision": "32d70c8fc305e3647098f3de0c71b618",
    "url": "/img/bg_network@2x.32d70c8f.png"
  },
  {
    "revision": "0078f03c08066d51d64b92a13e194ebb",
    "url": "/img/balanceRefund.0078f03c.png"
  },
  {
    "revision": "a859e9ca4606d567c42b9c7bcd4fdce9",
    "url": "/img/iccid_bg@2x.a859e9ca.png"
  },
  {
    "revision": "fa9050c4e9870e8fc0cd184f8515af4a",
    "url": "/img/iccid_bg@3x.fa9050c4.png"
  },
  {
    "revision": "af3ed0b3236bbfdbc3ad61b8d41c3dec",
    "url": "/img/changeBg.af3ed0b3.png"
  },
  {
    "revision": "f5f322478286641bd9887a155e35f222",
    "url": "/img/btn.f5f32247.png"
  },
  {
    "revision": "d140650fa64e0f1fc771610dba62aed7",
    "url": "/img/bg.d140650f.png"
  },
  {
    "revision": "2a67b73145562669220aa4639e1ad58f",
    "url": "/img/icon3.2a67b731.png"
  },
  {
    "revision": "813b5319e378dafdda952c16ad89906b",
    "url": "/img/icon2.813b5319.png"
  },
  {
    "revision": "e625229e32d9deeb5f2909c314d8e609",
    "url": "/img/ios@2x.e625229e.png"
  },
  {
    "revision": "af8bbdfa0a90c4eed4563f8c06ce5ff8",
    "url": "/img/android@2x.af8bbdfa.png"
  },
  {
    "revision": "014d354b9b25b67ae95857ba17e2f4cc",
    "url": "/img/activityPage.014d354b.png"
  },
  {
    "revision": "3f342771b9b81ab929e0fbcbcd0e6533",
    "url": "/img/bg-check-wrap@3x.3f342771.png"
  },
  {
    "revision": "9713b21819c4019befecd095069977df",
    "url": "/img/bg-check-wrap@2x.9713b218.png"
  },
  {
    "revision": "114a6e12b42b9b48586dd341105188fe",
    "url": "/img/usedOrder@2x.114a6e12.png"
  },
  {
    "revision": "c0170ec299b2418256fd515ee7849055",
    "url": "/img/unUsedOrder@2x.c0170ec2.png"
  },
  {
    "revision": "d9e14058d30dd312519fcf2de38d742b",
    "url": "/img/unUsedOrder@3x.d9e14058.png"
  },
  {
    "revision": "4a5b90f8076955f289b3dcda6a5af6ff",
    "url": "/img/invaildedOrder@3x.4a5b90f8.png"
  },
  {
    "revision": "0d5a5158e67bcb7a4604124715ed6fbf",
    "url": "/img/usedOrder@3x.0d5a5158.png"
  },
  {
    "revision": "be0f1e33b2553e71b117d3d3f838d32f",
    "url": "/img/invaildedOrder@2x.be0f1e33.png"
  },
  {
    "revision": "1d7515ee61c3f659227318b4050955ed",
    "url": "/img/mobile_sim@2x.1d7515ee.png"
  },
  {
    "revision": "0f980b79d9a52702004de9f652a68835",
    "url": "/img/telcom_sim@2x.0f980b79.png"
  },
  {
    "revision": "98141226a7e992e3072a280746a259c4",
    "url": "/img/mobile_sim@3x.98141226.png"
  },
  {
    "revision": "0c88168b284b92c37f3a873f26a97d69",
    "url": "/img/bg.0c88168b.jpg"
  },
  {
    "revision": "9e02095f31a07b972244f1c714c1dfe7",
    "url": "/img/telcom_sim@3x.9e02095f.png"
  },
  {
    "revision": "3d0fc424b703032ca595090e99f8354b",
    "url": "/img/login_bg@2x.3d0fc424.png"
  },
  {
    "revision": "11000d4e510a6df565eb69ba6f2c1dfc",
    "url": "/img/login_bg@3x.11000d4e.png"
  },
  {
    "revision": "f40c7e0b20fe25eb78a7658c3ae56312",
    "url": "/img/noData@3x.f40c7e0b.png"
  },
  {
    "revision": "644e6e3cf5f33943747b116316694e28",
    "url": "/img/noData@2x.644e6e3c.png"
  },
  {
    "revision": "01355f175bd20423ce45a838c1a998a9",
    "url": "/img/bg.01355f17.png"
  },
  {
    "revision": "fff5af4325410621aeec4e60b3b92d9b",
    "url": "/img/mifi_binding_bg@3x.fff5af43.png"
  },
  {
    "revision": "fff5af4325410621aeec4e60b3b92d9b",
    "url": "/img/mifi_binding_bg@2x.fff5af43.png"
  },
  {
    "revision": "3603a35a49dbb8ad94ec1e57c4dad229",
    "url": "/img/scanTop2.3603a35a.png"
  },
  {
    "revision": "05775dd69c53d7273b27aaa7c6c523f7",
    "url": "/img/04.05775dd6.png"
  },
  {
    "revision": "58a560568b7291ea926c2c7438035308",
    "url": "/img/subscribe@3x.58a56056.png"
  },
  {
    "revision": "541375e6bb7db2fba9e415be8045f5fb",
    "url": "/img/1.541375e6.png"
  },
  {
    "revision": "7c28431d304fa4f58f5070c59720683a",
    "url": "/img/2.7c28431d.png"
  },
  {
    "revision": "5a3428653945c17e1c146efeee81c987",
    "url": "/img/scanTop.5a342865.png"
  },
  {
    "revision": "824594523c01e48028f2b7eb4261134d",
    "url": "/img/unicom-logo.82459452.svg"
  },
  {
    "revision": "113f99e2189c2ca49db2168754fc2eb5",
    "url": "/img/mobile-logo.113f99e2.png"
  },
  {
    "revision": "0cba868fa977e09806638b9000636a36",
    "url": "/img/avatar.0cba868f.jpeg"
  },
  {
    "revision": "27158aa79eb0d4b89f317d076a801ca3",
    "url": "/img/coupon-log.27158aa7.png"
  },
  {
    "revision": "55d3f2f09efe17db6485d4c9f8f0c3b1",
    "url": "/img/icon-recharge_20181001.55d3f2f0.svg"
  },
  {
    "revision": "165beb68d8ba0d2b70df0fbb3769787a",
    "url": "/img/03.165beb68.png"
  },
  {
    "revision": "5f1f34037094c0613bccafa2ddd8cb3b",
    "url": "/img/telecom-logo.5f1f3403.svg"
  },
  {
    "revision": "0b3c3297decbd1152a314cce115f9632",
    "url": "/img/09.0b3c3297.png"
  },
  {
    "revision": "3e217df4202e41ad9b030aafc8cfcc24",
    "url": "/img/4.3e217df4.png"
  },
  {
    "revision": "aecc9531f2c3b1fd45338e7bf5084384",
    "url": "/img/bg_no_recharge.aecc9531.svg"
  },
  {
    "revision": "b0ffa4a0fd195a110ee4d4dabce3bc32",
    "url": "/img/08.b0ffa4a0.png"
  },
  {
    "revision": "96fab583abd57f2e7118324858fa3080",
    "url": "/img/05.96fab583.png"
  },
  {
    "revision": "9e8ecc7f7b760b55c56bddfab886da10",
    "url": "/img/3.9e8ecc7f.png"
  },
  {
    "revision": "275be51ae57c486bce58257febd6589f",
    "url": "/img/bg_no_plan.275be51a.svg"
  },
  {
    "revision": "b8c0c616a6394cecc1e8b001bd77d99a",
    "url": "/img/box@3x.b8c0c616.png"
  },
  {
    "revision": "a8272d2d742d9d50257e23dfac577def",
    "url": "/img/01.a8272d2d.png"
  },
  {
    "revision": "daa86b540bb9c2a6453ceac9bed77961",
    "url": "/img/07.daa86b54.png"
  },
  {
    "revision": "06385746a7cedb492d5539907631561c",
    "url": "/img/tip.06385746.png"
  },
  {
    "revision": "eacba58f9acf2b87cd801858146b2ba9",
    "url": "/img/02.eacba58f.png"
  },
  {
    "revision": "39d9e849fc1c724525f166646932a24d",
    "url": "/img/safari.39d9e849.png"
  },
  {
    "revision": "999589aae784a460b5e7c6ae9bbaa3d8",
    "url": "/img/06.999589aa.png"
  },
  {
    "revision": "aaed0405e559e607907169841ac63d79",
    "url": "/index.html"
  },
  {
    "revision": "76e02788e2d388b2d935",
    "url": "/css/Layout.2edb96b2.css"
  },
  {
    "revision": "9ce16f441b39b493af8b96d7e97cce22",
    "url": "/MP_verify_dkzAKjxyVyJvsHMS.txt"
  },
  {
    "revision": "86c422d8c98b247235d04b49fb1c4b05",
    "url": "/MP_verify_bKSdn2qZlUSULliu.txt"
  },
  {
    "revision": "652317b098ca24e4511926c7fd57cbbe",
    "url": "/MP_verify_8JoCCldW78DygS5c.txt"
  },
  {
    "revision": "00bbf6b458bf7ea6bd01f443eb3045d9",
    "url": "/MP_verify_4r3DVk3KUjgWsQsG.txt"
  }
];