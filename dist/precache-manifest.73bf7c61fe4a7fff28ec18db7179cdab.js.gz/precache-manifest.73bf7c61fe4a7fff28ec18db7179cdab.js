self.__precacheManifest = [
  {
    "revision": "fd9cf4615e1ee2818ae2",
    "url": "/css/refundRules.e033034d.css"
  },
  {
    "revision": "735ab4f94fbcd57074377afca324c813",
    "url": "/robots.txt"
  },
  {
    "revision": "fd9cf4615e1ee2818ae2",
    "url": "/js/refundRules.c56e067d.js"
  },
  {
    "revision": "78214ba34c5f1df936aa",
    "url": "/js/Layout~card_usage~eqReplaceMent~esim_plan_list~esim_usage~mifi_order~mifi_plan_list~mifi_plan_usage~~c6f87c36.6241bd21.js"
  },
  {
    "revision": "94d7cc9826a7aff7eaf5",
    "url": "/js/Not_fund.0696a0b9.js"
  },
  {
    "revision": "8c07452345639aa69f6b",
    "url": "/js/userCenterWrap.140f6840.js"
  },
  {
    "revision": "ea33d8408addf676eae7",
    "url": "/js/app.9501ba9a.js"
  },
  {
    "revision": "e8d6824e06a4bc16d461",
    "url": "/js/userCenter.61a269c6.js"
  },
  {
    "revision": "692056f2361c89b41472",
    "url": "/js/authority_middle.13f1d1b1.js"
  },
  {
    "revision": "e006895af3af88f9da5e",
    "url": "/js/transfer_url.8f8182e0.js"
  },
  {
    "revision": "56d177fdfb1e98837136",
    "url": "/js/balanceIndex.2e555ccb.js"
  },
  {
    "revision": "8c9495e19ffe9f27e805",
    "url": "/js/to_tb.daafbdcd.js"
  },
  {
    "revision": "6b6725d6bf3b8732da81",
    "url": "/js/balanceRefund.138b15e1.js"
  },
  {
    "revision": "9aecd45e2dbe1fc1c467",
    "url": "/js/speedup_wrapper.b2187980.js"
  },
  {
    "revision": "f70d4db296a515aa41e1",
    "url": "/js/cardPackage.310dcc34.js"
  },
  {
    "revision": "2f46a73fdf82dc05d2fa",
    "url": "/js/speedup_80.969a33e3.js"
  },
  {
    "revision": "52d9556d637a6960ff59",
    "url": "/js/card_check.d3980c69.js"
  },
  {
    "revision": "14ff711155c3e76cc267",
    "url": "/js/speedup_500.a530f324.js"
  },
  {
    "revision": "a43e4557c4eddaf6086f",
    "url": "/js/card_connection.772af5ff.js"
  },
  {
    "revision": "425d01de29f4759bf04f",
    "url": "/js/revoke_plan.83db99ae.js"
  },
  {
    "revision": "34a8ce926c4fd33a8b9a",
    "url": "/js/card_lookup.279e7dcd.js"
  },
  {
    "revision": "2ae60124150e71678350",
    "url": "/js/repeatRecharge.ea5b4cb6.js"
  },
  {
    "revision": "3e4adf8c7295f39acf0d",
    "url": "/js/card_more_flow.11810be0.js"
  },
  {
    "revision": "5b7d3881e77be3b32e2c",
    "url": "/js/refund_wrapper.1956a715.js"
  },
  {
    "revision": "bcedec3026eb60c99d7a",
    "url": "/js/card_usage.2e36f463.js"
  },
  {
    "revision": "92c15745bed99f3c28fa",
    "url": "/js/refund_plan.0d527800.js"
  },
  {
    "revision": "4c94b3d1cac77f9724a3",
    "url": "/js/card_usage~plan_list.8a5cfbeb.js"
  },
  {
    "revision": "846c550e9aa3f95effe8",
    "url": "/js/refund_argument.987e8197.js"
  },
  {
    "revision": "35fc4bb4981ba93fc75f",
    "url": "/js/card_wrapper.c4722014.js"
  },
  {
    "revision": "286e1e4044d019af20d7",
    "url": "/js/refund_applying.544c4174.js"
  },
  {
    "revision": "1524492b415d7ed68e25",
    "url": "/js/children_card.1fd06159.js"
  },
  {
    "revision": "f90b38eb237146125733",
    "url": "/js/recharge_wrapper.f0719096.js"
  },
  {
    "revision": "ff67e270e5771893b826",
    "url": "/js/chunk-4a4d2551.ca00c238.js"
  },
  {
    "revision": "43e99993ba300aeba308",
    "url": "/js/recharge_callback.00df4fc4.js"
  },
  {
    "revision": "b7a5465d66b621ee0914",
    "url": "/js/chunk-7c3543f4.d9512da1.js"
  },
  {
    "revision": "6d6618d81d86acee9c8c",
    "url": "/js/recharge_balance.a4d6e712.js"
  },
  {
    "revision": "7a37f1d32dcf31fafb6d",
    "url": "/js/chunk-vendors.6a1799b5.js"
  },
  {
    "revision": "04f8466b9b026db76a0a",
    "url": "/js/rechargeOrder.6459c087.js"
  },
  {
    "revision": "ecae8e24008591a64fe8",
    "url": "/js/commonProblem.061f6270.js"
  },
  {
    "revision": "8fd2f56685744623f15b",
    "url": "/js/recharge.f10c8d43.js"
  },
  {
    "revision": "d37d7b70e74302c1c36d",
    "url": "/js/commonQuestion.7452ca55.js"
  },
  {
    "revision": "4ee368b6fc04e6e84686",
    "url": "/js/real_name.4f12f8bd.js"
  },
  {
    "revision": "b21a748e92ec2a667d57",
    "url": "/js/consumerRecord.b7980b8b.js"
  },
  {
    "revision": "3ee81bbab16cf8e81b75",
    "url": "/js/realNameCourse.55a5fb89.js"
  },
  {
    "revision": "c3a364d2b4c50a9b7f87",
    "url": "/js/coupon_normal.a8df4ddf.js"
  },
  {
    "revision": "9d665f8bc559a47b23e4",
    "url": "/js/question_wrapper.6c869f53.js"
  },
  {
    "revision": "e2233f860809839047ba",
    "url": "/js/coupon_telcom.771a8a10.js"
  },
  {
    "revision": "1842c8f7aca0d41c8d4a",
    "url": "/js/question.e26e7810.js"
  },
  {
    "revision": "edf4d4b3ec379c8f2bcc",
    "url": "/js/coupon_wrapper.9ce5324a.js"
  },
  {
    "revision": "46e78d49990e3fa277f7",
    "url": "/js/plan_list.88c6d6b9.js"
  },
  {
    "revision": "c82a4b218b3dc175452b",
    "url": "/js/currencyConversion.1f3c12a4.js"
  },
  {
    "revision": "3a5b36f639640871cb7c",
    "url": "/js/orderRecord.1b2465f8.js"
  },
  {
    "revision": "ab59337f9e37a01e6ab6",
    "url": "/js/customerFeedback.9f8b52c2.js"
  },
  {
    "revision": "055b7c4182fba1d67ddc",
    "url": "/js/new_card_wrapper.ad57fb91.js"
  },
  {
    "revision": "1a27b7b8126bae522b89",
    "url": "/js/eqReplaceMent.32879846.js"
  },
  {
    "revision": "605ee770177ff6d189f1",
    "url": "/js/mifi_plan_wrapper.999361e8.js"
  },
  {
    "revision": "b1124b16093a74dc5550",
    "url": "/js/eqReplaceMent~recharge.3e20714b.js"
  },
  {
    "revision": "21cd38c87422e6ba6275",
    "url": "/js/mifi_plan_usage.d74d91dd.js"
  },
  {
    "revision": "30123fbae9214f8c7e3d",
    "url": "/js/esim_plan_list.ec29ece3.js"
  },
  {
    "revision": "5d8618c34253e9981d6f",
    "url": "/js/mifi_plan_list.fa07d2a5.js"
  },
  {
    "revision": "4c87e9571f89b1ffa3b7",
    "url": "/js/esim_usage.5e73c325.js"
  },
  {
    "revision": "bd85ab69b141d93a369e",
    "url": "/js/mifi_plan_group.b57a8bed.js"
  },
  {
    "revision": "3c9a0778963046c5e673",
    "url": "/js/find_plan.555222f5.js"
  },
  {
    "revision": "67a45ce3cad58d52d976",
    "url": "/js/mifi_order_wrapper.b8adcae4.js"
  },
  {
    "revision": "456d24dc095708ee7545",
    "url": "/js/logical_page.1138e607.js"
  },
  {
    "revision": "083a42c3d98933bf41e4",
    "url": "/js/mifi_order.73a37269.js"
  },
  {
    "revision": "416565ccee7060779b96",
    "url": "/js/login.6f047e27.js"
  },
  {
    "revision": "90a3d7d86be6fa3df548",
    "url": "/js/mifi_layout.7b8a871f.js"
  },
  {
    "revision": "6a07967fc244f64e5596",
    "url": "/js/lookup.a6aa9537.js"
  },
  {
    "revision": "df450486ae9c75a355cd",
    "url": "/js/mifi_index.93d6f129.js"
  },
  {
    "revision": "6d129e88a4561b060cfd",
    "url": "/js/mifi_binding.790e6d0c.js"
  },
  {
    "revision": "6439e4e7c4e4998e18da",
    "url": "/js/mifi_coupon_wrapper.0af95bdb.js"
  },
  {
    "revision": "39b4f93768cc6fdf6205",
    "url": "/js/mifi_card_info.07a864b9.js"
  },
  {
    "revision": "e5d379e4dd20e310f5c1",
    "url": "/js/mifi_coupon_index.c1a7b1f1.js"
  },
  {
    "revision": "a08d4f598ab34aae347f",
    "url": "/js/mifi_card_lookup.e5cce17e.js"
  },
  {
    "revision": "4019fa5ae3b19d9d2872",
    "url": "/js/mifi_change_network_explanation.08e07e2a.js"
  },
  {
    "revision": "dd0c13b253b862702252",
    "url": "/js/mifi_card_wrapper.4b911f1e.js"
  },
  {
    "revision": "1e0a31af09c579860a78",
    "url": "/js/mifi_change_network.bff679dd.js"
  },
  {
    "revision": "42c0fbd4915870e5e60452fd0ef2cbec",
    "url": "/img/orderTopBg@2x.42c0fbd4.png"
  },
  {
    "revision": "1e0a31af09c579860a78",
    "url": "/css/mifi_change_network.3299a9ba.css"
  },
  {
    "revision": "1bbd6214efe5db8417a802efa4623026",
    "url": "/index.html"
  },
  {
    "revision": "e5d379e4dd20e310f5c1",
    "url": "/css/mifi_coupon_index.12917432.css"
  },
  {
    "revision": "999589aae784a460b5e7c6ae9bbaa3d8",
    "url": "/img/06.999589aa.png"
  },
  {
    "revision": "6439e4e7c4e4998e18da",
    "url": "/css/mifi_coupon_wrapper.034f9976.css"
  },
  {
    "revision": "39d9e849fc1c724525f166646932a24d",
    "url": "/img/safari.39d9e849.png"
  },
  {
    "revision": "df450486ae9c75a355cd",
    "url": "/css/mifi_index.8a8969f9.css"
  },
  {
    "revision": "eacba58f9acf2b87cd801858146b2ba9",
    "url": "/img/02.eacba58f.png"
  },
  {
    "revision": "90a3d7d86be6fa3df548",
    "url": "/css/mifi_layout.4d5939c7.css"
  },
  {
    "revision": "a610420eab741be28278e60bc06387aa",
    "url": "/img/box-deco@3x.a610420e.png"
  },
  {
    "revision": "083a42c3d98933bf41e4",
    "url": "/css/mifi_order.e477f019.css"
  },
  {
    "revision": "687b6ce03f134f21173c949d79002960",
    "url": "/img/tip.687b6ce0.png"
  },
  {
    "revision": "67a45ce3cad58d52d976",
    "url": "/css/mifi_order_wrapper.9e98768f.css"
  },
  {
    "revision": "daa86b540bb9c2a6453ceac9bed77961",
    "url": "/img/07.daa86b54.png"
  },
  {
    "revision": "bd85ab69b141d93a369e",
    "url": "/css/mifi_plan_group.20a3cdec.css"
  },
  {
    "revision": "a8272d2d742d9d50257e23dfac577def",
    "url": "/img/01.a8272d2d.png"
  },
  {
    "revision": "5d8618c34253e9981d6f",
    "url": "/css/mifi_plan_list.79575d4e.css"
  },
  {
    "revision": "f23d9d1f76147bc89b48902c36818f1e",
    "url": "/img/bg_no_plan.f23d9d1f.svg"
  },
  {
    "revision": "21cd38c87422e6ba6275",
    "url": "/css/mifi_plan_usage.38a645b2.css"
  },
  {
    "revision": "9e8ecc7f7b760b55c56bddfab886da10",
    "url": "/img/3.9e8ecc7f.png"
  },
  {
    "revision": "605ee770177ff6d189f1",
    "url": "/css/mifi_plan_wrapper.bb17a37b.css"
  },
  {
    "revision": "96fab583abd57f2e7118324858fa3080",
    "url": "/img/05.96fab583.png"
  },
  {
    "revision": "055b7c4182fba1d67ddc",
    "url": "/css/new_card_wrapper.31258838.css"
  },
  {
    "revision": "b0ffa4a0fd195a110ee4d4dabce3bc32",
    "url": "/img/08.b0ffa4a0.png"
  },
  {
    "revision": "3a5b36f639640871cb7c",
    "url": "/css/orderRecord.e3815bdc.css"
  },
  {
    "revision": "34c67f6dfdb0ecc17c7a221aec74706f",
    "url": "/img/bg_no_recharge.34c67f6d.svg"
  },
  {
    "revision": "46e78d49990e3fa277f7",
    "url": "/css/plan_list.c8f445bb.css"
  },
  {
    "revision": "3e217df4202e41ad9b030aafc8cfcc24",
    "url": "/img/4.3e217df4.png"
  },
  {
    "revision": "1842c8f7aca0d41c8d4a",
    "url": "/css/question.f381841c.css"
  },
  {
    "revision": "0b3c3297decbd1152a314cce115f9632",
    "url": "/img/09.0b3c3297.png"
  },
  {
    "revision": "9d665f8bc559a47b23e4",
    "url": "/css/question_wrapper.f7ae0bf9.css"
  },
  {
    "revision": "89b99d16dd8a4a56746323a0ffbd754c",
    "url": "/img/migu.89b99d16.png"
  },
  {
    "revision": "3ee81bbab16cf8e81b75",
    "url": "/css/realNameCourse.45285408.css"
  },
  {
    "revision": "f7a51f1c554585b11d61499fd0a7520f",
    "url": "/img/only-box@3x.f7a51f1c.png"
  },
  {
    "revision": "4ee368b6fc04e6e84686",
    "url": "/css/real_name.77c7a19d.css"
  },
  {
    "revision": "8c605ac88ca50357355da465f322d10a",
    "url": "/img/telecom-logo.8c605ac8.svg"
  },
  {
    "revision": "8fd2f56685744623f15b",
    "url": "/css/recharge.d20b97b9.css"
  },
  {
    "revision": "165beb68d8ba0d2b70df0fbb3769787a",
    "url": "/img/03.165beb68.png"
  },
  {
    "revision": "04f8466b9b026db76a0a",
    "url": "/css/rechargeOrder.69857186.css"
  },
  {
    "revision": "55d3f2f09efe17db6485d4c9f8f0c3b1",
    "url": "/img/icon-recharge_20181001.55d3f2f0.svg"
  },
  {
    "revision": "6d6618d81d86acee9c8c",
    "url": "/css/recharge_balance.5ea8dd99.css"
  },
  {
    "revision": "27158aa79eb0d4b89f317d076a801ca3",
    "url": "/img/coupon-log.27158aa7.png"
  },
  {
    "revision": "43e99993ba300aeba308",
    "url": "/css/recharge_callback.83d9f3b7.css"
  },
  {
    "revision": "0cba868fa977e09806638b9000636a36",
    "url": "/img/avatar.0cba868f.jpeg"
  },
  {
    "revision": "f90b38eb237146125733",
    "url": "/css/recharge_wrapper.770742b7.css"
  },
  {
    "revision": "113f99e2189c2ca49db2168754fc2eb5",
    "url": "/img/mobile-logo.113f99e2.png"
  },
  {
    "revision": "c7acfdd102d29b9a6b80",
    "url": "/js/Layout.6a1df0ea.js"
  },
  {
    "revision": "0b9e0b5f4f28c68416f916ddce3fc7ef",
    "url": "/img/unicom-logo.0b9e0b5f.svg"
  },
  {
    "revision": "286e1e4044d019af20d7",
    "url": "/css/refund_applying.72abc82b.css"
  },
  {
    "revision": "5a3428653945c17e1c146efeee81c987",
    "url": "/img/scanTop.5a342865.png"
  },
  {
    "revision": "846c550e9aa3f95effe8",
    "url": "/css/refund_argument.92048c54.css"
  },
  {
    "revision": "7c28431d304fa4f58f5070c59720683a",
    "url": "/img/2.7c28431d.png"
  },
  {
    "revision": "92c15745bed99f3c28fa",
    "url": "/css/refund_plan.04b37d38.css"
  },
  {
    "revision": "541375e6bb7db2fba9e415be8045f5fb",
    "url": "/img/1.541375e6.png"
  },
  {
    "revision": "5b7d3881e77be3b32e2c",
    "url": "/css/refund_wrapper.80fa7896.css"
  },
  {
    "revision": "58a560568b7291ea926c2c7438035308",
    "url": "/img/subscribe@3x.58a56056.png"
  },
  {
    "revision": "2ae60124150e71678350",
    "url": "/css/repeatRecharge.d600ced8.css"
  },
  {
    "revision": "05775dd69c53d7273b27aaa7c6c523f7",
    "url": "/img/04.05775dd6.png"
  },
  {
    "revision": "425d01de29f4759bf04f",
    "url": "/css/revoke_plan.e130cf54.css"
  },
  {
    "revision": "3603a35a49dbb8ad94ec1e57c4dad229",
    "url": "/img/scanTop2.3603a35a.png"
  },
  {
    "revision": "14ff711155c3e76cc267",
    "url": "/css/speedup_500.76da9141.css"
  },
  {
    "revision": "be0f1e33b2553e71b117d3d3f838d32f",
    "url": "/img/invaildedOrder@2x.be0f1e33.png"
  },
  {
    "revision": "2f46a73fdf82dc05d2fa",
    "url": "/css/speedup_80.51fe9728.css"
  },
  {
    "revision": "0d5a5158e67bcb7a4604124715ed6fbf",
    "url": "/img/usedOrder@3x.0d5a5158.png"
  },
  {
    "revision": "9aecd45e2dbe1fc1c467",
    "url": "/css/speedup_wrapper.60be0825.css"
  },
  {
    "revision": "4a5b90f8076955f289b3dcda6a5af6ff",
    "url": "/img/invaildedOrder@3x.4a5b90f8.png"
  },
  {
    "revision": "8c9495e19ffe9f27e805",
    "url": "/css/to_tb.630d4cca.css"
  },
  {
    "revision": "d9e14058d30dd312519fcf2de38d742b",
    "url": "/img/unUsedOrder@3x.d9e14058.png"
  },
  {
    "revision": "e006895af3af88f9da5e",
    "url": "/css/transfer_url.4be7520f.css"
  },
  {
    "revision": "c0170ec299b2418256fd515ee7849055",
    "url": "/img/unUsedOrder@2x.c0170ec2.png"
  },
  {
    "revision": "e8d6824e06a4bc16d461",
    "url": "/css/userCenter.7c6534b4.css"
  },
  {
    "revision": "114a6e12b42b9b48586dd341105188fe",
    "url": "/img/usedOrder@2x.114a6e12.png"
  },
  {
    "revision": "8c07452345639aa69f6b",
    "url": "/css/userCenterWrap.87e05186.css"
  },
  {
    "revision": "fa9050c4e9870e8fc0cd184f8515af4a",
    "url": "/img/iccid_bg@3x.fa9050c4.png"
  },
  {
    "revision": "e4b411644706c29765eea3ffdd85ae39",
    "url": "/fonts/SourceHanSansCNRegular.e4b41164.woff"
  },
  {
    "revision": "834b022ab9ab0e6063904af32274e777",
    "url": "/fonts/SourceHanSansCNRegular.834b022a.eot"
  },
  {
    "revision": "f9509c5a10be7daaf1fa01922a7c6bc2",
    "url": "/fonts/SourceHanSansCNRegular.f9509c5a.ttf"
  },
  {
    "revision": "da0808e9fe85be160aab69c82dd8de1c",
    "url": "/img/SourceHanSansCNRegular.da0808e9.svg"
  },
  {
    "revision": "732389ded34cb9c52dd88271f1345af9",
    "url": "/fonts/element-icons.732389de.ttf"
  },
  {
    "revision": "535877f50039c0cb49a6196a5b7517cd",
    "url": "/fonts/element-icons.535877f5.woff"
  },
  {
    "revision": "0f16389ec218c90cf8f657e233b745f2",
    "url": "/img/balanceBg1.0f16389e.png"
  },
  {
    "revision": "565459ef2ee8b71db421144ad21c23e3",
    "url": "/img/balanceBg2.565459ef.png"
  },
  {
    "revision": "fff5af4325410621aeec4e60b3b92d9b",
    "url": "/img/mifi_binding_bg@3x.fff5af43.png"
  },
  {
    "revision": "fff5af4325410621aeec4e60b3b92d9b",
    "url": "/img/mifi_binding_bg@2x.fff5af43.png"
  },
  {
    "revision": "42c0fbd4915870e5e60452fd0ef2cbec",
    "url": "/img/orderTopBg@3x.42c0fbd4.png"
  },
  {
    "revision": "4019fa5ae3b19d9d2872",
    "url": "/css/mifi_change_network_explanation.f0a09fde.css"
  },
  {
    "revision": "b899232b79ad9962c5ab5572775a0400",
    "url": "/img/card_index_bg@3x.b899232b.png"
  },
  {
    "revision": "b899232b79ad9962c5ab5572775a0400",
    "url": "/img/card_index_bg@2x.b899232b.png"
  },
  {
    "revision": "2c51a1e53c1ea0b35086d8d7261b4933",
    "url": "/img/bg_network@3x.2c51a1e5.png"
  },
  {
    "revision": "32d70c8fc305e3647098f3de0c71b618",
    "url": "/img/bg_network@2x.32d70c8f.png"
  },
  {
    "revision": "f5f322478286641bd9887a155e35f222",
    "url": "/img/btn.f5f32247.png"
  },
  {
    "revision": "d140650fa64e0f1fc771610dba62aed7",
    "url": "/img/bg.d140650f.png"
  },
  {
    "revision": "e625229e32d9deeb5f2909c314d8e609",
    "url": "/img/ios@2x.e625229e.png"
  },
  {
    "revision": "af8bbdfa0a90c4eed4563f8c06ce5ff8",
    "url": "/img/android@2x.af8bbdfa.png"
  },
  {
    "revision": "cc0636ca2944024fd3ebf33a5412ff35",
    "url": "/img/icon-right@3x.cc0636ca.png"
  },
  {
    "revision": "1b983020cfed6b7a8ca5c300c24ca186",
    "url": "/img/icon-left@3x.1b983020.png"
  },
  {
    "revision": "d796d97eb9ebb2e89bb966343e2362e9",
    "url": "/img/icon-left@2x.d796d97e.png"
  },
  {
    "revision": "ccb9865dadbc642b8c4dd0a1abc8e570",
    "url": "/img/recharge-word@2x.ccb9865d.png"
  },
  {
    "revision": "ccb9865dadbc642b8c4dd0a1abc8e570",
    "url": "/img/recharge-word@3x.ccb9865d.png"
  },
  {
    "revision": "41a8c268f703fe646d5d08099eb778ae",
    "url": "/img/icon-right@2x.41a8c268.png"
  },
  {
    "revision": "2d6d06f4da15fc1a748677c49c5f1854",
    "url": "/img/bg.2d6d06f4.png"
  },
  {
    "revision": "3f342771b9b81ab929e0fbcbcd0e6533",
    "url": "/img/bg-check-wrap@3x.3f342771.png"
  },
  {
    "revision": "9713b21819c4019befecd095069977df",
    "url": "/img/bg-check-wrap@2x.9713b218.png"
  },
  {
    "revision": "fa855242805b87da42c65763acd64ac0",
    "url": "/img/bg-plan-type@2x.fa855242.png"
  },
  {
    "revision": "4a9ca192485effa8b8f4b5b2df5b9caf",
    "url": "/img/bg-plan-type@3x.4a9ca192.png"
  },
  {
    "revision": "1d7515ee61c3f659227318b4050955ed",
    "url": "/img/mobile_sim@2x.1d7515ee.png"
  },
  {
    "revision": "0f980b79d9a52702004de9f652a68835",
    "url": "/img/telcom_sim@2x.0f980b79.png"
  },
  {
    "revision": "98141226a7e992e3072a280746a259c4",
    "url": "/img/mobile_sim@3x.98141226.png"
  },
  {
    "revision": "0c88168b284b92c37f3a873f26a97d69",
    "url": "/img/bg.0c88168b.jpg"
  },
  {
    "revision": "9e02095f31a07b972244f1c714c1dfe7",
    "url": "/img/telcom_sim@3x.9e02095f.png"
  },
  {
    "revision": "3d0fc424b703032ca595090e99f8354b",
    "url": "/img/login_bg@2x.3d0fc424.png"
  },
  {
    "revision": "11000d4e510a6df565eb69ba6f2c1dfc",
    "url": "/img/login_bg@3x.11000d4e.png"
  },
  {
    "revision": "f40c7e0b20fe25eb78a7658c3ae56312",
    "url": "/img/noData@3x.f40c7e0b.png"
  },
  {
    "revision": "644e6e3cf5f33943747b116316694e28",
    "url": "/img/noData@2x.644e6e3c.png"
  },
  {
    "revision": "014d354b9b25b67ae95857ba17e2f4cc",
    "url": "/img/activityPage.014d354b.png"
  },
  {
    "revision": "91e1d2771efacd45e5e465d9a001f197",
    "url": "/img/liantong.91e1d277.png"
  },
  {
    "revision": "4a0cab0f33beb48ea985714d1b91fef7",
    "url": "/img/dianxin.4a0cab0f.png"
  },
  {
    "revision": "657033323334e91efb0011bbc18f8c04",
    "url": "/img/yidong.65703332.png"
  },
  {
    "revision": "8da3b83b73e44e54d6be4b2522bcb1f2",
    "url": "/img/pkgBg2.8da3b83b.png"
  },
  {
    "revision": "d3b42651f9f5048baeffb50c800913ec",
    "url": "/img/pkgBg1.d3b42651.png"
  },
  {
    "revision": "d461d18e42a310bd709b2ce97d159153",
    "url": "/img/pkgBg3.d461d18e.png"
  },
  {
    "revision": "2a67b73145562669220aa4639e1ad58f",
    "url": "/img/icon3.2a67b731.png"
  },
  {
    "revision": "813b5319e378dafdda952c16ad89906b",
    "url": "/img/icon2.813b5319.png"
  },
  {
    "revision": "6dedd4943e4c5848638196fb6f0c4145",
    "url": "/img/bg.6dedd494.png"
  },
  {
    "revision": "0078f03c08066d51d64b92a13e194ebb",
    "url": "/img/balanceRefund.0078f03c.png"
  },
  {
    "revision": "af3ed0b3236bbfdbc3ad61b8d41c3dec",
    "url": "/img/changeBg.af3ed0b3.png"
  },
  {
    "revision": "01355f175bd20423ce45a838c1a998a9",
    "url": "/img/bg.01355f17.png"
  },
  {
    "revision": "6e5cee7393060b0ec3dcd587c2518b94",
    "url": "/img/bg_test.6e5cee73.png"
  },
  {
    "revision": "d0ccbc8a35180bb40e027b44dd26035a",
    "url": "/img/youku.d0ccbc8a.png"
  },
  {
    "revision": "a859e9ca4606d567c42b9c7bcd4fdce9",
    "url": "/img/iccid_bg@2x.a859e9ca.png"
  },
  {
    "revision": "e2233f860809839047ba",
    "url": "/css/coupon_telcom.0749aa31.css"
  },
  {
    "revision": "ea33d8408addf676eae7",
    "url": "/css/app.15f7a604.css"
  },
  {
    "revision": "56d177fdfb1e98837136",
    "url": "/css/balanceIndex.7a56af75.css"
  },
  {
    "revision": "6b6725d6bf3b8732da81",
    "url": "/css/balanceRefund.9786d2b0.css"
  },
  {
    "revision": "f70d4db296a515aa41e1",
    "url": "/css/cardPackage.972d4cd7.css"
  },
  {
    "revision": "52d9556d637a6960ff59",
    "url": "/css/card_check.ac37fada.css"
  },
  {
    "revision": "a43e4557c4eddaf6086f",
    "url": "/css/card_connection.a284fb1d.css"
  },
  {
    "revision": "34a8ce926c4fd33a8b9a",
    "url": "/css/card_lookup.66a74d15.css"
  },
  {
    "revision": "3e4adf8c7295f39acf0d",
    "url": "/css/card_more_flow.91833569.css"
  },
  {
    "revision": "bcedec3026eb60c99d7a",
    "url": "/css/card_usage.19c4d050.css"
  },
  {
    "revision": "4c94b3d1cac77f9724a3",
    "url": "/css/card_usage~plan_list.c0e200ee.css"
  },
  {
    "revision": "35fc4bb4981ba93fc75f",
    "url": "/css/card_wrapper.57946dac.css"
  },
  {
    "revision": "1524492b415d7ed68e25",
    "url": "/css/children_card.9c71b5bf.css"
  },
  {
    "revision": "dd0c13b253b862702252",
    "url": "/css/mifi_card_wrapper.6ed40a32.css"
  },
  {
    "revision": "ff67e270e5771893b826",
    "url": "/css/chunk-4a4d2551.c74ec2b8.css"
  },
  {
    "revision": "b7a5465d66b621ee0914",
    "url": "/css/chunk-7c3543f4.36e67b84.css"
  },
  {
    "revision": "7a37f1d32dcf31fafb6d",
    "url": "/css/chunk-vendors.4dda4045.css"
  },
  {
    "revision": "ecae8e24008591a64fe8",
    "url": "/css/commonProblem.d1777633.css"
  },
  {
    "revision": "d37d7b70e74302c1c36d",
    "url": "/css/commonQuestion.5da74062.css"
  },
  {
    "revision": "b21a748e92ec2a667d57",
    "url": "/css/consumerRecord.41a75160.css"
  },
  {
    "revision": "c3a364d2b4c50a9b7f87",
    "url": "/css/coupon_normal.34e8c6e5.css"
  },
  {
    "revision": "692056f2361c89b41472",
    "url": "/css/authority_middle.f2c167a9.css"
  },
  {
    "revision": "edf4d4b3ec379c8f2bcc",
    "url": "/css/coupon_wrapper.bdf706e3.css"
  },
  {
    "revision": "c82a4b218b3dc175452b",
    "url": "/css/currencyConversion.29ba4fc2.css"
  },
  {
    "revision": "ab59337f9e37a01e6ab6",
    "url": "/css/customerFeedback.81103f78.css"
  },
  {
    "revision": "1a27b7b8126bae522b89",
    "url": "/css/eqReplaceMent.2bc7c758.css"
  },
  {
    "revision": "b1124b16093a74dc5550",
    "url": "/css/eqReplaceMent~recharge.1395966c.css"
  },
  {
    "revision": "30123fbae9214f8c7e3d",
    "url": "/css/esim_plan_list.a09d6e78.css"
  },
  {
    "revision": "4c87e9571f89b1ffa3b7",
    "url": "/css/esim_usage.3a894732.css"
  },
  {
    "revision": "3c9a0778963046c5e673",
    "url": "/css/find_plan.0ae10738.css"
  },
  {
    "revision": "456d24dc095708ee7545",
    "url": "/css/logical_page.738e621a.css"
  },
  {
    "revision": "416565ccee7060779b96",
    "url": "/css/login.0c61d3a0.css"
  },
  {
    "revision": "6a07967fc244f64e5596",
    "url": "/css/lookup.f188f57a.css"
  },
  {
    "revision": "6d129e88a4561b060cfd",
    "url": "/css/mifi_binding.4d63be72.css"
  },
  {
    "revision": "39b4f93768cc6fdf6205",
    "url": "/css/mifi_card_info.fe8abd93.css"
  },
  {
    "revision": "a08d4f598ab34aae347f",
    "url": "/css/mifi_card_lookup.6c8c9ae4.css"
  },
  {
    "revision": "94d7cc9826a7aff7eaf5",
    "url": "/css/Not_fund.335e4433.css"
  },
  {
    "revision": "c7acfdd102d29b9a6b80",
    "url": "/css/Layout.43b3cc9d.css"
  },
  {
    "revision": "9ce16f441b39b493af8b96d7e97cce22",
    "url": "/MP_verify_dkzAKjxyVyJvsHMS.txt"
  },
  {
    "revision": "86c422d8c98b247235d04b49fb1c4b05",
    "url": "/MP_verify_bKSdn2qZlUSULliu.txt"
  },
  {
    "revision": "652317b098ca24e4511926c7fd57cbbe",
    "url": "/MP_verify_8JoCCldW78DygS5c.txt"
  },
  {
    "revision": "00bbf6b458bf7ea6bd01f443eb3045d9",
    "url": "/MP_verify_4r3DVk3KUjgWsQsG.txt"
  }
];