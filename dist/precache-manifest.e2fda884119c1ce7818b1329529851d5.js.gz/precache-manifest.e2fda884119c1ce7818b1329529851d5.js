self.__precacheManifest = [
  {
    "revision": "a47cce6d5c5ee97a051f",
    "url": "/js/recharge_callback.39d16819.js"
  },
  {
    "revision": "89f204fb8a6de705a3da",
    "url": "/css/Layout.f1696a85.css"
  },
  {
    "revision": "a22a85b7bf5a0d77cd68",
    "url": "/css/Not_fund.08f80dd6.css"
  },
  {
    "revision": "a22a85b7bf5a0d77cd68",
    "url": "/js/Not_fund.68f35929.js"
  },
  {
    "revision": "04b0348c42dced1dbe05",
    "url": "/css/addSalesRecords.43dd7d5b.css"
  },
  {
    "revision": "04b0348c42dced1dbe05",
    "url": "/js/addSalesRecords.bc34f62a.js"
  },
  {
    "revision": "f45bfb15aa373452b4c0",
    "url": "/css/app.8b56f02a.css"
  },
  {
    "revision": "f45bfb15aa373452b4c0",
    "url": "/js/app.943a0028.js"
  },
  {
    "revision": "ce2f1173cdd1d8c71e9a",
    "url": "/css/authority_middle.c5942ca9.css"
  },
  {
    "revision": "ce2f1173cdd1d8c71e9a",
    "url": "/js/authority_middle.78710eb0.js"
  },
  {
    "revision": "8008eb52c9c15cb48a4e",
    "url": "/css/card_check.376bd7a7.css"
  },
  {
    "revision": "8008eb52c9c15cb48a4e",
    "url": "/js/card_check.0a756a0f.js"
  },
  {
    "revision": "c1f0daa190bdf0250237",
    "url": "/css/card_connection.b84d91ff.css"
  },
  {
    "revision": "c1f0daa190bdf0250237",
    "url": "/js/card_connection.11925269.js"
  },
  {
    "revision": "efc45ce7ec928e62231c",
    "url": "/css/card_lookup.4f607cf5.css"
  },
  {
    "revision": "efc45ce7ec928e62231c",
    "url": "/js/card_lookup.ea8bae2d.js"
  },
  {
    "revision": "45a187c0dac824c5190b",
    "url": "/css/card_usage.0e115036.css"
  },
  {
    "revision": "45a187c0dac824c5190b",
    "url": "/js/card_usage.1d5f6ccc.js"
  },
  {
    "revision": "e3de9fe9350508cb8bdd",
    "url": "/js/card_usage~eqReplaceMent~esim_plan_list~esim_usage~mifi_order~mifi_plan_list~mifi_plan_usage~plan_li~f915d233.7f59822f.js"
  },
  {
    "revision": "6b6ca5926d9c94d23350",
    "url": "/css/card_wrapper.482349c9.css"
  },
  {
    "revision": "6b6ca5926d9c94d23350",
    "url": "/js/card_wrapper.d600314d.js"
  },
  {
    "revision": "8c2be8d2ef6d7c049a9c",
    "url": "/css/children_card.41bb1ea3.css"
  },
  {
    "revision": "8c2be8d2ef6d7c049a9c",
    "url": "/js/children_card.78f5e4fa.js"
  },
  {
    "revision": "cbcf89ab31e4060fd569",
    "url": "/css/chunk-0517deef.686c0f3b.css"
  },
  {
    "revision": "cbcf89ab31e4060fd569",
    "url": "/js/chunk-0517deef.34cdcb38.js"
  },
  {
    "revision": "6075a085161392d233ac",
    "url": "/css/chunk-4cdf1444.a1283c2e.css"
  },
  {
    "revision": "6075a085161392d233ac",
    "url": "/js/chunk-4cdf1444.754bd388.js"
  },
  {
    "revision": "a0e382414fe79c4c4955",
    "url": "/css/chunk-vendors.19e02a39.css"
  },
  {
    "revision": "a0e382414fe79c4c4955",
    "url": "/js/chunk-vendors.f19af80f.js"
  },
  {
    "revision": "0d0e00b1505a025cf1f5",
    "url": "/css/contactUs.9fcbcc9a.css"
  },
  {
    "revision": "0d0e00b1505a025cf1f5",
    "url": "/js/contactUs.afb71119.js"
  },
  {
    "revision": "da05b588218b41213caa",
    "url": "/css/coupon_normal.a998dd6b.css"
  },
  {
    "revision": "da05b588218b41213caa",
    "url": "/js/coupon_normal.46da1ee9.js"
  },
  {
    "revision": "cc08ed9ae980fd756f2d",
    "url": "/css/coupon_telcom.b9f522ab.css"
  },
  {
    "revision": "cc08ed9ae980fd756f2d",
    "url": "/js/coupon_telcom.b5781399.js"
  },
  {
    "revision": "1b2b27d06ccd577632d0",
    "url": "/css/coupon_wrapper.acf02c15.css"
  },
  {
    "revision": "1b2b27d06ccd577632d0",
    "url": "/js/coupon_wrapper.9661da23.js"
  },
  {
    "revision": "34af4ddc235f1f145cfd",
    "url": "/css/eqReplaceMent.18e0dfd7.css"
  },
  {
    "revision": "34af4ddc235f1f145cfd",
    "url": "/js/eqReplaceMent.b1697d21.js"
  },
  {
    "revision": "21dd9f9bd8c360d4bbad",
    "url": "/css/esim_plan_list.c33177f7.css"
  },
  {
    "revision": "21dd9f9bd8c360d4bbad",
    "url": "/js/esim_plan_list.315db910.js"
  },
  {
    "revision": "7b59cd1718acd5e68a64",
    "url": "/css/esim_usage.81fe67f4.css"
  },
  {
    "revision": "7b59cd1718acd5e68a64",
    "url": "/js/esim_usage.84abc67a.js"
  },
  {
    "revision": "af176db7c322302c6e22",
    "url": "/css/find_plan.76fdcc7c.css"
  },
  {
    "revision": "af176db7c322302c6e22",
    "url": "/js/find_plan.fcb64f74.js"
  },
  {
    "revision": "82f71bf4f51deea294da",
    "url": "/css/helpCenter.872d6b06.css"
  },
  {
    "revision": "82f71bf4f51deea294da",
    "url": "/js/helpCenter.a6e12add.js"
  },
  {
    "revision": "fcef7affe200f531f7d4",
    "url": "/css/logical_page.68dab072.css"
  },
  {
    "revision": "fcef7affe200f531f7d4",
    "url": "/js/logical_page.3323c945.js"
  },
  {
    "revision": "279340a875b2a0fb84ef",
    "url": "/css/login.0f5c1936.css"
  },
  {
    "revision": "279340a875b2a0fb84ef",
    "url": "/js/login.42b12bb5.js"
  },
  {
    "revision": "f60273c9fe77fdd8d435",
    "url": "/css/lookup.3bf5bf50.css"
  },
  {
    "revision": "f60273c9fe77fdd8d435",
    "url": "/js/lookup.d2a2fc02.js"
  },
  {
    "revision": "ab3b0ba37298396b1212",
    "url": "/css/mifi_binding.6649ddd8.css"
  },
  {
    "revision": "ab3b0ba37298396b1212",
    "url": "/js/mifi_binding.00271981.js"
  },
  {
    "revision": "9a5b0cc6526393c9a9e4",
    "url": "/css/mifi_card_info.84617cbf.css"
  },
  {
    "revision": "9a5b0cc6526393c9a9e4",
    "url": "/js/mifi_card_info.27b41bc5.js"
  },
  {
    "revision": "1cbbf538f9becf73886b",
    "url": "/css/mifi_card_lookup.2e345759.css"
  },
  {
    "revision": "1cbbf538f9becf73886b",
    "url": "/js/mifi_card_lookup.e99bad02.js"
  },
  {
    "revision": "3c7ff5805023b80b24cb",
    "url": "/css/mifi_card_wrapper.3d9190f2.css"
  },
  {
    "revision": "3c7ff5805023b80b24cb",
    "url": "/js/mifi_card_wrapper.bb220fc5.js"
  },
  {
    "revision": "fbc3c3b5394c649628d4",
    "url": "/css/mifi_change_network.787e68d6.css"
  },
  {
    "revision": "fbc3c3b5394c649628d4",
    "url": "/js/mifi_change_network.7f9c4bd3.js"
  },
  {
    "revision": "fb3661dd4b6383f840cc",
    "url": "/css/mifi_coupon_index.d8655c92.css"
  },
  {
    "revision": "fb3661dd4b6383f840cc",
    "url": "/js/mifi_coupon_index.65b9140b.js"
  },
  {
    "revision": "fc0b895597e29cf33fff",
    "url": "/css/mifi_coupon_wrapper.b777319b.css"
  },
  {
    "revision": "fc0b895597e29cf33fff",
    "url": "/js/mifi_coupon_wrapper.83e0a6ed.js"
  },
  {
    "revision": "ab4ffbfd75f61beccca0",
    "url": "/css/mifi_index.2f0b7cf9.css"
  },
  {
    "revision": "ab4ffbfd75f61beccca0",
    "url": "/js/mifi_index.33277ade.js"
  },
  {
    "revision": "7863227d4c68bd8eb03c",
    "url": "/css/mifi_layout.f1696a85.css"
  },
  {
    "revision": "7863227d4c68bd8eb03c",
    "url": "/js/mifi_layout.952cf46e.js"
  },
  {
    "revision": "7153ad7b599cddc36fc5",
    "url": "/css/mifi_order.dbb05a7c.css"
  },
  {
    "revision": "7153ad7b599cddc36fc5",
    "url": "/js/mifi_order.d4a31a0a.js"
  },
  {
    "revision": "232277cde391af854952",
    "url": "/css/mifi_order_wrapper.f7ae0bf9.css"
  },
  {
    "revision": "232277cde391af854952",
    "url": "/js/mifi_order_wrapper.75f047c1.js"
  },
  {
    "revision": "df37ba0c12e5ffccef07",
    "url": "/css/mifi_order~mifi_plan_group.649e1a31.css"
  },
  {
    "revision": "df37ba0c12e5ffccef07",
    "url": "/js/mifi_order~mifi_plan_group.cee5964d.js"
  },
  {
    "revision": "227b49f0d847c0cce9d5",
    "url": "/css/mifi_plan_group.e07a284e.css"
  },
  {
    "revision": "227b49f0d847c0cce9d5",
    "url": "/js/mifi_plan_group.b2f74527.js"
  },
  {
    "revision": "720d26cbb933f29fd1a8",
    "url": "/css/mifi_plan_list.12b9cdd5.css"
  },
  {
    "revision": "720d26cbb933f29fd1a8",
    "url": "/js/mifi_plan_list.2cfa23ee.js"
  },
  {
    "revision": "4a407d4ad31738dea6b8",
    "url": "/css/mifi_plan_usage.9dd570ae.css"
  },
  {
    "revision": "4a407d4ad31738dea6b8",
    "url": "/js/mifi_plan_usage.abeee884.js"
  },
  {
    "revision": "e97c614c6d831370a904",
    "url": "/css/mifi_plan_wrapper.dc61eb75.css"
  },
  {
    "revision": "e97c614c6d831370a904",
    "url": "/js/mifi_plan_wrapper.c3496f18.js"
  },
  {
    "revision": "3b92b198314edf4e2dcb",
    "url": "/css/new_card_wrapper.fb63c830.css"
  },
  {
    "revision": "3b92b198314edf4e2dcb",
    "url": "/js/new_card_wrapper.4df90f67.js"
  },
  {
    "revision": "0f199d827ebe790cadd6",
    "url": "/css/plan_list.519f9a8d.css"
  },
  {
    "revision": "0f199d827ebe790cadd6",
    "url": "/js/plan_list.465196e8.js"
  },
  {
    "revision": "5ea2582c41024d8d8e91",
    "url": "/css/question.e4ca3e70.css"
  },
  {
    "revision": "5ea2582c41024d8d8e91",
    "url": "/js/question.a30bd3f4.js"
  },
  {
    "revision": "889fa911fe6f91fd3aad",
    "url": "/css/question_wrapper.8710c11d.css"
  },
  {
    "revision": "889fa911fe6f91fd3aad",
    "url": "/js/question_wrapper.d9a352ff.js"
  },
  {
    "revision": "2af41d883d74e49a1355",
    "url": "/css/realName.2d5861df.css"
  },
  {
    "revision": "2af41d883d74e49a1355",
    "url": "/js/realName.f74468b2.js"
  },
  {
    "revision": "81be18bdeff950059e39",
    "url": "/css/real_name.79a75a55.css"
  },
  {
    "revision": "81be18bdeff950059e39",
    "url": "/js/real_name.7de77a08.js"
  },
  {
    "revision": "46f39b5a0e9f5a237eb4",
    "url": "/css/recharge.09788cb7.css"
  },
  {
    "revision": "46f39b5a0e9f5a237eb4",
    "url": "/js/recharge.ec3ace73.js"
  },
  {
    "revision": "5c5880ac0ad10c6c27a1",
    "url": "/css/rechargeRecord.d25682bd.css"
  },
  {
    "revision": "5c5880ac0ad10c6c27a1",
    "url": "/js/rechargeRecord.86251af6.js"
  },
  {
    "revision": "a47cce6d5c5ee97a051f",
    "url": "/css/recharge_callback.2e01c7e0.css"
  },
  {
    "revision": "89f204fb8a6de705a3da",
    "url": "/js/Layout.12a256b9.js"
  },
  {
    "revision": "fb1d7e6619ecd6fb023a",
    "url": "/css/recharge_wrapper.907108b0.css"
  },
  {
    "revision": "fb1d7e6619ecd6fb023a",
    "url": "/js/recharge_wrapper.6bbe6de6.js"
  },
  {
    "revision": "ce079ed6322dd11b601d",
    "url": "/css/refund_applying.a2e298be.css"
  },
  {
    "revision": "ce079ed6322dd11b601d",
    "url": "/js/refund_applying.5c8092c2.js"
  },
  {
    "revision": "3b26c4ce1b8a9f51b815",
    "url": "/css/refund_argument.d930fbd4.css"
  },
  {
    "revision": "3b26c4ce1b8a9f51b815",
    "url": "/js/refund_argument.18748d80.js"
  },
  {
    "revision": "46b032fac6642ff09da1",
    "url": "/css/refund_plan.22c395e6.css"
  },
  {
    "revision": "46b032fac6642ff09da1",
    "url": "/js/refund_plan.3f1a7e3b.js"
  },
  {
    "revision": "12bd6fa402ef72b9ea36",
    "url": "/css/refund_wrapper.bdf706e3.css"
  },
  {
    "revision": "12bd6fa402ef72b9ea36",
    "url": "/js/refund_wrapper.7ab908e6.js"
  },
  {
    "revision": "b1be30a8ea5ae0efdfd5",
    "url": "/css/repeatRecharge.e3e8e690.css"
  },
  {
    "revision": "b1be30a8ea5ae0efdfd5",
    "url": "/js/repeatRecharge.d3afef06.js"
  },
  {
    "revision": "fb9b384b2c66c6f36058",
    "url": "/css/revoke_plan.25426673.css"
  },
  {
    "revision": "fb9b384b2c66c6f36058",
    "url": "/js/revoke_plan.05f5b32e.js"
  },
  {
    "revision": "e3906e1d250a04fbfe05",
    "url": "/css/salesRecords.6b8863dd.css"
  },
  {
    "revision": "e3906e1d250a04fbfe05",
    "url": "/js/salesRecords.51028442.js"
  },
  {
    "revision": "758e30760f1c55cffcaa",
    "url": "/css/speedup_500.a54a5ac3.css"
  },
  {
    "revision": "758e30760f1c55cffcaa",
    "url": "/js/speedup_500.c927c5fa.js"
  },
  {
    "revision": "59dd75b694db8c0cd958",
    "url": "/css/speedup_80.6d3e511a.css"
  },
  {
    "revision": "59dd75b694db8c0cd958",
    "url": "/js/speedup_80.5c3be59a.js"
  },
  {
    "revision": "b3444a2e4c3f368c958d",
    "url": "/css/speedup_wrapper.06a280b2.css"
  },
  {
    "revision": "b3444a2e4c3f368c958d",
    "url": "/js/speedup_wrapper.5bbff775.js"
  },
  {
    "revision": "ac5b25b4349f51ec873c",
    "url": "/css/to_tb.ef035efd.css"
  },
  {
    "revision": "ac5b25b4349f51ec873c",
    "url": "/js/to_tb.589f9c91.js"
  },
  {
    "revision": "9d5d49b689d9d4b55abd",
    "url": "/css/userCenter.5472e106.css"
  },
  {
    "revision": "9d5d49b689d9d4b55abd",
    "url": "/js/userCenter.206c4cdd.js"
  },
  {
    "revision": "ae380f2820530f69f71b",
    "url": "/css/userCenterAddress.300f2e81.css"
  },
  {
    "revision": "ae380f2820530f69f71b",
    "url": "/js/userCenterAddress.b7045e11.js"
  },
  {
    "revision": "3356f8d2f2eaa747b711",
    "url": "/css/userCenterWrap.d572d9dd.css"
  },
  {
    "revision": "3356f8d2f2eaa747b711",
    "url": "/js/userCenterWrap.9a549400.js"
  },
  {
    "revision": "e4b411644706c29765eea3ffdd85ae39",
    "url": "/fonts/SourceHanSansCNRegular.e4b41164.woff"
  },
  {
    "revision": "834b022ab9ab0e6063904af32274e777",
    "url": "/fonts/SourceHanSansCNRegular.834b022a.eot"
  },
  {
    "revision": "f9509c5a10be7daaf1fa01922a7c6bc2",
    "url": "/fonts/SourceHanSansCNRegular.f9509c5a.ttf"
  },
  {
    "revision": "da0808e9fe85be160aab69c82dd8de1c",
    "url": "/img/SourceHanSansCNRegular.da0808e9.svg"
  },
  {
    "revision": "ad4acc3d7da28ce6f33925b83bae2c94",
    "url": "/img/arrow1.ad4acc3d.png"
  },
  {
    "revision": "732389ded34cb9c52dd88271f1345af9",
    "url": "/fonts/element-icons.732389de.ttf"
  },
  {
    "revision": "535877f50039c0cb49a6196a5b7517cd",
    "url": "/fonts/element-icons.535877f5.woff"
  },
  {
    "revision": "6e5cee7393060b0ec3dcd587c2518b94",
    "url": "/img/bg_test.6e5cee73.png"
  },
  {
    "revision": "fff5af4325410621aeec4e60b3b92d9b",
    "url": "/img/mifi_binding_bg@3x.fff5af43.png"
  },
  {
    "revision": "fff5af4325410621aeec4e60b3b92d9b",
    "url": "/img/mifi_binding_bg@2x.fff5af43.png"
  },
  {
    "revision": "a1386d312938b126d701a6841fb742e8",
    "url": "/img/addressIcon.a1386d31.png"
  },
  {
    "revision": "83d0cd2dc163e83ef26f6bad98661da8",
    "url": "/img/addressBg.83d0cd2d.png"
  },
  {
    "revision": "a859e9ca4606d567c42b9c7bcd4fdce9",
    "url": "/img/iccid_bg@2x.a859e9ca.png"
  },
  {
    "revision": "fa9050c4e9870e8fc0cd184f8515af4a",
    "url": "/img/iccid_bg@3x.fa9050c4.png"
  },
  {
    "revision": "42c0fbd4915870e5e60452fd0ef2cbec",
    "url": "/img/orderTopBg@3x.42c0fbd4.png"
  },
  {
    "revision": "42c0fbd4915870e5e60452fd0ef2cbec",
    "url": "/img/orderTopBg@2x.42c0fbd4.png"
  },
  {
    "revision": "b899232b79ad9962c5ab5572775a0400",
    "url": "/img/card_index_bg@3x.b899232b.png"
  },
  {
    "revision": "b899232b79ad9962c5ab5572775a0400",
    "url": "/img/card_index_bg@2x.b899232b.png"
  },
  {
    "revision": "f5f322478286641bd9887a155e35f222",
    "url": "/img/btn.f5f32247.png"
  },
  {
    "revision": "d140650fa64e0f1fc771610dba62aed7",
    "url": "/img/bg.d140650f.png"
  },
  {
    "revision": "3f342771b9b81ab929e0fbcbcd0e6533",
    "url": "/img/bg-check-wrap@3x.3f342771.png"
  },
  {
    "revision": "9713b21819c4019befecd095069977df",
    "url": "/img/bg-check-wrap@2x.9713b218.png"
  },
  {
    "revision": "2c51a1e53c1ea0b35086d8d7261b4933",
    "url": "/img/bg_network@3x.2c51a1e5.png"
  },
  {
    "revision": "32d70c8fc305e3647098f3de0c71b618",
    "url": "/img/bg_network@2x.32d70c8f.png"
  },
  {
    "revision": "e625229e32d9deeb5f2909c314d8e609",
    "url": "/img/ios@2x.e625229e.png"
  },
  {
    "revision": "af8bbdfa0a90c4eed4563f8c06ce5ff8",
    "url": "/img/android@2x.af8bbdfa.png"
  },
  {
    "revision": "d32e5dc3875f1afd2be29aad1cfd0382",
    "url": "/img/contactBg.d32e5dc3.png"
  },
  {
    "revision": "1d7515ee61c3f659227318b4050955ed",
    "url": "/img/mobile_sim@2x.1d7515ee.png"
  },
  {
    "revision": "0f980b79d9a52702004de9f652a68835",
    "url": "/img/telcom_sim@2x.0f980b79.png"
  },
  {
    "revision": "98141226a7e992e3072a280746a259c4",
    "url": "/img/mobile_sim@3x.98141226.png"
  },
  {
    "revision": "0c88168b284b92c37f3a873f26a97d69",
    "url": "/img/bg.0c88168b.jpg"
  },
  {
    "revision": "9e02095f31a07b972244f1c714c1dfe7",
    "url": "/img/telcom_sim@3x.9e02095f.png"
  },
  {
    "revision": "114a6e12b42b9b48586dd341105188fe",
    "url": "/img/usedOrder@2x.114a6e12.png"
  },
  {
    "revision": "c0170ec299b2418256fd515ee7849055",
    "url": "/img/unUsedOrder@2x.c0170ec2.png"
  },
  {
    "revision": "d9e14058d30dd312519fcf2de38d742b",
    "url": "/img/unUsedOrder@3x.d9e14058.png"
  },
  {
    "revision": "4a5b90f8076955f289b3dcda6a5af6ff",
    "url": "/img/invaildedOrder@3x.4a5b90f8.png"
  },
  {
    "revision": "0d5a5158e67bcb7a4604124715ed6fbf",
    "url": "/img/usedOrder@3x.0d5a5158.png"
  },
  {
    "revision": "be0f1e33b2553e71b117d3d3f838d32f",
    "url": "/img/invaildedOrder@2x.be0f1e33.png"
  },
  {
    "revision": "3d0fc424b703032ca595090e99f8354b",
    "url": "/img/login_bg@2x.3d0fc424.png"
  },
  {
    "revision": "11000d4e510a6df565eb69ba6f2c1dfc",
    "url": "/img/login_bg@3x.11000d4e.png"
  },
  {
    "revision": "014d354b9b25b67ae95857ba17e2f4cc",
    "url": "/img/activityPage.014d354b.png"
  },
  {
    "revision": "2a67b73145562669220aa4639e1ad58f",
    "url": "/img/icon3.2a67b731.png"
  },
  {
    "revision": "813b5319e378dafdda952c16ad89906b",
    "url": "/img/icon2.813b5319.png"
  },
  {
    "revision": "01355f175bd20423ce45a838c1a998a9",
    "url": "/img/bg.01355f17.png"
  },
  {
    "revision": "6eb1cce5bab9ec1cb25d71e8f3110a15",
    "url": "/img/real7.6eb1cce5.jpeg"
  },
  {
    "revision": "b74ee4a485ffa8d4339c3412ac6659be",
    "url": "/img/real6.b74ee4a4.jpeg"
  },
  {
    "revision": "5a3428653945c17e1c146efeee81c987",
    "url": "/img/scanTop.5a342865.png"
  },
  {
    "revision": "824594523c01e48028f2b7eb4261134d",
    "url": "/img/unicom-logo.82459452.svg"
  },
  {
    "revision": "113f99e2189c2ca49db2168754fc2eb5",
    "url": "/img/mobile-logo.113f99e2.png"
  },
  {
    "revision": "0cba868fa977e09806638b9000636a36",
    "url": "/img/avatar.0cba868f.jpeg"
  },
  {
    "revision": "a5b636104342050950abea60fb65f9cd",
    "url": "/img/qrImg.a5b63610.png"
  },
  {
    "revision": "27158aa79eb0d4b89f317d076a801ca3",
    "url": "/img/coupon-log.27158aa7.png"
  },
  {
    "revision": "55d3f2f09efe17db6485d4c9f8f0c3b1",
    "url": "/img/icon-recharge_20181001.55d3f2f0.svg"
  },
  {
    "revision": "5f1f34037094c0613bccafa2ddd8cb3b",
    "url": "/img/telecom-logo.5f1f3403.svg"
  },
  {
    "revision": "644e6e3cf5f33943747b116316694e28",
    "url": "/img/noData@2x.644e6e3c.png"
  },
  {
    "revision": "4bdbe7dbdb6587c886a8290593100145",
    "url": "/img/recharge_callback_20181126.4bdbe7db.jpg"
  },
  {
    "revision": "aecc9531f2c3b1fd45338e7bf5084384",
    "url": "/img/bg_no_recharge.aecc9531.svg"
  },
  {
    "revision": "3af1a9430facd73c667ba61919fc414e",
    "url": "/img/real5.3af1a943.jpeg"
  },
  {
    "revision": "275be51ae57c486bce58257febd6589f",
    "url": "/img/bg_no_plan.275be51a.svg"
  },
  {
    "revision": "1cf937a060cb282e8b60ed6a7ec78604",
    "url": "/img/real3.1cf937a0.jpeg"
  },
  {
    "revision": "45fb414691fd8f78628e3e94f9db1ad4",
    "url": "/img/real2.45fb4146.jpeg"
  },
  {
    "revision": "a6d17ceb63edb524e63c9bbc7c671fec",
    "url": "/img/real4.a6d17ceb.jpeg"
  },
  {
    "revision": "39d9e849fc1c724525f166646932a24d",
    "url": "/img/safari.39d9e849.png"
  },
  {
    "revision": "1cc77fe95a0f28837ecea2300db5756d",
    "url": "/img/real1.1cc77fe9.jpeg"
  },
  {
    "revision": "018b5f611723dcd170b93822b6dfc48d",
    "url": "/img/real8.018b5f61.jpeg"
  },
  {
    "revision": "e8afc4589318a484bdc69b8ba9586912",
    "url": "/index.html"
  },
  {
    "revision": "b6216d61c03e6ce0c9aea6ca7808f7ca",
    "url": "/robots.txt"
  },
  {
    "revision": "9ce16f441b39b493af8b96d7e97cce22",
    "url": "/MP_verify_dkzAKjxyVyJvsHMS.txt"
  },
  {
    "revision": "86c422d8c98b247235d04b49fb1c4b05",
    "url": "/MP_verify_bKSdn2qZlUSULliu.txt"
  },
  {
    "revision": "652317b098ca24e4511926c7fd57cbbe",
    "url": "/MP_verify_8JoCCldW78DygS5c.txt"
  },
  {
    "revision": "00bbf6b458bf7ea6bd01f443eb3045d9",
    "url": "/MP_verify_4r3DVk3KUjgWsQsG.txt"
  }
];