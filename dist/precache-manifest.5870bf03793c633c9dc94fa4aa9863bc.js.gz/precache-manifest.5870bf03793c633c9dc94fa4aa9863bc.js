self.__precacheManifest = [
  {
    "revision": "bf22d99e9ae3debb876b",
    "url": "/js/recharge_callback.d8237c4b.js"
  },
  {
    "revision": "b6216d61c03e6ce0c9aea6ca7808f7ca",
    "url": "/robots.txt"
  },
  {
    "revision": "9feffacd2b7a96a33fbf",
    "url": "/css/recharge_wrapper.61f8e218.css"
  },
  {
    "revision": "be40bca99df105cbae95",
    "url": "/css/Layout~card_usage.cb0d2a22.css"
  },
  {
    "revision": "78214ba34c5f1df936aa",
    "url": "/js/Layout~card_usage~eqReplaceMent~esim_plan_list~esim_usage~mifi_order~mifi_plan_list~mifi_plan_usage~~c6f87c36.6241bd21.js"
  },
  {
    "revision": "33bc8d7c0421214121c0",
    "url": "/css/Not_fund.441b338e.css"
  },
  {
    "revision": "33bc8d7c0421214121c0",
    "url": "/js/Not_fund.a6629d31.js"
  },
  {
    "revision": "baecb0169e867780497e",
    "url": "/css/app.72184c26.css"
  },
  {
    "revision": "baecb0169e867780497e",
    "url": "/js/app.9e588833.js"
  },
  {
    "revision": "8cde91fc8f7ae2148208",
    "url": "/css/authority_middle.4be2bf2b.css"
  },
  {
    "revision": "8cde91fc8f7ae2148208",
    "url": "/js/authority_middle.93cff01a.js"
  },
  {
    "revision": "6eae12faa0a51c260f59",
    "url": "/css/balanceRefund.42812232.css"
  },
  {
    "revision": "6eae12faa0a51c260f59",
    "url": "/js/balanceRefund.337cebba.js"
  },
  {
    "revision": "c6d139302a629df676bb",
    "url": "/css/cardPackage.268156fc.css"
  },
  {
    "revision": "c6d139302a629df676bb",
    "url": "/js/cardPackage.33a1f1d5.js"
  },
  {
    "revision": "939f72331f814ad4ccde",
    "url": "/css/card_check.821d897a.css"
  },
  {
    "revision": "939f72331f814ad4ccde",
    "url": "/js/card_check.6aedaa2b.js"
  },
  {
    "revision": "9ce864f080a0a5d24a8e",
    "url": "/css/card_connection.0c0041ec.css"
  },
  {
    "revision": "9ce864f080a0a5d24a8e",
    "url": "/js/card_connection.a2c34b27.js"
  },
  {
    "revision": "82f89b92f76bfff196e1",
    "url": "/css/card_lookup.0458ded2.css"
  },
  {
    "revision": "82f89b92f76bfff196e1",
    "url": "/js/card_lookup.eb693961.js"
  },
  {
    "revision": "7808b45487cc0010b005",
    "url": "/css/card_usage.f4f44e8c.css"
  },
  {
    "revision": "7808b45487cc0010b005",
    "url": "/js/card_usage.89fa1d27.js"
  },
  {
    "revision": "59768519318b6230e09a",
    "url": "/css/card_wrapper.373da779.css"
  },
  {
    "revision": "59768519318b6230e09a",
    "url": "/js/card_wrapper.11810a6e.js"
  },
  {
    "revision": "f35374a63eb7d3910aa2",
    "url": "/css/children_card.3ec8d22c.css"
  },
  {
    "revision": "f35374a63eb7d3910aa2",
    "url": "/js/children_card.b2fae8bb.js"
  },
  {
    "revision": "af136a414a95246b54a4",
    "url": "/css/chunk-3175df15.d7982382.css"
  },
  {
    "revision": "af136a414a95246b54a4",
    "url": "/js/chunk-3175df15.1d9dcac8.js"
  },
  {
    "revision": "00daf38c0bf364a0f9bb",
    "url": "/css/chunk-7b3e02f8.6e41d363.css"
  },
  {
    "revision": "00daf38c0bf364a0f9bb",
    "url": "/js/chunk-7b3e02f8.61f4382d.js"
  },
  {
    "revision": "cd79ca3a12173f7fb9ec",
    "url": "/css/chunk-vendors.3b71a034.css"
  },
  {
    "revision": "cd79ca3a12173f7fb9ec",
    "url": "/js/chunk-vendors.10650154.js"
  },
  {
    "revision": "070018232df4695874b4",
    "url": "/css/commonProblem.a6a75547.css"
  },
  {
    "revision": "070018232df4695874b4",
    "url": "/js/commonProblem.d96b79ae.js"
  },
  {
    "revision": "fd7424c062e93a3b5cf9",
    "url": "/css/consumerRecord.31902f6d.css"
  },
  {
    "revision": "fd7424c062e93a3b5cf9",
    "url": "/js/consumerRecord.a81137ec.js"
  },
  {
    "revision": "23352b7d285a7565d120",
    "url": "/css/coupon_normal.94c7ba55.css"
  },
  {
    "revision": "23352b7d285a7565d120",
    "url": "/js/coupon_normal.e40ac141.js"
  },
  {
    "revision": "1c3ce6b90affe1918295",
    "url": "/css/coupon_telcom.72ee0bc0.css"
  },
  {
    "revision": "1c3ce6b90affe1918295",
    "url": "/js/coupon_telcom.c3c3f0a6.js"
  },
  {
    "revision": "3d29be284addf9ff5036",
    "url": "/css/coupon_wrapper.31258838.css"
  },
  {
    "revision": "3d29be284addf9ff5036",
    "url": "/js/coupon_wrapper.c1c14448.js"
  },
  {
    "revision": "c4697cce75c0ddff3ff4",
    "url": "/css/currencyConversion.3746d685.css"
  },
  {
    "revision": "c4697cce75c0ddff3ff4",
    "url": "/js/currencyConversion.dddde909.js"
  },
  {
    "revision": "30450cdb38b6d5995cd4",
    "url": "/css/eqReplaceMent.b1f305f8.css"
  },
  {
    "revision": "30450cdb38b6d5995cd4",
    "url": "/js/eqReplaceMent.5994e5b8.js"
  },
  {
    "revision": "d54669bdea24a8247e2f",
    "url": "/css/esim_plan_list.10d517ad.css"
  },
  {
    "revision": "d54669bdea24a8247e2f",
    "url": "/js/esim_plan_list.df938134.js"
  },
  {
    "revision": "c7e2a9d5310b34a33537",
    "url": "/css/esim_usage.d9734e83.css"
  },
  {
    "revision": "c7e2a9d5310b34a33537",
    "url": "/js/esim_usage.8482e7f2.js"
  },
  {
    "revision": "dda5f758266272d5dcd0",
    "url": "/css/find_plan.579625f7.css"
  },
  {
    "revision": "dda5f758266272d5dcd0",
    "url": "/js/find_plan.347d7a9e.js"
  },
  {
    "revision": "67df646ae241abb92c51",
    "url": "/css/logical_page.b1840a87.css"
  },
  {
    "revision": "67df646ae241abb92c51",
    "url": "/js/logical_page.f213e689.js"
  },
  {
    "revision": "93a76913dcec3e218b5f",
    "url": "/css/login.b710a567.css"
  },
  {
    "revision": "93a76913dcec3e218b5f",
    "url": "/js/login.d8794e9d.js"
  },
  {
    "revision": "65e6dcf99baa425c4460",
    "url": "/css/lookup.a0fdfe26.css"
  },
  {
    "revision": "65e6dcf99baa425c4460",
    "url": "/js/lookup.b5026444.js"
  },
  {
    "revision": "3729845ce3a84b6acb1d",
    "url": "/css/mifi_binding.d51dd9ee.css"
  },
  {
    "revision": "3729845ce3a84b6acb1d",
    "url": "/js/mifi_binding.a599835e.js"
  },
  {
    "revision": "9586ce84e88fce556dbe",
    "url": "/css/mifi_card_info.331a32b0.css"
  },
  {
    "revision": "9586ce84e88fce556dbe",
    "url": "/js/mifi_card_info.d778eb0b.js"
  },
  {
    "revision": "b887148fd5f5359521ef",
    "url": "/css/mifi_card_lookup.7e5595fc.css"
  },
  {
    "revision": "b887148fd5f5359521ef",
    "url": "/js/mifi_card_lookup.20aa39e6.js"
  },
  {
    "revision": "ea0397017a8f773eef8a",
    "url": "/css/mifi_card_wrapper.9134afdd.css"
  },
  {
    "revision": "ea0397017a8f773eef8a",
    "url": "/js/mifi_card_wrapper.8d1acc0c.js"
  },
  {
    "revision": "ef3db805e76570168dd4",
    "url": "/css/mifi_change_network.35493f66.css"
  },
  {
    "revision": "ef3db805e76570168dd4",
    "url": "/js/mifi_change_network.d0581a78.js"
  },
  {
    "revision": "f6a3076af748ae60741d",
    "url": "/css/mifi_coupon_index.64e0f7c2.css"
  },
  {
    "revision": "f6a3076af748ae60741d",
    "url": "/js/mifi_coupon_index.29bd576e.js"
  },
  {
    "revision": "ea994b4592c341a64f14",
    "url": "/css/mifi_coupon_wrapper.8b393e56.css"
  },
  {
    "revision": "ea994b4592c341a64f14",
    "url": "/js/mifi_coupon_wrapper.eca902c1.js"
  },
  {
    "revision": "e91e0d212ac6181047c9",
    "url": "/css/mifi_index.f1add01c.css"
  },
  {
    "revision": "e91e0d212ac6181047c9",
    "url": "/js/mifi_index.e52db31b.js"
  },
  {
    "revision": "96aedf723902e0f3438c",
    "url": "/css/mifi_layout.69f1d346.css"
  },
  {
    "revision": "96aedf723902e0f3438c",
    "url": "/js/mifi_layout.f91454ab.js"
  },
  {
    "revision": "9249c060477d4bd519f1",
    "url": "/css/mifi_order.73477860.css"
  },
  {
    "revision": "9249c060477d4bd519f1",
    "url": "/js/mifi_order.817737af.js"
  },
  {
    "revision": "9d35cfac4afd5c4afecf",
    "url": "/css/mifi_order_wrapper.d572d9dd.css"
  },
  {
    "revision": "9d35cfac4afd5c4afecf",
    "url": "/js/mifi_order_wrapper.9f3cb832.js"
  },
  {
    "revision": "0e3374b5b87d7be5ae97",
    "url": "/css/mifi_order~mifi_plan_group.649e1a31.css"
  },
  {
    "revision": "0e3374b5b87d7be5ae97",
    "url": "/js/mifi_order~mifi_plan_group.2b2aed2a.js"
  },
  {
    "revision": "73f25c65445674d91b94",
    "url": "/css/mifi_plan_group.f31fd3cc.css"
  },
  {
    "revision": "73f25c65445674d91b94",
    "url": "/js/mifi_plan_group.3bed64a6.js"
  },
  {
    "revision": "4a6348b077a62b6c063d",
    "url": "/css/mifi_plan_list.c16e50c4.css"
  },
  {
    "revision": "4a6348b077a62b6c063d",
    "url": "/js/mifi_plan_list.d371c749.js"
  },
  {
    "revision": "b7a1a6681eff2e16a665",
    "url": "/css/mifi_plan_usage.0d8003f8.css"
  },
  {
    "revision": "b7a1a6681eff2e16a665",
    "url": "/js/mifi_plan_usage.15c26dee.js"
  },
  {
    "revision": "2aceb9979f5c7596abba",
    "url": "/css/mifi_plan_wrapper.ad5b72f4.css"
  },
  {
    "revision": "2aceb9979f5c7596abba",
    "url": "/js/mifi_plan_wrapper.fd737b35.js"
  },
  {
    "revision": "139cf8d7765bde2f6eda",
    "url": "/css/new_card_wrapper.907108b0.css"
  },
  {
    "revision": "139cf8d7765bde2f6eda",
    "url": "/js/new_card_wrapper.58d4a208.js"
  },
  {
    "revision": "d113a01505c7ad2d196f",
    "url": "/css/orderRecord.cb4c1771.css"
  },
  {
    "revision": "d113a01505c7ad2d196f",
    "url": "/js/orderRecord.03a64ea9.js"
  },
  {
    "revision": "3d22d21c3cdde3770852",
    "url": "/css/plan_list.617d3e3f.css"
  },
  {
    "revision": "3d22d21c3cdde3770852",
    "url": "/js/plan_list.990f9649.js"
  },
  {
    "revision": "afd3e635e4c9a34971f2",
    "url": "/css/question.5419972b.css"
  },
  {
    "revision": "afd3e635e4c9a34971f2",
    "url": "/js/question.1f4ac23b.js"
  },
  {
    "revision": "a06f700330835789736e",
    "url": "/css/question_wrapper.09148f29.css"
  },
  {
    "revision": "a06f700330835789736e",
    "url": "/js/question_wrapper.e8fa6249.js"
  },
  {
    "revision": "714331461528f3d2deeb",
    "url": "/css/realNameCourse.c4765d59.css"
  },
  {
    "revision": "714331461528f3d2deeb",
    "url": "/js/realNameCourse.d640f54e.js"
  },
  {
    "revision": "7b6021347234afb4eaef",
    "url": "/css/real_name.d1375355.css"
  },
  {
    "revision": "7b6021347234afb4eaef",
    "url": "/js/real_name.7734cc59.js"
  },
  {
    "revision": "b4161ab65bcedc73ede2",
    "url": "/css/recharge.7de4fb68.css"
  },
  {
    "revision": "b4161ab65bcedc73ede2",
    "url": "/js/recharge.c88bd6e8.js"
  },
  {
    "revision": "bf22d99e9ae3debb876b",
    "url": "/css/recharge_callback.4776b260.css"
  },
  {
    "revision": "685f36a61c6b9388424d",
    "url": "/js/Layout.7e2130a0.js"
  },
  {
    "revision": "be40bca99df105cbae95",
    "url": "/js/Layout~card_usage.bcf0ce41.js"
  },
  {
    "revision": "9feffacd2b7a96a33fbf",
    "url": "/js/recharge_wrapper.9aba0f17.js"
  },
  {
    "revision": "b4b5c899c1dfaaaab89c",
    "url": "/css/refund_applying.a1718859.css"
  },
  {
    "revision": "b4b5c899c1dfaaaab89c",
    "url": "/js/refund_applying.5b1dac3d.js"
  },
  {
    "revision": "6d4a8182771ea3a147fc",
    "url": "/css/refund_argument.69661661.css"
  },
  {
    "revision": "6d4a8182771ea3a147fc",
    "url": "/js/refund_argument.472e4804.js"
  },
  {
    "revision": "20c3adedf4f2e93c7b24",
    "url": "/css/refund_plan.3c4d35cb.css"
  },
  {
    "revision": "20c3adedf4f2e93c7b24",
    "url": "/js/refund_plan.719ed969.js"
  },
  {
    "revision": "18f3a926060dcd5647ed",
    "url": "/css/refund_wrapper.2ce7ebad.css"
  },
  {
    "revision": "18f3a926060dcd5647ed",
    "url": "/js/refund_wrapper.4b26b5da.js"
  },
  {
    "revision": "764eadab58a95f8615b5",
    "url": "/css/repeatRecharge.15a3a6c8.css"
  },
  {
    "revision": "764eadab58a95f8615b5",
    "url": "/js/repeatRecharge.69d94be2.js"
  },
  {
    "revision": "5caeef11dbc4ab1cf75d",
    "url": "/css/revoke_plan.9d99e5a9.css"
  },
  {
    "revision": "5caeef11dbc4ab1cf75d",
    "url": "/js/revoke_plan.0bc53abc.js"
  },
  {
    "revision": "17b5460fa75946976c5a",
    "url": "/css/speedup_500.863f4cd3.css"
  },
  {
    "revision": "17b5460fa75946976c5a",
    "url": "/js/speedup_500.de96363b.js"
  },
  {
    "revision": "8129ab8b0c8f3a950de7",
    "url": "/css/speedup_80.d0292630.css"
  },
  {
    "revision": "8129ab8b0c8f3a950de7",
    "url": "/js/speedup_80.fcdfb3a7.js"
  },
  {
    "revision": "e8e646590c22cdecfe1f",
    "url": "/css/speedup_wrapper.69b3dda0.css"
  },
  {
    "revision": "e8e646590c22cdecfe1f",
    "url": "/js/speedup_wrapper.27f3dbaf.js"
  },
  {
    "revision": "fe766970aea5c772c011",
    "url": "/css/to_tb.96081c85.css"
  },
  {
    "revision": "fe766970aea5c772c011",
    "url": "/js/to_tb.2f6b2df6.js"
  },
  {
    "revision": "e317578793049d60e65f",
    "url": "/css/transfer_url.302c6a25.css"
  },
  {
    "revision": "e317578793049d60e65f",
    "url": "/js/transfer_url.20f0662b.js"
  },
  {
    "revision": "35d71b7abf18d6ace4b9",
    "url": "/css/userCenter.67e59211.css"
  },
  {
    "revision": "35d71b7abf18d6ace4b9",
    "url": "/js/userCenter.dc0a0ea0.js"
  },
  {
    "revision": "f85675de49038c151bda",
    "url": "/css/userCenterWrap.695b26f2.css"
  },
  {
    "revision": "f85675de49038c151bda",
    "url": "/js/userCenterWrap.9524d1f6.js"
  },
  {
    "revision": "e4b411644706c29765eea3ffdd85ae39",
    "url": "/fonts/SourceHanSansCNRegular.e4b41164.woff"
  },
  {
    "revision": "834b022ab9ab0e6063904af32274e777",
    "url": "/fonts/SourceHanSansCNRegular.834b022a.eot"
  },
  {
    "revision": "f9509c5a10be7daaf1fa01922a7c6bc2",
    "url": "/fonts/SourceHanSansCNRegular.f9509c5a.ttf"
  },
  {
    "revision": "da0808e9fe85be160aab69c82dd8de1c",
    "url": "/img/SourceHanSansCNRegular.da0808e9.svg"
  },
  {
    "revision": "732389ded34cb9c52dd88271f1345af9",
    "url": "/fonts/element-icons.732389de.ttf"
  },
  {
    "revision": "535877f50039c0cb49a6196a5b7517cd",
    "url": "/fonts/element-icons.535877f5.woff"
  },
  {
    "revision": "0078f03c08066d51d64b92a13e194ebb",
    "url": "/img/balanceRefund.0078f03c.png"
  },
  {
    "revision": "af3ed0b3236bbfdbc3ad61b8d41c3dec",
    "url": "/img/changeBg.af3ed0b3.png"
  },
  {
    "revision": "6e5cee7393060b0ec3dcd587c2518b94",
    "url": "/img/bg_test.6e5cee73.png"
  },
  {
    "revision": "42c0fbd4915870e5e60452fd0ef2cbec",
    "url": "/img/orderTopBg@3x.42c0fbd4.png"
  },
  {
    "revision": "42c0fbd4915870e5e60452fd0ef2cbec",
    "url": "/img/orderTopBg@2x.42c0fbd4.png"
  },
  {
    "revision": "fff5af4325410621aeec4e60b3b92d9b",
    "url": "/img/mifi_binding_bg@3x.fff5af43.png"
  },
  {
    "revision": "fff5af4325410621aeec4e60b3b92d9b",
    "url": "/img/mifi_binding_bg@2x.fff5af43.png"
  },
  {
    "revision": "f5f322478286641bd9887a155e35f222",
    "url": "/img/btn.f5f32247.png"
  },
  {
    "revision": "d140650fa64e0f1fc771610dba62aed7",
    "url": "/img/bg.d140650f.png"
  },
  {
    "revision": "e625229e32d9deeb5f2909c314d8e609",
    "url": "/img/ios@2x.e625229e.png"
  },
  {
    "revision": "af8bbdfa0a90c4eed4563f8c06ce5ff8",
    "url": "/img/android@2x.af8bbdfa.png"
  },
  {
    "revision": "b899232b79ad9962c5ab5572775a0400",
    "url": "/img/card_index_bg@3x.b899232b.png"
  },
  {
    "revision": "b899232b79ad9962c5ab5572775a0400",
    "url": "/img/card_index_bg@2x.b899232b.png"
  },
  {
    "revision": "1d7515ee61c3f659227318b4050955ed",
    "url": "/img/mobile_sim@2x.1d7515ee.png"
  },
  {
    "revision": "0f980b79d9a52702004de9f652a68835",
    "url": "/img/telcom_sim@2x.0f980b79.png"
  },
  {
    "revision": "98141226a7e992e3072a280746a259c4",
    "url": "/img/mobile_sim@3x.98141226.png"
  },
  {
    "revision": "0c88168b284b92c37f3a873f26a97d69",
    "url": "/img/bg.0c88168b.jpg"
  },
  {
    "revision": "9e02095f31a07b972244f1c714c1dfe7",
    "url": "/img/telcom_sim@3x.9e02095f.png"
  },
  {
    "revision": "b70eddccd257b21777e71bb64c83b876",
    "url": "/img/bg.b70eddcc.jpeg"
  },
  {
    "revision": "909816c3d34e63a9ad86b8c179ab543c",
    "url": "/img/bar.909816c3.png"
  },
  {
    "revision": "e92f547ba0209da3b4342fa2b56ea9ae",
    "url": "/img/animater.e92f547b.png"
  },
  {
    "revision": "2c51a1e53c1ea0b35086d8d7261b4933",
    "url": "/img/bg_network@3x.2c51a1e5.png"
  },
  {
    "revision": "32d70c8fc305e3647098f3de0c71b618",
    "url": "/img/bg_network@2x.32d70c8f.png"
  },
  {
    "revision": "3f342771b9b81ab929e0fbcbcd0e6533",
    "url": "/img/bg-check-wrap@3x.3f342771.png"
  },
  {
    "revision": "9713b21819c4019befecd095069977df",
    "url": "/img/bg-check-wrap@2x.9713b218.png"
  },
  {
    "revision": "3d0fc424b703032ca595090e99f8354b",
    "url": "/img/login_bg@2x.3d0fc424.png"
  },
  {
    "revision": "11000d4e510a6df565eb69ba6f2c1dfc",
    "url": "/img/login_bg@3x.11000d4e.png"
  },
  {
    "revision": "91e1d2771efacd45e5e465d9a001f197",
    "url": "/img/liantong.91e1d277.png"
  },
  {
    "revision": "4a0cab0f33beb48ea985714d1b91fef7",
    "url": "/img/dianxin.4a0cab0f.png"
  },
  {
    "revision": "657033323334e91efb0011bbc18f8c04",
    "url": "/img/yidong.65703332.png"
  },
  {
    "revision": "8da3b83b73e44e54d6be4b2522bcb1f2",
    "url": "/img/pkgBg2.8da3b83b.png"
  },
  {
    "revision": "d3b42651f9f5048baeffb50c800913ec",
    "url": "/img/pkgBg1.d3b42651.png"
  },
  {
    "revision": "d461d18e42a310bd709b2ce97d159153",
    "url": "/img/pkgBg3.d461d18e.png"
  },
  {
    "revision": "014d354b9b25b67ae95857ba17e2f4cc",
    "url": "/img/activityPage.014d354b.png"
  },
  {
    "revision": "2a67b73145562669220aa4639e1ad58f",
    "url": "/img/icon3.2a67b731.png"
  },
  {
    "revision": "813b5319e378dafdda952c16ad89906b",
    "url": "/img/icon2.813b5319.png"
  },
  {
    "revision": "6dedd4943e4c5848638196fb6f0c4145",
    "url": "/img/bg.6dedd494.png"
  },
  {
    "revision": "01355f175bd20423ce45a838c1a998a9",
    "url": "/img/bg.01355f17.png"
  },
  {
    "revision": "a859e9ca4606d567c42b9c7bcd4fdce9",
    "url": "/img/iccid_bg@2x.a859e9ca.png"
  },
  {
    "revision": "fa9050c4e9870e8fc0cd184f8515af4a",
    "url": "/img/iccid_bg@3x.fa9050c4.png"
  },
  {
    "revision": "114a6e12b42b9b48586dd341105188fe",
    "url": "/img/usedOrder@2x.114a6e12.png"
  },
  {
    "revision": "c0170ec299b2418256fd515ee7849055",
    "url": "/img/unUsedOrder@2x.c0170ec2.png"
  },
  {
    "revision": "d9e14058d30dd312519fcf2de38d742b",
    "url": "/img/unUsedOrder@3x.d9e14058.png"
  },
  {
    "revision": "4a5b90f8076955f289b3dcda6a5af6ff",
    "url": "/img/invaildedOrder@3x.4a5b90f8.png"
  },
  {
    "revision": "0d5a5158e67bcb7a4604124715ed6fbf",
    "url": "/img/usedOrder@3x.0d5a5158.png"
  },
  {
    "revision": "be0f1e33b2553e71b117d3d3f838d32f",
    "url": "/img/invaildedOrder@2x.be0f1e33.png"
  },
  {
    "revision": "3603a35a49dbb8ad94ec1e57c4dad229",
    "url": "/img/scanTop2.3603a35a.png"
  },
  {
    "revision": "05775dd69c53d7273b27aaa7c6c523f7",
    "url": "/img/04.05775dd6.png"
  },
  {
    "revision": "5a3428653945c17e1c146efeee81c987",
    "url": "/img/scanTop.5a342865.png"
  },
  {
    "revision": "824594523c01e48028f2b7eb4261134d",
    "url": "/img/unicom-logo.82459452.svg"
  },
  {
    "revision": "113f99e2189c2ca49db2168754fc2eb5",
    "url": "/img/mobile-logo.113f99e2.png"
  },
  {
    "revision": "0cba868fa977e09806638b9000636a36",
    "url": "/img/avatar.0cba868f.jpeg"
  },
  {
    "revision": "27158aa79eb0d4b89f317d076a801ca3",
    "url": "/img/coupon-log.27158aa7.png"
  },
  {
    "revision": "55d3f2f09efe17db6485d4c9f8f0c3b1",
    "url": "/img/icon-recharge_20181001.55d3f2f0.svg"
  },
  {
    "revision": "165beb68d8ba0d2b70df0fbb3769787a",
    "url": "/img/03.165beb68.png"
  },
  {
    "revision": "5f1f34037094c0613bccafa2ddd8cb3b",
    "url": "/img/telecom-logo.5f1f3403.svg"
  },
  {
    "revision": "0b3c3297decbd1152a314cce115f9632",
    "url": "/img/09.0b3c3297.png"
  },
  {
    "revision": "644e6e3cf5f33943747b116316694e28",
    "url": "/img/noData@2x.644e6e3c.png"
  },
  {
    "revision": "aecc9531f2c3b1fd45338e7bf5084384",
    "url": "/img/bg_no_recharge.aecc9531.svg"
  },
  {
    "revision": "b0ffa4a0fd195a110ee4d4dabce3bc32",
    "url": "/img/08.b0ffa4a0.png"
  },
  {
    "revision": "96fab583abd57f2e7118324858fa3080",
    "url": "/img/05.96fab583.png"
  },
  {
    "revision": "275be51ae57c486bce58257febd6589f",
    "url": "/img/bg_no_plan.275be51a.svg"
  },
  {
    "revision": "a8272d2d742d9d50257e23dfac577def",
    "url": "/img/01.a8272d2d.png"
  },
  {
    "revision": "daa86b540bb9c2a6453ceac9bed77961",
    "url": "/img/07.daa86b54.png"
  },
  {
    "revision": "06385746a7cedb492d5539907631561c",
    "url": "/img/tip.06385746.png"
  },
  {
    "revision": "eacba58f9acf2b87cd801858146b2ba9",
    "url": "/img/02.eacba58f.png"
  },
  {
    "revision": "39d9e849fc1c724525f166646932a24d",
    "url": "/img/safari.39d9e849.png"
  },
  {
    "revision": "999589aae784a460b5e7c6ae9bbaa3d8",
    "url": "/img/06.999589aa.png"
  },
  {
    "revision": "707a0ca1797e73fe94ad668c95d33919",
    "url": "/index.html"
  },
  {
    "revision": "685f36a61c6b9388424d",
    "url": "/css/Layout.83a36cb0.css"
  },
  {
    "revision": "9ce16f441b39b493af8b96d7e97cce22",
    "url": "/MP_verify_dkzAKjxyVyJvsHMS.txt"
  },
  {
    "revision": "86c422d8c98b247235d04b49fb1c4b05",
    "url": "/MP_verify_bKSdn2qZlUSULliu.txt"
  },
  {
    "revision": "652317b098ca24e4511926c7fd57cbbe",
    "url": "/MP_verify_8JoCCldW78DygS5c.txt"
  },
  {
    "revision": "00bbf6b458bf7ea6bd01f443eb3045d9",
    "url": "/MP_verify_4r3DVk3KUjgWsQsG.txt"
  }
];