self.__precacheManifest = [
  {
    "revision": "23aed03f74c2bfa4c58c",
    "url": "/js/refund_applying.a5de4e14.js"
  },
  {
    "revision": "3c0f71c3789cb13f0099",
    "url": "/css/Layout.f4abf345.css"
  },
  {
    "revision": "78214ba34c5f1df936aa",
    "url": "/js/Layout~card_usage~eqReplaceMent~esim_plan_list~esim_usage~mifi_order~mifi_plan_list~mifi_plan_usage~~c6f87c36.6241bd21.js"
  },
  {
    "revision": "f5272b20fc3ef4afb968",
    "url": "/css/Not_fund.72da8db7.css"
  },
  {
    "revision": "f5272b20fc3ef4afb968",
    "url": "/js/Not_fund.2401c79b.js"
  },
  {
    "revision": "d3e4473d047924d38040",
    "url": "/css/app.bec1065c.css"
  },
  {
    "revision": "d3e4473d047924d38040",
    "url": "/js/app.4140e970.js"
  },
  {
    "revision": "f67ace8d41137d17afa8",
    "url": "/css/authority_middle.f79c5b9c.css"
  },
  {
    "revision": "f67ace8d41137d17afa8",
    "url": "/js/authority_middle.e36a0d9c.js"
  },
  {
    "revision": "07a23b335798c452f8d3",
    "url": "/css/balanceIndex.d16bbc55.css"
  },
  {
    "revision": "07a23b335798c452f8d3",
    "url": "/js/balanceIndex.72735a08.js"
  },
  {
    "revision": "7d91553405c0998765f5",
    "url": "/css/balanceRefund.bae13223.css"
  },
  {
    "revision": "7d91553405c0998765f5",
    "url": "/js/balanceRefund.fe4cdeeb.js"
  },
  {
    "revision": "205ce6935c20788c7ff3",
    "url": "/css/cardPackage.f411c4c7.css"
  },
  {
    "revision": "205ce6935c20788c7ff3",
    "url": "/js/cardPackage.81b40c7d.js"
  },
  {
    "revision": "ac6d62b64ef6bdf195f2",
    "url": "/css/card_check.4a120c62.css"
  },
  {
    "revision": "ac6d62b64ef6bdf195f2",
    "url": "/js/card_check.5a2f6a6c.js"
  },
  {
    "revision": "d45f4c486447a240fcc4",
    "url": "/css/card_connection.25cf05c3.css"
  },
  {
    "revision": "d45f4c486447a240fcc4",
    "url": "/js/card_connection.d075f011.js"
  },
  {
    "revision": "464fe46ec436f03e9892",
    "url": "/css/card_lookup.1ed89768.css"
  },
  {
    "revision": "464fe46ec436f03e9892",
    "url": "/js/card_lookup.2e453016.js"
  },
  {
    "revision": "a98799ab7f07d5d3acad",
    "url": "/css/card_more_flow.8624a4d3.css"
  },
  {
    "revision": "a98799ab7f07d5d3acad",
    "url": "/js/card_more_flow.fb43f1ee.js"
  },
  {
    "revision": "36092548db32a433ccec",
    "url": "/css/card_usage.55b11ed2.css"
  },
  {
    "revision": "36092548db32a433ccec",
    "url": "/js/card_usage.6e8cb077.js"
  },
  {
    "revision": "42f143d8429c65b856b4",
    "url": "/css/card_wrapper.1a8d30f5.css"
  },
  {
    "revision": "42f143d8429c65b856b4",
    "url": "/js/card_wrapper.82486d16.js"
  },
  {
    "revision": "0d8d7098e9aa159a70ce",
    "url": "/css/children_card.a04f36e4.css"
  },
  {
    "revision": "0d8d7098e9aa159a70ce",
    "url": "/js/children_card.16f0de86.js"
  },
  {
    "revision": "c3b68aa3fe1a2c0e4a16",
    "url": "/css/chunk-407ba637.46afdd67.css"
  },
  {
    "revision": "c3b68aa3fe1a2c0e4a16",
    "url": "/js/chunk-407ba637.ec1fbea6.js"
  },
  {
    "revision": "c5c2b1bc06e5fa52287c",
    "url": "/css/chunk-735bcfd4.7f43c2d2.css"
  },
  {
    "revision": "c5c2b1bc06e5fa52287c",
    "url": "/js/chunk-735bcfd4.b2a03701.js"
  },
  {
    "revision": "12033d3a67b6441affdc",
    "url": "/css/chunk-vendors.1f0d5a39.css"
  },
  {
    "revision": "12033d3a67b6441affdc",
    "url": "/js/chunk-vendors.0660135f.js"
  },
  {
    "revision": "4ef20a0df084a0607426",
    "url": "/css/commonProblem.3bf99bae.css"
  },
  {
    "revision": "4ef20a0df084a0607426",
    "url": "/js/commonProblem.4cc187b0.js"
  },
  {
    "revision": "e69988c381cd9d3fb46b",
    "url": "/css/consumerRecord.53dc3733.css"
  },
  {
    "revision": "e69988c381cd9d3fb46b",
    "url": "/js/consumerRecord.cd7d27e8.js"
  },
  {
    "revision": "fabe0f273d2dcbc018c0",
    "url": "/css/coupon_normal.1a9a5f5b.css"
  },
  {
    "revision": "fabe0f273d2dcbc018c0",
    "url": "/js/coupon_normal.aecbbd50.js"
  },
  {
    "revision": "ea1606489920e3fe0c5a",
    "url": "/css/coupon_telcom.3e944761.css"
  },
  {
    "revision": "ea1606489920e3fe0c5a",
    "url": "/js/coupon_telcom.285d2189.js"
  },
  {
    "revision": "7038396d09f71fff5727",
    "url": "/css/coupon_wrapper.ab43c2ce.css"
  },
  {
    "revision": "7038396d09f71fff5727",
    "url": "/js/coupon_wrapper.d9947991.js"
  },
  {
    "revision": "0de8169f22e87634be5f",
    "url": "/css/currencyConversion.d72fe129.css"
  },
  {
    "revision": "0de8169f22e87634be5f",
    "url": "/js/currencyConversion.54db8d98.js"
  },
  {
    "revision": "04ede0ca837310fded61",
    "url": "/css/eqReplaceMent.bfc6bc9b.css"
  },
  {
    "revision": "04ede0ca837310fded61",
    "url": "/js/eqReplaceMent.2fd22ae7.js"
  },
  {
    "revision": "51991e69f5443695c873",
    "url": "/css/eqReplaceMent~recharge.8d01bd55.css"
  },
  {
    "revision": "51991e69f5443695c873",
    "url": "/js/eqReplaceMent~recharge.a4c1fa11.js"
  },
  {
    "revision": "958d9ef7017e3216b25b",
    "url": "/css/esim_plan_list.d3c3c314.css"
  },
  {
    "revision": "958d9ef7017e3216b25b",
    "url": "/js/esim_plan_list.f6b12c74.js"
  },
  {
    "revision": "f7b7840542be83e6336a",
    "url": "/css/esim_usage.3a311fc3.css"
  },
  {
    "revision": "f7b7840542be83e6336a",
    "url": "/js/esim_usage.44d721e7.js"
  },
  {
    "revision": "7a935f680efa63986550",
    "url": "/css/find_plan.d3d20fa5.css"
  },
  {
    "revision": "7a935f680efa63986550",
    "url": "/js/find_plan.7fc9dac4.js"
  },
  {
    "revision": "9f1daa85e1aadb9fa142",
    "url": "/css/logical_page.c381c241.css"
  },
  {
    "revision": "9f1daa85e1aadb9fa142",
    "url": "/js/logical_page.61d78fcc.js"
  },
  {
    "revision": "50c550cac9acf9ff47b3",
    "url": "/css/login.db6eac3f.css"
  },
  {
    "revision": "50c550cac9acf9ff47b3",
    "url": "/js/login.9746a7fb.js"
  },
  {
    "revision": "9480e35f6cd3bf57eb2f",
    "url": "/css/lookup.a84a91e8.css"
  },
  {
    "revision": "9480e35f6cd3bf57eb2f",
    "url": "/js/lookup.f5b72bf8.js"
  },
  {
    "revision": "d31e073e2d7376841ce0",
    "url": "/css/mifi_binding.67add20d.css"
  },
  {
    "revision": "d31e073e2d7376841ce0",
    "url": "/js/mifi_binding.3e108d98.js"
  },
  {
    "revision": "974a58a865ee50933ca5",
    "url": "/css/mifi_card_info.0f451ef6.css"
  },
  {
    "revision": "974a58a865ee50933ca5",
    "url": "/js/mifi_card_info.85459f0e.js"
  },
  {
    "revision": "086f2725a51875fcf77e",
    "url": "/css/mifi_card_lookup.cdacba2e.css"
  },
  {
    "revision": "086f2725a51875fcf77e",
    "url": "/js/mifi_card_lookup.2b475267.js"
  },
  {
    "revision": "08c47ed3f14843a5c035",
    "url": "/css/mifi_card_wrapper.0b1217f1.css"
  },
  {
    "revision": "08c47ed3f14843a5c035",
    "url": "/js/mifi_card_wrapper.42ff2c5e.js"
  },
  {
    "revision": "6a10f45c79c80b7b9543",
    "url": "/css/mifi_change_network.e15b9cf5.css"
  },
  {
    "revision": "6a10f45c79c80b7b9543",
    "url": "/js/mifi_change_network.94fa0b4c.js"
  },
  {
    "revision": "91289c729a581a00df9b",
    "url": "/css/mifi_change_network_explanation.f0e40b07.css"
  },
  {
    "revision": "91289c729a581a00df9b",
    "url": "/js/mifi_change_network_explanation.8d7f9c55.js"
  },
  {
    "revision": "7eb20d47eaa79f9ef0f0",
    "url": "/css/mifi_coupon_index.cea2c044.css"
  },
  {
    "revision": "7eb20d47eaa79f9ef0f0",
    "url": "/js/mifi_coupon_index.8deef76d.js"
  },
  {
    "revision": "714120d65d5bf65a3574",
    "url": "/css/mifi_coupon_wrapper.10042735.css"
  },
  {
    "revision": "714120d65d5bf65a3574",
    "url": "/js/mifi_coupon_wrapper.5f7a1b35.js"
  },
  {
    "revision": "48ebe5a8821e2a40b35e",
    "url": "/css/mifi_index.6c2f719e.css"
  },
  {
    "revision": "48ebe5a8821e2a40b35e",
    "url": "/js/mifi_index.ba1a3e93.js"
  },
  {
    "revision": "5f2b8b983426294c1f97",
    "url": "/css/mifi_layout.63b8c424.css"
  },
  {
    "revision": "5f2b8b983426294c1f97",
    "url": "/js/mifi_layout.879d37c8.js"
  },
  {
    "revision": "0248a069a35b37e01cc6",
    "url": "/css/mifi_order.05cdaf6f.css"
  },
  {
    "revision": "0248a069a35b37e01cc6",
    "url": "/js/mifi_order.c062af0e.js"
  },
  {
    "revision": "852587c9d0e89f170b0e",
    "url": "/css/mifi_order_wrapper.80fa7896.css"
  },
  {
    "revision": "852587c9d0e89f170b0e",
    "url": "/js/mifi_order_wrapper.6f299b08.js"
  },
  {
    "revision": "7e6ebca780ef36494bd1",
    "url": "/css/mifi_plan_group.0a8ea863.css"
  },
  {
    "revision": "7e6ebca780ef36494bd1",
    "url": "/js/mifi_plan_group.2d48a920.js"
  },
  {
    "revision": "19a7288ec24c97936e99",
    "url": "/css/mifi_plan_list.409ba955.css"
  },
  {
    "revision": "19a7288ec24c97936e99",
    "url": "/js/mifi_plan_list.28b68633.js"
  },
  {
    "revision": "29b1d31e6d80577d8976",
    "url": "/css/mifi_plan_usage.e89a7986.css"
  },
  {
    "revision": "29b1d31e6d80577d8976",
    "url": "/js/mifi_plan_usage.b5bbf1f4.js"
  },
  {
    "revision": "b6a63be718bdbbe51623",
    "url": "/css/mifi_plan_wrapper.32f1c95d.css"
  },
  {
    "revision": "b6a63be718bdbbe51623",
    "url": "/js/mifi_plan_wrapper.9c8f6004.js"
  },
  {
    "revision": "2904cc856e9d9c7f0ad0",
    "url": "/css/new_card_wrapper.06a280b2.css"
  },
  {
    "revision": "2904cc856e9d9c7f0ad0",
    "url": "/js/new_card_wrapper.d31483c4.js"
  },
  {
    "revision": "518d96a21f08afdf44e4",
    "url": "/css/orderRecord.77e929db.css"
  },
  {
    "revision": "518d96a21f08afdf44e4",
    "url": "/js/orderRecord.50b76159.js"
  },
  {
    "revision": "90bae11c7e7cf4487dfe",
    "url": "/css/plan_list.17e9ad66.css"
  },
  {
    "revision": "90bae11c7e7cf4487dfe",
    "url": "/js/plan_list.6f38d65b.js"
  },
  {
    "revision": "9bfb96967949d560c1fa",
    "url": "/css/question.7ff32912.css"
  },
  {
    "revision": "9bfb96967949d560c1fa",
    "url": "/js/question.d92a19f6.js"
  },
  {
    "revision": "1acbee19d867489d1a91",
    "url": "/css/question_wrapper.80b62e54.css"
  },
  {
    "revision": "1acbee19d867489d1a91",
    "url": "/js/question_wrapper.2cffb5aa.js"
  },
  {
    "revision": "fb61549c5e821dcfc0f9",
    "url": "/css/realNameCourse.dee117a2.css"
  },
  {
    "revision": "fb61549c5e821dcfc0f9",
    "url": "/js/realNameCourse.1e607d04.js"
  },
  {
    "revision": "e9e1a6713f97a2aa6d5a",
    "url": "/css/real_name.2fd595b9.css"
  },
  {
    "revision": "e9e1a6713f97a2aa6d5a",
    "url": "/js/real_name.a912e6f2.js"
  },
  {
    "revision": "6e19231107acaf037a25",
    "url": "/css/recharge.b9b2fac5.css"
  },
  {
    "revision": "6e19231107acaf037a25",
    "url": "/js/recharge.265960d9.js"
  },
  {
    "revision": "c002d40e54e1e4f8b9f3",
    "url": "/css/rechargeOrder.88336c82.css"
  },
  {
    "revision": "c002d40e54e1e4f8b9f3",
    "url": "/js/rechargeOrder.5d2ca952.js"
  },
  {
    "revision": "44663c912455bdec93d0",
    "url": "/css/recharge_balance.f2a766d8.css"
  },
  {
    "revision": "44663c912455bdec93d0",
    "url": "/js/recharge_balance.89f6a778.js"
  },
  {
    "revision": "23fbd5de25c56b9bfb19",
    "url": "/css/recharge_callback.c33c36e5.css"
  },
  {
    "revision": "23fbd5de25c56b9bfb19",
    "url": "/js/recharge_callback.df8958f9.js"
  },
  {
    "revision": "51707c33c67bebea78fe",
    "url": "/css/recharge_wrapper.e8ef40fd.css"
  },
  {
    "revision": "51707c33c67bebea78fe",
    "url": "/js/recharge_wrapper.5cb97f54.js"
  },
  {
    "revision": "982454399f93bbd81639",
    "url": "/css/refundRules.23881fab.css"
  },
  {
    "revision": "982454399f93bbd81639",
    "url": "/js/refundRules.8f7a8b9c.js"
  },
  {
    "revision": "23aed03f74c2bfa4c58c",
    "url": "/css/refund_applying.fbc44f97.css"
  },
  {
    "revision": "3c0f71c3789cb13f0099",
    "url": "/js/Layout.ec8440e6.js"
  },
  {
    "revision": "740ade7e29b4bd86600b",
    "url": "/css/refund_argument.0b731303.css"
  },
  {
    "revision": "740ade7e29b4bd86600b",
    "url": "/js/refund_argument.bba193b9.js"
  },
  {
    "revision": "9b41905223784dc20d68",
    "url": "/css/refund_plan.871a365e.css"
  },
  {
    "revision": "9b41905223784dc20d68",
    "url": "/js/refund_plan.1fb6ccfc.js"
  },
  {
    "revision": "eddc8d97644598036c3a",
    "url": "/css/refund_wrapper.fd3df4db.css"
  },
  {
    "revision": "eddc8d97644598036c3a",
    "url": "/js/refund_wrapper.4796da4f.js"
  },
  {
    "revision": "7e012432437e0d328c8f",
    "url": "/css/repeatRecharge.0d98eb50.css"
  },
  {
    "revision": "7e012432437e0d328c8f",
    "url": "/js/repeatRecharge.2e7898a0.js"
  },
  {
    "revision": "e4b29a8b9acebd4aa6c9",
    "url": "/css/revoke_plan.854f8912.css"
  },
  {
    "revision": "e4b29a8b9acebd4aa6c9",
    "url": "/js/revoke_plan.4b0aeb6a.js"
  },
  {
    "revision": "777e19ccab4e5e34fcc5",
    "url": "/css/speedup_500.653f81f5.css"
  },
  {
    "revision": "777e19ccab4e5e34fcc5",
    "url": "/js/speedup_500.f5d808c9.js"
  },
  {
    "revision": "8031b5d6b4cc96e14594",
    "url": "/css/speedup_80.0b0c3ab6.css"
  },
  {
    "revision": "8031b5d6b4cc96e14594",
    "url": "/js/speedup_80.3b6fdb5e.js"
  },
  {
    "revision": "c4b5be14c484e98e12e1",
    "url": "/css/speedup_wrapper.707898e1.css"
  },
  {
    "revision": "c4b5be14c484e98e12e1",
    "url": "/js/speedup_wrapper.b4674906.js"
  },
  {
    "revision": "e29b677a87cb07894c07",
    "url": "/css/to_tb.03eb33ae.css"
  },
  {
    "revision": "e29b677a87cb07894c07",
    "url": "/js/to_tb.a389dd04.js"
  },
  {
    "revision": "92f6f59d00247bfc8061",
    "url": "/css/transfer_url.99834881.css"
  },
  {
    "revision": "92f6f59d00247bfc8061",
    "url": "/js/transfer_url.b023d799.js"
  },
  {
    "revision": "3215e8b368908597cded",
    "url": "/css/userCenter.456f45d8.css"
  },
  {
    "revision": "3215e8b368908597cded",
    "url": "/js/userCenter.a9a314b5.js"
  },
  {
    "revision": "23d114c7944fbfb85f1c",
    "url": "/css/userCenterWrap.636ae42d.css"
  },
  {
    "revision": "23d114c7944fbfb85f1c",
    "url": "/js/userCenterWrap.8bada249.js"
  },
  {
    "revision": "e4b411644706c29765eea3ffdd85ae39",
    "url": "/fonts/SourceHanSansCNRegular.e4b41164.woff"
  },
  {
    "revision": "834b022ab9ab0e6063904af32274e777",
    "url": "/fonts/SourceHanSansCNRegular.834b022a.eot"
  },
  {
    "revision": "f9509c5a10be7daaf1fa01922a7c6bc2",
    "url": "/fonts/SourceHanSansCNRegular.f9509c5a.ttf"
  },
  {
    "revision": "da0808e9fe85be160aab69c82dd8de1c",
    "url": "/img/SourceHanSansCNRegular.da0808e9.svg"
  },
  {
    "revision": "732389ded34cb9c52dd88271f1345af9",
    "url": "/fonts/element-icons.732389de.ttf"
  },
  {
    "revision": "535877f50039c0cb49a6196a5b7517cd",
    "url": "/fonts/element-icons.535877f5.woff"
  },
  {
    "revision": "0f16389ec218c90cf8f657e233b745f2",
    "url": "/img/balanceBg1.0f16389e.png"
  },
  {
    "revision": "565459ef2ee8b71db421144ad21c23e3",
    "url": "/img/balanceBg2.565459ef.png"
  },
  {
    "revision": "fff5af4325410621aeec4e60b3b92d9b",
    "url": "/img/mifi_binding_bg@3x.fff5af43.png"
  },
  {
    "revision": "fff5af4325410621aeec4e60b3b92d9b",
    "url": "/img/mifi_binding_bg@2x.fff5af43.png"
  },
  {
    "revision": "b899232b79ad9962c5ab5572775a0400",
    "url": "/img/card_index_bg@3x.b899232b.png"
  },
  {
    "revision": "b899232b79ad9962c5ab5572775a0400",
    "url": "/img/card_index_bg@2x.b899232b.png"
  },
  {
    "revision": "f5f322478286641bd9887a155e35f222",
    "url": "/img/btn.f5f32247.png"
  },
  {
    "revision": "d140650fa64e0f1fc771610dba62aed7",
    "url": "/img/bg.d140650f.png"
  },
  {
    "revision": "e625229e32d9deeb5f2909c314d8e609",
    "url": "/img/ios@2x.e625229e.png"
  },
  {
    "revision": "af8bbdfa0a90c4eed4563f8c06ce5ff8",
    "url": "/img/android@2x.af8bbdfa.png"
  },
  {
    "revision": "cc0636ca2944024fd3ebf33a5412ff35",
    "url": "/img/icon-right@3x.cc0636ca.png"
  },
  {
    "revision": "1b983020cfed6b7a8ca5c300c24ca186",
    "url": "/img/icon-left@3x.1b983020.png"
  },
  {
    "revision": "d796d97eb9ebb2e89bb966343e2362e9",
    "url": "/img/icon-left@2x.d796d97e.png"
  },
  {
    "revision": "ccb9865dadbc642b8c4dd0a1abc8e570",
    "url": "/img/recharge-word@2x.ccb9865d.png"
  },
  {
    "revision": "ccb9865dadbc642b8c4dd0a1abc8e570",
    "url": "/img/recharge-word@3x.ccb9865d.png"
  },
  {
    "revision": "41a8c268f703fe646d5d08099eb778ae",
    "url": "/img/icon-right@2x.41a8c268.png"
  },
  {
    "revision": "2d6d06f4da15fc1a748677c49c5f1854",
    "url": "/img/bg.2d6d06f4.png"
  },
  {
    "revision": "1d7515ee61c3f659227318b4050955ed",
    "url": "/img/mobile_sim@2x.1d7515ee.png"
  },
  {
    "revision": "0f980b79d9a52702004de9f652a68835",
    "url": "/img/telcom_sim@2x.0f980b79.png"
  },
  {
    "revision": "98141226a7e992e3072a280746a259c4",
    "url": "/img/mobile_sim@3x.98141226.png"
  },
  {
    "revision": "0c88168b284b92c37f3a873f26a97d69",
    "url": "/img/bg.0c88168b.jpg"
  },
  {
    "revision": "9e02095f31a07b972244f1c714c1dfe7",
    "url": "/img/telcom_sim@3x.9e02095f.png"
  },
  {
    "revision": "3f342771b9b81ab929e0fbcbcd0e6533",
    "url": "/img/bg-check-wrap@3x.3f342771.png"
  },
  {
    "revision": "9713b21819c4019befecd095069977df",
    "url": "/img/bg-check-wrap@2x.9713b218.png"
  },
  {
    "revision": "fa855242805b87da42c65763acd64ac0",
    "url": "/img/bg-plan-type@2x.fa855242.png"
  },
  {
    "revision": "4a9ca192485effa8b8f4b5b2df5b9caf",
    "url": "/img/bg-plan-type@3x.4a9ca192.png"
  },
  {
    "revision": "3d0fc424b703032ca595090e99f8354b",
    "url": "/img/login_bg@2x.3d0fc424.png"
  },
  {
    "revision": "11000d4e510a6df565eb69ba6f2c1dfc",
    "url": "/img/login_bg@3x.11000d4e.png"
  },
  {
    "revision": "91e1d2771efacd45e5e465d9a001f197",
    "url": "/img/liantong.91e1d277.png"
  },
  {
    "revision": "4a0cab0f33beb48ea985714d1b91fef7",
    "url": "/img/dianxin.4a0cab0f.png"
  },
  {
    "revision": "657033323334e91efb0011bbc18f8c04",
    "url": "/img/yidong.65703332.png"
  },
  {
    "revision": "8da3b83b73e44e54d6be4b2522bcb1f2",
    "url": "/img/pkgBg2.8da3b83b.png"
  },
  {
    "revision": "d3b42651f9f5048baeffb50c800913ec",
    "url": "/img/pkgBg1.d3b42651.png"
  },
  {
    "revision": "d461d18e42a310bd709b2ce97d159153",
    "url": "/img/pkgBg3.d461d18e.png"
  },
  {
    "revision": "6dedd4943e4c5848638196fb6f0c4145",
    "url": "/img/bg.6dedd494.png"
  },
  {
    "revision": "2a67b73145562669220aa4639e1ad58f",
    "url": "/img/icon3.2a67b731.png"
  },
  {
    "revision": "813b5319e378dafdda952c16ad89906b",
    "url": "/img/icon2.813b5319.png"
  },
  {
    "revision": "0078f03c08066d51d64b92a13e194ebb",
    "url": "/img/balanceRefund.0078f03c.png"
  },
  {
    "revision": "af3ed0b3236bbfdbc3ad61b8d41c3dec",
    "url": "/img/changeBg.af3ed0b3.png"
  },
  {
    "revision": "014d354b9b25b67ae95857ba17e2f4cc",
    "url": "/img/activityPage.014d354b.png"
  },
  {
    "revision": "f40c7e0b20fe25eb78a7658c3ae56312",
    "url": "/img/noData@3x.f40c7e0b.png"
  },
  {
    "revision": "644e6e3cf5f33943747b116316694e28",
    "url": "/img/noData@2x.644e6e3c.png"
  },
  {
    "revision": "42c0fbd4915870e5e60452fd0ef2cbec",
    "url": "/img/orderTopBg@3x.42c0fbd4.png"
  },
  {
    "revision": "42c0fbd4915870e5e60452fd0ef2cbec",
    "url": "/img/orderTopBg@2x.42c0fbd4.png"
  },
  {
    "revision": "6e5cee7393060b0ec3dcd587c2518b94",
    "url": "/img/bg_test.6e5cee73.png"
  },
  {
    "revision": "01355f175bd20423ce45a838c1a998a9",
    "url": "/img/bg.01355f17.png"
  },
  {
    "revision": "d0ccbc8a35180bb40e027b44dd26035a",
    "url": "/img/youku.d0ccbc8a.png"
  },
  {
    "revision": "a859e9ca4606d567c42b9c7bcd4fdce9",
    "url": "/img/iccid_bg@2x.a859e9ca.png"
  },
  {
    "revision": "fa9050c4e9870e8fc0cd184f8515af4a",
    "url": "/img/iccid_bg@3x.fa9050c4.png"
  },
  {
    "revision": "2c51a1e53c1ea0b35086d8d7261b4933",
    "url": "/img/bg_network@3x.2c51a1e5.png"
  },
  {
    "revision": "32d70c8fc305e3647098f3de0c71b618",
    "url": "/img/bg_network@2x.32d70c8f.png"
  },
  {
    "revision": "114a6e12b42b9b48586dd341105188fe",
    "url": "/img/usedOrder@2x.114a6e12.png"
  },
  {
    "revision": "c0170ec299b2418256fd515ee7849055",
    "url": "/img/unUsedOrder@2x.c0170ec2.png"
  },
  {
    "revision": "d9e14058d30dd312519fcf2de38d742b",
    "url": "/img/unUsedOrder@3x.d9e14058.png"
  },
  {
    "revision": "4a5b90f8076955f289b3dcda6a5af6ff",
    "url": "/img/invaildedOrder@3x.4a5b90f8.png"
  },
  {
    "revision": "0d5a5158e67bcb7a4604124715ed6fbf",
    "url": "/img/usedOrder@3x.0d5a5158.png"
  },
  {
    "revision": "be0f1e33b2553e71b117d3d3f838d32f",
    "url": "/img/invaildedOrder@2x.be0f1e33.png"
  },
  {
    "revision": "3603a35a49dbb8ad94ec1e57c4dad229",
    "url": "/img/scanTop2.3603a35a.png"
  },
  {
    "revision": "05775dd69c53d7273b27aaa7c6c523f7",
    "url": "/img/04.05775dd6.png"
  },
  {
    "revision": "58a560568b7291ea926c2c7438035308",
    "url": "/img/subscribe@3x.58a56056.png"
  },
  {
    "revision": "541375e6bb7db2fba9e415be8045f5fb",
    "url": "/img/1.541375e6.png"
  },
  {
    "revision": "7c28431d304fa4f58f5070c59720683a",
    "url": "/img/2.7c28431d.png"
  },
  {
    "revision": "5a3428653945c17e1c146efeee81c987",
    "url": "/img/scanTop.5a342865.png"
  },
  {
    "revision": "824594523c01e48028f2b7eb4261134d",
    "url": "/img/unicom-logo.82459452.svg"
  },
  {
    "revision": "113f99e2189c2ca49db2168754fc2eb5",
    "url": "/img/mobile-logo.113f99e2.png"
  },
  {
    "revision": "0cba868fa977e09806638b9000636a36",
    "url": "/img/avatar.0cba868f.jpeg"
  },
  {
    "revision": "27158aa79eb0d4b89f317d076a801ca3",
    "url": "/img/coupon-log.27158aa7.png"
  },
  {
    "revision": "55d3f2f09efe17db6485d4c9f8f0c3b1",
    "url": "/img/icon-recharge_20181001.55d3f2f0.svg"
  },
  {
    "revision": "165beb68d8ba0d2b70df0fbb3769787a",
    "url": "/img/03.165beb68.png"
  },
  {
    "revision": "5f1f34037094c0613bccafa2ddd8cb3b",
    "url": "/img/telecom-logo.5f1f3403.svg"
  },
  {
    "revision": "f7a51f1c554585b11d61499fd0a7520f",
    "url": "/img/only-box@3x.f7a51f1c.png"
  },
  {
    "revision": "0b3c3297decbd1152a314cce115f9632",
    "url": "/img/09.0b3c3297.png"
  },
  {
    "revision": "3e217df4202e41ad9b030aafc8cfcc24",
    "url": "/img/4.3e217df4.png"
  },
  {
    "revision": "aecc9531f2c3b1fd45338e7bf5084384",
    "url": "/img/bg_no_recharge.aecc9531.svg"
  },
  {
    "revision": "b0ffa4a0fd195a110ee4d4dabce3bc32",
    "url": "/img/08.b0ffa4a0.png"
  },
  {
    "revision": "96fab583abd57f2e7118324858fa3080",
    "url": "/img/05.96fab583.png"
  },
  {
    "revision": "9e8ecc7f7b760b55c56bddfab886da10",
    "url": "/img/3.9e8ecc7f.png"
  },
  {
    "revision": "275be51ae57c486bce58257febd6589f",
    "url": "/img/bg_no_plan.275be51a.svg"
  },
  {
    "revision": "a8272d2d742d9d50257e23dfac577def",
    "url": "/img/01.a8272d2d.png"
  },
  {
    "revision": "daa86b540bb9c2a6453ceac9bed77961",
    "url": "/img/07.daa86b54.png"
  },
  {
    "revision": "06385746a7cedb492d5539907631561c",
    "url": "/img/tip.06385746.png"
  },
  {
    "revision": "a610420eab741be28278e60bc06387aa",
    "url": "/img/box-deco@3x.a610420e.png"
  },
  {
    "revision": "eacba58f9acf2b87cd801858146b2ba9",
    "url": "/img/02.eacba58f.png"
  },
  {
    "revision": "39d9e849fc1c724525f166646932a24d",
    "url": "/img/safari.39d9e849.png"
  },
  {
    "revision": "999589aae784a460b5e7c6ae9bbaa3d8",
    "url": "/img/06.999589aa.png"
  },
  {
    "revision": "ea549b0b6acc1f1807589418cfbc5a81",
    "url": "/index.html"
  },
  {
    "revision": "b6216d61c03e6ce0c9aea6ca7808f7ca",
    "url": "/robots.txt"
  },
  {
    "revision": "9ce16f441b39b493af8b96d7e97cce22",
    "url": "/MP_verify_dkzAKjxyVyJvsHMS.txt"
  },
  {
    "revision": "86c422d8c98b247235d04b49fb1c4b05",
    "url": "/MP_verify_bKSdn2qZlUSULliu.txt"
  },
  {
    "revision": "652317b098ca24e4511926c7fd57cbbe",
    "url": "/MP_verify_8JoCCldW78DygS5c.txt"
  },
  {
    "revision": "00bbf6b458bf7ea6bd01f443eb3045d9",
    "url": "/MP_verify_4r3DVk3KUjgWsQsG.txt"
  }
];