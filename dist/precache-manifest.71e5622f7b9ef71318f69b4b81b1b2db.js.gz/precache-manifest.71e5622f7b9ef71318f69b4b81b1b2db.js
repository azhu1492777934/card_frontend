self.__precacheManifest = [
  {
    "revision": "f81fc470ef810798ffba",
    "url": "/css/refund_argument.79a1da66.css"
  },
  {
    "revision": "b6216d61c03e6ce0c9aea6ca7808f7ca",
    "url": "/robots.txt"
  },
  {
    "revision": "f81fc470ef810798ffba",
    "url": "/js/refund_argument.9fc248be.js"
  },
  {
    "revision": "b3711af66d84aa146ffe",
    "url": "/css/Layout~card_usage.9ba5cd95.css"
  },
  {
    "revision": "78214ba34c5f1df936aa",
    "url": "/js/Layout~card_usage~eqReplaceMent~esim_plan_list~esim_usage~mifi_order~mifi_plan_list~mifi_plan_usage~~c6f87c36.6241bd21.js"
  },
  {
    "revision": "ff9f96551e97e4cdea4c",
    "url": "/css/Not_fund.56cc986a.css"
  },
  {
    "revision": "ff9f96551e97e4cdea4c",
    "url": "/js/Not_fund.10ea0383.js"
  },
  {
    "revision": "309f8ae187e4670895a7",
    "url": "/css/addSalesRecords.d65611ae.css"
  },
  {
    "revision": "309f8ae187e4670895a7",
    "url": "/js/addSalesRecords.8bfc8be4.js"
  },
  {
    "revision": "8b4f80846b062b62df72",
    "url": "/css/app.b7b25a58.css"
  },
  {
    "revision": "8b4f80846b062b62df72",
    "url": "/js/app.67de7b5c.js"
  },
  {
    "revision": "a628e3706125fb0c5425",
    "url": "/css/authority_middle.5a8664ac.css"
  },
  {
    "revision": "a628e3706125fb0c5425",
    "url": "/js/authority_middle.3584ed2e.js"
  },
  {
    "revision": "055a8341cb72cd12c40e",
    "url": "/css/card_check.a36b02e2.css"
  },
  {
    "revision": "055a8341cb72cd12c40e",
    "url": "/js/card_check.9e87b893.js"
  },
  {
    "revision": "3cb73ddfb137ac4feee1",
    "url": "/css/card_connection.c548c7f3.css"
  },
  {
    "revision": "3cb73ddfb137ac4feee1",
    "url": "/js/card_connection.d1bd5289.js"
  },
  {
    "revision": "95f46bb4e2a77001e55c",
    "url": "/css/card_lookup.ce0c179f.css"
  },
  {
    "revision": "95f46bb4e2a77001e55c",
    "url": "/js/card_lookup.8db7d4d1.js"
  },
  {
    "revision": "962520cb9285cb1b5f86",
    "url": "/css/card_usage.b1a3e7ea.css"
  },
  {
    "revision": "962520cb9285cb1b5f86",
    "url": "/js/card_usage.f0271035.js"
  },
  {
    "revision": "5288ea8a2d91c632d6f2",
    "url": "/css/card_wrapper.7421536f.css"
  },
  {
    "revision": "5288ea8a2d91c632d6f2",
    "url": "/js/card_wrapper.3c8096a6.js"
  },
  {
    "revision": "c5c8b2e659060c762aa2",
    "url": "/css/children_card.82cdc131.css"
  },
  {
    "revision": "c5c8b2e659060c762aa2",
    "url": "/js/children_card.57864f02.js"
  },
  {
    "revision": "222d14ad35afd930bf83",
    "url": "/css/chunk-34df9053.0fde750e.css"
  },
  {
    "revision": "222d14ad35afd930bf83",
    "url": "/js/chunk-34df9053.ae48772f.js"
  },
  {
    "revision": "f2124069e1ad78974e67",
    "url": "/css/chunk-f4f68b7c.996c8e83.css"
  },
  {
    "revision": "f2124069e1ad78974e67",
    "url": "/js/chunk-f4f68b7c.7091c447.js"
  },
  {
    "revision": "269e27b4a18d38c07113",
    "url": "/css/chunk-vendors.845797cf.css"
  },
  {
    "revision": "269e27b4a18d38c07113",
    "url": "/js/chunk-vendors.0c664671.js"
  },
  {
    "revision": "9558df79a2164db51e62",
    "url": "/css/commonProblem.633bd4ee.css"
  },
  {
    "revision": "9558df79a2164db51e62",
    "url": "/js/commonProblem.e9e9ee04.js"
  },
  {
    "revision": "e9b93e60a50bf57caabe",
    "url": "/css/contactUs.61928b44.css"
  },
  {
    "revision": "e9b93e60a50bf57caabe",
    "url": "/js/contactUs.8a5fcdd4.js"
  },
  {
    "revision": "41d1d6e0dbf0d673f318",
    "url": "/css/coupon_normal.35c88dfa.css"
  },
  {
    "revision": "41d1d6e0dbf0d673f318",
    "url": "/js/coupon_normal.8707ad84.js"
  },
  {
    "revision": "805dabb0c9dffde2d4f2",
    "url": "/css/coupon_telcom.94c7ba55.css"
  },
  {
    "revision": "805dabb0c9dffde2d4f2",
    "url": "/js/coupon_telcom.b4bbf15a.js"
  },
  {
    "revision": "17329f17d3054eda8ab2",
    "url": "/css/coupon_wrapper.482349c9.css"
  },
  {
    "revision": "17329f17d3054eda8ab2",
    "url": "/js/coupon_wrapper.cc3ca5f8.js"
  },
  {
    "revision": "2f430d6cc162337f75ac",
    "url": "/css/eqReplaceMent.b09da86b.css"
  },
  {
    "revision": "2f430d6cc162337f75ac",
    "url": "/js/eqReplaceMent.43f79fcc.js"
  },
  {
    "revision": "f99239990959cee5f7b5",
    "url": "/css/esim_plan_list.7fc9c42f.css"
  },
  {
    "revision": "f99239990959cee5f7b5",
    "url": "/js/esim_plan_list.a36f9703.js"
  },
  {
    "revision": "8252261226af1613a9f0",
    "url": "/css/esim_usage.f30b4203.css"
  },
  {
    "revision": "8252261226af1613a9f0",
    "url": "/js/esim_usage.ccc3ca51.js"
  },
  {
    "revision": "6051717652095af20d75",
    "url": "/css/find_plan.56a01abf.css"
  },
  {
    "revision": "6051717652095af20d75",
    "url": "/js/find_plan.889b0d0d.js"
  },
  {
    "revision": "d87dea2e21e955bba6c4",
    "url": "/css/helpCenter.564dff58.css"
  },
  {
    "revision": "d87dea2e21e955bba6c4",
    "url": "/js/helpCenter.99fad990.js"
  },
  {
    "revision": "8085e70df52ba0f169e4",
    "url": "/css/logical_page.e5210868.css"
  },
  {
    "revision": "8085e70df52ba0f169e4",
    "url": "/js/logical_page.aa9889ab.js"
  },
  {
    "revision": "f79cad771db8e859d0b1",
    "url": "/css/login.f204edf9.css"
  },
  {
    "revision": "f79cad771db8e859d0b1",
    "url": "/js/login.b29b3fd1.js"
  },
  {
    "revision": "6462c67ec253c8b599e3",
    "url": "/css/lookup.596acf97.css"
  },
  {
    "revision": "6462c67ec253c8b599e3",
    "url": "/js/lookup.60f6159f.js"
  },
  {
    "revision": "d888f2a0bd6eeae0d0ad",
    "url": "/css/mifi_binding.2b685a52.css"
  },
  {
    "revision": "d888f2a0bd6eeae0d0ad",
    "url": "/js/mifi_binding.233b25e2.js"
  },
  {
    "revision": "bd84264be67d737e6f70",
    "url": "/css/mifi_card_info.ca71de7d.css"
  },
  {
    "revision": "bd84264be67d737e6f70",
    "url": "/js/mifi_card_info.112c7144.js"
  },
  {
    "revision": "112ca5fee3a6c8cbcda6",
    "url": "/css/mifi_card_lookup.d03ae28c.css"
  },
  {
    "revision": "112ca5fee3a6c8cbcda6",
    "url": "/js/mifi_card_lookup.3b2aa986.js"
  },
  {
    "revision": "6a5a26ca19714bfdd7f2",
    "url": "/css/mifi_card_wrapper.1dddf2fc.css"
  },
  {
    "revision": "6a5a26ca19714bfdd7f2",
    "url": "/js/mifi_card_wrapper.a7b95de0.js"
  },
  {
    "revision": "6cce581533cbe07a887b",
    "url": "/css/mifi_change_network.1e371e14.css"
  },
  {
    "revision": "6cce581533cbe07a887b",
    "url": "/js/mifi_change_network.9999b2b3.js"
  },
  {
    "revision": "2321ee582a3f25c07bf5",
    "url": "/css/mifi_coupon_index.1c1700fe.css"
  },
  {
    "revision": "2321ee582a3f25c07bf5",
    "url": "/js/mifi_coupon_index.540374ba.js"
  },
  {
    "revision": "63cf3758c9100e03386f",
    "url": "/css/mifi_coupon_wrapper.80fa7896.css"
  },
  {
    "revision": "63cf3758c9100e03386f",
    "url": "/js/mifi_coupon_wrapper.130cc620.js"
  },
  {
    "revision": "63bb1041256056abc02d",
    "url": "/css/mifi_index.425e735b.css"
  },
  {
    "revision": "63bb1041256056abc02d",
    "url": "/js/mifi_index.7861b3db.js"
  },
  {
    "revision": "eb5de8b8f88ec13bff7f",
    "url": "/css/mifi_layout.4ae65286.css"
  },
  {
    "revision": "eb5de8b8f88ec13bff7f",
    "url": "/js/mifi_layout.089c12db.js"
  },
  {
    "revision": "2ffdadbae814d07ff285",
    "url": "/css/mifi_order.0ec61497.css"
  },
  {
    "revision": "2ffdadbae814d07ff285",
    "url": "/js/mifi_order.8d68c885.js"
  },
  {
    "revision": "e5c751e06ac7b48a5590",
    "url": "/css/mifi_order_wrapper.eeb3aab7.css"
  },
  {
    "revision": "e5c751e06ac7b48a5590",
    "url": "/js/mifi_order_wrapper.79d46351.js"
  },
  {
    "revision": "0e3374b5b87d7be5ae97",
    "url": "/css/mifi_order~mifi_plan_group.649e1a31.css"
  },
  {
    "revision": "0e3374b5b87d7be5ae97",
    "url": "/js/mifi_order~mifi_plan_group.2b2aed2a.js"
  },
  {
    "revision": "7dd810b521cc38c93b49",
    "url": "/css/mifi_plan_group.c2ad4b7d.css"
  },
  {
    "revision": "7dd810b521cc38c93b49",
    "url": "/js/mifi_plan_group.ed2595b3.js"
  },
  {
    "revision": "994e235d7a2a6f7c0b10",
    "url": "/css/mifi_plan_list.c876d002.css"
  },
  {
    "revision": "994e235d7a2a6f7c0b10",
    "url": "/js/mifi_plan_list.3a239c89.js"
  },
  {
    "revision": "76127d6038bd439f735f",
    "url": "/css/mifi_plan_usage.dc835dc3.css"
  },
  {
    "revision": "76127d6038bd439f735f",
    "url": "/js/mifi_plan_usage.98e35500.js"
  },
  {
    "revision": "0c91cd9f7265479849c3",
    "url": "/css/mifi_plan_wrapper.0b1217f1.css"
  },
  {
    "revision": "0c91cd9f7265479849c3",
    "url": "/js/mifi_plan_wrapper.e1dc6063.js"
  },
  {
    "revision": "45d39876b3fc685a2c75",
    "url": "/css/new_card_wrapper.08f9c69c.css"
  },
  {
    "revision": "45d39876b3fc685a2c75",
    "url": "/js/new_card_wrapper.bafc2688.js"
  },
  {
    "revision": "04c9fd259c93c1eede45",
    "url": "/css/plan_list.f97aff63.css"
  },
  {
    "revision": "04c9fd259c93c1eede45",
    "url": "/js/plan_list.6f193247.js"
  },
  {
    "revision": "af1ccf61a9ec631e140a",
    "url": "/css/question.02c2b99e.css"
  },
  {
    "revision": "af1ccf61a9ec631e140a",
    "url": "/js/question.5ce716f4.js"
  },
  {
    "revision": "29cc6106363b4534aec5",
    "url": "/css/question_wrapper.bdf706e3.css"
  },
  {
    "revision": "29cc6106363b4534aec5",
    "url": "/js/question_wrapper.6297ab27.js"
  },
  {
    "revision": "ca0be03a994f9aca5db0",
    "url": "/css/realName.661fa0e9.css"
  },
  {
    "revision": "ca0be03a994f9aca5db0",
    "url": "/js/realName.d93900ac.js"
  },
  {
    "revision": "4008eb0988b88527d380",
    "url": "/css/realNameCourse.3b818331.css"
  },
  {
    "revision": "4008eb0988b88527d380",
    "url": "/js/realNameCourse.30414cf7.js"
  },
  {
    "revision": "84602ea79b290af1fddd",
    "url": "/css/real_name.1be97b67.css"
  },
  {
    "revision": "84602ea79b290af1fddd",
    "url": "/js/real_name.75bb9a19.js"
  },
  {
    "revision": "dbb1d431278d89671e93",
    "url": "/css/recharge.2fb64f1c.css"
  },
  {
    "revision": "dbb1d431278d89671e93",
    "url": "/js/recharge.9cad7750.js"
  },
  {
    "revision": "07ee2b0eafa06fe05548",
    "url": "/css/rechargeRecord.8b39b5d9.css"
  },
  {
    "revision": "07ee2b0eafa06fe05548",
    "url": "/js/rechargeRecord.6b85a7ff.js"
  },
  {
    "revision": "de4d0b12592e1e894393",
    "url": "/css/recharge_callback.20e5cd37.css"
  },
  {
    "revision": "de4d0b12592e1e894393",
    "url": "/js/recharge_callback.a4c00dfa.js"
  },
  {
    "revision": "3e5f04cf3375a8532136",
    "url": "/css/recharge_wrapper.39e18c84.css"
  },
  {
    "revision": "3e5f04cf3375a8532136",
    "url": "/js/recharge_wrapper.5ca56a08.js"
  },
  {
    "revision": "850c9c9e277870b9b7a6",
    "url": "/css/refund_applying.c08c748d.css"
  },
  {
    "revision": "850c9c9e277870b9b7a6",
    "url": "/js/refund_applying.5fc13a95.js"
  },
  {
    "revision": "560e63d74e95587db9c3",
    "url": "/js/Layout.e878447c.js"
  },
  {
    "revision": "b3711af66d84aa146ffe",
    "url": "/js/Layout~card_usage.28700544.js"
  },
  {
    "revision": "3782b9400cb9aefd240c",
    "url": "/css/refund_plan.18635bb8.css"
  },
  {
    "revision": "3782b9400cb9aefd240c",
    "url": "/js/refund_plan.d86da095.js"
  },
  {
    "revision": "1b800ca26571a05f5073",
    "url": "/css/refund_wrapper.4307116a.css"
  },
  {
    "revision": "1b800ca26571a05f5073",
    "url": "/js/refund_wrapper.be3d5741.js"
  },
  {
    "revision": "d986b7b489de94bb1230",
    "url": "/css/repeatRecharge.84e8ad10.css"
  },
  {
    "revision": "d986b7b489de94bb1230",
    "url": "/js/repeatRecharge.45bff818.js"
  },
  {
    "revision": "1cc510d8febd349dd01e",
    "url": "/css/revoke_plan.579625f7.css"
  },
  {
    "revision": "1cc510d8febd349dd01e",
    "url": "/js/revoke_plan.3f1a7d35.js"
  },
  {
    "revision": "c4e87605f68988ec046c",
    "url": "/css/salesRecords.af1e14fe.css"
  },
  {
    "revision": "c4e87605f68988ec046c",
    "url": "/js/salesRecords.e6d5bba8.js"
  },
  {
    "revision": "acb49086f437887d1778",
    "url": "/css/speedup_500.d0292630.css"
  },
  {
    "revision": "acb49086f437887d1778",
    "url": "/js/speedup_500.f36c1012.js"
  },
  {
    "revision": "f3d63a488bbcd075ab92",
    "url": "/css/speedup_80.983370d9.css"
  },
  {
    "revision": "f3d63a488bbcd075ab92",
    "url": "/js/speedup_80.f4cb1be7.js"
  },
  {
    "revision": "cb102f1c5254161579d9",
    "url": "/css/speedup_wrapper.89c329fd.css"
  },
  {
    "revision": "cb102f1c5254161579d9",
    "url": "/js/speedup_wrapper.59a15437.js"
  },
  {
    "revision": "762b59cae17f7c60b1fb",
    "url": "/css/to_tb.3f81a7f4.css"
  },
  {
    "revision": "762b59cae17f7c60b1fb",
    "url": "/js/to_tb.ab8c8811.js"
  },
  {
    "revision": "368034a0b3701612d58c",
    "url": "/css/transfer_url.b0661208.css"
  },
  {
    "revision": "368034a0b3701612d58c",
    "url": "/js/transfer_url.776d359a.js"
  },
  {
    "revision": "b091a878f88fbd9265f7",
    "url": "/css/userCenter.9dcac979.css"
  },
  {
    "revision": "b091a878f88fbd9265f7",
    "url": "/js/userCenter.aa7041c1.js"
  },
  {
    "revision": "bb8da3ab392181ba62eb",
    "url": "/css/userCenterAddress.d835c3e7.css"
  },
  {
    "revision": "bb8da3ab392181ba62eb",
    "url": "/js/userCenterAddress.bce24428.js"
  },
  {
    "revision": "8fe4b08dab2cde3a96bf",
    "url": "/css/userCenterWrap.32f1c95d.css"
  },
  {
    "revision": "8fe4b08dab2cde3a96bf",
    "url": "/js/userCenterWrap.0d0d498e.js"
  },
  {
    "revision": "e4b411644706c29765eea3ffdd85ae39",
    "url": "/fonts/SourceHanSansCNRegular.e4b41164.woff"
  },
  {
    "revision": "834b022ab9ab0e6063904af32274e777",
    "url": "/fonts/SourceHanSansCNRegular.834b022a.eot"
  },
  {
    "revision": "f9509c5a10be7daaf1fa01922a7c6bc2",
    "url": "/fonts/SourceHanSansCNRegular.f9509c5a.ttf"
  },
  {
    "revision": "da0808e9fe85be160aab69c82dd8de1c",
    "url": "/img/SourceHanSansCNRegular.da0808e9.svg"
  },
  {
    "revision": "732389ded34cb9c52dd88271f1345af9",
    "url": "/fonts/element-icons.732389de.ttf"
  },
  {
    "revision": "535877f50039c0cb49a6196a5b7517cd",
    "url": "/fonts/element-icons.535877f5.woff"
  },
  {
    "revision": "ad4acc3d7da28ce6f33925b83bae2c94",
    "url": "/img/arrow1.ad4acc3d.png"
  },
  {
    "revision": "fff5af4325410621aeec4e60b3b92d9b",
    "url": "/img/mifi_binding_bg@3x.fff5af43.png"
  },
  {
    "revision": "fff5af4325410621aeec4e60b3b92d9b",
    "url": "/img/mifi_binding_bg@2x.fff5af43.png"
  },
  {
    "revision": "42c0fbd4915870e5e60452fd0ef2cbec",
    "url": "/img/orderTopBg@3x.42c0fbd4.png"
  },
  {
    "revision": "42c0fbd4915870e5e60452fd0ef2cbec",
    "url": "/img/orderTopBg@2x.42c0fbd4.png"
  },
  {
    "revision": "a1386d312938b126d701a6841fb742e8",
    "url": "/img/addressIcon.a1386d31.png"
  },
  {
    "revision": "83d0cd2dc163e83ef26f6bad98661da8",
    "url": "/img/addressBg.83d0cd2d.png"
  },
  {
    "revision": "a859e9ca4606d567c42b9c7bcd4fdce9",
    "url": "/img/iccid_bg@2x.a859e9ca.png"
  },
  {
    "revision": "fa9050c4e9870e8fc0cd184f8515af4a",
    "url": "/img/iccid_bg@3x.fa9050c4.png"
  },
  {
    "revision": "6e5cee7393060b0ec3dcd587c2518b94",
    "url": "/img/bg_test.6e5cee73.png"
  },
  {
    "revision": "f5f322478286641bd9887a155e35f222",
    "url": "/img/btn.f5f32247.png"
  },
  {
    "revision": "d140650fa64e0f1fc771610dba62aed7",
    "url": "/img/bg.d140650f.png"
  },
  {
    "revision": "e625229e32d9deeb5f2909c314d8e609",
    "url": "/img/ios@2x.e625229e.png"
  },
  {
    "revision": "af8bbdfa0a90c4eed4563f8c06ce5ff8",
    "url": "/img/android@2x.af8bbdfa.png"
  },
  {
    "revision": "2c51a1e53c1ea0b35086d8d7261b4933",
    "url": "/img/bg_network@3x.2c51a1e5.png"
  },
  {
    "revision": "32d70c8fc305e3647098f3de0c71b618",
    "url": "/img/bg_network@2x.32d70c8f.png"
  },
  {
    "revision": "b899232b79ad9962c5ab5572775a0400",
    "url": "/img/card_index_bg@3x.b899232b.png"
  },
  {
    "revision": "b899232b79ad9962c5ab5572775a0400",
    "url": "/img/card_index_bg@2x.b899232b.png"
  },
  {
    "revision": "3f342771b9b81ab929e0fbcbcd0e6533",
    "url": "/img/bg-check-wrap@3x.3f342771.png"
  },
  {
    "revision": "9713b21819c4019befecd095069977df",
    "url": "/img/bg-check-wrap@2x.9713b218.png"
  },
  {
    "revision": "014d354b9b25b67ae95857ba17e2f4cc",
    "url": "/img/activityPage.014d354b.png"
  },
  {
    "revision": "1d7515ee61c3f659227318b4050955ed",
    "url": "/img/mobile_sim@2x.1d7515ee.png"
  },
  {
    "revision": "0f980b79d9a52702004de9f652a68835",
    "url": "/img/telcom_sim@2x.0f980b79.png"
  },
  {
    "revision": "98141226a7e992e3072a280746a259c4",
    "url": "/img/mobile_sim@3x.98141226.png"
  },
  {
    "revision": "0c88168b284b92c37f3a873f26a97d69",
    "url": "/img/bg.0c88168b.jpg"
  },
  {
    "revision": "9e02095f31a07b972244f1c714c1dfe7",
    "url": "/img/telcom_sim@3x.9e02095f.png"
  },
  {
    "revision": "d32e5dc3875f1afd2be29aad1cfd0382",
    "url": "/img/contactBg.d32e5dc3.png"
  },
  {
    "revision": "b70eddccd257b21777e71bb64c83b876",
    "url": "/img/bg.b70eddcc.jpeg"
  },
  {
    "revision": "909816c3d34e63a9ad86b8c179ab543c",
    "url": "/img/bar.909816c3.png"
  },
  {
    "revision": "e92f547ba0209da3b4342fa2b56ea9ae",
    "url": "/img/animater.e92f547b.png"
  },
  {
    "revision": "114a6e12b42b9b48586dd341105188fe",
    "url": "/img/usedOrder@2x.114a6e12.png"
  },
  {
    "revision": "c0170ec299b2418256fd515ee7849055",
    "url": "/img/unUsedOrder@2x.c0170ec2.png"
  },
  {
    "revision": "d9e14058d30dd312519fcf2de38d742b",
    "url": "/img/unUsedOrder@3x.d9e14058.png"
  },
  {
    "revision": "4a5b90f8076955f289b3dcda6a5af6ff",
    "url": "/img/invaildedOrder@3x.4a5b90f8.png"
  },
  {
    "revision": "0d5a5158e67bcb7a4604124715ed6fbf",
    "url": "/img/usedOrder@3x.0d5a5158.png"
  },
  {
    "revision": "be0f1e33b2553e71b117d3d3f838d32f",
    "url": "/img/invaildedOrder@2x.be0f1e33.png"
  },
  {
    "revision": "3d0fc424b703032ca595090e99f8354b",
    "url": "/img/login_bg@2x.3d0fc424.png"
  },
  {
    "revision": "11000d4e510a6df565eb69ba6f2c1dfc",
    "url": "/img/login_bg@3x.11000d4e.png"
  },
  {
    "revision": "2a67b73145562669220aa4639e1ad58f",
    "url": "/img/icon3.2a67b731.png"
  },
  {
    "revision": "813b5319e378dafdda952c16ad89906b",
    "url": "/img/icon2.813b5319.png"
  },
  {
    "revision": "01355f175bd20423ce45a838c1a998a9",
    "url": "/img/bg.01355f17.png"
  },
  {
    "revision": "6eb1cce5bab9ec1cb25d71e8f3110a15",
    "url": "/img/real7.6eb1cce5.jpeg"
  },
  {
    "revision": "3603a35a49dbb8ad94ec1e57c4dad229",
    "url": "/img/scanTop2.3603a35a.png"
  },
  {
    "revision": "b74ee4a485ffa8d4339c3412ac6659be",
    "url": "/img/real6.b74ee4a4.jpeg"
  },
  {
    "revision": "05775dd69c53d7273b27aaa7c6c523f7",
    "url": "/img/04.05775dd6.png"
  },
  {
    "revision": "5a3428653945c17e1c146efeee81c987",
    "url": "/img/scanTop.5a342865.png"
  },
  {
    "revision": "824594523c01e48028f2b7eb4261134d",
    "url": "/img/unicom-logo.82459452.svg"
  },
  {
    "revision": "113f99e2189c2ca49db2168754fc2eb5",
    "url": "/img/mobile-logo.113f99e2.png"
  },
  {
    "revision": "0cba868fa977e09806638b9000636a36",
    "url": "/img/avatar.0cba868f.jpeg"
  },
  {
    "revision": "a5b636104342050950abea60fb65f9cd",
    "url": "/img/qrImg.a5b63610.png"
  },
  {
    "revision": "27158aa79eb0d4b89f317d076a801ca3",
    "url": "/img/coupon-log.27158aa7.png"
  },
  {
    "revision": "55d3f2f09efe17db6485d4c9f8f0c3b1",
    "url": "/img/icon-recharge_20181001.55d3f2f0.svg"
  },
  {
    "revision": "165beb68d8ba0d2b70df0fbb3769787a",
    "url": "/img/03.165beb68.png"
  },
  {
    "revision": "5f1f34037094c0613bccafa2ddd8cb3b",
    "url": "/img/telecom-logo.5f1f3403.svg"
  },
  {
    "revision": "0b3c3297decbd1152a314cce115f9632",
    "url": "/img/09.0b3c3297.png"
  },
  {
    "revision": "644e6e3cf5f33943747b116316694e28",
    "url": "/img/noData@2x.644e6e3c.png"
  },
  {
    "revision": "4bdbe7dbdb6587c886a8290593100145",
    "url": "/img/recharge_callback_20181126.4bdbe7db.jpg"
  },
  {
    "revision": "aecc9531f2c3b1fd45338e7bf5084384",
    "url": "/img/bg_no_recharge.aecc9531.svg"
  },
  {
    "revision": "b0ffa4a0fd195a110ee4d4dabce3bc32",
    "url": "/img/08.b0ffa4a0.png"
  },
  {
    "revision": "96fab583abd57f2e7118324858fa3080",
    "url": "/img/05.96fab583.png"
  },
  {
    "revision": "3af1a9430facd73c667ba61919fc414e",
    "url": "/img/real5.3af1a943.jpeg"
  },
  {
    "revision": "275be51ae57c486bce58257febd6589f",
    "url": "/img/bg_no_plan.275be51a.svg"
  },
  {
    "revision": "1cf937a060cb282e8b60ed6a7ec78604",
    "url": "/img/real3.1cf937a0.jpeg"
  },
  {
    "revision": "45fb414691fd8f78628e3e94f9db1ad4",
    "url": "/img/real2.45fb4146.jpeg"
  },
  {
    "revision": "a8272d2d742d9d50257e23dfac577def",
    "url": "/img/01.a8272d2d.png"
  },
  {
    "revision": "daa86b540bb9c2a6453ceac9bed77961",
    "url": "/img/07.daa86b54.png"
  },
  {
    "revision": "06385746a7cedb492d5539907631561c",
    "url": "/img/tip.06385746.png"
  },
  {
    "revision": "a6d17ceb63edb524e63c9bbc7c671fec",
    "url": "/img/real4.a6d17ceb.jpeg"
  },
  {
    "revision": "eacba58f9acf2b87cd801858146b2ba9",
    "url": "/img/02.eacba58f.png"
  },
  {
    "revision": "39d9e849fc1c724525f166646932a24d",
    "url": "/img/safari.39d9e849.png"
  },
  {
    "revision": "999589aae784a460b5e7c6ae9bbaa3d8",
    "url": "/img/06.999589aa.png"
  },
  {
    "revision": "1cc77fe95a0f28837ecea2300db5756d",
    "url": "/img/real1.1cc77fe9.jpeg"
  },
  {
    "revision": "018b5f611723dcd170b93822b6dfc48d",
    "url": "/img/real8.018b5f61.jpeg"
  },
  {
    "revision": "d9cc993ac89c4a2c099ac6e4bb59499c",
    "url": "/index.html"
  },
  {
    "revision": "560e63d74e95587db9c3",
    "url": "/css/Layout.c58d14ad.css"
  },
  {
    "revision": "9ce16f441b39b493af8b96d7e97cce22",
    "url": "/MP_verify_dkzAKjxyVyJvsHMS.txt"
  },
  {
    "revision": "86c422d8c98b247235d04b49fb1c4b05",
    "url": "/MP_verify_bKSdn2qZlUSULliu.txt"
  },
  {
    "revision": "652317b098ca24e4511926c7fd57cbbe",
    "url": "/MP_verify_8JoCCldW78DygS5c.txt"
  },
  {
    "revision": "00bbf6b458bf7ea6bd01f443eb3045d9",
    "url": "/MP_verify_4r3DVk3KUjgWsQsG.txt"
  }
];