self.__precacheManifest = [
  {
    "revision": "91c26f106dbc9563c949",
    "url": "/css/refund_applying.cc54cbbc.css"
  },
  {
    "revision": "b6216d61c03e6ce0c9aea6ca7808f7ca",
    "url": "/robots.txt"
  },
  {
    "revision": "91c26f106dbc9563c949",
    "url": "/js/refund_applying.7a6634e4.js"
  },
  {
    "revision": "aea18e1fc690e9682196",
    "url": "/css/Layout~card_usage.fbcdfb9a.css"
  },
  {
    "revision": "78214ba34c5f1df936aa",
    "url": "/js/Layout~card_usage~eqReplaceMent~esim_plan_list~esim_usage~mifi_order~mifi_plan_list~mifi_plan_usage~~c6f87c36.6241bd21.js"
  },
  {
    "revision": "d3c44d700e81edc4367c",
    "url": "/css/Not_fund.7e181e00.css"
  },
  {
    "revision": "d3c44d700e81edc4367c",
    "url": "/js/Not_fund.128cd473.js"
  },
  {
    "revision": "80b735d597257cfd574e",
    "url": "/css/app.2608000f.css"
  },
  {
    "revision": "80b735d597257cfd574e",
    "url": "/js/app.d2173d8d.js"
  },
  {
    "revision": "573ec46ca6cd81351084",
    "url": "/css/auditFail.7ad6233b.css"
  },
  {
    "revision": "573ec46ca6cd81351084",
    "url": "/js/auditFail.30070286.js"
  },
  {
    "revision": "bd0892eafaa895fe2041",
    "url": "/css/auditSuccess.060dd25d.css"
  },
  {
    "revision": "bd0892eafaa895fe2041",
    "url": "/js/auditSuccess.d987215b.js"
  },
  {
    "revision": "010a5e681bad03d7d0ef",
    "url": "/css/authority_middle.12684f0a.css"
  },
  {
    "revision": "010a5e681bad03d7d0ef",
    "url": "/js/authority_middle.436aa035.js"
  },
  {
    "revision": "be373e79ba2b719df9d0",
    "url": "/css/balanceIndex.2a7c4022.css"
  },
  {
    "revision": "be373e79ba2b719df9d0",
    "url": "/js/balanceIndex.6735c97b.js"
  },
  {
    "revision": "71aa140d2ed074cf6452",
    "url": "/css/balanceRefund.d5523737.css"
  },
  {
    "revision": "71aa140d2ed074cf6452",
    "url": "/js/balanceRefund.4156db45.js"
  },
  {
    "revision": "c0fe069ea1bd80cc9613",
    "url": "/css/cardPackage.acb7e902.css"
  },
  {
    "revision": "c0fe069ea1bd80cc9613",
    "url": "/js/cardPackage.50c7e137.js"
  },
  {
    "revision": "807db8da1c81bba838b7",
    "url": "/css/card_check.b5b1ecab.css"
  },
  {
    "revision": "807db8da1c81bba838b7",
    "url": "/js/card_check.223360d9.js"
  },
  {
    "revision": "6b7cee83f73375b0a378",
    "url": "/css/card_connection.d558badf.css"
  },
  {
    "revision": "6b7cee83f73375b0a378",
    "url": "/js/card_connection.861ee7df.js"
  },
  {
    "revision": "7e6fdaf187f6a917e657",
    "url": "/css/card_lookup.8174d844.css"
  },
  {
    "revision": "7e6fdaf187f6a917e657",
    "url": "/js/card_lookup.24cbccdb.js"
  },
  {
    "revision": "49d37ea9fd90914d23e8",
    "url": "/css/card_usage.f6f75021.css"
  },
  {
    "revision": "49d37ea9fd90914d23e8",
    "url": "/js/card_usage.96386d32.js"
  },
  {
    "revision": "e2480d6c773029d20292",
    "url": "/css/card_wrapper.770742b7.css"
  },
  {
    "revision": "e2480d6c773029d20292",
    "url": "/js/card_wrapper.2b96ae0c.js"
  },
  {
    "revision": "b0f26667d53fb70d1a0e",
    "url": "/css/children_card.ff02a1df.css"
  },
  {
    "revision": "b0f26667d53fb70d1a0e",
    "url": "/js/children_card.ae407935.js"
  },
  {
    "revision": "18d2cc95ae7193461614",
    "url": "/css/chunk-407ba637.46afdd67.css"
  },
  {
    "revision": "18d2cc95ae7193461614",
    "url": "/js/chunk-407ba637.f9d19ba4.js"
  },
  {
    "revision": "c5c2b1bc06e5fa52287c",
    "url": "/css/chunk-735bcfd4.7f43c2d2.css"
  },
  {
    "revision": "c5c2b1bc06e5fa52287c",
    "url": "/js/chunk-735bcfd4.b2a03701.js"
  },
  {
    "revision": "26be51635e617fc961df",
    "url": "/css/chunk-vendors.187f45a9.css"
  },
  {
    "revision": "26be51635e617fc961df",
    "url": "/js/chunk-vendors.508c8cbc.js"
  },
  {
    "revision": "3fae7aafd03c1f185cb3",
    "url": "/css/commonProblem.8665ff12.css"
  },
  {
    "revision": "3fae7aafd03c1f185cb3",
    "url": "/js/commonProblem.947e742d.js"
  },
  {
    "revision": "4fd00fd689af82edcb64",
    "url": "/css/consumerRecord.777014f2.css"
  },
  {
    "revision": "4fd00fd689af82edcb64",
    "url": "/js/consumerRecord.c9e3ccaf.js"
  },
  {
    "revision": "ec780c684e2832977a39",
    "url": "/css/coupon_normal.72ee0bc0.css"
  },
  {
    "revision": "ec780c684e2832977a39",
    "url": "/js/coupon_normal.d33947ca.js"
  },
  {
    "revision": "a75f98eff00ab1777a6a",
    "url": "/css/coupon_telcom.c97d76cf.css"
  },
  {
    "revision": "a75f98eff00ab1777a6a",
    "url": "/js/coupon_telcom.68382e32.js"
  },
  {
    "revision": "35665cf84dc00b2058c7",
    "url": "/css/coupon_wrapper.707898e1.css"
  },
  {
    "revision": "35665cf84dc00b2058c7",
    "url": "/js/coupon_wrapper.8e12c81c.js"
  },
  {
    "revision": "25ab1a3ef0604e2d053f",
    "url": "/css/currencyConversion.49ad62d9.css"
  },
  {
    "revision": "25ab1a3ef0604e2d053f",
    "url": "/js/currencyConversion.d4201be5.js"
  },
  {
    "revision": "ffd374b85cfcbacc2ba6",
    "url": "/css/eqReplaceMent.33e1388d.css"
  },
  {
    "revision": "ffd374b85cfcbacc2ba6",
    "url": "/js/eqReplaceMent.68740b6c.js"
  },
  {
    "revision": "f076b6742d8d47d38e1f",
    "url": "/css/esim_plan_list.b1d07154.css"
  },
  {
    "revision": "f076b6742d8d47d38e1f",
    "url": "/js/esim_plan_list.03b0039a.js"
  },
  {
    "revision": "3b9c17dfcf3bb1e8f464",
    "url": "/css/esim_usage.8bcb5bd7.css"
  },
  {
    "revision": "3b9c17dfcf3bb1e8f464",
    "url": "/js/esim_usage.7f1fc1a0.js"
  },
  {
    "revision": "ec42f37c1b5e8906f453",
    "url": "/css/find_plan.71f1c6bc.css"
  },
  {
    "revision": "ec42f37c1b5e8906f453",
    "url": "/js/find_plan.f73453d3.js"
  },
  {
    "revision": "2a5b70dff936026ec4c8",
    "url": "/css/logical_page.7e6f49b9.css"
  },
  {
    "revision": "2a5b70dff936026ec4c8",
    "url": "/js/logical_page.0b1267db.js"
  },
  {
    "revision": "1b810d36c3faf55fed12",
    "url": "/css/login.a1848749.css"
  },
  {
    "revision": "1b810d36c3faf55fed12",
    "url": "/js/login.8c785146.js"
  },
  {
    "revision": "1fd3a274cc427cdd68c4",
    "url": "/css/lookup.b5e8b610.css"
  },
  {
    "revision": "1fd3a274cc427cdd68c4",
    "url": "/js/lookup.74d4b896.js"
  },
  {
    "revision": "bd7056a5fc53b34f77cd",
    "url": "/css/mifi_binding.b5ffa534.css"
  },
  {
    "revision": "bd7056a5fc53b34f77cd",
    "url": "/js/mifi_binding.f774fd01.js"
  },
  {
    "revision": "70db8660855835cc7308",
    "url": "/css/mifi_card_info.83dd4962.css"
  },
  {
    "revision": "70db8660855835cc7308",
    "url": "/js/mifi_card_info.a075e8ef.js"
  },
  {
    "revision": "c657656b2ba90eab362a",
    "url": "/css/mifi_card_lookup.47db2ead.css"
  },
  {
    "revision": "c657656b2ba90eab362a",
    "url": "/js/mifi_card_lookup.94ba623b.js"
  },
  {
    "revision": "cf88c769e86c500a009e",
    "url": "/css/mifi_card_wrapper.c09367ca.css"
  },
  {
    "revision": "cf88c769e86c500a009e",
    "url": "/js/mifi_card_wrapper.ac09d9fb.js"
  },
  {
    "revision": "74101cdf5896fbba52db",
    "url": "/css/mifi_change_network.620a8a07.css"
  },
  {
    "revision": "74101cdf5896fbba52db",
    "url": "/js/mifi_change_network.94531f20.js"
  },
  {
    "revision": "86d05010240d346ae1ee",
    "url": "/css/mifi_change_network_explanation.362d9c01.css"
  },
  {
    "revision": "86d05010240d346ae1ee",
    "url": "/js/mifi_change_network_explanation.0a074201.js"
  },
  {
    "revision": "b1a7b8d80fbc6ead6d4e",
    "url": "/css/mifi_coupon_index.ab95dd2b.css"
  },
  {
    "revision": "b1a7b8d80fbc6ead6d4e",
    "url": "/js/mifi_coupon_index.5af00801.js"
  },
  {
    "revision": "41cb6b26c78653fcddf8",
    "url": "/css/mifi_coupon_wrapper.32f1c95d.css"
  },
  {
    "revision": "41cb6b26c78653fcddf8",
    "url": "/js/mifi_coupon_wrapper.f357646c.js"
  },
  {
    "revision": "b5d3198605923077aba3",
    "url": "/css/mifi_index.0212e484.css"
  },
  {
    "revision": "b5d3198605923077aba3",
    "url": "/js/mifi_index.9c671236.js"
  },
  {
    "revision": "ff7289eb0667e562b477",
    "url": "/css/mifi_layout.0a7c17e3.css"
  },
  {
    "revision": "ff7289eb0667e562b477",
    "url": "/js/mifi_layout.ad46e897.js"
  },
  {
    "revision": "c286f9dc9bc8b264894e",
    "url": "/css/mifi_order.27bb3351.css"
  },
  {
    "revision": "c286f9dc9bc8b264894e",
    "url": "/js/mifi_order.917c7430.js"
  },
  {
    "revision": "70cc91a31ace483ac4f3",
    "url": "/css/mifi_order_wrapper.0b1217f1.css"
  },
  {
    "revision": "70cc91a31ace483ac4f3",
    "url": "/js/mifi_order_wrapper.0d7f411b.js"
  },
  {
    "revision": "47dd43015500be3f9ac4",
    "url": "/css/mifi_order~mifi_plan_group.9b72222a.css"
  },
  {
    "revision": "47dd43015500be3f9ac4",
    "url": "/js/mifi_order~mifi_plan_group.8b8989db.js"
  },
  {
    "revision": "7e5385d84da3dbd52208",
    "url": "/css/mifi_plan_group.c3c5f64d.css"
  },
  {
    "revision": "7e5385d84da3dbd52208",
    "url": "/js/mifi_plan_group.13560ed9.js"
  },
  {
    "revision": "cfd1f3777611f230baee",
    "url": "/css/mifi_plan_list.0f398b91.css"
  },
  {
    "revision": "cfd1f3777611f230baee",
    "url": "/js/mifi_plan_list.a23af171.js"
  },
  {
    "revision": "ebf368540557a90087ef",
    "url": "/css/mifi_plan_usage.3d11e45c.css"
  },
  {
    "revision": "ebf368540557a90087ef",
    "url": "/js/mifi_plan_usage.237f2e1b.js"
  },
  {
    "revision": "ce2bc07e2623493d7081",
    "url": "/css/mifi_plan_wrapper.56a3339d.css"
  },
  {
    "revision": "ce2bc07e2623493d7081",
    "url": "/js/mifi_plan_wrapper.666c024b.js"
  },
  {
    "revision": "c64ee0336bbe15611264",
    "url": "/css/new_card_wrapper.9b92bcd2.css"
  },
  {
    "revision": "c64ee0336bbe15611264",
    "url": "/js/new_card_wrapper.def4274d.js"
  },
  {
    "revision": "f33cfb66277f435b203e",
    "url": "/css/orderRecord.edbc5072.css"
  },
  {
    "revision": "f33cfb66277f435b203e",
    "url": "/js/orderRecord.08c1f1e8.js"
  },
  {
    "revision": "bc3c6a74ba256096675c",
    "url": "/css/plan_list.f973d2fd.css"
  },
  {
    "revision": "bc3c6a74ba256096675c",
    "url": "/js/plan_list.47658411.js"
  },
  {
    "revision": "3d151e6e96299cc6d62d",
    "url": "/css/question.8dd8800b.css"
  },
  {
    "revision": "3d151e6e96299cc6d62d",
    "url": "/js/question.48fd3f38.js"
  },
  {
    "revision": "cbcc6a4a015494c52dbe",
    "url": "/css/question_wrapper.ce3120d7.css"
  },
  {
    "revision": "cbcc6a4a015494c52dbe",
    "url": "/js/question_wrapper.9e157315.js"
  },
  {
    "revision": "02f7bc5340423964d648",
    "url": "/css/realNameCourse.777d1c09.css"
  },
  {
    "revision": "02f7bc5340423964d648",
    "url": "/js/realNameCourse.65e5c0ad.js"
  },
  {
    "revision": "c40008a23081049712db",
    "url": "/css/realNameWrapper.0b3e62e0.css"
  },
  {
    "revision": "c40008a23081049712db",
    "url": "/js/realNameWrapper.919ff555.js"
  },
  {
    "revision": "66f28ad2021912affe6e",
    "url": "/css/real_name.af35d5a7.css"
  },
  {
    "revision": "66f28ad2021912affe6e",
    "url": "/js/real_name.9dd0ac49.js"
  },
  {
    "revision": "901d45e808dc84618478",
    "url": "/css/recharge.bfecf457.css"
  },
  {
    "revision": "901d45e808dc84618478",
    "url": "/js/recharge.7dd59091.js"
  },
  {
    "revision": "efbf69ec92294a911a44",
    "url": "/css/rechargeOrder.9970c52e.css"
  },
  {
    "revision": "efbf69ec92294a911a44",
    "url": "/js/rechargeOrder.988b9b3e.js"
  },
  {
    "revision": "02d19cd5b1b9adb7509f",
    "url": "/css/recharge_callback.bb080454.css"
  },
  {
    "revision": "02d19cd5b1b9adb7509f",
    "url": "/js/recharge_callback.30f59020.js"
  },
  {
    "revision": "ddf2f798d59d548dad5b",
    "url": "/css/recharge_wrapper.e624a46e.css"
  },
  {
    "revision": "ddf2f798d59d548dad5b",
    "url": "/js/recharge_wrapper.8c6a33c6.js"
  },
  {
    "revision": "fc94c2f1926798f90340",
    "url": "/css/refundRules.b82a6d0e.css"
  },
  {
    "revision": "fc94c2f1926798f90340",
    "url": "/js/refundRules.960703c4.js"
  },
  {
    "revision": "445d06e254b0e7ffec47",
    "url": "/js/Layout.6199f2c0.js"
  },
  {
    "revision": "aea18e1fc690e9682196",
    "url": "/js/Layout~card_usage.2893d1c4.js"
  },
  {
    "revision": "1d0ac9d8026ab55e5e43",
    "url": "/css/refund_argument.e3b1e80b.css"
  },
  {
    "revision": "1d0ac9d8026ab55e5e43",
    "url": "/js/refund_argument.fbecd76f.js"
  },
  {
    "revision": "00d961a328706248fbca",
    "url": "/css/refund_plan.ea04b1bc.css"
  },
  {
    "revision": "00d961a328706248fbca",
    "url": "/js/refund_plan.e8dfd187.js"
  },
  {
    "revision": "b16e7d476a7505d44e95",
    "url": "/css/refund_wrapper.cff284d8.css"
  },
  {
    "revision": "b16e7d476a7505d44e95",
    "url": "/js/refund_wrapper.eac9cc81.js"
  },
  {
    "revision": "68ee652e6532a018740e",
    "url": "/css/repeatRecharge.0cf1e6d1.css"
  },
  {
    "revision": "68ee652e6532a018740e",
    "url": "/js/repeatRecharge.44d335fc.js"
  },
  {
    "revision": "d374e58fd249a5141bd3",
    "url": "/css/revoke_plan.61a19168.css"
  },
  {
    "revision": "d374e58fd249a5141bd3",
    "url": "/js/revoke_plan.349eeabb.js"
  },
  {
    "revision": "3efd02719e59d4680845",
    "url": "/css/speedup_500.24158936.css"
  },
  {
    "revision": "3efd02719e59d4680845",
    "url": "/js/speedup_500.2dee047d.js"
  },
  {
    "revision": "27ce61b9dbf0d6b7746d",
    "url": "/css/speedup_80.863f4cd3.css"
  },
  {
    "revision": "27ce61b9dbf0d6b7746d",
    "url": "/js/speedup_80.b039a5d9.js"
  },
  {
    "revision": "41f28a5e876af9985e13",
    "url": "/css/speedup_wrapper.b45520a3.css"
  },
  {
    "revision": "41f28a5e876af9985e13",
    "url": "/js/speedup_wrapper.7b4cc455.js"
  },
  {
    "revision": "a4bdf03b4ca733671237",
    "url": "/css/to_tb.7168a430.css"
  },
  {
    "revision": "a4bdf03b4ca733671237",
    "url": "/js/to_tb.442535b0.js"
  },
  {
    "revision": "da9b151ef3a1d35dfc3c",
    "url": "/css/transfer_url.932da114.css"
  },
  {
    "revision": "da9b151ef3a1d35dfc3c",
    "url": "/js/transfer_url.6660d350.js"
  },
  {
    "revision": "45d2232df54a685ed8fd",
    "url": "/css/uploadIdInfo.0c412072.css"
  },
  {
    "revision": "45d2232df54a685ed8fd",
    "url": "/js/uploadIdInfo.d9887f16.js"
  },
  {
    "revision": "8547370c8d0634d96a81",
    "url": "/css/userCenter.f9031f72.css"
  },
  {
    "revision": "8547370c8d0634d96a81",
    "url": "/js/userCenter.d80af8b5.js"
  },
  {
    "revision": "5b2fccdbd3e825676897",
    "url": "/css/userCenterWrap.dfb1d208.css"
  },
  {
    "revision": "5b2fccdbd3e825676897",
    "url": "/js/userCenterWrap.c9390b7b.js"
  },
  {
    "revision": "ae39937a22c377d33819",
    "url": "/css/verifyInfo.4e549189.css"
  },
  {
    "revision": "ae39937a22c377d33819",
    "url": "/js/verifyInfo.407d354e.js"
  },
  {
    "revision": "e4b411644706c29765eea3ffdd85ae39",
    "url": "/fonts/SourceHanSansCNRegular.e4b41164.woff"
  },
  {
    "revision": "834b022ab9ab0e6063904af32274e777",
    "url": "/fonts/SourceHanSansCNRegular.834b022a.eot"
  },
  {
    "revision": "f9509c5a10be7daaf1fa01922a7c6bc2",
    "url": "/fonts/SourceHanSansCNRegular.f9509c5a.ttf"
  },
  {
    "revision": "da0808e9fe85be160aab69c82dd8de1c",
    "url": "/img/SourceHanSansCNRegular.da0808e9.svg"
  },
  {
    "revision": "732389ded34cb9c52dd88271f1345af9",
    "url": "/fonts/element-icons.732389de.ttf"
  },
  {
    "revision": "535877f50039c0cb49a6196a5b7517cd",
    "url": "/fonts/element-icons.535877f5.woff"
  },
  {
    "revision": "cb28460b38b9de81603addeacf165064",
    "url": "/img/result_success@3x.cb28460b.png"
  },
  {
    "revision": "ab7b6bac5b5d732b2207c49ad3bbf32b",
    "url": "/img/result_error@3x.ab7b6bac.png"
  },
  {
    "revision": "009e0aad44114271651c8859ba2803fb",
    "url": "/img/btn_camera@3x.009e0aad.png"
  },
  {
    "revision": "8053681a09934ec0745117c798770884",
    "url": "/img/card_person@3x.8053681a.png"
  },
  {
    "revision": "a38cf1db1ecb9f0759a551ecc03aa161",
    "url": "/img/card_national_emblem@3x.a38cf1db.png"
  },
  {
    "revision": "171573d0985aafafc274434182a38e06",
    "url": "/img/card_id_photo@2x.171573d0.png"
  },
  {
    "revision": "2b7d8fa5a82581aea8b0edbb0d600f70",
    "url": "/img/card_person@2x.2b7d8fa5.png"
  },
  {
    "revision": "b7a05a33f96811c6b26c47f566201f43",
    "url": "/img/card_id_photo@3x.b7a05a33.png"
  },
  {
    "revision": "f5f322478286641bd9887a155e35f222",
    "url": "/img/btn.f5f32247.png"
  },
  {
    "revision": "d140650fa64e0f1fc771610dba62aed7",
    "url": "/img/bg.d140650f.png"
  },
  {
    "revision": "e625229e32d9deeb5f2909c314d8e609",
    "url": "/img/ios@2x.e625229e.png"
  },
  {
    "revision": "af8bbdfa0a90c4eed4563f8c06ce5ff8",
    "url": "/img/android@2x.af8bbdfa.png"
  },
  {
    "revision": "3f342771b9b81ab929e0fbcbcd0e6533",
    "url": "/img/bg-check-wrap@3x.3f342771.png"
  },
  {
    "revision": "9713b21819c4019befecd095069977df",
    "url": "/img/bg-check-wrap@2x.9713b218.png"
  },
  {
    "revision": "1d7515ee61c3f659227318b4050955ed",
    "url": "/img/mobile_sim@2x.1d7515ee.png"
  },
  {
    "revision": "0f980b79d9a52702004de9f652a68835",
    "url": "/img/telcom_sim@2x.0f980b79.png"
  },
  {
    "revision": "98141226a7e992e3072a280746a259c4",
    "url": "/img/mobile_sim@3x.98141226.png"
  },
  {
    "revision": "0c88168b284b92c37f3a873f26a97d69",
    "url": "/img/bg.0c88168b.jpg"
  },
  {
    "revision": "9e02095f31a07b972244f1c714c1dfe7",
    "url": "/img/telcom_sim@3x.9e02095f.png"
  },
  {
    "revision": "b70eddccd257b21777e71bb64c83b876",
    "url": "/img/bg.b70eddcc.jpeg"
  },
  {
    "revision": "909816c3d34e63a9ad86b8c179ab543c",
    "url": "/img/bar.909816c3.png"
  },
  {
    "revision": "e92f547ba0209da3b4342fa2b56ea9ae",
    "url": "/img/animater.e92f547b.png"
  },
  {
    "revision": "3d0fc424b703032ca595090e99f8354b",
    "url": "/img/login_bg@2x.3d0fc424.png"
  },
  {
    "revision": "11000d4e510a6df565eb69ba6f2c1dfc",
    "url": "/img/login_bg@3x.11000d4e.png"
  },
  {
    "revision": "0f16389ec218c90cf8f657e233b745f2",
    "url": "/img/balanceBg1.0f16389e.png"
  },
  {
    "revision": "565459ef2ee8b71db421144ad21c23e3",
    "url": "/img/balanceBg2.565459ef.png"
  },
  {
    "revision": "91e1d2771efacd45e5e465d9a001f197",
    "url": "/img/liantong.91e1d277.png"
  },
  {
    "revision": "4a0cab0f33beb48ea985714d1b91fef7",
    "url": "/img/dianxin.4a0cab0f.png"
  },
  {
    "revision": "657033323334e91efb0011bbc18f8c04",
    "url": "/img/yidong.65703332.png"
  },
  {
    "revision": "8da3b83b73e44e54d6be4b2522bcb1f2",
    "url": "/img/pkgBg2.8da3b83b.png"
  },
  {
    "revision": "d3b42651f9f5048baeffb50c800913ec",
    "url": "/img/pkgBg1.d3b42651.png"
  },
  {
    "revision": "d461d18e42a310bd709b2ce97d159153",
    "url": "/img/pkgBg3.d461d18e.png"
  },
  {
    "revision": "6dedd4943e4c5848638196fb6f0c4145",
    "url": "/img/bg.6dedd494.png"
  },
  {
    "revision": "0078f03c08066d51d64b92a13e194ebb",
    "url": "/img/balanceRefund.0078f03c.png"
  },
  {
    "revision": "af3ed0b3236bbfdbc3ad61b8d41c3dec",
    "url": "/img/changeBg.af3ed0b3.png"
  },
  {
    "revision": "42c0fbd4915870e5e60452fd0ef2cbec",
    "url": "/img/orderTopBg@3x.42c0fbd4.png"
  },
  {
    "revision": "42c0fbd4915870e5e60452fd0ef2cbec",
    "url": "/img/orderTopBg@2x.42c0fbd4.png"
  },
  {
    "revision": "b899232b79ad9962c5ab5572775a0400",
    "url": "/img/card_index_bg@3x.b899232b.png"
  },
  {
    "revision": "b899232b79ad9962c5ab5572775a0400",
    "url": "/img/card_index_bg@2x.b899232b.png"
  },
  {
    "revision": "01355f175bd20423ce45a838c1a998a9",
    "url": "/img/bg.01355f17.png"
  },
  {
    "revision": "2a67b73145562669220aa4639e1ad58f",
    "url": "/img/icon3.2a67b731.png"
  },
  {
    "revision": "813b5319e378dafdda952c16ad89906b",
    "url": "/img/icon2.813b5319.png"
  },
  {
    "revision": "6e5cee7393060b0ec3dcd587c2518b94",
    "url": "/img/bg_test.6e5cee73.png"
  },
  {
    "revision": "d0ccbc8a35180bb40e027b44dd26035a",
    "url": "/img/youku.d0ccbc8a.png"
  },
  {
    "revision": "a859e9ca4606d567c42b9c7bcd4fdce9",
    "url": "/img/iccid_bg@2x.a859e9ca.png"
  },
  {
    "revision": "fa9050c4e9870e8fc0cd184f8515af4a",
    "url": "/img/iccid_bg@3x.fa9050c4.png"
  },
  {
    "revision": "fff5af4325410621aeec4e60b3b92d9b",
    "url": "/img/mifi_binding_bg@3x.fff5af43.png"
  },
  {
    "revision": "fff5af4325410621aeec4e60b3b92d9b",
    "url": "/img/mifi_binding_bg@2x.fff5af43.png"
  },
  {
    "revision": "2c51a1e53c1ea0b35086d8d7261b4933",
    "url": "/img/bg_network@3x.2c51a1e5.png"
  },
  {
    "revision": "32d70c8fc305e3647098f3de0c71b618",
    "url": "/img/bg_network@2x.32d70c8f.png"
  },
  {
    "revision": "014d354b9b25b67ae95857ba17e2f4cc",
    "url": "/img/activityPage.014d354b.png"
  },
  {
    "revision": "114a6e12b42b9b48586dd341105188fe",
    "url": "/img/usedOrder@2x.114a6e12.png"
  },
  {
    "revision": "c0170ec299b2418256fd515ee7849055",
    "url": "/img/unUsedOrder@2x.c0170ec2.png"
  },
  {
    "revision": "d9e14058d30dd312519fcf2de38d742b",
    "url": "/img/unUsedOrder@3x.d9e14058.png"
  },
  {
    "revision": "4a5b90f8076955f289b3dcda6a5af6ff",
    "url": "/img/invaildedOrder@3x.4a5b90f8.png"
  },
  {
    "revision": "0d5a5158e67bcb7a4604124715ed6fbf",
    "url": "/img/usedOrder@3x.0d5a5158.png"
  },
  {
    "revision": "be0f1e33b2553e71b117d3d3f838d32f",
    "url": "/img/invaildedOrder@2x.be0f1e33.png"
  },
  {
    "revision": "3603a35a49dbb8ad94ec1e57c4dad229",
    "url": "/img/scanTop2.3603a35a.png"
  },
  {
    "revision": "05775dd69c53d7273b27aaa7c6c523f7",
    "url": "/img/04.05775dd6.png"
  },
  {
    "revision": "541375e6bb7db2fba9e415be8045f5fb",
    "url": "/img/1.541375e6.png"
  },
  {
    "revision": "7c28431d304fa4f58f5070c59720683a",
    "url": "/img/2.7c28431d.png"
  },
  {
    "revision": "5a3428653945c17e1c146efeee81c987",
    "url": "/img/scanTop.5a342865.png"
  },
  {
    "revision": "824594523c01e48028f2b7eb4261134d",
    "url": "/img/unicom-logo.82459452.svg"
  },
  {
    "revision": "113f99e2189c2ca49db2168754fc2eb5",
    "url": "/img/mobile-logo.113f99e2.png"
  },
  {
    "revision": "0cba868fa977e09806638b9000636a36",
    "url": "/img/avatar.0cba868f.jpeg"
  },
  {
    "revision": "27158aa79eb0d4b89f317d076a801ca3",
    "url": "/img/coupon-log.27158aa7.png"
  },
  {
    "revision": "55d3f2f09efe17db6485d4c9f8f0c3b1",
    "url": "/img/icon-recharge_20181001.55d3f2f0.svg"
  },
  {
    "revision": "165beb68d8ba0d2b70df0fbb3769787a",
    "url": "/img/03.165beb68.png"
  },
  {
    "revision": "5f1f34037094c0613bccafa2ddd8cb3b",
    "url": "/img/telecom-logo.5f1f3403.svg"
  },
  {
    "revision": "0b3c3297decbd1152a314cce115f9632",
    "url": "/img/09.0b3c3297.png"
  },
  {
    "revision": "644e6e3cf5f33943747b116316694e28",
    "url": "/img/noData@2x.644e6e3c.png"
  },
  {
    "revision": "3e217df4202e41ad9b030aafc8cfcc24",
    "url": "/img/4.3e217df4.png"
  },
  {
    "revision": "aecc9531f2c3b1fd45338e7bf5084384",
    "url": "/img/bg_no_recharge.aecc9531.svg"
  },
  {
    "revision": "b0ffa4a0fd195a110ee4d4dabce3bc32",
    "url": "/img/08.b0ffa4a0.png"
  },
  {
    "revision": "96fab583abd57f2e7118324858fa3080",
    "url": "/img/05.96fab583.png"
  },
  {
    "revision": "9e8ecc7f7b760b55c56bddfab886da10",
    "url": "/img/3.9e8ecc7f.png"
  },
  {
    "revision": "275be51ae57c486bce58257febd6589f",
    "url": "/img/bg_no_plan.275be51a.svg"
  },
  {
    "revision": "a8272d2d742d9d50257e23dfac577def",
    "url": "/img/01.a8272d2d.png"
  },
  {
    "revision": "daa86b540bb9c2a6453ceac9bed77961",
    "url": "/img/07.daa86b54.png"
  },
  {
    "revision": "06385746a7cedb492d5539907631561c",
    "url": "/img/tip.06385746.png"
  },
  {
    "revision": "eacba58f9acf2b87cd801858146b2ba9",
    "url": "/img/02.eacba58f.png"
  },
  {
    "revision": "39d9e849fc1c724525f166646932a24d",
    "url": "/img/safari.39d9e849.png"
  },
  {
    "revision": "999589aae784a460b5e7c6ae9bbaa3d8",
    "url": "/img/06.999589aa.png"
  },
  {
    "revision": "de27cefccb3741ae28775de6cb54ff9f",
    "url": "/index.html"
  },
  {
    "revision": "445d06e254b0e7ffec47",
    "url": "/css/Layout.be4cf75c.css"
  },
  {
    "revision": "9ce16f441b39b493af8b96d7e97cce22",
    "url": "/MP_verify_dkzAKjxyVyJvsHMS.txt"
  },
  {
    "revision": "86c422d8c98b247235d04b49fb1c4b05",
    "url": "/MP_verify_bKSdn2qZlUSULliu.txt"
  },
  {
    "revision": "652317b098ca24e4511926c7fd57cbbe",
    "url": "/MP_verify_8JoCCldW78DygS5c.txt"
  },
  {
    "revision": "00bbf6b458bf7ea6bd01f443eb3045d9",
    "url": "/MP_verify_4r3DVk3KUjgWsQsG.txt"
  }
];