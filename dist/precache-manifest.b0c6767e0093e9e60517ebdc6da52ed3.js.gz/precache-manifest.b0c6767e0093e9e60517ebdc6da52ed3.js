self.__precacheManifest = [
  {
    "revision": "8f2992899930a05640b8",
    "url": "/css/refund_applying.359849d0.css"
  },
  {
    "revision": "aeb56096965082ce3628",
    "url": "/css/Layout.a3c868d6.css"
  },
  {
    "revision": "a075d4b0a2a227b3317e",
    "url": "/css/Not_fund.8eb1c097.css"
  },
  {
    "revision": "a075d4b0a2a227b3317e",
    "url": "/js/Not_fund.93e1fada.js"
  },
  {
    "revision": "9ea1cb7b3f210633188c",
    "url": "/css/addSalesRecords.cf51b131.css"
  },
  {
    "revision": "9ea1cb7b3f210633188c",
    "url": "/js/addSalesRecords.4dc3acc1.js"
  },
  {
    "revision": "52f4b074285846613edb",
    "url": "/css/app.97457166.css"
  },
  {
    "revision": "52f4b074285846613edb",
    "url": "/js/app.f0f6291e.js"
  },
  {
    "revision": "6dd94dd62a191120c5a7",
    "url": "/css/authority_middle.fdedab6c.css"
  },
  {
    "revision": "6dd94dd62a191120c5a7",
    "url": "/js/authority_middle.a4146830.js"
  },
  {
    "revision": "4131496016e76a1e1aa2",
    "url": "/css/card_check.6ee82010.css"
  },
  {
    "revision": "4131496016e76a1e1aa2",
    "url": "/js/card_check.c3a291fa.js"
  },
  {
    "revision": "eb68863940d2397ee5e2",
    "url": "/css/card_connection.4e060f47.css"
  },
  {
    "revision": "eb68863940d2397ee5e2",
    "url": "/js/card_connection.e8713a3a.js"
  },
  {
    "revision": "cfcd9800d1e6a5b0a84d",
    "url": "/css/card_lookup.4e495813.css"
  },
  {
    "revision": "cfcd9800d1e6a5b0a84d",
    "url": "/js/card_lookup.7d17b018.js"
  },
  {
    "revision": "0be3ce96104bacf98032",
    "url": "/css/card_usage.391450bf.css"
  },
  {
    "revision": "0be3ce96104bacf98032",
    "url": "/js/card_usage.5aba5fb3.js"
  },
  {
    "revision": "e3de9fe9350508cb8bdd",
    "url": "/js/card_usage~eqReplaceMent~esim_plan_list~esim_usage~mifi_order~mifi_plan_list~mifi_plan_usage~plan_li~f915d233.7f59822f.js"
  },
  {
    "revision": "4dccdbd601525fd2b6d3",
    "url": "/css/card_wrapper.31258838.css"
  },
  {
    "revision": "4dccdbd601525fd2b6d3",
    "url": "/js/card_wrapper.fd793605.js"
  },
  {
    "revision": "ba4eb831902f707ab81f",
    "url": "/css/children_card.f05136a3.css"
  },
  {
    "revision": "ba4eb831902f707ab81f",
    "url": "/js/children_card.da242c56.js"
  },
  {
    "revision": "af136a414a95246b54a4",
    "url": "/css/chunk-3175df15.d7982382.css"
  },
  {
    "revision": "af136a414a95246b54a4",
    "url": "/js/chunk-3175df15.1d9dcac8.js"
  },
  {
    "revision": "00daf38c0bf364a0f9bb",
    "url": "/css/chunk-7b3e02f8.6e41d363.css"
  },
  {
    "revision": "00daf38c0bf364a0f9bb",
    "url": "/js/chunk-7b3e02f8.61f4382d.js"
  },
  {
    "revision": "269e27b4a18d38c07113",
    "url": "/css/chunk-vendors.845797cf.css"
  },
  {
    "revision": "269e27b4a18d38c07113",
    "url": "/js/chunk-vendors.0c664671.js"
  },
  {
    "revision": "50c118379670ed4b262a",
    "url": "/css/commonProblem.55b1bee4.css"
  },
  {
    "revision": "50c118379670ed4b262a",
    "url": "/js/commonProblem.de5122ee.js"
  },
  {
    "revision": "dc7a77c8e22241088a4f",
    "url": "/css/contactUs.59499bc0.css"
  },
  {
    "revision": "dc7a77c8e22241088a4f",
    "url": "/js/contactUs.12909563.js"
  },
  {
    "revision": "df9b8833e0135adcd0b4",
    "url": "/css/coupon_normal.b9f522ab.css"
  },
  {
    "revision": "df9b8833e0135adcd0b4",
    "url": "/js/coupon_normal.1ea417ee.js"
  },
  {
    "revision": "2d3f899f6d0f22902d34",
    "url": "/css/coupon_telcom.19461797.css"
  },
  {
    "revision": "2d3f899f6d0f22902d34",
    "url": "/js/coupon_telcom.c920e678.js"
  },
  {
    "revision": "a67e1d502950055e3a23",
    "url": "/css/coupon_wrapper.89c329fd.css"
  },
  {
    "revision": "a67e1d502950055e3a23",
    "url": "/js/coupon_wrapper.f53634a8.js"
  },
  {
    "revision": "6cd063e819b8186d30a0",
    "url": "/css/eqReplaceMent.b29c6430.css"
  },
  {
    "revision": "6cd063e819b8186d30a0",
    "url": "/js/eqReplaceMent.bc4c4b5d.js"
  },
  {
    "revision": "56eeeb57560c543c5c6f",
    "url": "/css/esim_plan_list.576f61c4.css"
  },
  {
    "revision": "56eeeb57560c543c5c6f",
    "url": "/js/esim_plan_list.1382d40b.js"
  },
  {
    "revision": "b3334ded1854b55ea38c",
    "url": "/css/esim_usage.cb030da5.css"
  },
  {
    "revision": "b3334ded1854b55ea38c",
    "url": "/js/esim_usage.89496e85.js"
  },
  {
    "revision": "f1a3de06f468719cd83a",
    "url": "/css/find_plan.8b35510e.css"
  },
  {
    "revision": "f1a3de06f468719cd83a",
    "url": "/js/find_plan.60093ce2.js"
  },
  {
    "revision": "ce77adbb4c15f26ae39a",
    "url": "/css/helpCenter.2262a1e9.css"
  },
  {
    "revision": "ce77adbb4c15f26ae39a",
    "url": "/js/helpCenter.04fe27c3.js"
  },
  {
    "revision": "f9a51aea25db7c60517e",
    "url": "/css/logical_page.2a42509b.css"
  },
  {
    "revision": "f9a51aea25db7c60517e",
    "url": "/js/logical_page.f5c2d7b3.js"
  },
  {
    "revision": "3f279e3b9e3e20d02f81",
    "url": "/css/login.f698dc3a.css"
  },
  {
    "revision": "3f279e3b9e3e20d02f81",
    "url": "/js/login.151455bc.js"
  },
  {
    "revision": "8e226d35f26509e82a48",
    "url": "/css/lookup.ff0cf398.css"
  },
  {
    "revision": "8e226d35f26509e82a48",
    "url": "/js/lookup.7d4a4ab2.js"
  },
  {
    "revision": "d47eddddd7e017778f7f",
    "url": "/css/mifi_binding.db536d39.css"
  },
  {
    "revision": "d47eddddd7e017778f7f",
    "url": "/js/mifi_binding.6860eb82.js"
  },
  {
    "revision": "1e6b95d65e7f52327929",
    "url": "/css/mifi_card_info.2144b3cb.css"
  },
  {
    "revision": "1e6b95d65e7f52327929",
    "url": "/js/mifi_card_info.4ee07102.js"
  },
  {
    "revision": "1cd5a2e846f25edd2914",
    "url": "/css/mifi_card_lookup.3bc30525.css"
  },
  {
    "revision": "1cd5a2e846f25edd2914",
    "url": "/js/mifi_card_lookup.0f928091.js"
  },
  {
    "revision": "8c3eac8173738c313aa7",
    "url": "/css/mifi_card_wrapper.efcdaad9.css"
  },
  {
    "revision": "8c3eac8173738c313aa7",
    "url": "/js/mifi_card_wrapper.47980b7d.js"
  },
  {
    "revision": "1b20e6292182ce540fca",
    "url": "/css/mifi_change_network.19a7585f.css"
  },
  {
    "revision": "1b20e6292182ce540fca",
    "url": "/js/mifi_change_network.ca630c85.js"
  },
  {
    "revision": "6ecf0e4ffaf4b60be77e",
    "url": "/css/mifi_coupon_index.e6a718de.css"
  },
  {
    "revision": "6ecf0e4ffaf4b60be77e",
    "url": "/js/mifi_coupon_index.a7f30ad1.js"
  },
  {
    "revision": "3764d330a91cb9575307",
    "url": "/css/mifi_coupon_wrapper.56a3339d.css"
  },
  {
    "revision": "3764d330a91cb9575307",
    "url": "/js/mifi_coupon_wrapper.34b92e26.js"
  },
  {
    "revision": "7f4c23fc196169059dff",
    "url": "/css/mifi_index.9d017776.css"
  },
  {
    "revision": "7f4c23fc196169059dff",
    "url": "/js/mifi_index.7df00200.js"
  },
  {
    "revision": "d5ec40c484b0339b10ce",
    "url": "/css/mifi_layout.4ae65286.css"
  },
  {
    "revision": "d5ec40c484b0339b10ce",
    "url": "/js/mifi_layout.add3ce7a.js"
  },
  {
    "revision": "7c244c7d76d73ffd49b6",
    "url": "/css/mifi_order.34fdd4ca.css"
  },
  {
    "revision": "7c244c7d76d73ffd49b6",
    "url": "/js/mifi_order.2baabbed.js"
  },
  {
    "revision": "185caa8c95e7cbb59c2b",
    "url": "/css/mifi_order_wrapper.c09367ca.css"
  },
  {
    "revision": "185caa8c95e7cbb59c2b",
    "url": "/js/mifi_order_wrapper.f5f2c4be.js"
  },
  {
    "revision": "0e3374b5b87d7be5ae97",
    "url": "/css/mifi_order~mifi_plan_group.649e1a31.css"
  },
  {
    "revision": "0e3374b5b87d7be5ae97",
    "url": "/js/mifi_order~mifi_plan_group.2b2aed2a.js"
  },
  {
    "revision": "02bcba5a7c7a79057470",
    "url": "/css/mifi_plan_group.d655ac1b.css"
  },
  {
    "revision": "02bcba5a7c7a79057470",
    "url": "/js/mifi_plan_group.bb85bc76.js"
  },
  {
    "revision": "cd156f004ac3516f1ca3",
    "url": "/css/mifi_plan_list.4058e2ca.css"
  },
  {
    "revision": "cd156f004ac3516f1ca3",
    "url": "/js/mifi_plan_list.d2378fed.js"
  },
  {
    "revision": "b8d47e98f193c111b1ef",
    "url": "/css/mifi_plan_usage.106b445d.css"
  },
  {
    "revision": "b8d47e98f193c111b1ef",
    "url": "/js/mifi_plan_usage.fea01542.js"
  },
  {
    "revision": "2713bb50d6fb1e9bcf8a",
    "url": "/css/mifi_plan_wrapper.eeb3aab7.css"
  },
  {
    "revision": "2713bb50d6fb1e9bcf8a",
    "url": "/js/mifi_plan_wrapper.f5e0cdfa.js"
  },
  {
    "revision": "7896e1f98483a890920d",
    "url": "/css/new_card_wrapper.30e0f4fe.css"
  },
  {
    "revision": "7896e1f98483a890920d",
    "url": "/js/new_card_wrapper.26f79bbf.js"
  },
  {
    "revision": "bd325757a157927fbc18",
    "url": "/css/plan_list.dfecf9ff.css"
  },
  {
    "revision": "bd325757a157927fbc18",
    "url": "/js/plan_list.e2cc61fa.js"
  },
  {
    "revision": "72be01c0850d5aa1c0b5",
    "url": "/css/question.3f323bf8.css"
  },
  {
    "revision": "72be01c0850d5aa1c0b5",
    "url": "/js/question.99990c66.js"
  },
  {
    "revision": "9184686c8116602cbd04",
    "url": "/css/question_wrapper.50c34f6c.css"
  },
  {
    "revision": "9184686c8116602cbd04",
    "url": "/js/question_wrapper.9b7ff245.js"
  },
  {
    "revision": "1f45291fb7d745be5d9a",
    "url": "/css/realName.467e30c0.css"
  },
  {
    "revision": "1f45291fb7d745be5d9a",
    "url": "/js/realName.48be343c.js"
  },
  {
    "revision": "f9a7ee75b13367b673e4",
    "url": "/css/realNameCourse.59e88dd7.css"
  },
  {
    "revision": "f9a7ee75b13367b673e4",
    "url": "/js/realNameCourse.b4f27469.js"
  },
  {
    "revision": "e473a9aab5d3f22c9c4b",
    "url": "/css/real_name.ac8e34f3.css"
  },
  {
    "revision": "e473a9aab5d3f22c9c4b",
    "url": "/js/real_name.d90031bc.js"
  },
  {
    "revision": "e2ba81ae4294ccbcf984",
    "url": "/css/recharge.4744f805.css"
  },
  {
    "revision": "e2ba81ae4294ccbcf984",
    "url": "/js/recharge.a34f7e12.js"
  },
  {
    "revision": "ae9e71cdb7d25e681969",
    "url": "/css/rechargeRecord.669399f0.css"
  },
  {
    "revision": "ae9e71cdb7d25e681969",
    "url": "/js/rechargeRecord.1de6fe97.js"
  },
  {
    "revision": "36edcddebf8d86956077",
    "url": "/css/recharge_callback.989ec6d7.css"
  },
  {
    "revision": "36edcddebf8d86956077",
    "url": "/js/recharge_callback.d2489c33.js"
  },
  {
    "revision": "f3bb6b8ae342b928e7ff",
    "url": "/css/recharge_wrapper.9b92bcd2.css"
  },
  {
    "revision": "f3bb6b8ae342b928e7ff",
    "url": "/js/recharge_wrapper.6af5ce98.js"
  },
  {
    "revision": "aeb56096965082ce3628",
    "url": "/js/Layout.8580c85a.js"
  },
  {
    "revision": "8f2992899930a05640b8",
    "url": "/js/refund_applying.30326a6d.js"
  },
  {
    "revision": "da96a1dfaaf3bf0ee1a2",
    "url": "/css/refund_argument.21d9320c.css"
  },
  {
    "revision": "da96a1dfaaf3bf0ee1a2",
    "url": "/js/refund_argument.609608e6.js"
  },
  {
    "revision": "8636e2d145f480f3897a",
    "url": "/css/refund_plan.c484110a.css"
  },
  {
    "revision": "8636e2d145f480f3897a",
    "url": "/js/refund_plan.40003922.js"
  },
  {
    "revision": "f1740171b6faafbc71bb",
    "url": "/css/refund_wrapper.8ab9a0db.css"
  },
  {
    "revision": "f1740171b6faafbc71bb",
    "url": "/js/refund_wrapper.688b94ac.js"
  },
  {
    "revision": "176196e5367e42871971",
    "url": "/css/repeatRecharge.15a3a6c8.css"
  },
  {
    "revision": "176196e5367e42871971",
    "url": "/js/repeatRecharge.f5cec89b.js"
  },
  {
    "revision": "b7194f26337cd5a0eb77",
    "url": "/css/revoke_plan.569cf52d.css"
  },
  {
    "revision": "b7194f26337cd5a0eb77",
    "url": "/js/revoke_plan.3e15a3e7.js"
  },
  {
    "revision": "d7adacfce98bb6882429",
    "url": "/css/salesRecords.e7b75d79.css"
  },
  {
    "revision": "d7adacfce98bb6882429",
    "url": "/js/salesRecords.baf4633d.js"
  },
  {
    "revision": "552d4f47675018f42437",
    "url": "/css/speedup_500.073b7a81.css"
  },
  {
    "revision": "552d4f47675018f42437",
    "url": "/js/speedup_500.19319ade.js"
  },
  {
    "revision": "f2b7643f82969435bbb2",
    "url": "/css/speedup_80.a54a5ac3.css"
  },
  {
    "revision": "f2b7643f82969435bbb2",
    "url": "/js/speedup_80.19ab231e.js"
  },
  {
    "revision": "31da478ac790358d8fa9",
    "url": "/css/speedup_wrapper.39e18c84.css"
  },
  {
    "revision": "31da478ac790358d8fa9",
    "url": "/js/speedup_wrapper.603e1540.js"
  },
  {
    "revision": "414e092bd9c789b15af8",
    "url": "/css/to_tb.4baa7294.css"
  },
  {
    "revision": "414e092bd9c789b15af8",
    "url": "/js/to_tb.5f45b6a2.js"
  },
  {
    "revision": "dca7059aca7038165151",
    "url": "/css/userCenter.db894a30.css"
  },
  {
    "revision": "dca7059aca7038165151",
    "url": "/js/userCenter.436679fe.js"
  },
  {
    "revision": "66d4cc47559952de3587",
    "url": "/css/userCenterAddress.219b7499.css"
  },
  {
    "revision": "66d4cc47559952de3587",
    "url": "/js/userCenterAddress.f5681b84.js"
  },
  {
    "revision": "60f81e0a292da946e7c8",
    "url": "/css/userCenterWrap.80fa7896.css"
  },
  {
    "revision": "60f81e0a292da946e7c8",
    "url": "/js/userCenterWrap.94e26532.js"
  },
  {
    "revision": "e4b411644706c29765eea3ffdd85ae39",
    "url": "/fonts/SourceHanSansCNRegular.e4b41164.woff"
  },
  {
    "revision": "834b022ab9ab0e6063904af32274e777",
    "url": "/fonts/SourceHanSansCNRegular.834b022a.eot"
  },
  {
    "revision": "f9509c5a10be7daaf1fa01922a7c6bc2",
    "url": "/fonts/SourceHanSansCNRegular.f9509c5a.ttf"
  },
  {
    "revision": "da0808e9fe85be160aab69c82dd8de1c",
    "url": "/img/SourceHanSansCNRegular.da0808e9.svg"
  },
  {
    "revision": "732389ded34cb9c52dd88271f1345af9",
    "url": "/fonts/element-icons.732389de.ttf"
  },
  {
    "revision": "535877f50039c0cb49a6196a5b7517cd",
    "url": "/fonts/element-icons.535877f5.woff"
  },
  {
    "revision": "ad4acc3d7da28ce6f33925b83bae2c94",
    "url": "/img/arrow1.ad4acc3d.png"
  },
  {
    "revision": "fff5af4325410621aeec4e60b3b92d9b",
    "url": "/img/mifi_binding_bg@3x.fff5af43.png"
  },
  {
    "revision": "fff5af4325410621aeec4e60b3b92d9b",
    "url": "/img/mifi_binding_bg@2x.fff5af43.png"
  },
  {
    "revision": "a1386d312938b126d701a6841fb742e8",
    "url": "/img/addressIcon.a1386d31.png"
  },
  {
    "revision": "83d0cd2dc163e83ef26f6bad98661da8",
    "url": "/img/addressBg.83d0cd2d.png"
  },
  {
    "revision": "a859e9ca4606d567c42b9c7bcd4fdce9",
    "url": "/img/iccid_bg@2x.a859e9ca.png"
  },
  {
    "revision": "fa9050c4e9870e8fc0cd184f8515af4a",
    "url": "/img/iccid_bg@3x.fa9050c4.png"
  },
  {
    "revision": "42c0fbd4915870e5e60452fd0ef2cbec",
    "url": "/img/orderTopBg@3x.42c0fbd4.png"
  },
  {
    "revision": "42c0fbd4915870e5e60452fd0ef2cbec",
    "url": "/img/orderTopBg@2x.42c0fbd4.png"
  },
  {
    "revision": "b899232b79ad9962c5ab5572775a0400",
    "url": "/img/card_index_bg@3x.b899232b.png"
  },
  {
    "revision": "b899232b79ad9962c5ab5572775a0400",
    "url": "/img/card_index_bg@2x.b899232b.png"
  },
  {
    "revision": "6e5cee7393060b0ec3dcd587c2518b94",
    "url": "/img/bg_test.6e5cee73.png"
  },
  {
    "revision": "2c51a1e53c1ea0b35086d8d7261b4933",
    "url": "/img/bg_network@3x.2c51a1e5.png"
  },
  {
    "revision": "32d70c8fc305e3647098f3de0c71b618",
    "url": "/img/bg_network@2x.32d70c8f.png"
  },
  {
    "revision": "d32e5dc3875f1afd2be29aad1cfd0382",
    "url": "/img/contactBg.d32e5dc3.png"
  },
  {
    "revision": "f5f322478286641bd9887a155e35f222",
    "url": "/img/btn.f5f32247.png"
  },
  {
    "revision": "d140650fa64e0f1fc771610dba62aed7",
    "url": "/img/bg.d140650f.png"
  },
  {
    "revision": "3f342771b9b81ab929e0fbcbcd0e6533",
    "url": "/img/bg-check-wrap@3x.3f342771.png"
  },
  {
    "revision": "9713b21819c4019befecd095069977df",
    "url": "/img/bg-check-wrap@2x.9713b218.png"
  },
  {
    "revision": "e625229e32d9deeb5f2909c314d8e609",
    "url": "/img/ios@2x.e625229e.png"
  },
  {
    "revision": "af8bbdfa0a90c4eed4563f8c06ce5ff8",
    "url": "/img/android@2x.af8bbdfa.png"
  },
  {
    "revision": "1d7515ee61c3f659227318b4050955ed",
    "url": "/img/mobile_sim@2x.1d7515ee.png"
  },
  {
    "revision": "0f980b79d9a52702004de9f652a68835",
    "url": "/img/telcom_sim@2x.0f980b79.png"
  },
  {
    "revision": "98141226a7e992e3072a280746a259c4",
    "url": "/img/mobile_sim@3x.98141226.png"
  },
  {
    "revision": "0c88168b284b92c37f3a873f26a97d69",
    "url": "/img/bg.0c88168b.jpg"
  },
  {
    "revision": "9e02095f31a07b972244f1c714c1dfe7",
    "url": "/img/telcom_sim@3x.9e02095f.png"
  },
  {
    "revision": "114a6e12b42b9b48586dd341105188fe",
    "url": "/img/usedOrder@2x.114a6e12.png"
  },
  {
    "revision": "c0170ec299b2418256fd515ee7849055",
    "url": "/img/unUsedOrder@2x.c0170ec2.png"
  },
  {
    "revision": "d9e14058d30dd312519fcf2de38d742b",
    "url": "/img/unUsedOrder@3x.d9e14058.png"
  },
  {
    "revision": "4a5b90f8076955f289b3dcda6a5af6ff",
    "url": "/img/invaildedOrder@3x.4a5b90f8.png"
  },
  {
    "revision": "0d5a5158e67bcb7a4604124715ed6fbf",
    "url": "/img/usedOrder@3x.0d5a5158.png"
  },
  {
    "revision": "be0f1e33b2553e71b117d3d3f838d32f",
    "url": "/img/invaildedOrder@2x.be0f1e33.png"
  },
  {
    "revision": "3d0fc424b703032ca595090e99f8354b",
    "url": "/img/login_bg@2x.3d0fc424.png"
  },
  {
    "revision": "11000d4e510a6df565eb69ba6f2c1dfc",
    "url": "/img/login_bg@3x.11000d4e.png"
  },
  {
    "revision": "014d354b9b25b67ae95857ba17e2f4cc",
    "url": "/img/activityPage.014d354b.png"
  },
  {
    "revision": "2a67b73145562669220aa4639e1ad58f",
    "url": "/img/icon3.2a67b731.png"
  },
  {
    "revision": "813b5319e378dafdda952c16ad89906b",
    "url": "/img/icon2.813b5319.png"
  },
  {
    "revision": "01355f175bd20423ce45a838c1a998a9",
    "url": "/img/bg.01355f17.png"
  },
  {
    "revision": "6eb1cce5bab9ec1cb25d71e8f3110a15",
    "url": "/img/real7.6eb1cce5.jpeg"
  },
  {
    "revision": "3603a35a49dbb8ad94ec1e57c4dad229",
    "url": "/img/scanTop2.3603a35a.png"
  },
  {
    "revision": "b74ee4a485ffa8d4339c3412ac6659be",
    "url": "/img/real6.b74ee4a4.jpeg"
  },
  {
    "revision": "05775dd69c53d7273b27aaa7c6c523f7",
    "url": "/img/04.05775dd6.png"
  },
  {
    "revision": "5a3428653945c17e1c146efeee81c987",
    "url": "/img/scanTop.5a342865.png"
  },
  {
    "revision": "824594523c01e48028f2b7eb4261134d",
    "url": "/img/unicom-logo.82459452.svg"
  },
  {
    "revision": "113f99e2189c2ca49db2168754fc2eb5",
    "url": "/img/mobile-logo.113f99e2.png"
  },
  {
    "revision": "0cba868fa977e09806638b9000636a36",
    "url": "/img/avatar.0cba868f.jpeg"
  },
  {
    "revision": "a5b636104342050950abea60fb65f9cd",
    "url": "/img/qrImg.a5b63610.png"
  },
  {
    "revision": "27158aa79eb0d4b89f317d076a801ca3",
    "url": "/img/coupon-log.27158aa7.png"
  },
  {
    "revision": "55d3f2f09efe17db6485d4c9f8f0c3b1",
    "url": "/img/icon-recharge_20181001.55d3f2f0.svg"
  },
  {
    "revision": "165beb68d8ba0d2b70df0fbb3769787a",
    "url": "/img/03.165beb68.png"
  },
  {
    "revision": "5f1f34037094c0613bccafa2ddd8cb3b",
    "url": "/img/telecom-logo.5f1f3403.svg"
  },
  {
    "revision": "0b3c3297decbd1152a314cce115f9632",
    "url": "/img/09.0b3c3297.png"
  },
  {
    "revision": "644e6e3cf5f33943747b116316694e28",
    "url": "/img/noData@2x.644e6e3c.png"
  },
  {
    "revision": "4bdbe7dbdb6587c886a8290593100145",
    "url": "/img/recharge_callback_20181126.4bdbe7db.jpg"
  },
  {
    "revision": "aecc9531f2c3b1fd45338e7bf5084384",
    "url": "/img/bg_no_recharge.aecc9531.svg"
  },
  {
    "revision": "b0ffa4a0fd195a110ee4d4dabce3bc32",
    "url": "/img/08.b0ffa4a0.png"
  },
  {
    "revision": "96fab583abd57f2e7118324858fa3080",
    "url": "/img/05.96fab583.png"
  },
  {
    "revision": "3af1a9430facd73c667ba61919fc414e",
    "url": "/img/real5.3af1a943.jpeg"
  },
  {
    "revision": "275be51ae57c486bce58257febd6589f",
    "url": "/img/bg_no_plan.275be51a.svg"
  },
  {
    "revision": "1cf937a060cb282e8b60ed6a7ec78604",
    "url": "/img/real3.1cf937a0.jpeg"
  },
  {
    "revision": "45fb414691fd8f78628e3e94f9db1ad4",
    "url": "/img/real2.45fb4146.jpeg"
  },
  {
    "revision": "a8272d2d742d9d50257e23dfac577def",
    "url": "/img/01.a8272d2d.png"
  },
  {
    "revision": "daa86b540bb9c2a6453ceac9bed77961",
    "url": "/img/07.daa86b54.png"
  },
  {
    "revision": "a6d17ceb63edb524e63c9bbc7c671fec",
    "url": "/img/real4.a6d17ceb.jpeg"
  },
  {
    "revision": "eacba58f9acf2b87cd801858146b2ba9",
    "url": "/img/02.eacba58f.png"
  },
  {
    "revision": "39d9e849fc1c724525f166646932a24d",
    "url": "/img/safari.39d9e849.png"
  },
  {
    "revision": "999589aae784a460b5e7c6ae9bbaa3d8",
    "url": "/img/06.999589aa.png"
  },
  {
    "revision": "1cc77fe95a0f28837ecea2300db5756d",
    "url": "/img/real1.1cc77fe9.jpeg"
  },
  {
    "revision": "018b5f611723dcd170b93822b6dfc48d",
    "url": "/img/real8.018b5f61.jpeg"
  },
  {
    "revision": "e07ba2f3efd5d6f434b6aae7c522b399",
    "url": "/index.html"
  },
  {
    "revision": "b6216d61c03e6ce0c9aea6ca7808f7ca",
    "url": "/robots.txt"
  },
  {
    "revision": "9ce16f441b39b493af8b96d7e97cce22",
    "url": "/MP_verify_dkzAKjxyVyJvsHMS.txt"
  },
  {
    "revision": "86c422d8c98b247235d04b49fb1c4b05",
    "url": "/MP_verify_bKSdn2qZlUSULliu.txt"
  },
  {
    "revision": "652317b098ca24e4511926c7fd57cbbe",
    "url": "/MP_verify_8JoCCldW78DygS5c.txt"
  },
  {
    "revision": "00bbf6b458bf7ea6bd01f443eb3045d9",
    "url": "/MP_verify_4r3DVk3KUjgWsQsG.txt"
  }
];