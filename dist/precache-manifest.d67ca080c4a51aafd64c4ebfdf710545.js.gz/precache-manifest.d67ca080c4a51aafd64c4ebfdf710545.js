self.__precacheManifest = [
  {
    "revision": "e53644a54c7fd7943c75",
    "url": "/css/refund_applying.a765fb53.css"
  },
  {
    "revision": "ebcb76dad3c727a6ddc3",
    "url": "/css/Layout.83a36cb0.css"
  },
  {
    "revision": "be40bca99df105cbae95",
    "url": "/css/Layout~card_usage.cb0d2a22.css"
  },
  {
    "revision": "be40bca99df105cbae95",
    "url": "/js/Layout~card_usage.bcf0ce41.js"
  },
  {
    "revision": "78214ba34c5f1df936aa",
    "url": "/js/Layout~card_usage~eqReplaceMent~esim_plan_list~esim_usage~mifi_order~mifi_plan_list~mifi_plan_usage~~c6f87c36.6241bd21.js"
  },
  {
    "revision": "33bc8d7c0421214121c0",
    "url": "/css/Not_fund.441b338e.css"
  },
  {
    "revision": "33bc8d7c0421214121c0",
    "url": "/js/Not_fund.a6629d31.js"
  },
  {
    "revision": "ca1e4435e73924143ed2",
    "url": "/css/app.72184c26.css"
  },
  {
    "revision": "ca1e4435e73924143ed2",
    "url": "/js/app.472a6ee3.js"
  },
  {
    "revision": "0a19ab25edbf5f9ca397",
    "url": "/css/auditFail.0f734e22.css"
  },
  {
    "revision": "0a19ab25edbf5f9ca397",
    "url": "/js/auditFail.c709775b.js"
  },
  {
    "revision": "65cba5ebb64be3a78cea",
    "url": "/css/auditSuccess.60aa705f.css"
  },
  {
    "revision": "65cba5ebb64be3a78cea",
    "url": "/js/auditSuccess.97754482.js"
  },
  {
    "revision": "c8f537e171afffb82997",
    "url": "/css/authority_middle.4be2bf2b.css"
  },
  {
    "revision": "c8f537e171afffb82997",
    "url": "/js/authority_middle.0beb8dc6.js"
  },
  {
    "revision": "23bc82827f2d0281a838",
    "url": "/css/balanceIndex.5194685d.css"
  },
  {
    "revision": "23bc82827f2d0281a838",
    "url": "/js/balanceIndex.168d4179.js"
  },
  {
    "revision": "c23074ee20cbb36bf17e",
    "url": "/css/balanceRefund.676b3239.css"
  },
  {
    "revision": "c23074ee20cbb36bf17e",
    "url": "/js/balanceRefund.72c9c9a9.js"
  },
  {
    "revision": "369b49486611f9bce87d",
    "url": "/css/cardPackage.f190f1fa.css"
  },
  {
    "revision": "369b49486611f9bce87d",
    "url": "/js/cardPackage.e4ba510d.js"
  },
  {
    "revision": "a26253add053237f15eb",
    "url": "/css/card_check.821d897a.css"
  },
  {
    "revision": "a26253add053237f15eb",
    "url": "/js/card_check.a6695f01.js"
  },
  {
    "revision": "76953e2ff985bb3ddc7d",
    "url": "/css/card_connection.0c0041ec.css"
  },
  {
    "revision": "76953e2ff985bb3ddc7d",
    "url": "/js/card_connection.a3d5eb6e.js"
  },
  {
    "revision": "20e535ffba4bd8676c7d",
    "url": "/css/card_lookup.b29ceb0f.css"
  },
  {
    "revision": "20e535ffba4bd8676c7d",
    "url": "/js/card_lookup.8a236c67.js"
  },
  {
    "revision": "1ddb32a93511f85959ea",
    "url": "/css/card_usage.f4f44e8c.css"
  },
  {
    "revision": "1ddb32a93511f85959ea",
    "url": "/js/card_usage.035798e5.js"
  },
  {
    "revision": "59768519318b6230e09a",
    "url": "/css/card_wrapper.373da779.css"
  },
  {
    "revision": "59768519318b6230e09a",
    "url": "/js/card_wrapper.11810a6e.js"
  },
  {
    "revision": "6936f580abe83445ffb1",
    "url": "/css/children_card.c0bffb1e.css"
  },
  {
    "revision": "6936f580abe83445ffb1",
    "url": "/js/children_card.6af3fdb9.js"
  },
  {
    "revision": "31a5b39f03d29055834b",
    "url": "/css/chunk-3d11f4f9.d4c62a7b.css"
  },
  {
    "revision": "31a5b39f03d29055834b",
    "url": "/js/chunk-3d11f4f9.e20f6893.js"
  },
  {
    "revision": "c4d022a0a72ef3e058e6",
    "url": "/css/chunk-9f8fd7d4.e471d80a.css"
  },
  {
    "revision": "c4d022a0a72ef3e058e6",
    "url": "/js/chunk-9f8fd7d4.237cf6cf.js"
  },
  {
    "revision": "cd79ca3a12173f7fb9ec",
    "url": "/css/chunk-vendors.3b71a034.css"
  },
  {
    "revision": "cd79ca3a12173f7fb9ec",
    "url": "/js/chunk-vendors.10650154.js"
  },
  {
    "revision": "070018232df4695874b4",
    "url": "/css/commonProblem.a6a75547.css"
  },
  {
    "revision": "070018232df4695874b4",
    "url": "/js/commonProblem.d96b79ae.js"
  },
  {
    "revision": "58c5d5eaf4f9b6ec8c41",
    "url": "/css/consumerRecord.08d5cc3b.css"
  },
  {
    "revision": "58c5d5eaf4f9b6ec8c41",
    "url": "/js/consumerRecord.58065b58.js"
  },
  {
    "revision": "9284b1ec5e44a9f7b0d5",
    "url": "/css/coupon_normal.94c7ba55.css"
  },
  {
    "revision": "9284b1ec5e44a9f7b0d5",
    "url": "/js/coupon_normal.ce323a27.js"
  },
  {
    "revision": "5a0d95536d2ca3c20541",
    "url": "/css/coupon_telcom.72ee0bc0.css"
  },
  {
    "revision": "5a0d95536d2ca3c20541",
    "url": "/js/coupon_telcom.12565cd5.js"
  },
  {
    "revision": "3d29be284addf9ff5036",
    "url": "/css/coupon_wrapper.31258838.css"
  },
  {
    "revision": "3d29be284addf9ff5036",
    "url": "/js/coupon_wrapper.c1c14448.js"
  },
  {
    "revision": "66caaca6a79ef9a68a1a",
    "url": "/css/currencyConversion.9b86fdcd.css"
  },
  {
    "revision": "66caaca6a79ef9a68a1a",
    "url": "/js/currencyConversion.e5eb742f.js"
  },
  {
    "revision": "ef9a8a112b08c48b5a0c",
    "url": "/css/eqReplaceMent.de095f77.css"
  },
  {
    "revision": "ef9a8a112b08c48b5a0c",
    "url": "/js/eqReplaceMent.d7295d3b.js"
  },
  {
    "revision": "6feec3d1df478ad6d511",
    "url": "/css/esim_plan_list.93e26022.css"
  },
  {
    "revision": "6feec3d1df478ad6d511",
    "url": "/js/esim_plan_list.0fcd6b87.js"
  },
  {
    "revision": "cc378f54ae0834a3b39c",
    "url": "/css/esim_usage.d9734e83.css"
  },
  {
    "revision": "cc378f54ae0834a3b39c",
    "url": "/js/esim_usage.3184ab73.js"
  },
  {
    "revision": "41e9a9a72f9781f95eb3",
    "url": "/css/find_plan.2ec0236a.css"
  },
  {
    "revision": "41e9a9a72f9781f95eb3",
    "url": "/js/find_plan.e1b24385.js"
  },
  {
    "revision": "432facc81dfedaaaa3ff",
    "url": "/css/logical_page.b1840a87.css"
  },
  {
    "revision": "432facc81dfedaaaa3ff",
    "url": "/js/logical_page.d0739e14.js"
  },
  {
    "revision": "f398a281dd894bf0372a",
    "url": "/css/login.b710a567.css"
  },
  {
    "revision": "f398a281dd894bf0372a",
    "url": "/js/login.11eb4889.js"
  },
  {
    "revision": "65e6dcf99baa425c4460",
    "url": "/css/lookup.a0fdfe26.css"
  },
  {
    "revision": "65e6dcf99baa425c4460",
    "url": "/js/lookup.b5026444.js"
  },
  {
    "revision": "363399437ebec928e25b",
    "url": "/css/mifi_binding.d51dd9ee.css"
  },
  {
    "revision": "363399437ebec928e25b",
    "url": "/js/mifi_binding.681e8bf8.js"
  },
  {
    "revision": "dbfd58c048d1a9bc50c8",
    "url": "/css/mifi_card_info.331a32b0.css"
  },
  {
    "revision": "dbfd58c048d1a9bc50c8",
    "url": "/js/mifi_card_info.6f64841e.js"
  },
  {
    "revision": "a47705ebf249f556a389",
    "url": "/css/mifi_card_lookup.1216b9dd.css"
  },
  {
    "revision": "a47705ebf249f556a389",
    "url": "/js/mifi_card_lookup.493403f8.js"
  },
  {
    "revision": "ea0397017a8f773eef8a",
    "url": "/css/mifi_card_wrapper.9134afdd.css"
  },
  {
    "revision": "ea0397017a8f773eef8a",
    "url": "/js/mifi_card_wrapper.8d1acc0c.js"
  },
  {
    "revision": "edfba5f0a59dde195e0e",
    "url": "/css/mifi_change_network.35493f66.css"
  },
  {
    "revision": "edfba5f0a59dde195e0e",
    "url": "/js/mifi_change_network.5324ff8f.js"
  },
  {
    "revision": "6bb2fd29e466a27f3756",
    "url": "/css/mifi_change_network_explanation.82431f87.css"
  },
  {
    "revision": "6bb2fd29e466a27f3756",
    "url": "/js/mifi_change_network_explanation.80560dc9.js"
  },
  {
    "revision": "d3f19fae9e6483e34fe7",
    "url": "/css/mifi_coupon_index.64e0f7c2.css"
  },
  {
    "revision": "d3f19fae9e6483e34fe7",
    "url": "/js/mifi_coupon_index.e78fd72a.js"
  },
  {
    "revision": "ea994b4592c341a64f14",
    "url": "/css/mifi_coupon_wrapper.8b393e56.css"
  },
  {
    "revision": "ea994b4592c341a64f14",
    "url": "/js/mifi_coupon_wrapper.eca902c1.js"
  },
  {
    "revision": "030abe08193970e66613",
    "url": "/css/mifi_index.f1add01c.css"
  },
  {
    "revision": "030abe08193970e66613",
    "url": "/js/mifi_index.db531e40.js"
  },
  {
    "revision": "0ef200cb38312dd45960",
    "url": "/css/mifi_layout.69f1d346.css"
  },
  {
    "revision": "0ef200cb38312dd45960",
    "url": "/js/mifi_layout.50308c6e.js"
  },
  {
    "revision": "5ebecae17b448e085e13",
    "url": "/css/mifi_order.73477860.css"
  },
  {
    "revision": "5ebecae17b448e085e13",
    "url": "/js/mifi_order.6d6d5279.js"
  },
  {
    "revision": "9d35cfac4afd5c4afecf",
    "url": "/css/mifi_order_wrapper.d572d9dd.css"
  },
  {
    "revision": "9d35cfac4afd5c4afecf",
    "url": "/js/mifi_order_wrapper.9f3cb832.js"
  },
  {
    "revision": "0e3374b5b87d7be5ae97",
    "url": "/css/mifi_order~mifi_plan_group.649e1a31.css"
  },
  {
    "revision": "0e3374b5b87d7be5ae97",
    "url": "/js/mifi_order~mifi_plan_group.2b2aed2a.js"
  },
  {
    "revision": "3b31e2f5939c68edbb37",
    "url": "/css/mifi_plan_group.75aeedb1.css"
  },
  {
    "revision": "3b31e2f5939c68edbb37",
    "url": "/js/mifi_plan_group.91ed1bb9.js"
  },
  {
    "revision": "1591e7854a3e10f46edd",
    "url": "/css/mifi_plan_list.c16e50c4.css"
  },
  {
    "revision": "1591e7854a3e10f46edd",
    "url": "/js/mifi_plan_list.c1bcd3c8.js"
  },
  {
    "revision": "65e418db6c768857b387",
    "url": "/css/mifi_plan_usage.5c7c316d.css"
  },
  {
    "revision": "65e418db6c768857b387",
    "url": "/js/mifi_plan_usage.31a2e4ff.js"
  },
  {
    "revision": "2aceb9979f5c7596abba",
    "url": "/css/mifi_plan_wrapper.ad5b72f4.css"
  },
  {
    "revision": "2aceb9979f5c7596abba",
    "url": "/js/mifi_plan_wrapper.fd737b35.js"
  },
  {
    "revision": "139cf8d7765bde2f6eda",
    "url": "/css/new_card_wrapper.907108b0.css"
  },
  {
    "revision": "139cf8d7765bde2f6eda",
    "url": "/js/new_card_wrapper.58d4a208.js"
  },
  {
    "revision": "502a7ad0a2375cb65e17",
    "url": "/css/orderRecord.81c4828c.css"
  },
  {
    "revision": "502a7ad0a2375cb65e17",
    "url": "/js/orderRecord.18f1555b.js"
  },
  {
    "revision": "11cba4264b4406523f05",
    "url": "/css/plan_list.ec3d9cd1.css"
  },
  {
    "revision": "11cba4264b4406523f05",
    "url": "/js/plan_list.f2ba33bf.js"
  },
  {
    "revision": "1be173923d0031cbcd1f",
    "url": "/css/question.6faada89.css"
  },
  {
    "revision": "1be173923d0031cbcd1f",
    "url": "/js/question.e06e88cb.js"
  },
  {
    "revision": "a06f700330835789736e",
    "url": "/css/question_wrapper.09148f29.css"
  },
  {
    "revision": "a06f700330835789736e",
    "url": "/js/question_wrapper.e8fa6249.js"
  },
  {
    "revision": "714331461528f3d2deeb",
    "url": "/css/realNameCourse.c4765d59.css"
  },
  {
    "revision": "714331461528f3d2deeb",
    "url": "/js/realNameCourse.d640f54e.js"
  },
  {
    "revision": "0dae02ea923193b2114b",
    "url": "/css/realNameWrapper.bd47aa9c.css"
  },
  {
    "revision": "0dae02ea923193b2114b",
    "url": "/js/realNameWrapper.23381599.js"
  },
  {
    "revision": "b485828fd3748eba32a0",
    "url": "/css/real_name.d1375355.css"
  },
  {
    "revision": "b485828fd3748eba32a0",
    "url": "/js/real_name.6742d593.js"
  },
  {
    "revision": "1eaf2d488e95d99a3d96",
    "url": "/css/recharge.70692713.css"
  },
  {
    "revision": "1eaf2d488e95d99a3d96",
    "url": "/js/recharge.e9c74f00.js"
  },
  {
    "revision": "aa30c4e5d41cfe4358ac",
    "url": "/css/rechargeOrder.02d2f2c9.css"
  },
  {
    "revision": "aa30c4e5d41cfe4358ac",
    "url": "/js/rechargeOrder.27efd469.js"
  },
  {
    "revision": "4e6ada6ed56b124c50a1",
    "url": "/css/recharge_callback.fd5e694b.css"
  },
  {
    "revision": "4e6ada6ed56b124c50a1",
    "url": "/js/recharge_callback.34297e55.js"
  },
  {
    "revision": "dde103bffdd71d2acd48",
    "url": "/css/recharge_wrapper.ecb61e58.css"
  },
  {
    "revision": "dde103bffdd71d2acd48",
    "url": "/js/recharge_wrapper.5368934d.js"
  },
  {
    "revision": "c3b664a9550572852b55",
    "url": "/css/refundRules.e8500f7f.css"
  },
  {
    "revision": "c3b664a9550572852b55",
    "url": "/js/refundRules.c289d97c.js"
  },
  {
    "revision": "ebcb76dad3c727a6ddc3",
    "url": "/js/Layout.55f221ff.js"
  },
  {
    "revision": "e53644a54c7fd7943c75",
    "url": "/js/refund_applying.6ed7bf0a.js"
  },
  {
    "revision": "119ed122586f0e856275",
    "url": "/css/refund_argument.69661661.css"
  },
  {
    "revision": "119ed122586f0e856275",
    "url": "/js/refund_argument.d2227949.js"
  },
  {
    "revision": "33ab867d7455e18b25af",
    "url": "/css/refund_plan.d6afc21e.css"
  },
  {
    "revision": "33ab867d7455e18b25af",
    "url": "/js/refund_plan.6a3744aa.js"
  },
  {
    "revision": "18f3a926060dcd5647ed",
    "url": "/css/refund_wrapper.2ce7ebad.css"
  },
  {
    "revision": "18f3a926060dcd5647ed",
    "url": "/js/refund_wrapper.4b26b5da.js"
  },
  {
    "revision": "212078dd5ef667151602",
    "url": "/css/repeatRecharge.c6a3e0c8.css"
  },
  {
    "revision": "212078dd5ef667151602",
    "url": "/js/repeatRecharge.01fb4038.js"
  },
  {
    "revision": "25c5c5d1db6a0d897243",
    "url": "/css/revoke_plan.0c04faff.css"
  },
  {
    "revision": "25c5c5d1db6a0d897243",
    "url": "/js/revoke_plan.80b35021.js"
  },
  {
    "revision": "362b861829f7b63bb395",
    "url": "/css/speedup_500.863f4cd3.css"
  },
  {
    "revision": "362b861829f7b63bb395",
    "url": "/js/speedup_500.a14894b4.js"
  },
  {
    "revision": "467584ea5abd4e73e882",
    "url": "/css/speedup_80.d0292630.css"
  },
  {
    "revision": "467584ea5abd4e73e882",
    "url": "/js/speedup_80.d8c68672.js"
  },
  {
    "revision": "e8e646590c22cdecfe1f",
    "url": "/css/speedup_wrapper.69b3dda0.css"
  },
  {
    "revision": "e8e646590c22cdecfe1f",
    "url": "/js/speedup_wrapper.27f3dbaf.js"
  },
  {
    "revision": "4292effde6bde48cf51f",
    "url": "/css/to_tb.96081c85.css"
  },
  {
    "revision": "4292effde6bde48cf51f",
    "url": "/js/to_tb.12ced939.js"
  },
  {
    "revision": "dd7729d0479a4ba01f7f",
    "url": "/css/transfer_url.302c6a25.css"
  },
  {
    "revision": "dd7729d0479a4ba01f7f",
    "url": "/js/transfer_url.16558afa.js"
  },
  {
    "revision": "475a7e02d11ddd061b56",
    "url": "/css/uploadIdInfo.70c1fd51.css"
  },
  {
    "revision": "475a7e02d11ddd061b56",
    "url": "/js/uploadIdInfo.4e3df9e7.js"
  },
  {
    "revision": "e1ced221553106b87473",
    "url": "/css/userCenter.677fbea6.css"
  },
  {
    "revision": "e1ced221553106b87473",
    "url": "/js/userCenter.8a158e9e.js"
  },
  {
    "revision": "2d274296b35bcd3e9a2a",
    "url": "/css/userCenterWrap.b8d99837.css"
  },
  {
    "revision": "2d274296b35bcd3e9a2a",
    "url": "/js/userCenterWrap.3c78ef04.js"
  },
  {
    "revision": "db411df03a804a2bc3b4",
    "url": "/css/verifyInfo.cbed7d5e.css"
  },
  {
    "revision": "db411df03a804a2bc3b4",
    "url": "/js/verifyInfo.b938c1e4.js"
  },
  {
    "revision": "e4b411644706c29765eea3ffdd85ae39",
    "url": "/fonts/SourceHanSansCNRegular.e4b41164.woff"
  },
  {
    "revision": "834b022ab9ab0e6063904af32274e777",
    "url": "/fonts/SourceHanSansCNRegular.834b022a.eot"
  },
  {
    "revision": "f9509c5a10be7daaf1fa01922a7c6bc2",
    "url": "/fonts/SourceHanSansCNRegular.f9509c5a.ttf"
  },
  {
    "revision": "da0808e9fe85be160aab69c82dd8de1c",
    "url": "/img/SourceHanSansCNRegular.da0808e9.svg"
  },
  {
    "revision": "732389ded34cb9c52dd88271f1345af9",
    "url": "/fonts/element-icons.732389de.ttf"
  },
  {
    "revision": "535877f50039c0cb49a6196a5b7517cd",
    "url": "/fonts/element-icons.535877f5.woff"
  },
  {
    "revision": "cb28460b38b9de81603addeacf165064",
    "url": "/img/result_success@3x.cb28460b.png"
  },
  {
    "revision": "ab7b6bac5b5d732b2207c49ad3bbf32b",
    "url": "/img/result_error@3x.ab7b6bac.png"
  },
  {
    "revision": "009e0aad44114271651c8859ba2803fb",
    "url": "/img/btn_camera@3x.009e0aad.png"
  },
  {
    "revision": "8053681a09934ec0745117c798770884",
    "url": "/img/card_person@3x.8053681a.png"
  },
  {
    "revision": "a38cf1db1ecb9f0759a551ecc03aa161",
    "url": "/img/card_national_emblem@3x.a38cf1db.png"
  },
  {
    "revision": "171573d0985aafafc274434182a38e06",
    "url": "/img/card_id_photo@2x.171573d0.png"
  },
  {
    "revision": "2b7d8fa5a82581aea8b0edbb0d600f70",
    "url": "/img/card_person@2x.2b7d8fa5.png"
  },
  {
    "revision": "b7a05a33f96811c6b26c47f566201f43",
    "url": "/img/card_id_photo@3x.b7a05a33.png"
  },
  {
    "revision": "fff5af4325410621aeec4e60b3b92d9b",
    "url": "/img/mifi_binding_bg@3x.fff5af43.png"
  },
  {
    "revision": "fff5af4325410621aeec4e60b3b92d9b",
    "url": "/img/mifi_binding_bg@2x.fff5af43.png"
  },
  {
    "revision": "f5f322478286641bd9887a155e35f222",
    "url": "/img/btn.f5f32247.png"
  },
  {
    "revision": "d140650fa64e0f1fc771610dba62aed7",
    "url": "/img/bg.d140650f.png"
  },
  {
    "revision": "e625229e32d9deeb5f2909c314d8e609",
    "url": "/img/ios@2x.e625229e.png"
  },
  {
    "revision": "af8bbdfa0a90c4eed4563f8c06ce5ff8",
    "url": "/img/android@2x.af8bbdfa.png"
  },
  {
    "revision": "3f342771b9b81ab929e0fbcbcd0e6533",
    "url": "/img/bg-check-wrap@3x.3f342771.png"
  },
  {
    "revision": "9713b21819c4019befecd095069977df",
    "url": "/img/bg-check-wrap@2x.9713b218.png"
  },
  {
    "revision": "1d7515ee61c3f659227318b4050955ed",
    "url": "/img/mobile_sim@2x.1d7515ee.png"
  },
  {
    "revision": "0f980b79d9a52702004de9f652a68835",
    "url": "/img/telcom_sim@2x.0f980b79.png"
  },
  {
    "revision": "98141226a7e992e3072a280746a259c4",
    "url": "/img/mobile_sim@3x.98141226.png"
  },
  {
    "revision": "0c88168b284b92c37f3a873f26a97d69",
    "url": "/img/bg.0c88168b.jpg"
  },
  {
    "revision": "9e02095f31a07b972244f1c714c1dfe7",
    "url": "/img/telcom_sim@3x.9e02095f.png"
  },
  {
    "revision": "b70eddccd257b21777e71bb64c83b876",
    "url": "/img/bg.b70eddcc.jpeg"
  },
  {
    "revision": "909816c3d34e63a9ad86b8c179ab543c",
    "url": "/img/bar.909816c3.png"
  },
  {
    "revision": "e92f547ba0209da3b4342fa2b56ea9ae",
    "url": "/img/animater.e92f547b.png"
  },
  {
    "revision": "3d0fc424b703032ca595090e99f8354b",
    "url": "/img/login_bg@2x.3d0fc424.png"
  },
  {
    "revision": "11000d4e510a6df565eb69ba6f2c1dfc",
    "url": "/img/login_bg@3x.11000d4e.png"
  },
  {
    "revision": "0f16389ec218c90cf8f657e233b745f2",
    "url": "/img/balanceBg1.0f16389e.png"
  },
  {
    "revision": "565459ef2ee8b71db421144ad21c23e3",
    "url": "/img/balanceBg2.565459ef.png"
  },
  {
    "revision": "91e1d2771efacd45e5e465d9a001f197",
    "url": "/img/liantong.91e1d277.png"
  },
  {
    "revision": "4a0cab0f33beb48ea985714d1b91fef7",
    "url": "/img/dianxin.4a0cab0f.png"
  },
  {
    "revision": "657033323334e91efb0011bbc18f8c04",
    "url": "/img/yidong.65703332.png"
  },
  {
    "revision": "8da3b83b73e44e54d6be4b2522bcb1f2",
    "url": "/img/pkgBg2.8da3b83b.png"
  },
  {
    "revision": "d3b42651f9f5048baeffb50c800913ec",
    "url": "/img/pkgBg1.d3b42651.png"
  },
  {
    "revision": "d461d18e42a310bd709b2ce97d159153",
    "url": "/img/pkgBg3.d461d18e.png"
  },
  {
    "revision": "6dedd4943e4c5848638196fb6f0c4145",
    "url": "/img/bg.6dedd494.png"
  },
  {
    "revision": "af3ed0b3236bbfdbc3ad61b8d41c3dec",
    "url": "/img/changeBg.af3ed0b3.png"
  },
  {
    "revision": "0078f03c08066d51d64b92a13e194ebb",
    "url": "/img/balanceRefund.0078f03c.png"
  },
  {
    "revision": "42c0fbd4915870e5e60452fd0ef2cbec",
    "url": "/img/orderTopBg@3x.42c0fbd4.png"
  },
  {
    "revision": "42c0fbd4915870e5e60452fd0ef2cbec",
    "url": "/img/orderTopBg@2x.42c0fbd4.png"
  },
  {
    "revision": "a859e9ca4606d567c42b9c7bcd4fdce9",
    "url": "/img/iccid_bg@2x.a859e9ca.png"
  },
  {
    "revision": "fa9050c4e9870e8fc0cd184f8515af4a",
    "url": "/img/iccid_bg@3x.fa9050c4.png"
  },
  {
    "revision": "6e5cee7393060b0ec3dcd587c2518b94",
    "url": "/img/bg_test.6e5cee73.png"
  },
  {
    "revision": "d0ccbc8a35180bb40e027b44dd26035a",
    "url": "/img/youku.d0ccbc8a.png"
  },
  {
    "revision": "2a67b73145562669220aa4639e1ad58f",
    "url": "/img/icon3.2a67b731.png"
  },
  {
    "revision": "813b5319e378dafdda952c16ad89906b",
    "url": "/img/icon2.813b5319.png"
  },
  {
    "revision": "01355f175bd20423ce45a838c1a998a9",
    "url": "/img/bg.01355f17.png"
  },
  {
    "revision": "b899232b79ad9962c5ab5572775a0400",
    "url": "/img/card_index_bg@3x.b899232b.png"
  },
  {
    "revision": "b899232b79ad9962c5ab5572775a0400",
    "url": "/img/card_index_bg@2x.b899232b.png"
  },
  {
    "revision": "2c51a1e53c1ea0b35086d8d7261b4933",
    "url": "/img/bg_network@3x.2c51a1e5.png"
  },
  {
    "revision": "32d70c8fc305e3647098f3de0c71b618",
    "url": "/img/bg_network@2x.32d70c8f.png"
  },
  {
    "revision": "014d354b9b25b67ae95857ba17e2f4cc",
    "url": "/img/activityPage.014d354b.png"
  },
  {
    "revision": "114a6e12b42b9b48586dd341105188fe",
    "url": "/img/usedOrder@2x.114a6e12.png"
  },
  {
    "revision": "c0170ec299b2418256fd515ee7849055",
    "url": "/img/unUsedOrder@2x.c0170ec2.png"
  },
  {
    "revision": "d9e14058d30dd312519fcf2de38d742b",
    "url": "/img/unUsedOrder@3x.d9e14058.png"
  },
  {
    "revision": "4a5b90f8076955f289b3dcda6a5af6ff",
    "url": "/img/invaildedOrder@3x.4a5b90f8.png"
  },
  {
    "revision": "0d5a5158e67bcb7a4604124715ed6fbf",
    "url": "/img/usedOrder@3x.0d5a5158.png"
  },
  {
    "revision": "be0f1e33b2553e71b117d3d3f838d32f",
    "url": "/img/invaildedOrder@2x.be0f1e33.png"
  },
  {
    "revision": "3603a35a49dbb8ad94ec1e57c4dad229",
    "url": "/img/scanTop2.3603a35a.png"
  },
  {
    "revision": "05775dd69c53d7273b27aaa7c6c523f7",
    "url": "/img/04.05775dd6.png"
  },
  {
    "revision": "541375e6bb7db2fba9e415be8045f5fb",
    "url": "/img/1.541375e6.png"
  },
  {
    "revision": "7c28431d304fa4f58f5070c59720683a",
    "url": "/img/2.7c28431d.png"
  },
  {
    "revision": "5a3428653945c17e1c146efeee81c987",
    "url": "/img/scanTop.5a342865.png"
  },
  {
    "revision": "824594523c01e48028f2b7eb4261134d",
    "url": "/img/unicom-logo.82459452.svg"
  },
  {
    "revision": "113f99e2189c2ca49db2168754fc2eb5",
    "url": "/img/mobile-logo.113f99e2.png"
  },
  {
    "revision": "0cba868fa977e09806638b9000636a36",
    "url": "/img/avatar.0cba868f.jpeg"
  },
  {
    "revision": "27158aa79eb0d4b89f317d076a801ca3",
    "url": "/img/coupon-log.27158aa7.png"
  },
  {
    "revision": "55d3f2f09efe17db6485d4c9f8f0c3b1",
    "url": "/img/icon-recharge_20181001.55d3f2f0.svg"
  },
  {
    "revision": "165beb68d8ba0d2b70df0fbb3769787a",
    "url": "/img/03.165beb68.png"
  },
  {
    "revision": "5f1f34037094c0613bccafa2ddd8cb3b",
    "url": "/img/telecom-logo.5f1f3403.svg"
  },
  {
    "revision": "0b3c3297decbd1152a314cce115f9632",
    "url": "/img/09.0b3c3297.png"
  },
  {
    "revision": "644e6e3cf5f33943747b116316694e28",
    "url": "/img/noData@2x.644e6e3c.png"
  },
  {
    "revision": "3e217df4202e41ad9b030aafc8cfcc24",
    "url": "/img/4.3e217df4.png"
  },
  {
    "revision": "aecc9531f2c3b1fd45338e7bf5084384",
    "url": "/img/bg_no_recharge.aecc9531.svg"
  },
  {
    "revision": "b0ffa4a0fd195a110ee4d4dabce3bc32",
    "url": "/img/08.b0ffa4a0.png"
  },
  {
    "revision": "96fab583abd57f2e7118324858fa3080",
    "url": "/img/05.96fab583.png"
  },
  {
    "revision": "9e8ecc7f7b760b55c56bddfab886da10",
    "url": "/img/3.9e8ecc7f.png"
  },
  {
    "revision": "275be51ae57c486bce58257febd6589f",
    "url": "/img/bg_no_plan.275be51a.svg"
  },
  {
    "revision": "a8272d2d742d9d50257e23dfac577def",
    "url": "/img/01.a8272d2d.png"
  },
  {
    "revision": "daa86b540bb9c2a6453ceac9bed77961",
    "url": "/img/07.daa86b54.png"
  },
  {
    "revision": "06385746a7cedb492d5539907631561c",
    "url": "/img/tip.06385746.png"
  },
  {
    "revision": "eacba58f9acf2b87cd801858146b2ba9",
    "url": "/img/02.eacba58f.png"
  },
  {
    "revision": "39d9e849fc1c724525f166646932a24d",
    "url": "/img/safari.39d9e849.png"
  },
  {
    "revision": "999589aae784a460b5e7c6ae9bbaa3d8",
    "url": "/img/06.999589aa.png"
  },
  {
    "revision": "3cf7193934d97163376f0da77e2d4fec",
    "url": "/index.html"
  },
  {
    "revision": "b6216d61c03e6ce0c9aea6ca7808f7ca",
    "url": "/robots.txt"
  },
  {
    "revision": "9ce16f441b39b493af8b96d7e97cce22",
    "url": "/MP_verify_dkzAKjxyVyJvsHMS.txt"
  },
  {
    "revision": "86c422d8c98b247235d04b49fb1c4b05",
    "url": "/MP_verify_bKSdn2qZlUSULliu.txt"
  },
  {
    "revision": "652317b098ca24e4511926c7fd57cbbe",
    "url": "/MP_verify_8JoCCldW78DygS5c.txt"
  },
  {
    "revision": "00bbf6b458bf7ea6bd01f443eb3045d9",
    "url": "/MP_verify_4r3DVk3KUjgWsQsG.txt"
  }
];