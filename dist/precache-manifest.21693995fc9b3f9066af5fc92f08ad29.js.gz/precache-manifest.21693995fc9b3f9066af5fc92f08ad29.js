self.__precacheManifest = [
  {
    "revision": "08a249b78a0e4ce77ab2",
    "url": "/css/Layout.293b19b8.css"
  },
  {
    "revision": "08a249b78a0e4ce77ab2",
    "url": "/js/Layout.98cd1b72.js"
  },
  {
    "revision": "78214ba34c5f1df936aa",
    "url": "/js/Layout~card_usage~eqReplaceMent~esim_plan_list~esim_usage~mifi_order~mifi_plan_list~mifi_plan_usage~~c6f87c36.6241bd21.js"
  },
  {
    "revision": "f5272b20fc3ef4afb968",
    "url": "/css/Not_fund.72da8db7.css"
  },
  {
    "revision": "f5272b20fc3ef4afb968",
    "url": "/js/Not_fund.2401c79b.js"
  },
  {
    "revision": "91d8159ac76fad67922b",
    "url": "/css/app.bec1065c.css"
  },
  {
    "revision": "91d8159ac76fad67922b",
    "url": "/js/app.cc41eb40.js"
  },
  {
    "revision": "69d169627aab8e938787",
    "url": "/css/authority_middle.f79c5b9c.css"
  },
  {
    "revision": "69d169627aab8e938787",
    "url": "/js/authority_middle.73d12101.js"
  },
  {
    "revision": "5fef857cea1bd2b63011",
    "url": "/css/balanceIndex.d16bbc55.css"
  },
  {
    "revision": "5fef857cea1bd2b63011",
    "url": "/js/balanceIndex.fa97323b.js"
  },
  {
    "revision": "3e02e05374b092ec635c",
    "url": "/css/balanceRefund.bae13223.css"
  },
  {
    "revision": "3e02e05374b092ec635c",
    "url": "/js/balanceRefund.b6297e26.js"
  },
  {
    "revision": "122cf25b8f623c8100e0",
    "url": "/css/cardPackage.f411c4c7.css"
  },
  {
    "revision": "122cf25b8f623c8100e0",
    "url": "/js/cardPackage.31700b23.js"
  },
  {
    "revision": "d038f7585213760a546b",
    "url": "/css/card_check.4a120c62.css"
  },
  {
    "revision": "d038f7585213760a546b",
    "url": "/js/card_check.b380f418.js"
  },
  {
    "revision": "21399fe0407c7ca4b409",
    "url": "/css/card_connection.25cf05c3.css"
  },
  {
    "revision": "21399fe0407c7ca4b409",
    "url": "/js/card_connection.37a7cb1a.js"
  },
  {
    "revision": "67010c4b50d787f802a1",
    "url": "/css/card_lookup.44d1cffb.css"
  },
  {
    "revision": "67010c4b50d787f802a1",
    "url": "/js/card_lookup.e5d2450d.js"
  },
  {
    "revision": "551f116e29267b5ed06e",
    "url": "/css/card_more_flow.c5a8248e.css"
  },
  {
    "revision": "551f116e29267b5ed06e",
    "url": "/js/card_more_flow.65a3e537.js"
  },
  {
    "revision": "b1f3bbc6964b019281d5",
    "url": "/css/card_usage.17d327d6.css"
  },
  {
    "revision": "b1f3bbc6964b019281d5",
    "url": "/js/card_usage.32a493d1.js"
  },
  {
    "revision": "a8985e465ae5e00d9bf9",
    "url": "/css/card_wrapper.1a8d30f5.css"
  },
  {
    "revision": "a8985e465ae5e00d9bf9",
    "url": "/js/card_wrapper.ba982237.js"
  },
  {
    "revision": "ae6cde7883aa7ce93e14",
    "url": "/css/children_card.a04f36e4.css"
  },
  {
    "revision": "ae6cde7883aa7ce93e14",
    "url": "/js/children_card.d806b145.js"
  },
  {
    "revision": "61d555baecb4592b45e6",
    "url": "/css/chunk-3527d19d.46afdd67.css"
  },
  {
    "revision": "61d555baecb4592b45e6",
    "url": "/js/chunk-3527d19d.99aa0d9d.js"
  },
  {
    "revision": "c5c2b1bc06e5fa52287c",
    "url": "/css/chunk-735bcfd4.7f43c2d2.css"
  },
  {
    "revision": "c5c2b1bc06e5fa52287c",
    "url": "/js/chunk-735bcfd4.b2a03701.js"
  },
  {
    "revision": "c6e04b19b25056391a7f",
    "url": "/css/chunk-vendors.baf23398.css"
  },
  {
    "revision": "c6e04b19b25056391a7f",
    "url": "/js/chunk-vendors.9a4e4963.js"
  },
  {
    "revision": "a852ea3205dce60d7584",
    "url": "/css/commonProblem.3bf99bae.css"
  },
  {
    "revision": "a852ea3205dce60d7584",
    "url": "/js/commonProblem.695cac93.js"
  },
  {
    "revision": "70e47b9c717a6c0c8c6c",
    "url": "/css/consumerRecord.53dc3733.css"
  },
  {
    "revision": "70e47b9c717a6c0c8c6c",
    "url": "/js/consumerRecord.6c8a1658.js"
  },
  {
    "revision": "fabe0f273d2dcbc018c0",
    "url": "/css/coupon_normal.1a9a5f5b.css"
  },
  {
    "revision": "fabe0f273d2dcbc018c0",
    "url": "/js/coupon_normal.aecbbd50.js"
  },
  {
    "revision": "288e181561c09ba4011b",
    "url": "/css/coupon_telcom.3e944761.css"
  },
  {
    "revision": "288e181561c09ba4011b",
    "url": "/js/coupon_telcom.3dffbe66.js"
  },
  {
    "revision": "7038396d09f71fff5727",
    "url": "/css/coupon_wrapper.ab43c2ce.css"
  },
  {
    "revision": "7038396d09f71fff5727",
    "url": "/js/coupon_wrapper.d9947991.js"
  },
  {
    "revision": "52959f2b1519a7813beb",
    "url": "/css/currencyConversion.d72fe129.css"
  },
  {
    "revision": "52959f2b1519a7813beb",
    "url": "/js/currencyConversion.4703a2f7.js"
  },
  {
    "revision": "91baae2832d78c1eac44",
    "url": "/css/eqReplaceMent.bfc6bc9b.css"
  },
  {
    "revision": "91baae2832d78c1eac44",
    "url": "/js/eqReplaceMent.d5a31ee1.js"
  },
  {
    "revision": "b9b218c3509eec825099",
    "url": "/css/eqReplaceMent~recharge.8d01bd55.css"
  },
  {
    "revision": "b9b218c3509eec825099",
    "url": "/js/eqReplaceMent~recharge.839b294d.js"
  },
  {
    "revision": "2f7929a3c2d8790f5c2f",
    "url": "/css/esim_plan_list.42c9e68a.css"
  },
  {
    "revision": "2f7929a3c2d8790f5c2f",
    "url": "/js/esim_plan_list.4299cdc1.js"
  },
  {
    "revision": "3babadc7e5a39ec77314",
    "url": "/css/esim_usage.3a311fc3.css"
  },
  {
    "revision": "3babadc7e5a39ec77314",
    "url": "/js/esim_usage.1e4b3466.js"
  },
  {
    "revision": "7a935f680efa63986550",
    "url": "/css/find_plan.d3d20fa5.css"
  },
  {
    "revision": "7a935f680efa63986550",
    "url": "/js/find_plan.7fc9dac4.js"
  },
  {
    "revision": "ccfaedd727cb296eeb6a",
    "url": "/css/logical_page.c381c241.css"
  },
  {
    "revision": "ccfaedd727cb296eeb6a",
    "url": "/js/logical_page.2d6c0f83.js"
  },
  {
    "revision": "aa79ee59b9b4f963729e",
    "url": "/css/login.db6eac3f.css"
  },
  {
    "revision": "aa79ee59b9b4f963729e",
    "url": "/js/login.4c934f1e.js"
  },
  {
    "revision": "7ad3db93931cb633ae04",
    "url": "/css/lookup.a84a91e8.css"
  },
  {
    "revision": "7ad3db93931cb633ae04",
    "url": "/js/lookup.e18afd73.js"
  },
  {
    "revision": "8d3607b8c9307a1230c0",
    "url": "/css/mifi_binding.67add20d.css"
  },
  {
    "revision": "8d3607b8c9307a1230c0",
    "url": "/js/mifi_binding.26ae3943.js"
  },
  {
    "revision": "af4df6a5a25b17e1bf96",
    "url": "/css/mifi_card_info.8e535db1.css"
  },
  {
    "revision": "af4df6a5a25b17e1bf96",
    "url": "/js/mifi_card_info.078a339f.js"
  },
  {
    "revision": "e7f8da201c42eca94b6a",
    "url": "/css/mifi_card_lookup.cdacba2e.css"
  },
  {
    "revision": "e7f8da201c42eca94b6a",
    "url": "/js/mifi_card_lookup.501b4a3a.js"
  },
  {
    "revision": "08c47ed3f14843a5c035",
    "url": "/css/mifi_card_wrapper.0b1217f1.css"
  },
  {
    "revision": "08c47ed3f14843a5c035",
    "url": "/js/mifi_card_wrapper.42ff2c5e.js"
  },
  {
    "revision": "20beba5eaa78ca192586",
    "url": "/css/mifi_change_network.e15b9cf5.css"
  },
  {
    "revision": "20beba5eaa78ca192586",
    "url": "/js/mifi_change_network.0dd54e00.js"
  },
  {
    "revision": "ad030ff036c322771ac0",
    "url": "/css/mifi_change_network_explanation.f0e40b07.css"
  },
  {
    "revision": "ad030ff036c322771ac0",
    "url": "/js/mifi_change_network_explanation.aa9bf3a0.js"
  },
  {
    "revision": "6d112404ebb4eb459ccb",
    "url": "/css/mifi_coupon_index.cea2c044.css"
  },
  {
    "revision": "6d112404ebb4eb459ccb",
    "url": "/js/mifi_coupon_index.171c4371.js"
  },
  {
    "revision": "714120d65d5bf65a3574",
    "url": "/css/mifi_coupon_wrapper.10042735.css"
  },
  {
    "revision": "714120d65d5bf65a3574",
    "url": "/js/mifi_coupon_wrapper.5f7a1b35.js"
  },
  {
    "revision": "b099c3acbd62b9dc518e",
    "url": "/css/mifi_index.6c2f719e.css"
  },
  {
    "revision": "b099c3acbd62b9dc518e",
    "url": "/js/mifi_index.c7b2572b.js"
  },
  {
    "revision": "94b6b6e9eb641a28a632",
    "url": "/css/mifi_layout.63b8c424.css"
  },
  {
    "revision": "94b6b6e9eb641a28a632",
    "url": "/js/mifi_layout.9e3fd11d.js"
  },
  {
    "revision": "cafb72552b3c37ed886c",
    "url": "/css/mifi_order.05cdaf6f.css"
  },
  {
    "revision": "cafb72552b3c37ed886c",
    "url": "/js/mifi_order.56389f4f.js"
  },
  {
    "revision": "852587c9d0e89f170b0e",
    "url": "/css/mifi_order_wrapper.80fa7896.css"
  },
  {
    "revision": "852587c9d0e89f170b0e",
    "url": "/js/mifi_order_wrapper.6f299b08.js"
  },
  {
    "revision": "7814a50498b06c742c44",
    "url": "/css/mifi_plan_group.0b86329e.css"
  },
  {
    "revision": "7814a50498b06c742c44",
    "url": "/js/mifi_plan_group.948aff34.js"
  },
  {
    "revision": "28b9c47e65b9ce50cf11",
    "url": "/css/mifi_plan_list.409ba955.css"
  },
  {
    "revision": "28b9c47e65b9ce50cf11",
    "url": "/js/mifi_plan_list.580015cb.js"
  },
  {
    "revision": "fceb59f3d138ffa5761b",
    "url": "/css/mifi_plan_usage.51e5e938.css"
  },
  {
    "revision": "fceb59f3d138ffa5761b",
    "url": "/js/mifi_plan_usage.8bfdb2e5.js"
  },
  {
    "revision": "e380412cdd141238b018",
    "url": "/css/mifi_plan_wrapper.32f1c95d.css"
  },
  {
    "revision": "e380412cdd141238b018",
    "url": "/js/mifi_plan_wrapper.6c9f768f.js"
  },
  {
    "revision": "863269068ab5c264364f",
    "url": "/css/new_card_wrapper.06a280b2.css"
  },
  {
    "revision": "863269068ab5c264364f",
    "url": "/js/new_card_wrapper.90952c08.js"
  },
  {
    "revision": "a687b40b9859f25f5fc1",
    "url": "/css/orderRecord.b3e03491.css"
  },
  {
    "revision": "a687b40b9859f25f5fc1",
    "url": "/js/orderRecord.82758c61.js"
  },
  {
    "revision": "d469f0f0fe0db2ad8ac4",
    "url": "/css/plan_list.47d43fcb.css"
  },
  {
    "revision": "d469f0f0fe0db2ad8ac4",
    "url": "/js/plan_list.260a03cf.js"
  },
  {
    "revision": "8d2136c0b9a9933f2f82",
    "url": "/css/question.5348f0a7.css"
  },
  {
    "revision": "8d2136c0b9a9933f2f82",
    "url": "/js/question.6da0aedf.js"
  },
  {
    "revision": "1acbee19d867489d1a91",
    "url": "/css/question_wrapper.80b62e54.css"
  },
  {
    "revision": "1acbee19d867489d1a91",
    "url": "/js/question_wrapper.2cffb5aa.js"
  },
  {
    "revision": "59f4e20000a77f22ac9c",
    "url": "/css/realNameCourse.dee117a2.css"
  },
  {
    "revision": "59f4e20000a77f22ac9c",
    "url": "/js/realNameCourse.45b2a477.js"
  },
  {
    "revision": "5fe20d184b4e7a973e0e",
    "url": "/css/real_name.2fd595b9.css"
  },
  {
    "revision": "5fe20d184b4e7a973e0e",
    "url": "/js/real_name.15a1f943.js"
  },
  {
    "revision": "87ff669e586914db26f7",
    "url": "/css/recharge.32ae6af0.css"
  },
  {
    "revision": "87ff669e586914db26f7",
    "url": "/js/recharge.207d1fa8.js"
  },
  {
    "revision": "1049abac44cd4f6f7d76",
    "url": "/css/rechargeOrder.88336c82.css"
  },
  {
    "revision": "1049abac44cd4f6f7d76",
    "url": "/js/rechargeOrder.7fc41a97.js"
  },
  {
    "revision": "f10543a9d4171c4d9404",
    "url": "/css/recharge_balance.af09dcc4.css"
  },
  {
    "revision": "f10543a9d4171c4d9404",
    "url": "/js/recharge_balance.c5ae1419.js"
  },
  {
    "revision": "23fbd5de25c56b9bfb19",
    "url": "/css/recharge_callback.c33c36e5.css"
  },
  {
    "revision": "23fbd5de25c56b9bfb19",
    "url": "/js/recharge_callback.df8958f9.js"
  },
  {
    "revision": "90e9338c3deb5fd373b6",
    "url": "/css/recharge_wrapper.e8ef40fd.css"
  },
  {
    "revision": "90e9338c3deb5fd373b6",
    "url": "/js/recharge_wrapper.83f14224.js"
  },
  {
    "revision": "7409b8cd52bf81406f8d",
    "url": "/css/refundRules.23881fab.css"
  },
  {
    "revision": "7409b8cd52bf81406f8d",
    "url": "/js/refundRules.4e9de0fd.js"
  },
  {
    "revision": "d06f0083297eb47cae8f",
    "url": "/css/refund_applying.fbc44f97.css"
  },
  {
    "revision": "d06f0083297eb47cae8f",
    "url": "/js/refund_applying.0401ec42.js"
  },
  {
    "revision": "8ed1f82c9f407b4b2f1e",
    "url": "/css/refund_argument.0b731303.css"
  },
  {
    "revision": "8ed1f82c9f407b4b2f1e",
    "url": "/js/refund_argument.60b3a5d1.js"
  },
  {
    "revision": "ef51a064bf826c1aa132",
    "url": "/css/refund_plan.172e3022.css"
  },
  {
    "revision": "ef51a064bf826c1aa132",
    "url": "/js/refund_plan.245f30a6.js"
  },
  {
    "revision": "83ffca6ad577e0715469",
    "url": "/css/refund_wrapper.fd3df4db.css"
  },
  {
    "revision": "83ffca6ad577e0715469",
    "url": "/js/refund_wrapper.ef41f3eb.js"
  },
  {
    "revision": "300db7c85879f89d69c6",
    "url": "/css/repeatRecharge.2ff54678.css"
  },
  {
    "revision": "300db7c85879f89d69c6",
    "url": "/js/repeatRecharge.8bf0d6f8.js"
  },
  {
    "revision": "364f2a17aa8ea534df02",
    "url": "/css/revoke_plan.854f8912.css"
  },
  {
    "revision": "364f2a17aa8ea534df02",
    "url": "/js/revoke_plan.5fbc8ecd.js"
  },
  {
    "revision": "92265dede8b7be2a1e70",
    "url": "/css/speedup_500.653f81f5.css"
  },
  {
    "revision": "92265dede8b7be2a1e70",
    "url": "/js/speedup_500.c08854b0.js"
  },
  {
    "revision": "698fd666b528eed3bfe7",
    "url": "/css/speedup_80.0b0c3ab6.css"
  },
  {
    "revision": "698fd666b528eed3bfe7",
    "url": "/js/speedup_80.9b08e339.js"
  },
  {
    "revision": "c4b5be14c484e98e12e1",
    "url": "/css/speedup_wrapper.707898e1.css"
  },
  {
    "revision": "c4b5be14c484e98e12e1",
    "url": "/js/speedup_wrapper.b4674906.js"
  },
  {
    "revision": "44562a7901323b748996",
    "url": "/css/to_tb.03eb33ae.css"
  },
  {
    "revision": "44562a7901323b748996",
    "url": "/js/to_tb.b2ca1b22.js"
  },
  {
    "revision": "e7993768636ce1eb05de",
    "url": "/css/transfer_url.99834881.css"
  },
  {
    "revision": "e7993768636ce1eb05de",
    "url": "/js/transfer_url.1e46b7df.js"
  },
  {
    "revision": "f07a0e77126b148a85a0",
    "url": "/css/userCenter.456f45d8.css"
  },
  {
    "revision": "f07a0e77126b148a85a0",
    "url": "/js/userCenter.70d57f88.js"
  },
  {
    "revision": "23d114c7944fbfb85f1c",
    "url": "/css/userCenterWrap.636ae42d.css"
  },
  {
    "revision": "23d114c7944fbfb85f1c",
    "url": "/js/userCenterWrap.8bada249.js"
  },
  {
    "revision": "e4b411644706c29765eea3ffdd85ae39",
    "url": "/fonts/SourceHanSansCNRegular.e4b41164.woff"
  },
  {
    "revision": "834b022ab9ab0e6063904af32274e777",
    "url": "/fonts/SourceHanSansCNRegular.834b022a.eot"
  },
  {
    "revision": "f9509c5a10be7daaf1fa01922a7c6bc2",
    "url": "/fonts/SourceHanSansCNRegular.f9509c5a.ttf"
  },
  {
    "revision": "da0808e9fe85be160aab69c82dd8de1c",
    "url": "/img/SourceHanSansCNRegular.da0808e9.svg"
  },
  {
    "revision": "732389ded34cb9c52dd88271f1345af9",
    "url": "/fonts/element-icons.732389de.ttf"
  },
  {
    "revision": "535877f50039c0cb49a6196a5b7517cd",
    "url": "/fonts/element-icons.535877f5.woff"
  },
  {
    "revision": "6dedd4943e4c5848638196fb6f0c4145",
    "url": "/img/bg.6dedd494.png"
  },
  {
    "revision": "6e5cee7393060b0ec3dcd587c2518b94",
    "url": "/img/bg_test.6e5cee73.png"
  },
  {
    "revision": "d0ccbc8a35180bb40e027b44dd26035a",
    "url": "/img/youku.d0ccbc8a.png"
  },
  {
    "revision": "a859e9ca4606d567c42b9c7bcd4fdce9",
    "url": "/img/iccid_bg@2x.a859e9ca.png"
  },
  {
    "revision": "fa9050c4e9870e8fc0cd184f8515af4a",
    "url": "/img/iccid_bg@3x.fa9050c4.png"
  },
  {
    "revision": "b899232b79ad9962c5ab5572775a0400",
    "url": "/img/card_index_bg@3x.b899232b.png"
  },
  {
    "revision": "b899232b79ad9962c5ab5572775a0400",
    "url": "/img/card_index_bg@2x.b899232b.png"
  },
  {
    "revision": "2c51a1e53c1ea0b35086d8d7261b4933",
    "url": "/img/bg_network@3x.2c51a1e5.png"
  },
  {
    "revision": "32d70c8fc305e3647098f3de0c71b618",
    "url": "/img/bg_network@2x.32d70c8f.png"
  },
  {
    "revision": "42c0fbd4915870e5e60452fd0ef2cbec",
    "url": "/img/orderTopBg@3x.42c0fbd4.png"
  },
  {
    "revision": "42c0fbd4915870e5e60452fd0ef2cbec",
    "url": "/img/orderTopBg@2x.42c0fbd4.png"
  },
  {
    "revision": "4ecd943eb3a2c5c0890145b943c1c659",
    "url": "/img/85.4ecd943e.png"
  },
  {
    "revision": "cc0636ca2944024fd3ebf33a5412ff35",
    "url": "/img/icon-right@3x.cc0636ca.png"
  },
  {
    "revision": "1b983020cfed6b7a8ca5c300c24ca186",
    "url": "/img/icon-left@3x.1b983020.png"
  },
  {
    "revision": "d796d97eb9ebb2e89bb966343e2362e9",
    "url": "/img/icon-left@2x.d796d97e.png"
  },
  {
    "revision": "ccb9865dadbc642b8c4dd0a1abc8e570",
    "url": "/img/recharge-word@2x.ccb9865d.png"
  },
  {
    "revision": "ccb9865dadbc642b8c4dd0a1abc8e570",
    "url": "/img/recharge-word@3x.ccb9865d.png"
  },
  {
    "revision": "41a8c268f703fe646d5d08099eb778ae",
    "url": "/img/icon-right@2x.41a8c268.png"
  },
  {
    "revision": "2d6d06f4da15fc1a748677c49c5f1854",
    "url": "/img/bg.2d6d06f4.png"
  },
  {
    "revision": "fff5af4325410621aeec4e60b3b92d9b",
    "url": "/img/mifi_binding_bg@3x.fff5af43.png"
  },
  {
    "revision": "fff5af4325410621aeec4e60b3b92d9b",
    "url": "/img/mifi_binding_bg@2x.fff5af43.png"
  },
  {
    "revision": "fa855242805b87da42c65763acd64ac0",
    "url": "/img/bg-plan-type@2x.fa855242.png"
  },
  {
    "revision": "4a9ca192485effa8b8f4b5b2df5b9caf",
    "url": "/img/bg-plan-type@3x.4a9ca192.png"
  },
  {
    "revision": "91e1d2771efacd45e5e465d9a001f197",
    "url": "/img/liantong.91e1d277.png"
  },
  {
    "revision": "4a0cab0f33beb48ea985714d1b91fef7",
    "url": "/img/dianxin.4a0cab0f.png"
  },
  {
    "revision": "657033323334e91efb0011bbc18f8c04",
    "url": "/img/yidong.65703332.png"
  },
  {
    "revision": "8da3b83b73e44e54d6be4b2522bcb1f2",
    "url": "/img/pkgBg2.8da3b83b.png"
  },
  {
    "revision": "d3b42651f9f5048baeffb50c800913ec",
    "url": "/img/pkgBg1.d3b42651.png"
  },
  {
    "revision": "d461d18e42a310bd709b2ce97d159153",
    "url": "/img/pkgBg3.d461d18e.png"
  },
  {
    "revision": "0078f03c08066d51d64b92a13e194ebb",
    "url": "/img/balanceRefund.0078f03c.png"
  },
  {
    "revision": "0f16389ec218c90cf8f657e233b745f2",
    "url": "/img/balanceBg1.0f16389e.png"
  },
  {
    "revision": "565459ef2ee8b71db421144ad21c23e3",
    "url": "/img/balanceBg2.565459ef.png"
  },
  {
    "revision": "af3ed0b3236bbfdbc3ad61b8d41c3dec",
    "url": "/img/changeBg.af3ed0b3.png"
  },
  {
    "revision": "f5f322478286641bd9887a155e35f222",
    "url": "/img/btn.f5f32247.png"
  },
  {
    "revision": "d140650fa64e0f1fc771610dba62aed7",
    "url": "/img/bg.d140650f.png"
  },
  {
    "revision": "e625229e32d9deeb5f2909c314d8e609",
    "url": "/img/ios@2x.e625229e.png"
  },
  {
    "revision": "af8bbdfa0a90c4eed4563f8c06ce5ff8",
    "url": "/img/android@2x.af8bbdfa.png"
  },
  {
    "revision": "114a6e12b42b9b48586dd341105188fe",
    "url": "/img/usedOrder@2x.114a6e12.png"
  },
  {
    "revision": "c0170ec299b2418256fd515ee7849055",
    "url": "/img/unUsedOrder@2x.c0170ec2.png"
  },
  {
    "revision": "d9e14058d30dd312519fcf2de38d742b",
    "url": "/img/unUsedOrder@3x.d9e14058.png"
  },
  {
    "revision": "4a5b90f8076955f289b3dcda6a5af6ff",
    "url": "/img/invaildedOrder@3x.4a5b90f8.png"
  },
  {
    "revision": "0d5a5158e67bcb7a4604124715ed6fbf",
    "url": "/img/usedOrder@3x.0d5a5158.png"
  },
  {
    "revision": "be0f1e33b2553e71b117d3d3f838d32f",
    "url": "/img/invaildedOrder@2x.be0f1e33.png"
  },
  {
    "revision": "1d7515ee61c3f659227318b4050955ed",
    "url": "/img/mobile_sim@2x.1d7515ee.png"
  },
  {
    "revision": "0f980b79d9a52702004de9f652a68835",
    "url": "/img/telcom_sim@2x.0f980b79.png"
  },
  {
    "revision": "98141226a7e992e3072a280746a259c4",
    "url": "/img/mobile_sim@3x.98141226.png"
  },
  {
    "revision": "0c88168b284b92c37f3a873f26a97d69",
    "url": "/img/bg.0c88168b.jpg"
  },
  {
    "revision": "9e02095f31a07b972244f1c714c1dfe7",
    "url": "/img/telcom_sim@3x.9e02095f.png"
  },
  {
    "revision": "3d0fc424b703032ca595090e99f8354b",
    "url": "/img/login_bg@2x.3d0fc424.png"
  },
  {
    "revision": "11000d4e510a6df565eb69ba6f2c1dfc",
    "url": "/img/login_bg@3x.11000d4e.png"
  },
  {
    "revision": "3f342771b9b81ab929e0fbcbcd0e6533",
    "url": "/img/bg-check-wrap@3x.3f342771.png"
  },
  {
    "revision": "9713b21819c4019befecd095069977df",
    "url": "/img/bg-check-wrap@2x.9713b218.png"
  },
  {
    "revision": "014d354b9b25b67ae95857ba17e2f4cc",
    "url": "/img/activityPage.014d354b.png"
  },
  {
    "revision": "2a67b73145562669220aa4639e1ad58f",
    "url": "/img/icon3.2a67b731.png"
  },
  {
    "revision": "813b5319e378dafdda952c16ad89906b",
    "url": "/img/icon2.813b5319.png"
  },
  {
    "revision": "f40c7e0b20fe25eb78a7658c3ae56312",
    "url": "/img/noData@3x.f40c7e0b.png"
  },
  {
    "revision": "644e6e3cf5f33943747b116316694e28",
    "url": "/img/noData@2x.644e6e3c.png"
  },
  {
    "revision": "01355f175bd20423ce45a838c1a998a9",
    "url": "/img/bg.01355f17.png"
  },
  {
    "revision": "3603a35a49dbb8ad94ec1e57c4dad229",
    "url": "/img/scanTop2.3603a35a.png"
  },
  {
    "revision": "05775dd69c53d7273b27aaa7c6c523f7",
    "url": "/img/04.05775dd6.png"
  },
  {
    "revision": "58a560568b7291ea926c2c7438035308",
    "url": "/img/subscribe@3x.58a56056.png"
  },
  {
    "revision": "541375e6bb7db2fba9e415be8045f5fb",
    "url": "/img/1.541375e6.png"
  },
  {
    "revision": "5a3428653945c17e1c146efeee81c987",
    "url": "/img/scanTop.5a342865.png"
  },
  {
    "revision": "824594523c01e48028f2b7eb4261134d",
    "url": "/img/unicom-logo.82459452.svg"
  },
  {
    "revision": "113f99e2189c2ca49db2168754fc2eb5",
    "url": "/img/mobile-logo.113f99e2.png"
  },
  {
    "revision": "0cba868fa977e09806638b9000636a36",
    "url": "/img/avatar.0cba868f.jpeg"
  },
  {
    "revision": "27158aa79eb0d4b89f317d076a801ca3",
    "url": "/img/coupon-log.27158aa7.png"
  },
  {
    "revision": "55d3f2f09efe17db6485d4c9f8f0c3b1",
    "url": "/img/icon-recharge_20181001.55d3f2f0.svg"
  },
  {
    "revision": "165beb68d8ba0d2b70df0fbb3769787a",
    "url": "/img/03.165beb68.png"
  },
  {
    "revision": "5f1f34037094c0613bccafa2ddd8cb3b",
    "url": "/img/telecom-logo.5f1f3403.svg"
  },
  {
    "revision": "f7a51f1c554585b11d61499fd0a7520f",
    "url": "/img/only-box@3x.f7a51f1c.png"
  },
  {
    "revision": "0b3c3297decbd1152a314cce115f9632",
    "url": "/img/09.0b3c3297.png"
  },
  {
    "revision": "aecc9531f2c3b1fd45338e7bf5084384",
    "url": "/img/bg_no_recharge.aecc9531.svg"
  },
  {
    "revision": "b0ffa4a0fd195a110ee4d4dabce3bc32",
    "url": "/img/08.b0ffa4a0.png"
  },
  {
    "revision": "96fab583abd57f2e7118324858fa3080",
    "url": "/img/05.96fab583.png"
  },
  {
    "revision": "9e8ecc7f7b760b55c56bddfab886da10",
    "url": "/img/3.9e8ecc7f.png"
  },
  {
    "revision": "275be51ae57c486bce58257febd6589f",
    "url": "/img/bg_no_plan.275be51a.svg"
  },
  {
    "revision": "a8272d2d742d9d50257e23dfac577def",
    "url": "/img/01.a8272d2d.png"
  },
  {
    "revision": "daa86b540bb9c2a6453ceac9bed77961",
    "url": "/img/07.daa86b54.png"
  },
  {
    "revision": "06385746a7cedb492d5539907631561c",
    "url": "/img/tip.06385746.png"
  },
  {
    "revision": "a610420eab741be28278e60bc06387aa",
    "url": "/img/box-deco@3x.a610420e.png"
  },
  {
    "revision": "eacba58f9acf2b87cd801858146b2ba9",
    "url": "/img/02.eacba58f.png"
  },
  {
    "revision": "39d9e849fc1c724525f166646932a24d",
    "url": "/img/safari.39d9e849.png"
  },
  {
    "revision": "999589aae784a460b5e7c6ae9bbaa3d8",
    "url": "/img/06.999589aa.png"
  },
  {
    "revision": "7c28431d304fa4f58f5070c59720683a",
    "url": "/img/2.7c28431d.png"
  },
  {
    "revision": "3e217df4202e41ad9b030aafc8cfcc24",
    "url": "/img/4.3e217df4.png"
  },
  {
    "revision": "0bac885fcead95f78d90ab73fc891966",
    "url": "/index.html"
  },
  {
    "revision": "00bbf6b458bf7ea6bd01f443eb3045d9",
    "url": "/MP_verify_4r3DVk3KUjgWsQsG.txt"
  },
  {
    "revision": "86c422d8c98b247235d04b49fb1c4b05",
    "url": "/MP_verify_bKSdn2qZlUSULliu.txt"
  },
  {
    "revision": "652317b098ca24e4511926c7fd57cbbe",
    "url": "/MP_verify_8JoCCldW78DygS5c.txt"
  },
  {
    "revision": "9ce16f441b39b493af8b96d7e97cce22",
    "url": "/MP_verify_dkzAKjxyVyJvsHMS.txt"
  },
  {
    "revision": "b6216d61c03e6ce0c9aea6ca7808f7ca",
    "url": "/robots.txt"
  }
];