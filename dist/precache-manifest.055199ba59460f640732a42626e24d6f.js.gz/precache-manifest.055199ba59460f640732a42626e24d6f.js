self.__precacheManifest = [
  {
    "revision": "93d0de102dc5644a53da",
    "url": "/js/recharge_callback.dee0271e.js"
  },
  {
    "revision": "b6216d61c03e6ce0c9aea6ca7808f7ca",
    "url": "/robots.txt"
  },
  {
    "revision": "c89c0139fe8d266942f8",
    "url": "/css/refund_applying.682a7c2d.css"
  },
  {
    "revision": "f30c648f214675497967",
    "url": "/css/_404.0aa83713.css"
  },
  {
    "revision": "d41c96f5e6521dd55461",
    "url": "/css/app.f82b8cea.css"
  },
  {
    "revision": "d41c96f5e6521dd55461",
    "url": "/js/app.032c752b.js"
  },
  {
    "revision": "0fc3b8e6b843929f1743",
    "url": "/css/card_check.b700e0a6.css"
  },
  {
    "revision": "0fc3b8e6b843929f1743",
    "url": "/js/card_check.f85f453e.js"
  },
  {
    "revision": "0ad2a62f21b78143306f",
    "url": "/css/card_connection.1dcd9e95.css"
  },
  {
    "revision": "0ad2a62f21b78143306f",
    "url": "/js/card_connection.09f5935c.js"
  },
  {
    "revision": "80d787edb703b5b08d93",
    "url": "/css/card_lookup.6c93b6fc.css"
  },
  {
    "revision": "80d787edb703b5b08d93",
    "url": "/js/card_lookup.e3ea761a.js"
  },
  {
    "revision": "547974d89114ef80eba5",
    "url": "/css/card_usage.c7591460.css"
  },
  {
    "revision": "547974d89114ef80eba5",
    "url": "/js/card_usage.99cdbc5a.js"
  },
  {
    "revision": "272e6b3875c5e6a0bab4",
    "url": "/css/card_usage~plan_list.092deafd.css"
  },
  {
    "revision": "272e6b3875c5e6a0bab4",
    "url": "/js/card_usage~plan_list.1ce848e9.js"
  },
  {
    "revision": "8dbac5081bd234a58e5c",
    "url": "/css/children_card.11ccd174.css"
  },
  {
    "revision": "8dbac5081bd234a58e5c",
    "url": "/js/children_card.0c05ae37.js"
  },
  {
    "revision": "bcf840af1e2059d7acda",
    "url": "/css/chunk-1b993786.92d7c6f2.css"
  },
  {
    "revision": "bcf840af1e2059d7acda",
    "url": "/js/chunk-1b993786.5cfa3bce.js"
  },
  {
    "revision": "be4b93e3b8d806d31c9f",
    "url": "/css/chunk-2c60680e.e82da1b2.css"
  },
  {
    "revision": "be4b93e3b8d806d31c9f",
    "url": "/js/chunk-2c60680e.89dee109.js"
  },
  {
    "revision": "de8bf5d4e57b8a73b3d5",
    "url": "/css/chunk-vendors.0a14d1e9.css"
  },
  {
    "revision": "de8bf5d4e57b8a73b3d5",
    "url": "/js/chunk-vendors.4cb3f68e.js"
  },
  {
    "revision": "065e36fe0c715b14b469",
    "url": "/css/coupon_normal.34b21aaf.css"
  },
  {
    "revision": "065e36fe0c715b14b469",
    "url": "/js/coupon_normal.6d00820b.js"
  },
  {
    "revision": "9c727afc9156aa02a1e3",
    "url": "/css/coupon_telcom.c4d7b922.css"
  },
  {
    "revision": "9c727afc9156aa02a1e3",
    "url": "/js/coupon_telcom.5a7f0920.js"
  },
  {
    "revision": "e290f27c095909124159",
    "url": "/css/find_plan.13ea77b9.css"
  },
  {
    "revision": "e290f27c095909124159",
    "url": "/js/find_plan.78302121.js"
  },
  {
    "revision": "116d864b50a110768440",
    "url": "/css/login.6509ca6e.css"
  },
  {
    "revision": "116d864b50a110768440",
    "url": "/js/login.2e2407b0.js"
  },
  {
    "revision": "cba4592a6774e09faecf",
    "url": "/css/lookup.324c73c2.css"
  },
  {
    "revision": "cba4592a6774e09faecf",
    "url": "/js/lookup.a43d494e.js"
  },
  {
    "revision": "a601adbd85ca6d7c7856",
    "url": "/css/plan_list.3c827c4a.css"
  },
  {
    "revision": "a601adbd85ca6d7c7856",
    "url": "/js/plan_list.a86854f3.js"
  },
  {
    "revision": "4d20de6e37813fb4b551",
    "url": "/css/question.9573b0b5.css"
  },
  {
    "revision": "4d20de6e37813fb4b551",
    "url": "/js/question.8a1242fd.js"
  },
  {
    "revision": "c11b9d07a7d11a1265d9",
    "url": "/css/real_name.49362bec.css"
  },
  {
    "revision": "c11b9d07a7d11a1265d9",
    "url": "/js/real_name.7de71996.js"
  },
  {
    "revision": "d6d0beccb1ad25b77dc5",
    "url": "/css/recharge.d049f50c.css"
  },
  {
    "revision": "d6d0beccb1ad25b77dc5",
    "url": "/js/recharge.e1006f4f.js"
  },
  {
    "revision": "93d0de102dc5644a53da",
    "url": "/css/recharge_callback.a107fbe0.css"
  },
  {
    "revision": "c6125700cef12b525abf",
    "url": "/js/Layout.101e5edc.js"
  },
  {
    "revision": "f30c648f214675497967",
    "url": "/js/_404.f24126b9.js"
  },
  {
    "revision": "c89c0139fe8d266942f8",
    "url": "/js/refund_applying.b79bec05.js"
  },
  {
    "revision": "22a85c3a58d7b582dd04",
    "url": "/css/refund_argument.7c09adfe.css"
  },
  {
    "revision": "22a85c3a58d7b582dd04",
    "url": "/js/refund_argument.c77d00ec.js"
  },
  {
    "revision": "d8be617c22c5d7ed666a",
    "url": "/css/refund_plan.803875a9.css"
  },
  {
    "revision": "d8be617c22c5d7ed666a",
    "url": "/js/refund_plan.c27c5da7.js"
  },
  {
    "revision": "f618ddb9f848c7799725",
    "url": "/css/revoke_plan.12a985f9.css"
  },
  {
    "revision": "f618ddb9f848c7799725",
    "url": "/js/revoke_plan.c93bfb9d.js"
  },
  {
    "revision": "d26ff5503a47d340bb4a",
    "url": "/css/speedup_500.3b61fe01.css"
  },
  {
    "revision": "d26ff5503a47d340bb4a",
    "url": "/js/speedup_500.6e469a21.js"
  },
  {
    "revision": "5a3ce541acf4be971e56",
    "url": "/css/speedup_80.df2b44fb.css"
  },
  {
    "revision": "5a3ce541acf4be971e56",
    "url": "/js/speedup_80.da063244.js"
  },
  {
    "revision": "7d71dfa29a8771ae2ebf",
    "url": "/css/to_tb.5f146892.css"
  },
  {
    "revision": "7d71dfa29a8771ae2ebf",
    "url": "/js/to_tb.5f6c3d05.js"
  },
  {
    "revision": "e4b411644706c29765eea3ffdd85ae39",
    "url": "/fonts/SourceHanSansCNRegular.e4b41164.woff"
  },
  {
    "revision": "834b022ab9ab0e6063904af32274e777",
    "url": "/fonts/SourceHanSansCNRegular.834b022a.eot"
  },
  {
    "revision": "f9509c5a10be7daaf1fa01922a7c6bc2",
    "url": "/fonts/SourceHanSansCNRegular.f9509c5a.ttf"
  },
  {
    "revision": "da0808e9fe85be160aab69c82dd8de1c",
    "url": "/img/SourceHanSansCNRegular.da0808e9.svg"
  },
  {
    "revision": "f5f322478286641bd9887a155e35f222",
    "url": "/img/btn.f5f32247.png"
  },
  {
    "revision": "d140650fa64e0f1fc771610dba62aed7",
    "url": "/img/bg.d140650f.png"
  },
  {
    "revision": "3f342771b9b81ab929e0fbcbcd0e6533",
    "url": "/img/bg-check-wrap@3x.3f342771.png"
  },
  {
    "revision": "9713b21819c4019befecd095069977df",
    "url": "/img/bg-check-wrap@2x.9713b218.png"
  },
  {
    "revision": "1d7515ee61c3f659227318b4050955ed",
    "url": "/img/mobile_sim@2x.1d7515ee.png"
  },
  {
    "revision": "0f980b79d9a52702004de9f652a68835",
    "url": "/img/telcom_sim@2x.0f980b79.png"
  },
  {
    "revision": "98141226a7e992e3072a280746a259c4",
    "url": "/img/mobile_sim@3x.98141226.png"
  },
  {
    "revision": "0c88168b284b92c37f3a873f26a97d69",
    "url": "/img/bg.0c88168b.jpg"
  },
  {
    "revision": "9e02095f31a07b972244f1c714c1dfe7",
    "url": "/img/telcom_sim@3x.9e02095f.png"
  },
  {
    "revision": "3d0fc424b703032ca595090e99f8354b",
    "url": "/img/login_bg@2x.3d0fc424.png"
  },
  {
    "revision": "11000d4e510a6df565eb69ba6f2c1dfc",
    "url": "/img/login_bg@3x.11000d4e.png"
  },
  {
    "revision": "5a3428653945c17e1c146efeee81c987",
    "url": "/img/scanTop.5a342865.png"
  },
  {
    "revision": "824594523c01e48028f2b7eb4261134d",
    "url": "/img/unicom-logo.82459452.svg"
  },
  {
    "revision": "113f99e2189c2ca49db2168754fc2eb5",
    "url": "/img/mobile-logo.113f99e2.png"
  },
  {
    "revision": "27158aa79eb0d4b89f317d076a801ca3",
    "url": "/img/coupon-log.27158aa7.png"
  },
  {
    "revision": "55d3f2f09efe17db6485d4c9f8f0c3b1",
    "url": "/img/icon-recharge_20181001.55d3f2f0.svg"
  },
  {
    "revision": "5f1f34037094c0613bccafa2ddd8cb3b",
    "url": "/img/telecom-logo.5f1f3403.svg"
  },
  {
    "revision": "4bdbe7dbdb6587c886a8290593100145",
    "url": "/img/recharge_callback_20181126.4bdbe7db.jpg"
  },
  {
    "revision": "aecc9531f2c3b1fd45338e7bf5084384",
    "url": "/img/bg_no_recharge.aecc9531.svg"
  },
  {
    "revision": "275be51ae57c486bce58257febd6589f",
    "url": "/img/bg_no_plan.275be51a.svg"
  },
  {
    "revision": "1b4099d62a5dc6b4ec75bb83892a6e42",
    "url": "/index.html"
  },
  {
    "revision": "c6125700cef12b525abf",
    "url": "/css/Layout.c59a8b7e.css"
  },
  {
    "revision": "86c422d8c98b247235d04b49fb1c4b05",
    "url": "/MP_verify_bKSdn2qZlUSULliu.txt"
  },
  {
    "revision": "652317b098ca24e4511926c7fd57cbbe",
    "url": "/MP_verify_8JoCCldW78DygS5c.txt"
  },
  {
    "revision": "00bbf6b458bf7ea6bd01f443eb3045d9",
    "url": "/MP_verify_4r3DVk3KUjgWsQsG.txt"
  }
];