self.__precacheManifest = [
  {
    "revision": "c19b6853ffb4fa04d88c",
    "url": "/js/recharge_callback.e12e362d.js"
  },
  {
    "revision": "db93b0f5af5ac6325831",
    "url": "/css/Layout.c59a8b7e.css"
  },
  {
    "revision": "cd47ac83c8d014d1f511",
    "url": "/css/_404.b6476c76.css"
  },
  {
    "revision": "cd47ac83c8d014d1f511",
    "url": "/js/_404.e08bc7bc.js"
  },
  {
    "revision": "d64a2d08840536f029de",
    "url": "/css/app.9acfb0a8.css"
  },
  {
    "revision": "d64a2d08840536f029de",
    "url": "/js/app.e862c478.js"
  },
  {
    "revision": "8eb147eb961761727e13",
    "url": "/css/authority_middle.e6f03762.css"
  },
  {
    "revision": "8eb147eb961761727e13",
    "url": "/js/authority_middle.4e64506e.js"
  },
  {
    "revision": "dfb4b954ebfcfedd4b62",
    "url": "/css/card_check.1fc58509.css"
  },
  {
    "revision": "dfb4b954ebfcfedd4b62",
    "url": "/js/card_check.d8860c86.js"
  },
  {
    "revision": "38626946721d4b2b8c99",
    "url": "/css/card_connection.011f509b.css"
  },
  {
    "revision": "38626946721d4b2b8c99",
    "url": "/js/card_connection.450a4b42.js"
  },
  {
    "revision": "442ad53fdeea073d50f0",
    "url": "/css/card_lookup.54a49771.css"
  },
  {
    "revision": "442ad53fdeea073d50f0",
    "url": "/js/card_lookup.3667c497.js"
  },
  {
    "revision": "e2e1cfe778f404ee203e",
    "url": "/css/card_usage.5ce8e886.css"
  },
  {
    "revision": "e2e1cfe778f404ee203e",
    "url": "/js/card_usage.3cc337c7.js"
  },
  {
    "revision": "272e6b3875c5e6a0bab4",
    "url": "/css/card_usage~plan_list.092deafd.css"
  },
  {
    "revision": "272e6b3875c5e6a0bab4",
    "url": "/js/card_usage~plan_list.1ce848e9.js"
  },
  {
    "revision": "88ca9606a67f0a99116f",
    "url": "/css/card_wrapper.acf02c15.css"
  },
  {
    "revision": "88ca9606a67f0a99116f",
    "url": "/js/card_wrapper.dfbb3b9b.js"
  },
  {
    "revision": "bc9fccd8f3890870046f",
    "url": "/css/children_card.d5aac1fd.css"
  },
  {
    "revision": "bc9fccd8f3890870046f",
    "url": "/js/children_card.188d825e.js"
  },
  {
    "revision": "d591cf3fff6ab7f2fd0a",
    "url": "/css/chunk-5ddcf211.2b221153.css"
  },
  {
    "revision": "d591cf3fff6ab7f2fd0a",
    "url": "/js/chunk-5ddcf211.fe19b20c.js"
  },
  {
    "revision": "00e0387ccb0450bc51af",
    "url": "/css/chunk-7fb98680.47a09aae.css"
  },
  {
    "revision": "00e0387ccb0450bc51af",
    "url": "/js/chunk-7fb98680.d8658605.js"
  },
  {
    "revision": "4200d5739430f20445eb",
    "url": "/css/chunk-vendors.850af779.css"
  },
  {
    "revision": "4200d5739430f20445eb",
    "url": "/js/chunk-vendors.4cb3f68e.js"
  },
  {
    "revision": "db70086405c7506119e0",
    "url": "/css/coupon_normal.a455d940.css"
  },
  {
    "revision": "db70086405c7506119e0",
    "url": "/js/coupon_normal.92028aa8.js"
  },
  {
    "revision": "b32b6f62d9df48317ac6",
    "url": "/css/coupon_telcom.210cc699.css"
  },
  {
    "revision": "b32b6f62d9df48317ac6",
    "url": "/js/coupon_telcom.8179bea2.js"
  },
  {
    "revision": "f2176c70a250a69b56b2",
    "url": "/css/coupon_wrapper.9b92bcd2.css"
  },
  {
    "revision": "f2176c70a250a69b56b2",
    "url": "/js/coupon_wrapper.e1719114.js"
  },
  {
    "revision": "a3c4ce9285464b04c983",
    "url": "/css/find_plan.5c549760.css"
  },
  {
    "revision": "a3c4ce9285464b04c983",
    "url": "/js/find_plan.7d1cd9a0.js"
  },
  {
    "revision": "67d593f6342620d2e40c",
    "url": "/css/login.6509ca6e.css"
  },
  {
    "revision": "67d593f6342620d2e40c",
    "url": "/js/login.fa8c158c.js"
  },
  {
    "revision": "93f585c73a96b48e4be5",
    "url": "/css/lookup.c8cec05f.css"
  },
  {
    "revision": "93f585c73a96b48e4be5",
    "url": "/js/lookup.687655d5.js"
  },
  {
    "revision": "332028b7bf86f62538fc",
    "url": "/css/new_card_wrapper.63acae48.css"
  },
  {
    "revision": "332028b7bf86f62538fc",
    "url": "/js/new_card_wrapper.b9a58b32.js"
  },
  {
    "revision": "e5082038ffcc5a4bb7d1",
    "url": "/css/plan_list.9540957b.css"
  },
  {
    "revision": "e5082038ffcc5a4bb7d1",
    "url": "/js/plan_list.7ff9ee5c.js"
  },
  {
    "revision": "554e2f803570a99b8f93",
    "url": "/css/question.4a3349ab.css"
  },
  {
    "revision": "554e2f803570a99b8f93",
    "url": "/js/question.ef1705a8.js"
  },
  {
    "revision": "2d755e86ac83ffb0a5d2",
    "url": "/css/question_wrapper.707898e1.css"
  },
  {
    "revision": "2d755e86ac83ffb0a5d2",
    "url": "/js/question_wrapper.0d48f26f.js"
  },
  {
    "revision": "e2aadbb18f2cee415e1c",
    "url": "/css/real_name.84a42d52.css"
  },
  {
    "revision": "e2aadbb18f2cee415e1c",
    "url": "/js/real_name.a564a4fe.js"
  },
  {
    "revision": "1a9323998fbb90d0d2db",
    "url": "/css/recharge.38481b9f.css"
  },
  {
    "revision": "1a9323998fbb90d0d2db",
    "url": "/js/recharge.d662f0c2.js"
  },
  {
    "revision": "c19b6853ffb4fa04d88c",
    "url": "/css/recharge_callback.aaf38d88.css"
  },
  {
    "revision": "db93b0f5af5ac6325831",
    "url": "/js/Layout.80bbfd40.js"
  },
  {
    "revision": "ee9c00003910a3ee3730",
    "url": "/css/recharge_wrapper.a4c7e1f3.css"
  },
  {
    "revision": "ee9c00003910a3ee3730",
    "url": "/js/recharge_wrapper.75cd4889.js"
  },
  {
    "revision": "b44557040f927f98190c",
    "url": "/css/refund_applying.bef9c933.css"
  },
  {
    "revision": "b44557040f927f98190c",
    "url": "/js/refund_applying.620a1d6a.js"
  },
  {
    "revision": "b15aced6e7f26596230a",
    "url": "/css/refund_argument.e9479511.css"
  },
  {
    "revision": "b15aced6e7f26596230a",
    "url": "/js/refund_argument.1ac2be3a.js"
  },
  {
    "revision": "3c5f9692ec174925107a",
    "url": "/css/refund_plan.a72f3270.css"
  },
  {
    "revision": "3c5f9692ec174925107a",
    "url": "/js/refund_plan.1e452d04.js"
  },
  {
    "revision": "69f731873249e9f97a01",
    "url": "/css/refund_wrapper.6e1b567f.css"
  },
  {
    "revision": "69f731873249e9f97a01",
    "url": "/js/refund_wrapper.258a2cef.js"
  },
  {
    "revision": "db80396079b6f198bdb1",
    "url": "/css/revoke_plan.00366d72.css"
  },
  {
    "revision": "db80396079b6f198bdb1",
    "url": "/js/revoke_plan.fc5acfdb.js"
  },
  {
    "revision": "8de273ae8fa51a088c17",
    "url": "/css/speedup_500.3fae4bd5.css"
  },
  {
    "revision": "8de273ae8fa51a088c17",
    "url": "/js/speedup_500.7ad9dbb4.js"
  },
  {
    "revision": "2e93633809b768a1eb66",
    "url": "/css/speedup_80.5a1c30a7.css"
  },
  {
    "revision": "2e93633809b768a1eb66",
    "url": "/js/speedup_80.6afe2ff2.js"
  },
  {
    "revision": "d18b8fdc98bdfb36ce7b",
    "url": "/css/speedup_wrapper.23e7f2d1.css"
  },
  {
    "revision": "d18b8fdc98bdfb36ce7b",
    "url": "/js/speedup_wrapper.194089ca.js"
  },
  {
    "revision": "79cf1c45d06b54376f71",
    "url": "/css/to_tb.d02f17bb.css"
  },
  {
    "revision": "79cf1c45d06b54376f71",
    "url": "/js/to_tb.55ed9485.js"
  },
  {
    "revision": "e4b411644706c29765eea3ffdd85ae39",
    "url": "/fonts/SourceHanSansCNRegular.e4b41164.woff"
  },
  {
    "revision": "834b022ab9ab0e6063904af32274e777",
    "url": "/fonts/SourceHanSansCNRegular.834b022a.eot"
  },
  {
    "revision": "f9509c5a10be7daaf1fa01922a7c6bc2",
    "url": "/fonts/SourceHanSansCNRegular.f9509c5a.ttf"
  },
  {
    "revision": "da0808e9fe85be160aab69c82dd8de1c",
    "url": "/img/SourceHanSansCNRegular.da0808e9.svg"
  },
  {
    "revision": "f5f322478286641bd9887a155e35f222",
    "url": "/img/btn.f5f32247.png"
  },
  {
    "revision": "d140650fa64e0f1fc771610dba62aed7",
    "url": "/img/bg.d140650f.png"
  },
  {
    "revision": "3f342771b9b81ab929e0fbcbcd0e6533",
    "url": "/img/bg-check-wrap@3x.3f342771.png"
  },
  {
    "revision": "9713b21819c4019befecd095069977df",
    "url": "/img/bg-check-wrap@2x.9713b218.png"
  },
  {
    "revision": "1d7515ee61c3f659227318b4050955ed",
    "url": "/img/mobile_sim@2x.1d7515ee.png"
  },
  {
    "revision": "0f980b79d9a52702004de9f652a68835",
    "url": "/img/telcom_sim@2x.0f980b79.png"
  },
  {
    "revision": "98141226a7e992e3072a280746a259c4",
    "url": "/img/mobile_sim@3x.98141226.png"
  },
  {
    "revision": "0c88168b284b92c37f3a873f26a97d69",
    "url": "/img/bg.0c88168b.jpg"
  },
  {
    "revision": "9e02095f31a07b972244f1c714c1dfe7",
    "url": "/img/telcom_sim@3x.9e02095f.png"
  },
  {
    "revision": "e625229e32d9deeb5f2909c314d8e609",
    "url": "/img/ios@2x.e625229e.png"
  },
  {
    "revision": "af8bbdfa0a90c4eed4563f8c06ce5ff8",
    "url": "/img/android@2x.af8bbdfa.png"
  },
  {
    "revision": "3d0fc424b703032ca595090e99f8354b",
    "url": "/img/login_bg@2x.3d0fc424.png"
  },
  {
    "revision": "11000d4e510a6df565eb69ba6f2c1dfc",
    "url": "/img/login_bg@3x.11000d4e.png"
  },
  {
    "revision": "5a3428653945c17e1c146efeee81c987",
    "url": "/img/scanTop.5a342865.png"
  },
  {
    "revision": "824594523c01e48028f2b7eb4261134d",
    "url": "/img/unicom-logo.82459452.svg"
  },
  {
    "revision": "113f99e2189c2ca49db2168754fc2eb5",
    "url": "/img/mobile-logo.113f99e2.png"
  },
  {
    "revision": "27158aa79eb0d4b89f317d076a801ca3",
    "url": "/img/coupon-log.27158aa7.png"
  },
  {
    "revision": "55d3f2f09efe17db6485d4c9f8f0c3b1",
    "url": "/img/icon-recharge_20181001.55d3f2f0.svg"
  },
  {
    "revision": "5f1f34037094c0613bccafa2ddd8cb3b",
    "url": "/img/telecom-logo.5f1f3403.svg"
  },
  {
    "revision": "4bdbe7dbdb6587c886a8290593100145",
    "url": "/img/recharge_callback_20181126.4bdbe7db.jpg"
  },
  {
    "revision": "aecc9531f2c3b1fd45338e7bf5084384",
    "url": "/img/bg_no_recharge.aecc9531.svg"
  },
  {
    "revision": "275be51ae57c486bce58257febd6589f",
    "url": "/img/bg_no_plan.275be51a.svg"
  },
  {
    "revision": "39d9e849fc1c724525f166646932a24d",
    "url": "/img/safari.39d9e849.png"
  },
  {
    "revision": "b162aa4b13987be7137d22bd081fa193",
    "url": "/index.html"
  },
  {
    "revision": "b6216d61c03e6ce0c9aea6ca7808f7ca",
    "url": "/robots.txt"
  },
  {
    "revision": "86c422d8c98b247235d04b49fb1c4b05",
    "url": "/MP_verify_bKSdn2qZlUSULliu.txt"
  },
  {
    "revision": "652317b098ca24e4511926c7fd57cbbe",
    "url": "/MP_verify_8JoCCldW78DygS5c.txt"
  },
  {
    "revision": "00bbf6b458bf7ea6bd01f443eb3045d9",
    "url": "/MP_verify_4r3DVk3KUjgWsQsG.txt"
  }
];