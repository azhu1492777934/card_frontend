self.__precacheManifest = [
  {
    "revision": "90e9338c3deb5fd373b6",
    "url": "/js/recharge_wrapper.83f14224.js"
  },
  {
    "revision": "b6216d61c03e6ce0c9aea6ca7808f7ca",
    "url": "/robots.txt"
  },
  {
    "revision": "da1be45fd64832fc2913",
    "url": "/css/refundRules.e8f23458.css"
  },
  {
    "revision": "486c88a173afee991629",
    "url": "/css/Layout~card_usage.c5af5c36.css"
  },
  {
    "revision": "f6fe50ccd582c459975e",
    "url": "/js/Layout~card_usage~eqReplaceMent~esim_plan_list~esim_usage~mifi_order~mifi_plan_list~mifi_plan_usage~~3166b5eb.91e2eec6.js"
  },
  {
    "revision": "29fa2271cd631de4db88",
    "url": "/css/Not_fund.e2fd00c5.css"
  },
  {
    "revision": "29fa2271cd631de4db88",
    "url": "/js/Not_fund.15ff5217.js"
  },
  {
    "revision": "0d222e92756f4271802c",
    "url": "/css/app.2608000f.css"
  },
  {
    "revision": "0d222e92756f4271802c",
    "url": "/js/app.0af8ab5b.js"
  },
  {
    "revision": "5ce5c4c3f219babc6869",
    "url": "/css/authority_middle.aaa01b3c.css"
  },
  {
    "revision": "5ce5c4c3f219babc6869",
    "url": "/js/authority_middle.ad76a818.js"
  },
  {
    "revision": "a63072d90a7bb97d6d53",
    "url": "/css/balanceIndex.8c9e1000.css"
  },
  {
    "revision": "a63072d90a7bb97d6d53",
    "url": "/js/balanceIndex.76884404.js"
  },
  {
    "revision": "1995fb962d749ebf17c9",
    "url": "/css/balanceRefund.ced5af09.css"
  },
  {
    "revision": "1995fb962d749ebf17c9",
    "url": "/js/balanceRefund.c1796cc1.js"
  },
  {
    "revision": "79d67b6453dd404c1f82",
    "url": "/css/cardPackage.8a1d6b87.css"
  },
  {
    "revision": "79d67b6453dd404c1f82",
    "url": "/js/cardPackage.f867e97a.js"
  },
  {
    "revision": "98d52daa70c7b287bf36",
    "url": "/css/card_check.e0383461.css"
  },
  {
    "revision": "98d52daa70c7b287bf36",
    "url": "/js/card_check.90f3943b.js"
  },
  {
    "revision": "73d93829f5fe2e15f2a6",
    "url": "/css/card_connection.b576c6c3.css"
  },
  {
    "revision": "73d93829f5fe2e15f2a6",
    "url": "/js/card_connection.09187d30.js"
  },
  {
    "revision": "37de702645131b759255",
    "url": "/css/card_lookup.e5b6e117.css"
  },
  {
    "revision": "37de702645131b759255",
    "url": "/js/card_lookup.86018347.js"
  },
  {
    "revision": "c2724a3955c8bf6d2f92",
    "url": "/css/card_more_flow.b52df8ea.css"
  },
  {
    "revision": "c2724a3955c8bf6d2f92",
    "url": "/js/card_more_flow.12cb5192.js"
  },
  {
    "revision": "a2c08a525cb655ebeb7c",
    "url": "/css/card_usage.3139af90.css"
  },
  {
    "revision": "a2c08a525cb655ebeb7c",
    "url": "/js/card_usage.712d4667.js"
  },
  {
    "revision": "57ea04cf4ea9f2d42499",
    "url": "/css/card_wrapper.5a54ff6c.css"
  },
  {
    "revision": "57ea04cf4ea9f2d42499",
    "url": "/js/card_wrapper.6e83ac25.js"
  },
  {
    "revision": "a7db2b6f7553c43055bf",
    "url": "/css/children_card.20a94084.css"
  },
  {
    "revision": "a7db2b6f7553c43055bf",
    "url": "/js/children_card.fa237510.js"
  },
  {
    "revision": "2a29d9d5d8f4bafe1c65",
    "url": "/css/chunk-3ec6cd98.b2facc3b.css"
  },
  {
    "revision": "2a29d9d5d8f4bafe1c65",
    "url": "/js/chunk-3ec6cd98.a172f5c5.js"
  },
  {
    "revision": "ccc7fbe3f4e25ca56b0c",
    "url": "/css/chunk-dc6c1c16.4acfaafb.css"
  },
  {
    "revision": "ccc7fbe3f4e25ca56b0c",
    "url": "/js/chunk-dc6c1c16.417de04b.js"
  },
  {
    "revision": "12033d3a67b6441affdc",
    "url": "/css/chunk-vendors.1f0d5a39.css"
  },
  {
    "revision": "12033d3a67b6441affdc",
    "url": "/js/chunk-vendors.0660135f.js"
  },
  {
    "revision": "2d122bddff2d901e1df6",
    "url": "/css/commonProblem.16934f1e.css"
  },
  {
    "revision": "2d122bddff2d901e1df6",
    "url": "/js/commonProblem.87bd6b07.js"
  },
  {
    "revision": "55f67abc37fd0a037bcd",
    "url": "/css/consumerRecord.72f86aff.css"
  },
  {
    "revision": "55f67abc37fd0a037bcd",
    "url": "/js/consumerRecord.c07d3ea9.js"
  },
  {
    "revision": "fabe0f273d2dcbc018c0",
    "url": "/css/coupon_normal.1a9a5f5b.css"
  },
  {
    "revision": "fabe0f273d2dcbc018c0",
    "url": "/js/coupon_normal.aecbbd50.js"
  },
  {
    "revision": "ea1606489920e3fe0c5a",
    "url": "/css/coupon_telcom.3e944761.css"
  },
  {
    "revision": "ea1606489920e3fe0c5a",
    "url": "/js/coupon_telcom.285d2189.js"
  },
  {
    "revision": "7038396d09f71fff5727",
    "url": "/css/coupon_wrapper.ab43c2ce.css"
  },
  {
    "revision": "7038396d09f71fff5727",
    "url": "/js/coupon_wrapper.d9947991.js"
  },
  {
    "revision": "8e63e7c7fc3689947e16",
    "url": "/css/currencyConversion.96200d28.css"
  },
  {
    "revision": "8e63e7c7fc3689947e16",
    "url": "/js/currencyConversion.9d4f1e16.js"
  },
  {
    "revision": "982b858b22a7a120b05c",
    "url": "/css/eqReplaceMent.e80a9416.css"
  },
  {
    "revision": "982b858b22a7a120b05c",
    "url": "/js/eqReplaceMent.6b995146.js"
  },
  {
    "revision": "046d4bd90f40aa4b8ad5",
    "url": "/css/eqReplaceMent~recharge.8d01bd55.css"
  },
  {
    "revision": "046d4bd90f40aa4b8ad5",
    "url": "/js/eqReplaceMent~recharge.140f1cf6.js"
  },
  {
    "revision": "209cfb0cfe697ecc50cd",
    "url": "/css/esim_plan_list.d53f8d51.css"
  },
  {
    "revision": "209cfb0cfe697ecc50cd",
    "url": "/js/esim_plan_list.15794ef7.js"
  },
  {
    "revision": "4b77b7c89e6ace80b5ac",
    "url": "/css/esim_usage.cccb02b2.css"
  },
  {
    "revision": "4b77b7c89e6ace80b5ac",
    "url": "/js/esim_usage.0226290c.js"
  },
  {
    "revision": "003aee1eb6da0732de1b",
    "url": "/css/find_plan.87b02ca7.css"
  },
  {
    "revision": "003aee1eb6da0732de1b",
    "url": "/js/find_plan.0e9eb901.js"
  },
  {
    "revision": "498c2fa4b3d252c710a3",
    "url": "/css/logical_page.412cdcf5.css"
  },
  {
    "revision": "498c2fa4b3d252c710a3",
    "url": "/js/logical_page.13d56120.js"
  },
  {
    "revision": "f2b5798ed72481494e57",
    "url": "/css/login.db6eac3f.css"
  },
  {
    "revision": "f2b5798ed72481494e57",
    "url": "/js/login.312fc030.js"
  },
  {
    "revision": "6eb35db5c8070bad4b54",
    "url": "/css/lookup.a84a91e8.css"
  },
  {
    "revision": "6eb35db5c8070bad4b54",
    "url": "/js/lookup.c564a84e.js"
  },
  {
    "revision": "1a497855f405c1fa5179",
    "url": "/css/mifi_binding.24b68c5f.css"
  },
  {
    "revision": "1a497855f405c1fa5179",
    "url": "/js/mifi_binding.44195786.js"
  },
  {
    "revision": "02177b15f020cef898de",
    "url": "/css/mifi_card_info.51068e21.css"
  },
  {
    "revision": "02177b15f020cef898de",
    "url": "/js/mifi_card_info.bf128a58.js"
  },
  {
    "revision": "e00acda9e6d7958299c4",
    "url": "/css/mifi_card_lookup.81c4d85c.css"
  },
  {
    "revision": "e00acda9e6d7958299c4",
    "url": "/js/mifi_card_lookup.c70c818a.js"
  },
  {
    "revision": "ee876501682c4a2ec35a",
    "url": "/css/mifi_card_wrapper.d572d9dd.css"
  },
  {
    "revision": "ee876501682c4a2ec35a",
    "url": "/js/mifi_card_wrapper.a3e5eb15.js"
  },
  {
    "revision": "83ea62a2e789a1f0ec2f",
    "url": "/css/mifi_change_network.14a1a192.css"
  },
  {
    "revision": "83ea62a2e789a1f0ec2f",
    "url": "/js/mifi_change_network.46b3a6e4.js"
  },
  {
    "revision": "d1d05371a44a6a5a75e6",
    "url": "/css/mifi_change_network_explanation.70e4946d.css"
  },
  {
    "revision": "d1d05371a44a6a5a75e6",
    "url": "/js/mifi_change_network_explanation.d9bb3866.js"
  },
  {
    "revision": "06ce7ab2e30f0766af36",
    "url": "/css/mifi_coupon_index.6dcb0715.css"
  },
  {
    "revision": "06ce7ab2e30f0766af36",
    "url": "/js/mifi_coupon_index.36dd9ab2.js"
  },
  {
    "revision": "a815840aacaed64d1b3b",
    "url": "/css/mifi_coupon_wrapper.85e2e6da.css"
  },
  {
    "revision": "a815840aacaed64d1b3b",
    "url": "/js/mifi_coupon_wrapper.1dcde4f8.js"
  },
  {
    "revision": "a769e1f7f99f5598e936",
    "url": "/css/mifi_index.ba5c3ed6.css"
  },
  {
    "revision": "a769e1f7f99f5598e936",
    "url": "/js/mifi_index.18443ecc.js"
  },
  {
    "revision": "8e22876008ea505fcb41",
    "url": "/css/mifi_layout.f1be9149.css"
  },
  {
    "revision": "8e22876008ea505fcb41",
    "url": "/js/mifi_layout.ab476d0e.js"
  },
  {
    "revision": "9c129a5bd88dd5055dc6",
    "url": "/css/mifi_order.8445b84a.css"
  },
  {
    "revision": "9c129a5bd88dd5055dc6",
    "url": "/js/mifi_order.6d015d2c.js"
  },
  {
    "revision": "e96276206e48270d0f1b",
    "url": "/css/mifi_order_wrapper.c537a243.css"
  },
  {
    "revision": "e96276206e48270d0f1b",
    "url": "/js/mifi_order_wrapper.45f1229c.js"
  },
  {
    "revision": "08e236ad8825c9416d22",
    "url": "/css/mifi_plan_group.7ab311df.css"
  },
  {
    "revision": "08e236ad8825c9416d22",
    "url": "/js/mifi_plan_group.d0df6a1d.js"
  },
  {
    "revision": "4597a66ab03dce0d2f74",
    "url": "/css/mifi_plan_list.59b75359.css"
  },
  {
    "revision": "4597a66ab03dce0d2f74",
    "url": "/js/mifi_plan_list.0de93daf.js"
  },
  {
    "revision": "2dd7714d13dbe433f535",
    "url": "/css/mifi_plan_usage.9c76e5a2.css"
  },
  {
    "revision": "2dd7714d13dbe433f535",
    "url": "/js/mifi_plan_usage.ed892c15.js"
  },
  {
    "revision": "4611a7071a5347669966",
    "url": "/css/mifi_plan_wrapper.8b393e56.css"
  },
  {
    "revision": "4611a7071a5347669966",
    "url": "/js/mifi_plan_wrapper.1355dd31.js"
  },
  {
    "revision": "2904cc856e9d9c7f0ad0",
    "url": "/css/new_card_wrapper.06a280b2.css"
  },
  {
    "revision": "2904cc856e9d9c7f0ad0",
    "url": "/js/new_card_wrapper.d31483c4.js"
  },
  {
    "revision": "e760b67163478e16da92",
    "url": "/css/orderRecord.a19581a5.css"
  },
  {
    "revision": "e760b67163478e16da92",
    "url": "/js/orderRecord.d5cef6ab.js"
  },
  {
    "revision": "ba84770a6470b6192877",
    "url": "/css/plan_list.c6b094bb.css"
  },
  {
    "revision": "ba84770a6470b6192877",
    "url": "/js/plan_list.bf63a65d.js"
  },
  {
    "revision": "3131717c13ec90c5f0ee",
    "url": "/css/question.acd749ec.css"
  },
  {
    "revision": "3131717c13ec90c5f0ee",
    "url": "/js/question.5707afb9.js"
  },
  {
    "revision": "ce60d24fa749a307f15c",
    "url": "/css/question_wrapper.8ab9a0db.css"
  },
  {
    "revision": "ce60d24fa749a307f15c",
    "url": "/js/question_wrapper.133d9ef0.js"
  },
  {
    "revision": "f1b54ea5ce25447fde80",
    "url": "/css/realNameCourse.6bd3a228.css"
  },
  {
    "revision": "f1b54ea5ce25447fde80",
    "url": "/js/realNameCourse.6c4bd1dc.js"
  },
  {
    "revision": "f743f58e786f6d2865c8",
    "url": "/css/real_name.2fd595b9.css"
  },
  {
    "revision": "f743f58e786f6d2865c8",
    "url": "/js/real_name.3a6f8a11.js"
  },
  {
    "revision": "c21d253f3aa0832b74f1",
    "url": "/css/recharge.32ae6af0.css"
  },
  {
    "revision": "c21d253f3aa0832b74f1",
    "url": "/js/recharge.e29a7dfa.js"
  },
  {
    "revision": "54f78c41a7341def425e",
    "url": "/css/rechargeOrder.ec4bfd8c.css"
  },
  {
    "revision": "54f78c41a7341def425e",
    "url": "/js/rechargeOrder.589450da.js"
  },
  {
    "revision": "5b2f21c9aafaab4cea32",
    "url": "/css/recharge_balance.af09dcc4.css"
  },
  {
    "revision": "5b2f21c9aafaab4cea32",
    "url": "/js/recharge_balance.48355168.js"
  },
  {
    "revision": "23fbd5de25c56b9bfb19",
    "url": "/css/recharge_callback.c33c36e5.css"
  },
  {
    "revision": "23fbd5de25c56b9bfb19",
    "url": "/js/recharge_callback.df8958f9.js"
  },
  {
    "revision": "90e9338c3deb5fd373b6",
    "url": "/css/recharge_wrapper.e8ef40fd.css"
  },
  {
    "revision": "3c6156336002281fa031",
    "url": "/js/Layout.4551dd29.js"
  },
  {
    "revision": "486c88a173afee991629",
    "url": "/js/Layout~card_usage.399408d8.js"
  },
  {
    "revision": "da1be45fd64832fc2913",
    "url": "/js/refundRules.f0f22a4d.js"
  },
  {
    "revision": "0826d0b6f69806ad3701",
    "url": "/css/refund_applying.f98e4d4f.css"
  },
  {
    "revision": "0826d0b6f69806ad3701",
    "url": "/js/refund_applying.22e0fe2f.js"
  },
  {
    "revision": "365b36d42032e92298c0",
    "url": "/css/refund_argument.134128d7.css"
  },
  {
    "revision": "365b36d42032e92298c0",
    "url": "/js/refund_argument.e3cb2f52.js"
  },
  {
    "revision": "002870900b929108cd8e",
    "url": "/css/refund_plan.7e3acd80.css"
  },
  {
    "revision": "002870900b929108cd8e",
    "url": "/js/refund_plan.2595cee9.js"
  },
  {
    "revision": "19884767f8436f6be3e9",
    "url": "/css/refund_wrapper.f2324655.css"
  },
  {
    "revision": "19884767f8436f6be3e9",
    "url": "/js/refund_wrapper.c1c2bda7.js"
  },
  {
    "revision": "f5344885964a3bbef922",
    "url": "/css/repeatRecharge.badbf23a.css"
  },
  {
    "revision": "f5344885964a3bbef922",
    "url": "/js/repeatRecharge.8da05a0c.js"
  },
  {
    "revision": "f81d01bb26517a9c0ff3",
    "url": "/css/revoke_plan.d3d20fa5.css"
  },
  {
    "revision": "f81d01bb26517a9c0ff3",
    "url": "/js/revoke_plan.846088f6.js"
  },
  {
    "revision": "bcf74f54812c44ceb589",
    "url": "/css/speedup_500.653f81f5.css"
  },
  {
    "revision": "bcf74f54812c44ceb589",
    "url": "/js/speedup_500.4da17a9a.js"
  },
  {
    "revision": "f74127cbced6976197cc",
    "url": "/css/speedup_80.0b0c3ab6.css"
  },
  {
    "revision": "f74127cbced6976197cc",
    "url": "/js/speedup_80.0a8993b6.js"
  },
  {
    "revision": "c4b5be14c484e98e12e1",
    "url": "/css/speedup_wrapper.707898e1.css"
  },
  {
    "revision": "c4b5be14c484e98e12e1",
    "url": "/js/speedup_wrapper.b4674906.js"
  },
  {
    "revision": "6aa956322965b3891f4d",
    "url": "/css/to_tb.03eb33ae.css"
  },
  {
    "revision": "6aa956322965b3891f4d",
    "url": "/js/to_tb.2e36301a.js"
  },
  {
    "revision": "babf488b295c25e454db",
    "url": "/css/transfer_url.f90dd7e3.css"
  },
  {
    "revision": "babf488b295c25e454db",
    "url": "/js/transfer_url.29f578ea.js"
  },
  {
    "revision": "de6bac5edf57046c66c7",
    "url": "/css/userCenter.40a62a6e.css"
  },
  {
    "revision": "de6bac5edf57046c66c7",
    "url": "/js/userCenter.2bf50c02.js"
  },
  {
    "revision": "58e8f76be9099cc3b629",
    "url": "/css/userCenterWrap.38541705.css"
  },
  {
    "revision": "58e8f76be9099cc3b629",
    "url": "/js/userCenterWrap.b1c6e958.js"
  },
  {
    "revision": "e4b411644706c29765eea3ffdd85ae39",
    "url": "/fonts/SourceHanSansCNRegular.e4b41164.woff"
  },
  {
    "revision": "834b022ab9ab0e6063904af32274e777",
    "url": "/fonts/SourceHanSansCNRegular.834b022a.eot"
  },
  {
    "revision": "f9509c5a10be7daaf1fa01922a7c6bc2",
    "url": "/fonts/SourceHanSansCNRegular.f9509c5a.ttf"
  },
  {
    "revision": "da0808e9fe85be160aab69c82dd8de1c",
    "url": "/img/SourceHanSansCNRegular.da0808e9.svg"
  },
  {
    "revision": "732389ded34cb9c52dd88271f1345af9",
    "url": "/fonts/element-icons.732389de.ttf"
  },
  {
    "revision": "535877f50039c0cb49a6196a5b7517cd",
    "url": "/fonts/element-icons.535877f5.woff"
  },
  {
    "revision": "6e5cee7393060b0ec3dcd587c2518b94",
    "url": "/img/bg_test.6e5cee73.png"
  },
  {
    "revision": "d0ccbc8a35180bb40e027b44dd26035a",
    "url": "/img/youku.d0ccbc8a.png"
  },
  {
    "revision": "42c0fbd4915870e5e60452fd0ef2cbec",
    "url": "/img/orderTopBg@3x.42c0fbd4.png"
  },
  {
    "revision": "42c0fbd4915870e5e60452fd0ef2cbec",
    "url": "/img/orderTopBg@2x.42c0fbd4.png"
  },
  {
    "revision": "fff5af4325410621aeec4e60b3b92d9b",
    "url": "/img/mifi_binding_bg@3x.fff5af43.png"
  },
  {
    "revision": "fff5af4325410621aeec4e60b3b92d9b",
    "url": "/img/mifi_binding_bg@2x.fff5af43.png"
  },
  {
    "revision": "b899232b79ad9962c5ab5572775a0400",
    "url": "/img/card_index_bg@3x.b899232b.png"
  },
  {
    "revision": "b899232b79ad9962c5ab5572775a0400",
    "url": "/img/card_index_bg@2x.b899232b.png"
  },
  {
    "revision": "2c51a1e53c1ea0b35086d8d7261b4933",
    "url": "/img/bg_network@3x.2c51a1e5.png"
  },
  {
    "revision": "32d70c8fc305e3647098f3de0c71b618",
    "url": "/img/bg_network@2x.32d70c8f.png"
  },
  {
    "revision": "f5f322478286641bd9887a155e35f222",
    "url": "/img/btn.f5f32247.png"
  },
  {
    "revision": "d140650fa64e0f1fc771610dba62aed7",
    "url": "/img/bg.d140650f.png"
  },
  {
    "revision": "e625229e32d9deeb5f2909c314d8e609",
    "url": "/img/ios@2x.e625229e.png"
  },
  {
    "revision": "af8bbdfa0a90c4eed4563f8c06ce5ff8",
    "url": "/img/android@2x.af8bbdfa.png"
  },
  {
    "revision": "4ecd943eb3a2c5c0890145b943c1c659",
    "url": "/img/85.4ecd943e.png"
  },
  {
    "revision": "1d7515ee61c3f659227318b4050955ed",
    "url": "/img/mobile_sim@2x.1d7515ee.png"
  },
  {
    "revision": "0f980b79d9a52702004de9f652a68835",
    "url": "/img/telcom_sim@2x.0f980b79.png"
  },
  {
    "revision": "98141226a7e992e3072a280746a259c4",
    "url": "/img/mobile_sim@3x.98141226.png"
  },
  {
    "revision": "0c88168b284b92c37f3a873f26a97d69",
    "url": "/img/bg.0c88168b.jpg"
  },
  {
    "revision": "9e02095f31a07b972244f1c714c1dfe7",
    "url": "/img/telcom_sim@3x.9e02095f.png"
  },
  {
    "revision": "3f342771b9b81ab929e0fbcbcd0e6533",
    "url": "/img/bg-check-wrap@3x.3f342771.png"
  },
  {
    "revision": "9713b21819c4019befecd095069977df",
    "url": "/img/bg-check-wrap@2x.9713b218.png"
  },
  {
    "revision": "fa855242805b87da42c65763acd64ac0",
    "url": "/img/bg-plan-type@2x.fa855242.png"
  },
  {
    "revision": "4a9ca192485effa8b8f4b5b2df5b9caf",
    "url": "/img/bg-plan-type@3x.4a9ca192.png"
  },
  {
    "revision": "b70eddccd257b21777e71bb64c83b876",
    "url": "/img/bg.b70eddcc.jpeg"
  },
  {
    "revision": "909816c3d34e63a9ad86b8c179ab543c",
    "url": "/img/bar.909816c3.png"
  },
  {
    "revision": "e92f547ba0209da3b4342fa2b56ea9ae",
    "url": "/img/animater.e92f547b.png"
  },
  {
    "revision": "114a6e12b42b9b48586dd341105188fe",
    "url": "/img/usedOrder@2x.114a6e12.png"
  },
  {
    "revision": "c0170ec299b2418256fd515ee7849055",
    "url": "/img/unUsedOrder@2x.c0170ec2.png"
  },
  {
    "revision": "d9e14058d30dd312519fcf2de38d742b",
    "url": "/img/unUsedOrder@3x.d9e14058.png"
  },
  {
    "revision": "4a5b90f8076955f289b3dcda6a5af6ff",
    "url": "/img/invaildedOrder@3x.4a5b90f8.png"
  },
  {
    "revision": "0d5a5158e67bcb7a4604124715ed6fbf",
    "url": "/img/usedOrder@3x.0d5a5158.png"
  },
  {
    "revision": "be0f1e33b2553e71b117d3d3f838d32f",
    "url": "/img/invaildedOrder@2x.be0f1e33.png"
  },
  {
    "revision": "3d0fc424b703032ca595090e99f8354b",
    "url": "/img/login_bg@2x.3d0fc424.png"
  },
  {
    "revision": "11000d4e510a6df565eb69ba6f2c1dfc",
    "url": "/img/login_bg@3x.11000d4e.png"
  },
  {
    "revision": "0f16389ec218c90cf8f657e233b745f2",
    "url": "/img/balanceBg1.0f16389e.png"
  },
  {
    "revision": "565459ef2ee8b71db421144ad21c23e3",
    "url": "/img/balanceBg2.565459ef.png"
  },
  {
    "revision": "91e1d2771efacd45e5e465d9a001f197",
    "url": "/img/liantong.91e1d277.png"
  },
  {
    "revision": "4a0cab0f33beb48ea985714d1b91fef7",
    "url": "/img/dianxin.4a0cab0f.png"
  },
  {
    "revision": "657033323334e91efb0011bbc18f8c04",
    "url": "/img/yidong.65703332.png"
  },
  {
    "revision": "8da3b83b73e44e54d6be4b2522bcb1f2",
    "url": "/img/pkgBg2.8da3b83b.png"
  },
  {
    "revision": "d3b42651f9f5048baeffb50c800913ec",
    "url": "/img/pkgBg1.d3b42651.png"
  },
  {
    "revision": "d461d18e42a310bd709b2ce97d159153",
    "url": "/img/pkgBg3.d461d18e.png"
  },
  {
    "revision": "01355f175bd20423ce45a838c1a998a9",
    "url": "/img/bg.01355f17.png"
  },
  {
    "revision": "014d354b9b25b67ae95857ba17e2f4cc",
    "url": "/img/activityPage.014d354b.png"
  },
  {
    "revision": "2a67b73145562669220aa4639e1ad58f",
    "url": "/img/icon3.2a67b731.png"
  },
  {
    "revision": "813b5319e378dafdda952c16ad89906b",
    "url": "/img/icon2.813b5319.png"
  },
  {
    "revision": "f40c7e0b20fe25eb78a7658c3ae56312",
    "url": "/img/noData@3x.f40c7e0b.png"
  },
  {
    "revision": "644e6e3cf5f33943747b116316694e28",
    "url": "/img/noData@2x.644e6e3c.png"
  },
  {
    "revision": "6dedd4943e4c5848638196fb6f0c4145",
    "url": "/img/bg.6dedd494.png"
  },
  {
    "revision": "0078f03c08066d51d64b92a13e194ebb",
    "url": "/img/balanceRefund.0078f03c.png"
  },
  {
    "revision": "af3ed0b3236bbfdbc3ad61b8d41c3dec",
    "url": "/img/changeBg.af3ed0b3.png"
  },
  {
    "revision": "a859e9ca4606d567c42b9c7bcd4fdce9",
    "url": "/img/iccid_bg@2x.a859e9ca.png"
  },
  {
    "revision": "fa9050c4e9870e8fc0cd184f8515af4a",
    "url": "/img/iccid_bg@3x.fa9050c4.png"
  },
  {
    "revision": "3603a35a49dbb8ad94ec1e57c4dad229",
    "url": "/img/scanTop2.3603a35a.png"
  },
  {
    "revision": "05775dd69c53d7273b27aaa7c6c523f7",
    "url": "/img/04.05775dd6.png"
  },
  {
    "revision": "541375e6bb7db2fba9e415be8045f5fb",
    "url": "/img/1.541375e6.png"
  },
  {
    "revision": "7c28431d304fa4f58f5070c59720683a",
    "url": "/img/2.7c28431d.png"
  },
  {
    "revision": "5a3428653945c17e1c146efeee81c987",
    "url": "/img/scanTop.5a342865.png"
  },
  {
    "revision": "824594523c01e48028f2b7eb4261134d",
    "url": "/img/unicom-logo.82459452.svg"
  },
  {
    "revision": "113f99e2189c2ca49db2168754fc2eb5",
    "url": "/img/mobile-logo.113f99e2.png"
  },
  {
    "revision": "0cba868fa977e09806638b9000636a36",
    "url": "/img/avatar.0cba868f.jpeg"
  },
  {
    "revision": "27158aa79eb0d4b89f317d076a801ca3",
    "url": "/img/coupon-log.27158aa7.png"
  },
  {
    "revision": "55d3f2f09efe17db6485d4c9f8f0c3b1",
    "url": "/img/icon-recharge_20181001.55d3f2f0.svg"
  },
  {
    "revision": "165beb68d8ba0d2b70df0fbb3769787a",
    "url": "/img/03.165beb68.png"
  },
  {
    "revision": "5f1f34037094c0613bccafa2ddd8cb3b",
    "url": "/img/telecom-logo.5f1f3403.svg"
  },
  {
    "revision": "0b3c3297decbd1152a314cce115f9632",
    "url": "/img/09.0b3c3297.png"
  },
  {
    "revision": "3e217df4202e41ad9b030aafc8cfcc24",
    "url": "/img/4.3e217df4.png"
  },
  {
    "revision": "aecc9531f2c3b1fd45338e7bf5084384",
    "url": "/img/bg_no_recharge.aecc9531.svg"
  },
  {
    "revision": "b0ffa4a0fd195a110ee4d4dabce3bc32",
    "url": "/img/08.b0ffa4a0.png"
  },
  {
    "revision": "96fab583abd57f2e7118324858fa3080",
    "url": "/img/05.96fab583.png"
  },
  {
    "revision": "9e8ecc7f7b760b55c56bddfab886da10",
    "url": "/img/3.9e8ecc7f.png"
  },
  {
    "revision": "275be51ae57c486bce58257febd6589f",
    "url": "/img/bg_no_plan.275be51a.svg"
  },
  {
    "revision": "a8272d2d742d9d50257e23dfac577def",
    "url": "/img/01.a8272d2d.png"
  },
  {
    "revision": "daa86b540bb9c2a6453ceac9bed77961",
    "url": "/img/07.daa86b54.png"
  },
  {
    "revision": "06385746a7cedb492d5539907631561c",
    "url": "/img/tip.06385746.png"
  },
  {
    "revision": "eacba58f9acf2b87cd801858146b2ba9",
    "url": "/img/02.eacba58f.png"
  },
  {
    "revision": "39d9e849fc1c724525f166646932a24d",
    "url": "/img/safari.39d9e849.png"
  },
  {
    "revision": "999589aae784a460b5e7c6ae9bbaa3d8",
    "url": "/img/06.999589aa.png"
  },
  {
    "revision": "019a8ddeddae83f38dabc543cb6a50d8",
    "url": "/index.html"
  },
  {
    "revision": "3c6156336002281fa031",
    "url": "/css/Layout.cb7ba494.css"
  },
  {
    "revision": "9ce16f441b39b493af8b96d7e97cce22",
    "url": "/MP_verify_dkzAKjxyVyJvsHMS.txt"
  },
  {
    "revision": "86c422d8c98b247235d04b49fb1c4b05",
    "url": "/MP_verify_bKSdn2qZlUSULliu.txt"
  },
  {
    "revision": "652317b098ca24e4511926c7fd57cbbe",
    "url": "/MP_verify_8JoCCldW78DygS5c.txt"
  },
  {
    "revision": "00bbf6b458bf7ea6bd01f443eb3045d9",
    "url": "/MP_verify_4r3DVk3KUjgWsQsG.txt"
  }
];