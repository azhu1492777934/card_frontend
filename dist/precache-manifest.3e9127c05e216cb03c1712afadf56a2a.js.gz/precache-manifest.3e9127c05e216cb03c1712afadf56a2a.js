self.__precacheManifest = [
  {
    "revision": "c19b6853ffb4fa04d88c",
    "url": "/js/recharge_callback.e12e362d.js"
  },
  {
    "revision": "b6216d61c03e6ce0c9aea6ca7808f7ca",
    "url": "/robots.txt"
  },
  {
    "revision": "c4bbcb8abe74049726f0",
    "url": "/css/recharge_wrapper.a4c7e1f3.css"
  },
  {
    "revision": "1c89bce346dc8c535a3d",
    "url": "/css/_404.b6476c76.css"
  },
  {
    "revision": "9f5a6707d2b8d55e343a",
    "url": "/css/app.9acfb0a8.css"
  },
  {
    "revision": "9f5a6707d2b8d55e343a",
    "url": "/js/app.4380ed7b.js"
  },
  {
    "revision": "3a6289523f00ec82f640",
    "url": "/css/authority_middle.e6f03762.css"
  },
  {
    "revision": "3a6289523f00ec82f640",
    "url": "/js/authority_middle.b2c1d893.js"
  },
  {
    "revision": "9e05cebe0001862ab2e3",
    "url": "/css/card_check.1fc58509.css"
  },
  {
    "revision": "9e05cebe0001862ab2e3",
    "url": "/js/card_check.1a6b01cf.js"
  },
  {
    "revision": "0644e44d0896dc447382",
    "url": "/css/card_connection.011f509b.css"
  },
  {
    "revision": "0644e44d0896dc447382",
    "url": "/js/card_connection.15488da6.js"
  },
  {
    "revision": "dad9520b3a35beb9a532",
    "url": "/css/card_lookup.54a49771.css"
  },
  {
    "revision": "dad9520b3a35beb9a532",
    "url": "/js/card_lookup.f6b6e4cb.js"
  },
  {
    "revision": "77dbd1da5a0cd8bc67c3",
    "url": "/css/card_usage.5ce8e886.css"
  },
  {
    "revision": "77dbd1da5a0cd8bc67c3",
    "url": "/js/card_usage.90ed6690.js"
  },
  {
    "revision": "272e6b3875c5e6a0bab4",
    "url": "/css/card_usage~plan_list.092deafd.css"
  },
  {
    "revision": "272e6b3875c5e6a0bab4",
    "url": "/js/card_usage~plan_list.1ce848e9.js"
  },
  {
    "revision": "88ca9606a67f0a99116f",
    "url": "/css/card_wrapper.acf02c15.css"
  },
  {
    "revision": "88ca9606a67f0a99116f",
    "url": "/js/card_wrapper.dfbb3b9b.js"
  },
  {
    "revision": "1ba354fe0b81530f52be",
    "url": "/css/children_card.d5aac1fd.css"
  },
  {
    "revision": "1ba354fe0b81530f52be",
    "url": "/js/children_card.643fe64e.js"
  },
  {
    "revision": "c85e6197a085ba6a626b",
    "url": "/css/chunk-5ddcf211.2b221153.css"
  },
  {
    "revision": "c85e6197a085ba6a626b",
    "url": "/js/chunk-5ddcf211.dcbd8315.js"
  },
  {
    "revision": "b7ba899ae0fea6a1f82b",
    "url": "/css/chunk-7fb98680.47a09aae.css"
  },
  {
    "revision": "b7ba899ae0fea6a1f82b",
    "url": "/js/chunk-7fb98680.b3865b19.js"
  },
  {
    "revision": "a4a0ec33228c057e84f6",
    "url": "/css/chunk-vendors.0a14d1e9.css"
  },
  {
    "revision": "a4a0ec33228c057e84f6",
    "url": "/js/chunk-vendors.3c345b30.js"
  },
  {
    "revision": "e8d9cb671422b931d270",
    "url": "/css/coupon_normal.a455d940.css"
  },
  {
    "revision": "e8d9cb671422b931d270",
    "url": "/js/coupon_normal.9eedfaf4.js"
  },
  {
    "revision": "b32b6f62d9df48317ac6",
    "url": "/css/coupon_telcom.210cc699.css"
  },
  {
    "revision": "b32b6f62d9df48317ac6",
    "url": "/js/coupon_telcom.8179bea2.js"
  },
  {
    "revision": "f2176c70a250a69b56b2",
    "url": "/css/coupon_wrapper.9b92bcd2.css"
  },
  {
    "revision": "f2176c70a250a69b56b2",
    "url": "/js/coupon_wrapper.e1719114.js"
  },
  {
    "revision": "6e22ad17a5677b8d6079",
    "url": "/css/find_plan.5c549760.css"
  },
  {
    "revision": "6e22ad17a5677b8d6079",
    "url": "/js/find_plan.f9d55907.js"
  },
  {
    "revision": "51f89fbc53f205459f03",
    "url": "/css/login.6509ca6e.css"
  },
  {
    "revision": "51f89fbc53f205459f03",
    "url": "/js/login.626e212e.js"
  },
  {
    "revision": "3e0c0aeb2500b3b124f1",
    "url": "/css/lookup.c8cec05f.css"
  },
  {
    "revision": "3e0c0aeb2500b3b124f1",
    "url": "/js/lookup.6c6778be.js"
  },
  {
    "revision": "331bfb15d5cdb5561b70",
    "url": "/css/new_card_wrapper.63acae48.css"
  },
  {
    "revision": "331bfb15d5cdb5561b70",
    "url": "/js/new_card_wrapper.bed1437c.js"
  },
  {
    "revision": "1df1b671eae7608d307c",
    "url": "/css/plan_list.9224feee.css"
  },
  {
    "revision": "1df1b671eae7608d307c",
    "url": "/js/plan_list.e24fd4e8.js"
  },
  {
    "revision": "cd00d51d4ab331674edb",
    "url": "/css/question.4a3349ab.css"
  },
  {
    "revision": "cd00d51d4ab331674edb",
    "url": "/js/question.351323ed.js"
  },
  {
    "revision": "ca6583c241fda8461d44",
    "url": "/css/question_wrapper.707898e1.css"
  },
  {
    "revision": "ca6583c241fda8461d44",
    "url": "/js/question_wrapper.31972217.js"
  },
  {
    "revision": "747483ed29cf8d797518",
    "url": "/css/real_name.84a42d52.css"
  },
  {
    "revision": "747483ed29cf8d797518",
    "url": "/js/real_name.f34f166d.js"
  },
  {
    "revision": "b63ba443857945918a8c",
    "url": "/css/recharge.a1d95c84.css"
  },
  {
    "revision": "b63ba443857945918a8c",
    "url": "/js/recharge.32a90ecb.js"
  },
  {
    "revision": "c19b6853ffb4fa04d88c",
    "url": "/css/recharge_callback.aaf38d88.css"
  },
  {
    "revision": "fe9b05bd92123230c4e5",
    "url": "/js/Layout.3602c395.js"
  },
  {
    "revision": "1c89bce346dc8c535a3d",
    "url": "/js/_404.f6b46c0f.js"
  },
  {
    "revision": "c4bbcb8abe74049726f0",
    "url": "/js/recharge_wrapper.0f417de1.js"
  },
  {
    "revision": "a70dc1a97ee1725c514f",
    "url": "/css/refund_applying.bef9c933.css"
  },
  {
    "revision": "a70dc1a97ee1725c514f",
    "url": "/js/refund_applying.316f6732.js"
  },
  {
    "revision": "b15aced6e7f26596230a",
    "url": "/css/refund_argument.e9479511.css"
  },
  {
    "revision": "b15aced6e7f26596230a",
    "url": "/js/refund_argument.1ac2be3a.js"
  },
  {
    "revision": "23ff8265f91b54d5abb9",
    "url": "/css/refund_plan.a72f3270.css"
  },
  {
    "revision": "23ff8265f91b54d5abb9",
    "url": "/js/refund_plan.3a8376f9.js"
  },
  {
    "revision": "5995edcbe1c17b5a7d85",
    "url": "/css/refund_wrapper.6e1b567f.css"
  },
  {
    "revision": "5995edcbe1c17b5a7d85",
    "url": "/js/refund_wrapper.6ba3f456.js"
  },
  {
    "revision": "925e8514b52981f6f2a5",
    "url": "/css/revoke_plan.00366d72.css"
  },
  {
    "revision": "925e8514b52981f6f2a5",
    "url": "/js/revoke_plan.fca5d23a.js"
  },
  {
    "revision": "bb3e08845163c99c40e8",
    "url": "/css/speedup_500.3fae4bd5.css"
  },
  {
    "revision": "bb3e08845163c99c40e8",
    "url": "/js/speedup_500.f871dab4.js"
  },
  {
    "revision": "b4258578490745a20dd7",
    "url": "/css/speedup_80.5a1c30a7.css"
  },
  {
    "revision": "b4258578490745a20dd7",
    "url": "/js/speedup_80.1cdfc53a.js"
  },
  {
    "revision": "d18b8fdc98bdfb36ce7b",
    "url": "/css/speedup_wrapper.23e7f2d1.css"
  },
  {
    "revision": "d18b8fdc98bdfb36ce7b",
    "url": "/js/speedup_wrapper.194089ca.js"
  },
  {
    "revision": "545eefefad341fa57398",
    "url": "/css/to_tb.d02f17bb.css"
  },
  {
    "revision": "545eefefad341fa57398",
    "url": "/js/to_tb.045c44df.js"
  },
  {
    "revision": "e4b411644706c29765eea3ffdd85ae39",
    "url": "/fonts/SourceHanSansCNRegular.e4b41164.woff"
  },
  {
    "revision": "834b022ab9ab0e6063904af32274e777",
    "url": "/fonts/SourceHanSansCNRegular.834b022a.eot"
  },
  {
    "revision": "f9509c5a10be7daaf1fa01922a7c6bc2",
    "url": "/fonts/SourceHanSansCNRegular.f9509c5a.ttf"
  },
  {
    "revision": "da0808e9fe85be160aab69c82dd8de1c",
    "url": "/img/SourceHanSansCNRegular.da0808e9.svg"
  },
  {
    "revision": "f5f322478286641bd9887a155e35f222",
    "url": "/img/btn.f5f32247.png"
  },
  {
    "revision": "d140650fa64e0f1fc771610dba62aed7",
    "url": "/img/bg.d140650f.png"
  },
  {
    "revision": "3f342771b9b81ab929e0fbcbcd0e6533",
    "url": "/img/bg-check-wrap@3x.3f342771.png"
  },
  {
    "revision": "9713b21819c4019befecd095069977df",
    "url": "/img/bg-check-wrap@2x.9713b218.png"
  },
  {
    "revision": "3d0fc424b703032ca595090e99f8354b",
    "url": "/img/login_bg@2x.3d0fc424.png"
  },
  {
    "revision": "11000d4e510a6df565eb69ba6f2c1dfc",
    "url": "/img/login_bg@3x.11000d4e.png"
  },
  {
    "revision": "e625229e32d9deeb5f2909c314d8e609",
    "url": "/img/ios@2x.e625229e.png"
  },
  {
    "revision": "af8bbdfa0a90c4eed4563f8c06ce5ff8",
    "url": "/img/android@2x.af8bbdfa.png"
  },
  {
    "revision": "1d7515ee61c3f659227318b4050955ed",
    "url": "/img/mobile_sim@2x.1d7515ee.png"
  },
  {
    "revision": "0f980b79d9a52702004de9f652a68835",
    "url": "/img/telcom_sim@2x.0f980b79.png"
  },
  {
    "revision": "98141226a7e992e3072a280746a259c4",
    "url": "/img/mobile_sim@3x.98141226.png"
  },
  {
    "revision": "0c88168b284b92c37f3a873f26a97d69",
    "url": "/img/bg.0c88168b.jpg"
  },
  {
    "revision": "9e02095f31a07b972244f1c714c1dfe7",
    "url": "/img/telcom_sim@3x.9e02095f.png"
  },
  {
    "revision": "5a3428653945c17e1c146efeee81c987",
    "url": "/img/scanTop.5a342865.png"
  },
  {
    "revision": "824594523c01e48028f2b7eb4261134d",
    "url": "/img/unicom-logo.82459452.svg"
  },
  {
    "revision": "113f99e2189c2ca49db2168754fc2eb5",
    "url": "/img/mobile-logo.113f99e2.png"
  },
  {
    "revision": "27158aa79eb0d4b89f317d076a801ca3",
    "url": "/img/coupon-log.27158aa7.png"
  },
  {
    "revision": "55d3f2f09efe17db6485d4c9f8f0c3b1",
    "url": "/img/icon-recharge_20181001.55d3f2f0.svg"
  },
  {
    "revision": "5f1f34037094c0613bccafa2ddd8cb3b",
    "url": "/img/telecom-logo.5f1f3403.svg"
  },
  {
    "revision": "4bdbe7dbdb6587c886a8290593100145",
    "url": "/img/recharge_callback_20181126.4bdbe7db.jpg"
  },
  {
    "revision": "aecc9531f2c3b1fd45338e7bf5084384",
    "url": "/img/bg_no_recharge.aecc9531.svg"
  },
  {
    "revision": "275be51ae57c486bce58257febd6589f",
    "url": "/img/bg_no_plan.275be51a.svg"
  },
  {
    "revision": "39d9e849fc1c724525f166646932a24d",
    "url": "/img/safari.39d9e849.png"
  },
  {
    "revision": "94c38b4e41766bc3c73e60a94472854b",
    "url": "/index.html"
  },
  {
    "revision": "fe9b05bd92123230c4e5",
    "url": "/css/Layout.c59a8b7e.css"
  },
  {
    "revision": "86c422d8c98b247235d04b49fb1c4b05",
    "url": "/MP_verify_bKSdn2qZlUSULliu.txt"
  },
  {
    "revision": "652317b098ca24e4511926c7fd57cbbe",
    "url": "/MP_verify_8JoCCldW78DygS5c.txt"
  },
  {
    "revision": "00bbf6b458bf7ea6bd01f443eb3045d9",
    "url": "/MP_verify_4r3DVk3KUjgWsQsG.txt"
  }
];