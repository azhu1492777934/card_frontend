self.__precacheManifest = [
  {
    "revision": "c00e3035889eb7191341",
    "url": "/css/Layout.04cc742d.css"
  },
  {
    "revision": "c00e3035889eb7191341",
    "url": "/js/Layout.51732b91.js"
  },
  {
    "revision": "cb71e88bd43ec65f574f",
    "url": "/js/Layout~card_usage~eqReplaceMent~esim_plan_list~esim_usage~jdReplaceMent~mifi_order~mifi_plan_list~mi~504954e7.f06824d4.js"
  },
  {
    "revision": "2eaa2d184a8729843447",
    "url": "/css/Layout~card_usage~plan_list.b0e6d92a.css"
  },
  {
    "revision": "2eaa2d184a8729843447",
    "url": "/js/Layout~card_usage~plan_list.0aa5516a.js"
  },
  {
    "revision": "f69741f23577cabcc5d2",
    "url": "/css/Not_fund.7c7d6228.css"
  },
  {
    "revision": "f69741f23577cabcc5d2",
    "url": "/js/Not_fund.bed435a2.js"
  },
  {
    "revision": "35ba57f520d38e13022e",
    "url": "/css/app.097110e6.css"
  },
  {
    "revision": "35ba57f520d38e13022e",
    "url": "/js/app.1d173a75.js"
  },
  {
    "revision": "4961bdd7a00ee8d97cda",
    "url": "/css/authority_middle.99c68701.css"
  },
  {
    "revision": "4961bdd7a00ee8d97cda",
    "url": "/js/authority_middle.2638b52f.js"
  },
  {
    "revision": "96ff940592bd7d50402d",
    "url": "/css/balanceIndex.1d6f8eb5.css"
  },
  {
    "revision": "96ff940592bd7d50402d",
    "url": "/js/balanceIndex.db5fa8d7.js"
  },
  {
    "revision": "d73d75a29513800f05c6",
    "url": "/css/balanceRefund.ed91b145.css"
  },
  {
    "revision": "d73d75a29513800f05c6",
    "url": "/js/balanceRefund.e8b08888.js"
  },
  {
    "revision": "101d5abd47c7ffcfe1dc",
    "url": "/css/cardPackage.b6fefdf4.css"
  },
  {
    "revision": "101d5abd47c7ffcfe1dc",
    "url": "/js/cardPackage.832c6225.js"
  },
  {
    "revision": "da445fa17a5a7fcf9600",
    "url": "/css/card_check.956702f6.css"
  },
  {
    "revision": "da445fa17a5a7fcf9600",
    "url": "/js/card_check.4cabc130.js"
  },
  {
    "revision": "f6b5285903da59dd84f6",
    "url": "/css/card_connection.a1d7906f.css"
  },
  {
    "revision": "f6b5285903da59dd84f6",
    "url": "/js/card_connection.019fdfde.js"
  },
  {
    "revision": "42fc5163514d5ec27d2b",
    "url": "/css/card_invoice.95abeac4.css"
  },
  {
    "revision": "42fc5163514d5ec27d2b",
    "url": "/js/card_invoice.5bbba6b3.js"
  },
  {
    "revision": "f0c8873991d201ba4970",
    "url": "/css/card_invoice~customerFeedback~eqReplaceMent~jdReplaceMent~mifi_plan_group~recharge.7c820d35.css"
  },
  {
    "revision": "f0c8873991d201ba4970",
    "url": "/js/card_invoice~customerFeedback~eqReplaceMent~jdReplaceMent~mifi_plan_group~recharge.cf95c04e.js"
  },
  {
    "revision": "22fc74ec031d7cfae1fb",
    "url": "/js/card_invoice~eqReplaceMent~jdReplaceMent.4bedf392.js"
  },
  {
    "revision": "7170b3d6b49fa291b188",
    "url": "/css/card_lookup.007e51d1.css"
  },
  {
    "revision": "7170b3d6b49fa291b188",
    "url": "/js/card_lookup.3e9b06f2.js"
  },
  {
    "revision": "c0bc26864edcaf5a7217",
    "url": "/css/card_lookup_notice.f7774610.css"
  },
  {
    "revision": "c0bc26864edcaf5a7217",
    "url": "/js/card_lookup_notice.e45248f3.js"
  },
  {
    "revision": "0bedc31033ba4562d5d2",
    "url": "/css/card_lookup~card_lookup_notice.c536ca70.css"
  },
  {
    "revision": "0bedc31033ba4562d5d2",
    "url": "/js/card_lookup~card_lookup_notice.73428632.js"
  },
  {
    "revision": "2a3fdbffcce476c51bcb",
    "url": "/css/card_more_flow.93485b26.css"
  },
  {
    "revision": "2a3fdbffcce476c51bcb",
    "url": "/js/card_more_flow.56eceb2e.js"
  },
  {
    "revision": "928991c2849cfc2dc19e",
    "url": "/css/card_usage.8ec64569.css"
  },
  {
    "revision": "928991c2849cfc2dc19e",
    "url": "/js/card_usage.f23da810.js"
  },
  {
    "revision": "00658657d9e3c4bfb3e9",
    "url": "/css/card_wrapper.f711a980.css"
  },
  {
    "revision": "00658657d9e3c4bfb3e9",
    "url": "/js/card_wrapper.da64c1ac.js"
  },
  {
    "revision": "ed6e76e2649c567bb828",
    "url": "/css/children_card.ecf9abda.css"
  },
  {
    "revision": "ed6e76e2649c567bb828",
    "url": "/js/children_card.6acc95dc.js"
  },
  {
    "revision": "7cd6c9b787c231d754a7",
    "url": "/css/chunk-28be3d5a.17df8dc0.css"
  },
  {
    "revision": "7cd6c9b787c231d754a7",
    "url": "/js/chunk-28be3d5a.13f6639e.js"
  },
  {
    "revision": "03a1501abadb0482063d",
    "url": "/css/chunk-3527d1fe.63572b30.css"
  },
  {
    "revision": "03a1501abadb0482063d",
    "url": "/js/chunk-3527d1fe.b8ce16df.js"
  },
  {
    "revision": "2c7914532f8347f9c82a",
    "url": "/css/chunk-vendors.3bcdc4d8.css"
  },
  {
    "revision": "2c7914532f8347f9c82a",
    "url": "/js/chunk-vendors.9a72f089.js"
  },
  {
    "revision": "12d901afabe2b8ac7600",
    "url": "/css/commonProblem.ee24a20e.css"
  },
  {
    "revision": "12d901afabe2b8ac7600",
    "url": "/js/commonProblem.8041ce28.js"
  },
  {
    "revision": "c8dbd85edc4c622624a8",
    "url": "/css/commonQuestion.806725e2.css"
  },
  {
    "revision": "c8dbd85edc4c622624a8",
    "url": "/js/commonQuestion.4edd08d7.js"
  },
  {
    "revision": "144a53121d8a6a5fc73a",
    "url": "/css/consumerRecord.0cfcfa98.css"
  },
  {
    "revision": "144a53121d8a6a5fc73a",
    "url": "/js/consumerRecord.d1567a79.js"
  },
  {
    "revision": "150070122a3128fb782c",
    "url": "/css/coupon_normal.1637bd89.css"
  },
  {
    "revision": "150070122a3128fb782c",
    "url": "/js/coupon_normal.3a599496.js"
  },
  {
    "revision": "fd5c20680056b3e04e86",
    "url": "/css/coupon_telcom.46713ac9.css"
  },
  {
    "revision": "fd5c20680056b3e04e86",
    "url": "/js/coupon_telcom.e1d76ebd.js"
  },
  {
    "revision": "29aa974a0c0b87a2d937",
    "url": "/css/coupon_wrapper.4307116a.css"
  },
  {
    "revision": "29aa974a0c0b87a2d937",
    "url": "/js/coupon_wrapper.a0acaf6e.js"
  },
  {
    "revision": "dbc1f6a54c20b489923e",
    "url": "/css/currencyConversion.99225cfb.css"
  },
  {
    "revision": "dbc1f6a54c20b489923e",
    "url": "/js/currencyConversion.81ff4f4e.js"
  },
  {
    "revision": "218c0008053c2718cf61",
    "url": "/css/customerFeedback.a647bc31.css"
  },
  {
    "revision": "218c0008053c2718cf61",
    "url": "/js/customerFeedback.eea22c70.js"
  },
  {
    "revision": "8c2d77bda31a42fa6304",
    "url": "/css/eqReplaceMent.d006b855.css"
  },
  {
    "revision": "8c2d77bda31a42fa6304",
    "url": "/js/eqReplaceMent.b0a82bdc.js"
  },
  {
    "revision": "980d4319038c6a370cf3",
    "url": "/css/esim_plan_list.b69f520d.css"
  },
  {
    "revision": "980d4319038c6a370cf3",
    "url": "/js/esim_plan_list.42ff0951.js"
  },
  {
    "revision": "a1a4034494ee58a01566",
    "url": "/css/esim_usage.0820cde0.css"
  },
  {
    "revision": "a1a4034494ee58a01566",
    "url": "/js/esim_usage.31273fbd.js"
  },
  {
    "revision": "2e216446d39ee315fd1e",
    "url": "/css/find_plan.aa1e02a8.css"
  },
  {
    "revision": "2e216446d39ee315fd1e",
    "url": "/js/find_plan.aadc63de.js"
  },
  {
    "revision": "9a5638e203bda2de6010",
    "url": "/css/guardian.7e4313c3.css"
  },
  {
    "revision": "9a5638e203bda2de6010",
    "url": "/js/guardian.c577893c.js"
  },
  {
    "revision": "fc37c41262f7aec28d30",
    "url": "/css/jdReplaceMent.1386757d.css"
  },
  {
    "revision": "fc37c41262f7aec28d30",
    "url": "/js/jdReplaceMent.8d12a26f.js"
  },
  {
    "revision": "78a9ab5e135b265eaa35",
    "url": "/css/jdWrapper.0342873f.css"
  },
  {
    "revision": "78a9ab5e135b265eaa35",
    "url": "/js/jdWrapper.2bbaa6a7.js"
  },
  {
    "revision": "18ff7d66de083eac43b5",
    "url": "/css/logical_page.d5bfa128.css"
  },
  {
    "revision": "18ff7d66de083eac43b5",
    "url": "/js/logical_page.9e8a7d69.js"
  },
  {
    "revision": "d3d47177637669add74e",
    "url": "/css/login.af0dccb3.css"
  },
  {
    "revision": "d3d47177637669add74e",
    "url": "/js/login.535c1791.js"
  },
  {
    "revision": "9d03afecbb89760d5cdd",
    "url": "/css/lookup.01c41de4.css"
  },
  {
    "revision": "9d03afecbb89760d5cdd",
    "url": "/js/lookup.091b4d05.js"
  },
  {
    "revision": "08c79c43d0f65d4bdd3f",
    "url": "/css/mifi_binding.f8af5368.css"
  },
  {
    "revision": "08c79c43d0f65d4bdd3f",
    "url": "/js/mifi_binding.c428c81b.js"
  },
  {
    "revision": "9a6adf3b4c83f2bc0094",
    "url": "/css/mifi_card_info.8e779fd9.css"
  },
  {
    "revision": "9a6adf3b4c83f2bc0094",
    "url": "/js/mifi_card_info.a4ed41e3.js"
  },
  {
    "revision": "8ae171cf0d299714523a",
    "url": "/css/mifi_card_lookup.f5480fed.css"
  },
  {
    "revision": "8ae171cf0d299714523a",
    "url": "/js/mifi_card_lookup.5e90a378.js"
  },
  {
    "revision": "aa7148d7e74377b2a752",
    "url": "/css/mifi_card_wrapper.3db278e7.css"
  },
  {
    "revision": "aa7148d7e74377b2a752",
    "url": "/js/mifi_card_wrapper.f60eec0c.js"
  },
  {
    "revision": "e2abd226cb35b2c08258",
    "url": "/css/mifi_change_network.d707f97f.css"
  },
  {
    "revision": "e2abd226cb35b2c08258",
    "url": "/js/mifi_change_network.b8bc3e4f.js"
  },
  {
    "revision": "145b66675ee4235ec11a",
    "url": "/css/mifi_change_network_explanation.63fde815.css"
  },
  {
    "revision": "145b66675ee4235ec11a",
    "url": "/js/mifi_change_network_explanation.194c6c60.js"
  },
  {
    "revision": "3c727004f0798821412a",
    "url": "/css/mifi_coupon_index.2aea1628.css"
  },
  {
    "revision": "3c727004f0798821412a",
    "url": "/js/mifi_coupon_index.7960e362.js"
  },
  {
    "revision": "d2e089b76b8bcef76d1f",
    "url": "/css/mifi_coupon_wrapper.100ed2e1.css"
  },
  {
    "revision": "d2e089b76b8bcef76d1f",
    "url": "/js/mifi_coupon_wrapper.74e049ba.js"
  },
  {
    "revision": "c29bba926473323cf9f3",
    "url": "/css/mifi_index.37173ef0.css"
  },
  {
    "revision": "c29bba926473323cf9f3",
    "url": "/js/mifi_index.a2cfa904.js"
  },
  {
    "revision": "775f3e7e1ddaabe41c19",
    "url": "/css/mifi_layout.e62efd16.css"
  },
  {
    "revision": "775f3e7e1ddaabe41c19",
    "url": "/js/mifi_layout.caa2418f.js"
  },
  {
    "revision": "76b7af2e94c92c77e3e8",
    "url": "/css/mifi_order.10ed5a06.css"
  },
  {
    "revision": "76b7af2e94c92c77e3e8",
    "url": "/js/mifi_order.5b493af5.js"
  },
  {
    "revision": "cc1b8ddbf3524061cae7",
    "url": "/css/mifi_order_wrapper.2bcf9a83.css"
  },
  {
    "revision": "cc1b8ddbf3524061cae7",
    "url": "/js/mifi_order_wrapper.3713f0cd.js"
  },
  {
    "revision": "d5a22caeed751527ab4b",
    "url": "/css/mifi_plan_group.5f627870.css"
  },
  {
    "revision": "d5a22caeed751527ab4b",
    "url": "/js/mifi_plan_group.43d84dcf.js"
  },
  {
    "revision": "5edccdf6c5a6bcb5edbd",
    "url": "/css/mifi_plan_list.8b2b206a.css"
  },
  {
    "revision": "5edccdf6c5a6bcb5edbd",
    "url": "/js/mifi_plan_list.3186fe5f.js"
  },
  {
    "revision": "9236a9c8dad26c79f985",
    "url": "/css/mifi_plan_usage.664848b9.css"
  },
  {
    "revision": "9236a9c8dad26c79f985",
    "url": "/js/mifi_plan_usage.c8beac88.js"
  },
  {
    "revision": "f3e05ece3b97dfd5d369",
    "url": "/css/mifi_plan_wrapper.9fad4617.css"
  },
  {
    "revision": "f3e05ece3b97dfd5d369",
    "url": "/js/mifi_plan_wrapper.f8aacc32.js"
  },
  {
    "revision": "ad7906802873a5c25520",
    "url": "/css/new_card_wrapper.8710c11d.css"
  },
  {
    "revision": "ad7906802873a5c25520",
    "url": "/js/new_card_wrapper.f7dba093.js"
  },
  {
    "revision": "e566cb9fa384049819ec",
    "url": "/css/official_accounts.fd7fcaa2.css"
  },
  {
    "revision": "e566cb9fa384049819ec",
    "url": "/js/official_accounts.38fbf372.js"
  },
  {
    "revision": "a5e0e776625bf325230f",
    "url": "/css/orderRecord.077eb076.css"
  },
  {
    "revision": "a5e0e776625bf325230f",
    "url": "/js/orderRecord.ba5405ee.js"
  },
  {
    "revision": "5e1c982caa0c5197d369",
    "url": "/css/plan_list.41a32b32.css"
  },
  {
    "revision": "5e1c982caa0c5197d369",
    "url": "/js/plan_list.2379aeb4.js"
  },
  {
    "revision": "51abf24b99c3df784fd3",
    "url": "/css/question.8d77d581.css"
  },
  {
    "revision": "51abf24b99c3df784fd3",
    "url": "/js/question.624ab436.js"
  },
  {
    "revision": "693254f34b03edcb3315",
    "url": "/css/question_wrapper.c537a243.css"
  },
  {
    "revision": "693254f34b03edcb3315",
    "url": "/js/question_wrapper.69824684.js"
  },
  {
    "revision": "1ffce4d01e71794eb2ae",
    "url": "/css/realNameCourse.fc493020.css"
  },
  {
    "revision": "1ffce4d01e71794eb2ae",
    "url": "/js/realNameCourse.d07a6bff.js"
  },
  {
    "revision": "f971274b25150023dec5",
    "url": "/css/real_name.43434d9f.css"
  },
  {
    "revision": "f971274b25150023dec5",
    "url": "/js/real_name.d76a4ed3.js"
  },
  {
    "revision": "2844c6997e3f24079cf0",
    "url": "/css/recharge.0f01abf8.css"
  },
  {
    "revision": "2844c6997e3f24079cf0",
    "url": "/js/recharge.34a2f69a.js"
  },
  {
    "revision": "ae43bc74bcf4d1d8ced6",
    "url": "/css/rechargeOrder.8bf72eb2.css"
  },
  {
    "revision": "ae43bc74bcf4d1d8ced6",
    "url": "/js/rechargeOrder.25092f16.js"
  },
  {
    "revision": "f02899100f6fc0b3437e",
    "url": "/css/rechargeOrder~whiteSearch.99b4da45.css"
  },
  {
    "revision": "f02899100f6fc0b3437e",
    "url": "/js/rechargeOrder~whiteSearch.173544da.js"
  },
  {
    "revision": "974b5104fa20c04ffdf8",
    "url": "/css/recharge_balance.c9d42481.css"
  },
  {
    "revision": "974b5104fa20c04ffdf8",
    "url": "/js/recharge_balance.4adb64d6.js"
  },
  {
    "revision": "bc6aa5fbd5aeff28036f",
    "url": "/css/recharge_callback.96a7b545.css"
  },
  {
    "revision": "bc6aa5fbd5aeff28036f",
    "url": "/js/recharge_callback.5d85b883.js"
  },
  {
    "revision": "3681408ca10383d7c348",
    "url": "/css/recharge_wrapper.d50ea4c2.css"
  },
  {
    "revision": "3681408ca10383d7c348",
    "url": "/js/recharge_wrapper.22341ba9.js"
  },
  {
    "revision": "683b49e3d189bcb18432",
    "url": "/css/refundRules.e82d0170.css"
  },
  {
    "revision": "683b49e3d189bcb18432",
    "url": "/js/refundRules.1572b68a.js"
  },
  {
    "revision": "9aba02d2185dd1a63acf",
    "url": "/css/refund_applying.e52633ee.css"
  },
  {
    "revision": "9aba02d2185dd1a63acf",
    "url": "/js/refund_applying.622bd30e.js"
  },
  {
    "revision": "3ff1d5801e888e7d0fe2",
    "url": "/css/refund_argument.79ea24e5.css"
  },
  {
    "revision": "3ff1d5801e888e7d0fe2",
    "url": "/js/refund_argument.1c78404d.js"
  },
  {
    "revision": "4fb7c2d94df2e4124dc8",
    "url": "/css/refund_plan.5ae123ab.css"
  },
  {
    "revision": "4fb7c2d94df2e4124dc8",
    "url": "/js/refund_plan.4e1ca608.js"
  },
  {
    "revision": "93b1fb210d725a9670e4",
    "url": "/css/refund_wrapper.9e98768f.css"
  },
  {
    "revision": "93b1fb210d725a9670e4",
    "url": "/js/refund_wrapper.5662f6f6.js"
  },
  {
    "revision": "19ec97ee75bfd22e35eb",
    "url": "/css/repeatRecharge.d55f2cbe.css"
  },
  {
    "revision": "19ec97ee75bfd22e35eb",
    "url": "/js/repeatRecharge.325f7b47.js"
  },
  {
    "revision": "5f4520ef3add0b32baa6",
    "url": "/css/revoke_plan.708c9a4a.css"
  },
  {
    "revision": "5f4520ef3add0b32baa6",
    "url": "/js/revoke_plan.4fafc55c.js"
  },
  {
    "revision": "c4c2a6586a55a0532822",
    "url": "/css/speedup_500.beaed54e.css"
  },
  {
    "revision": "c4c2a6586a55a0532822",
    "url": "/js/speedup_500.3353b816.js"
  },
  {
    "revision": "441aeaa4ee1c3242e420",
    "url": "/css/speedup_80.d66cf460.css"
  },
  {
    "revision": "441aeaa4ee1c3242e420",
    "url": "/js/speedup_80.1bf87fd9.js"
  },
  {
    "revision": "5632b2db36970eea0974",
    "url": "/css/speedup_wrapper.12696ad3.css"
  },
  {
    "revision": "5632b2db36970eea0974",
    "url": "/js/speedup_wrapper.378e34a3.js"
  },
  {
    "revision": "dafb2d107abb880dbffd",
    "url": "/css/to_tb.e0e24c34.css"
  },
  {
    "revision": "dafb2d107abb880dbffd",
    "url": "/js/to_tb.a94e6e0a.js"
  },
  {
    "revision": "79e5649b40bb069badcd",
    "url": "/css/transfer_url.313cd7c6.css"
  },
  {
    "revision": "79e5649b40bb069badcd",
    "url": "/js/transfer_url.543cbfef.js"
  },
  {
    "revision": "58019f115a3830c65227",
    "url": "/css/userCenter.01a72288.css"
  },
  {
    "revision": "58019f115a3830c65227",
    "url": "/js/userCenter.9af62b1f.js"
  },
  {
    "revision": "01b3e1302382323b880e",
    "url": "/css/userCenterWrap.702dc4c1.css"
  },
  {
    "revision": "01b3e1302382323b880e",
    "url": "/js/userCenterWrap.fc4adbe1.js"
  },
  {
    "revision": "c403bd4e3a50e4417655",
    "url": "/css/whiteListsWrapper.75f341e2.css"
  },
  {
    "revision": "c403bd4e3a50e4417655",
    "url": "/js/whiteListsWrapper.9c8052f0.js"
  },
  {
    "revision": "d86a030d5fd7b57e566c",
    "url": "/css/whiteNewlist.f0e37d5a.css"
  },
  {
    "revision": "d86a030d5fd7b57e566c",
    "url": "/js/whiteNewlist.cd57f0d6.js"
  },
  {
    "revision": "6e4aaeb0debbf088b94a",
    "url": "/css/whiteSearch.03aed408.css"
  },
  {
    "revision": "6e4aaeb0debbf088b94a",
    "url": "/js/whiteSearch.e1d3269d.js"
  },
  {
    "revision": "e4b411644706c29765eea3ffdd85ae39",
    "url": "/fonts/SourceHanSansCNRegular.e4b41164.woff"
  },
  {
    "revision": "834b022ab9ab0e6063904af32274e777",
    "url": "/fonts/SourceHanSansCNRegular.834b022a.eot"
  },
  {
    "revision": "f9509c5a10be7daaf1fa01922a7c6bc2",
    "url": "/fonts/SourceHanSansCNRegular.f9509c5a.ttf"
  },
  {
    "revision": "da0808e9fe85be160aab69c82dd8de1c",
    "url": "/img/SourceHanSansCNRegular.da0808e9.svg"
  },
  {
    "revision": "732389ded34cb9c52dd88271f1345af9",
    "url": "/fonts/element-icons.732389de.ttf"
  },
  {
    "revision": "535877f50039c0cb49a6196a5b7517cd",
    "url": "/fonts/element-icons.535877f5.woff"
  },
  {
    "revision": "fff5af4325410621aeec4e60b3b92d9b",
    "url": "/img/mifi_binding_bg@3x.fff5af43.png"
  },
  {
    "revision": "fff5af4325410621aeec4e60b3b92d9b",
    "url": "/img/mifi_binding_bg@2x.fff5af43.png"
  },
  {
    "revision": "6e5cee7393060b0ec3dcd587c2518b94",
    "url": "/img/bg_test.6e5cee73.png"
  },
  {
    "revision": "d0ccbc8a35180bb40e027b44dd26035a",
    "url": "/img/youku.d0ccbc8a.png"
  },
  {
    "revision": "42c0fbd4915870e5e60452fd0ef2cbec",
    "url": "/img/orderTopBg@3x.42c0fbd4.png"
  },
  {
    "revision": "42c0fbd4915870e5e60452fd0ef2cbec",
    "url": "/img/orderTopBg@2x.42c0fbd4.png"
  },
  {
    "revision": "8cb139e0169560e725d23c2ab8d8310e",
    "url": "/img/advert.8cb139e0.gif"
  },
  {
    "revision": "b899232b79ad9962c5ab5572775a0400",
    "url": "/img/card_index_bg@3x.b899232b.png"
  },
  {
    "revision": "b899232b79ad9962c5ab5572775a0400",
    "url": "/img/card_index_bg@2x.b899232b.png"
  },
  {
    "revision": "2c51a1e53c1ea0b35086d8d7261b4933",
    "url": "/img/bg_network@3x.2c51a1e5.png"
  },
  {
    "revision": "32d70c8fc305e3647098f3de0c71b618",
    "url": "/img/bg_network@2x.32d70c8f.png"
  },
  {
    "revision": "f5f322478286641bd9887a155e35f222",
    "url": "/img/btn.f5f32247.png"
  },
  {
    "revision": "d140650fa64e0f1fc771610dba62aed7",
    "url": "/img/bg.d140650f.png"
  },
  {
    "revision": "cc0636ca2944024fd3ebf33a5412ff35",
    "url": "/img/icon-right@3x.cc0636ca.png"
  },
  {
    "revision": "1b983020cfed6b7a8ca5c300c24ca186",
    "url": "/img/icon-left@3x.1b983020.png"
  },
  {
    "revision": "d796d97eb9ebb2e89bb966343e2362e9",
    "url": "/img/icon-left@2x.d796d97e.png"
  },
  {
    "revision": "ccb9865dadbc642b8c4dd0a1abc8e570",
    "url": "/img/recharge-word@2x.ccb9865d.png"
  },
  {
    "revision": "ccb9865dadbc642b8c4dd0a1abc8e570",
    "url": "/img/recharge-word@3x.ccb9865d.png"
  },
  {
    "revision": "41a8c268f703fe646d5d08099eb778ae",
    "url": "/img/icon-right@2x.41a8c268.png"
  },
  {
    "revision": "2d6d06f4da15fc1a748677c49c5f1854",
    "url": "/img/bg.2d6d06f4.png"
  },
  {
    "revision": "e93b8c03293c5b6a311da784f9c19c8f",
    "url": "/img/bg.e93b8c03.jpeg"
  },
  {
    "revision": "ffb1612d9660e2ecd9d3872d57a8a2f9",
    "url": "/img/bar.ffb1612d.png"
  },
  {
    "revision": "3d0fc424b703032ca595090e99f8354b",
    "url": "/img/login_bg@2x.3d0fc424.png"
  },
  {
    "revision": "11000d4e510a6df565eb69ba6f2c1dfc",
    "url": "/img/login_bg@3x.11000d4e.png"
  },
  {
    "revision": "e625229e32d9deeb5f2909c314d8e609",
    "url": "/img/ios@2x.e625229e.png"
  },
  {
    "revision": "af8bbdfa0a90c4eed4563f8c06ce5ff8",
    "url": "/img/android@2x.af8bbdfa.png"
  },
  {
    "revision": "1d7515ee61c3f659227318b4050955ed",
    "url": "/img/mobile_sim@2x.1d7515ee.png"
  },
  {
    "revision": "0f980b79d9a52702004de9f652a68835",
    "url": "/img/telcom_sim@2x.0f980b79.png"
  },
  {
    "revision": "98141226a7e992e3072a280746a259c4",
    "url": "/img/mobile_sim@3x.98141226.png"
  },
  {
    "revision": "0c88168b284b92c37f3a873f26a97d69",
    "url": "/img/bg.0c88168b.jpg"
  },
  {
    "revision": "9e02095f31a07b972244f1c714c1dfe7",
    "url": "/img/telcom_sim@3x.9e02095f.png"
  },
  {
    "revision": "3f342771b9b81ab929e0fbcbcd0e6533",
    "url": "/img/bg-check-wrap@3x.3f342771.png"
  },
  {
    "revision": "9713b21819c4019befecd095069977df",
    "url": "/img/bg-check-wrap@2x.9713b218.png"
  },
  {
    "revision": "fa855242805b87da42c65763acd64ac0",
    "url": "/img/bg-plan-type@2x.fa855242.png"
  },
  {
    "revision": "4a9ca192485effa8b8f4b5b2df5b9caf",
    "url": "/img/bg-plan-type@3x.4a9ca192.png"
  },
  {
    "revision": "f40c7e0b20fe25eb78a7658c3ae56312",
    "url": "/img/noData@3x.f40c7e0b.png"
  },
  {
    "revision": "644e6e3cf5f33943747b116316694e28",
    "url": "/img/noData@2x.644e6e3c.png"
  },
  {
    "revision": "01355f175bd20423ce45a838c1a998a9",
    "url": "/img/bg.01355f17.png"
  },
  {
    "revision": "2a67b73145562669220aa4639e1ad58f",
    "url": "/img/icon3.2a67b731.png"
  },
  {
    "revision": "813b5319e378dafdda952c16ad89906b",
    "url": "/img/icon2.813b5319.png"
  },
  {
    "revision": "0f16389ec218c90cf8f657e233b745f2",
    "url": "/img/balanceBg1.0f16389e.png"
  },
  {
    "revision": "565459ef2ee8b71db421144ad21c23e3",
    "url": "/img/balanceBg2.565459ef.png"
  },
  {
    "revision": "91e1d2771efacd45e5e465d9a001f197",
    "url": "/img/liantong.91e1d277.png"
  },
  {
    "revision": "4a0cab0f33beb48ea985714d1b91fef7",
    "url": "/img/dianxin.4a0cab0f.png"
  },
  {
    "revision": "657033323334e91efb0011bbc18f8c04",
    "url": "/img/yidong.65703332.png"
  },
  {
    "revision": "8da3b83b73e44e54d6be4b2522bcb1f2",
    "url": "/img/pkgBg2.8da3b83b.png"
  },
  {
    "revision": "d3b42651f9f5048baeffb50c800913ec",
    "url": "/img/pkgBg1.d3b42651.png"
  },
  {
    "revision": "d461d18e42a310bd709b2ce97d159153",
    "url": "/img/pkgBg3.d461d18e.png"
  },
  {
    "revision": "0078f03c08066d51d64b92a13e194ebb",
    "url": "/img/balanceRefund.0078f03c.png"
  },
  {
    "revision": "af3ed0b3236bbfdbc3ad61b8d41c3dec",
    "url": "/img/changeBg.af3ed0b3.png"
  },
  {
    "revision": "6dedd4943e4c5848638196fb6f0c4145",
    "url": "/img/bg.6dedd494.png"
  },
  {
    "revision": "a859e9ca4606d567c42b9c7bcd4fdce9",
    "url": "/img/iccid_bg@2x.a859e9ca.png"
  },
  {
    "revision": "fa9050c4e9870e8fc0cd184f8515af4a",
    "url": "/img/iccid_bg@3x.fa9050c4.png"
  },
  {
    "revision": "014d354b9b25b67ae95857ba17e2f4cc",
    "url": "/img/activityPage.014d354b.png"
  },
  {
    "revision": "6e5cee7393060b0ec3dcd587c2518b94",
    "url": "/img/bg_test@3x.6e5cee73.png"
  },
  {
    "revision": "114a6e12b42b9b48586dd341105188fe",
    "url": "/img/usedOrder@2x.114a6e12.png"
  },
  {
    "revision": "6e5cee7393060b0ec3dcd587c2518b94",
    "url": "/img/bg_test@2x.6e5cee73.png"
  },
  {
    "revision": "c0170ec299b2418256fd515ee7849055",
    "url": "/img/unUsedOrder@2x.c0170ec2.png"
  },
  {
    "revision": "d9e14058d30dd312519fcf2de38d742b",
    "url": "/img/unUsedOrder@3x.d9e14058.png"
  },
  {
    "revision": "4a5b90f8076955f289b3dcda6a5af6ff",
    "url": "/img/invaildedOrder@3x.4a5b90f8.png"
  },
  {
    "revision": "0d5a5158e67bcb7a4604124715ed6fbf",
    "url": "/img/usedOrder@3x.0d5a5158.png"
  },
  {
    "revision": "be0f1e33b2553e71b117d3d3f838d32f",
    "url": "/img/invaildedOrder@2x.be0f1e33.png"
  },
  {
    "revision": "3603a35a49dbb8ad94ec1e57c4dad229",
    "url": "/img/scanTop2.3603a35a.png"
  },
  {
    "revision": "05775dd69c53d7273b27aaa7c6c523f7",
    "url": "/img/04.05775dd6.png"
  },
  {
    "revision": "58a560568b7291ea926c2c7438035308",
    "url": "/img/subscribe@3x.58a56056.png"
  },
  {
    "revision": "541375e6bb7db2fba9e415be8045f5fb",
    "url": "/img/1.541375e6.png"
  },
  {
    "revision": "5a3428653945c17e1c146efeee81c987",
    "url": "/img/scanTop.5a342865.png"
  },
  {
    "revision": "0b9e0b5f4f28c68416f916ddce3fc7ef",
    "url": "/img/unicom-logo.0b9e0b5f.svg"
  },
  {
    "revision": "113f99e2189c2ca49db2168754fc2eb5",
    "url": "/img/mobile-logo.113f99e2.png"
  },
  {
    "revision": "0cba868fa977e09806638b9000636a36",
    "url": "/img/avatar.0cba868f.jpeg"
  },
  {
    "revision": "27158aa79eb0d4b89f317d076a801ca3",
    "url": "/img/coupon-log.27158aa7.png"
  },
  {
    "revision": "55d3f2f09efe17db6485d4c9f8f0c3b1",
    "url": "/img/icon-recharge_20181001.55d3f2f0.svg"
  },
  {
    "revision": "165beb68d8ba0d2b70df0fbb3769787a",
    "url": "/img/03.165beb68.png"
  },
  {
    "revision": "8c605ac88ca50357355da465f322d10a",
    "url": "/img/telecom-logo.8c605ac8.svg"
  },
  {
    "revision": "f7a51f1c554585b11d61499fd0a7520f",
    "url": "/img/only-box@3x.f7a51f1c.png"
  },
  {
    "revision": "89b99d16dd8a4a56746323a0ffbd754c",
    "url": "/img/migu.89b99d16.png"
  },
  {
    "revision": "0b3c3297decbd1152a314cce115f9632",
    "url": "/img/09.0b3c3297.png"
  },
  {
    "revision": "34c67f6dfdb0ecc17c7a221aec74706f",
    "url": "/img/bg_no_recharge.34c67f6d.svg"
  },
  {
    "revision": "b0ffa4a0fd195a110ee4d4dabce3bc32",
    "url": "/img/08.b0ffa4a0.png"
  },
  {
    "revision": "96fab583abd57f2e7118324858fa3080",
    "url": "/img/05.96fab583.png"
  },
  {
    "revision": "9e8ecc7f7b760b55c56bddfab886da10",
    "url": "/img/3.9e8ecc7f.png"
  },
  {
    "revision": "f23d9d1f76147bc89b48902c36818f1e",
    "url": "/img/bg_no_plan.f23d9d1f.svg"
  },
  {
    "revision": "a8272d2d742d9d50257e23dfac577def",
    "url": "/img/01.a8272d2d.png"
  },
  {
    "revision": "daa86b540bb9c2a6453ceac9bed77961",
    "url": "/img/07.daa86b54.png"
  },
  {
    "revision": "687b6ce03f134f21173c949d79002960",
    "url": "/img/tip.687b6ce0.png"
  },
  {
    "revision": "a610420eab741be28278e60bc06387aa",
    "url": "/img/box-deco@3x.a610420e.png"
  },
  {
    "revision": "eacba58f9acf2b87cd801858146b2ba9",
    "url": "/img/02.eacba58f.png"
  },
  {
    "revision": "39d9e849fc1c724525f166646932a24d",
    "url": "/img/safari.39d9e849.png"
  },
  {
    "revision": "999589aae784a460b5e7c6ae9bbaa3d8",
    "url": "/img/06.999589aa.png"
  },
  {
    "revision": "7c28431d304fa4f58f5070c59720683a",
    "url": "/img/2.7c28431d.png"
  },
  {
    "revision": "3e217df4202e41ad9b030aafc8cfcc24",
    "url": "/img/4.3e217df4.png"
  },
  {
    "revision": "d3ee3cb97544cc677868311a5a760c6a",
    "url": "/index.html"
  },
  {
    "revision": "00bbf6b458bf7ea6bd01f443eb3045d9",
    "url": "/MP_verify_4r3DVk3KUjgWsQsG.txt"
  },
  {
    "revision": "652317b098ca24e4511926c7fd57cbbe",
    "url": "/MP_verify_8JoCCldW78DygS5c.txt"
  },
  {
    "revision": "86c422d8c98b247235d04b49fb1c4b05",
    "url": "/MP_verify_bKSdn2qZlUSULliu.txt"
  },
  {
    "revision": "735ab4f94fbcd57074377afca324c813",
    "url": "/robots.txt"
  },
  {
    "revision": "9ce16f441b39b493af8b96d7e97cce22",
    "url": "/MP_verify_dkzAKjxyVyJvsHMS.txt"
  }
];