self.__precacheManifest = [
  {
    "revision": "18325135f9dbd5a3ed4b",
    "url": "/css/recharge_wrapper.acf02c15.css"
  },
  {
    "revision": "b6216d61c03e6ce0c9aea6ca7808f7ca",
    "url": "/robots.txt"
  },
  {
    "revision": "18325135f9dbd5a3ed4b",
    "url": "/js/recharge_wrapper.d9e765ca.js"
  },
  {
    "revision": "aea18e1fc690e9682196",
    "url": "/css/Layout~card_usage.fbcdfb9a.css"
  },
  {
    "revision": "78214ba34c5f1df936aa",
    "url": "/js/Layout~card_usage~eqReplaceMent~esim_plan_list~esim_usage~mifi_order~mifi_plan_list~mifi_plan_usage~~c6f87c36.6241bd21.js"
  },
  {
    "revision": "d3c44d700e81edc4367c",
    "url": "/css/Not_fund.7e181e00.css"
  },
  {
    "revision": "d3c44d700e81edc4367c",
    "url": "/js/Not_fund.128cd473.js"
  },
  {
    "revision": "31272fc5f2364b207cde",
    "url": "/css/app.2608000f.css"
  },
  {
    "revision": "31272fc5f2364b207cde",
    "url": "/js/app.10706c84.js"
  },
  {
    "revision": "dd2627d5764cc64bc1fb",
    "url": "/css/authority_middle.12684f0a.css"
  },
  {
    "revision": "dd2627d5764cc64bc1fb",
    "url": "/js/authority_middle.4298d130.js"
  },
  {
    "revision": "71aa140d2ed074cf6452",
    "url": "/css/balanceRefund.d5523737.css"
  },
  {
    "revision": "71aa140d2ed074cf6452",
    "url": "/js/balanceRefund.4156db45.js"
  },
  {
    "revision": "061640a4304edefac687",
    "url": "/css/cardPackage.acb7e902.css"
  },
  {
    "revision": "061640a4304edefac687",
    "url": "/js/cardPackage.f97eba63.js"
  },
  {
    "revision": "8c041449330043e369b9",
    "url": "/css/card_check.b5b1ecab.css"
  },
  {
    "revision": "8c041449330043e369b9",
    "url": "/js/card_check.56feedb4.js"
  },
  {
    "revision": "9caf73f140d3f8e15d99",
    "url": "/css/card_connection.d558badf.css"
  },
  {
    "revision": "9caf73f140d3f8e15d99",
    "url": "/js/card_connection.855507ff.js"
  },
  {
    "revision": "b23d1bb538ee796b360b",
    "url": "/css/card_lookup.9d33044b.css"
  },
  {
    "revision": "b23d1bb538ee796b360b",
    "url": "/js/card_lookup.7c636e1b.js"
  },
  {
    "revision": "3dd5deed3d6f08eb6b95",
    "url": "/css/card_usage.f6f75021.css"
  },
  {
    "revision": "3dd5deed3d6f08eb6b95",
    "url": "/js/card_usage.c79a1f8e.js"
  },
  {
    "revision": "e2480d6c773029d20292",
    "url": "/css/card_wrapper.770742b7.css"
  },
  {
    "revision": "e2480d6c773029d20292",
    "url": "/js/card_wrapper.2b96ae0c.js"
  },
  {
    "revision": "cd15c5bd8df3020e735e",
    "url": "/css/children_card.3dd836b1.css"
  },
  {
    "revision": "cd15c5bd8df3020e735e",
    "url": "/js/children_card.7feb75ab.js"
  },
  {
    "revision": "983c00b649447c4cbe38",
    "url": "/css/chunk-34df9053.0fde750e.css"
  },
  {
    "revision": "983c00b649447c4cbe38",
    "url": "/js/chunk-34df9053.d08f2cd2.js"
  },
  {
    "revision": "f2124069e1ad78974e67",
    "url": "/css/chunk-f4f68b7c.996c8e83.css"
  },
  {
    "revision": "f2124069e1ad78974e67",
    "url": "/js/chunk-f4f68b7c.7091c447.js"
  },
  {
    "revision": "2ef2b4e8ff50a96098b7",
    "url": "/css/chunk-vendors.187f45a9.css"
  },
  {
    "revision": "2ef2b4e8ff50a96098b7",
    "url": "/js/chunk-vendors.589c6f09.js"
  },
  {
    "revision": "3fae7aafd03c1f185cb3",
    "url": "/css/commonProblem.8665ff12.css"
  },
  {
    "revision": "3fae7aafd03c1f185cb3",
    "url": "/js/commonProblem.947e742d.js"
  },
  {
    "revision": "4a885bc011aac2312865",
    "url": "/css/consumerRecord.29e621d0.css"
  },
  {
    "revision": "4a885bc011aac2312865",
    "url": "/js/consumerRecord.2f926949.js"
  },
  {
    "revision": "617e0dd50aa4e9b3f562",
    "url": "/css/coupon_normal.72ee0bc0.css"
  },
  {
    "revision": "617e0dd50aa4e9b3f562",
    "url": "/js/coupon_normal.7f573954.js"
  },
  {
    "revision": "e2a477807b336b06158b",
    "url": "/css/coupon_telcom.c97d76cf.css"
  },
  {
    "revision": "e2a477807b336b06158b",
    "url": "/js/coupon_telcom.774eafa6.js"
  },
  {
    "revision": "35665cf84dc00b2058c7",
    "url": "/css/coupon_wrapper.707898e1.css"
  },
  {
    "revision": "35665cf84dc00b2058c7",
    "url": "/js/coupon_wrapper.8e12c81c.js"
  },
  {
    "revision": "2625fc614dc010525089",
    "url": "/css/currencyConversion.49ad62d9.css"
  },
  {
    "revision": "2625fc614dc010525089",
    "url": "/js/currencyConversion.e77db3d4.js"
  },
  {
    "revision": "d25fe263de959519d81a",
    "url": "/css/eqReplaceMent.c6ab9d22.css"
  },
  {
    "revision": "d25fe263de959519d81a",
    "url": "/js/eqReplaceMent.310b7f92.js"
  },
  {
    "revision": "1fd61987d0224af7103b",
    "url": "/css/esim_plan_list.f9ad569b.css"
  },
  {
    "revision": "1fd61987d0224af7103b",
    "url": "/js/esim_plan_list.b12e7562.js"
  },
  {
    "revision": "8b6ecdee62759586b0c8",
    "url": "/css/esim_usage.8bcb5bd7.css"
  },
  {
    "revision": "8b6ecdee62759586b0c8",
    "url": "/js/esim_usage.34486bd2.js"
  },
  {
    "revision": "d35935813a8be771ac62",
    "url": "/css/find_plan.0c04faff.css"
  },
  {
    "revision": "d35935813a8be771ac62",
    "url": "/js/find_plan.dd5cc8c7.js"
  },
  {
    "revision": "2082545acce7b2a699fa",
    "url": "/css/logical_page.7e6f49b9.css"
  },
  {
    "revision": "2082545acce7b2a699fa",
    "url": "/js/logical_page.c19c60be.js"
  },
  {
    "revision": "ebd17ec69537751862f5",
    "url": "/css/login.a1848749.css"
  },
  {
    "revision": "ebd17ec69537751862f5",
    "url": "/js/login.78f296b6.js"
  },
  {
    "revision": "1fd3a274cc427cdd68c4",
    "url": "/css/lookup.b5e8b610.css"
  },
  {
    "revision": "1fd3a274cc427cdd68c4",
    "url": "/js/lookup.74d4b896.js"
  },
  {
    "revision": "367056cccbcd8f4dbeca",
    "url": "/css/mifi_binding.b5ffa534.css"
  },
  {
    "revision": "367056cccbcd8f4dbeca",
    "url": "/js/mifi_binding.55a6bfa7.js"
  },
  {
    "revision": "66626abb98e5ed23adfe",
    "url": "/css/mifi_card_info.83dd4962.css"
  },
  {
    "revision": "66626abb98e5ed23adfe",
    "url": "/js/mifi_card_info.276164fe.js"
  },
  {
    "revision": "55bd1f9210d158443f4f",
    "url": "/css/mifi_card_lookup.92dec11c.css"
  },
  {
    "revision": "55bd1f9210d158443f4f",
    "url": "/js/mifi_card_lookup.263b6977.js"
  },
  {
    "revision": "cf88c769e86c500a009e",
    "url": "/css/mifi_card_wrapper.c09367ca.css"
  },
  {
    "revision": "cf88c769e86c500a009e",
    "url": "/js/mifi_card_wrapper.ac09d9fb.js"
  },
  {
    "revision": "c4fb72a0e83c18840322",
    "url": "/css/mifi_change_network.620a8a07.css"
  },
  {
    "revision": "c4fb72a0e83c18840322",
    "url": "/js/mifi_change_network.0f7a4a39.js"
  },
  {
    "revision": "dabf225a66f69c72470a",
    "url": "/css/mifi_change_network_explanation.362d9c01.css"
  },
  {
    "revision": "dabf225a66f69c72470a",
    "url": "/js/mifi_change_network_explanation.2f78cc70.js"
  },
  {
    "revision": "9664e4c361e8b8713584",
    "url": "/css/mifi_coupon_index.ab95dd2b.css"
  },
  {
    "revision": "9664e4c361e8b8713584",
    "url": "/js/mifi_coupon_index.17b7c1db.js"
  },
  {
    "revision": "41cb6b26c78653fcddf8",
    "url": "/css/mifi_coupon_wrapper.32f1c95d.css"
  },
  {
    "revision": "41cb6b26c78653fcddf8",
    "url": "/js/mifi_coupon_wrapper.f357646c.js"
  },
  {
    "revision": "f572453aefccb6242b4f",
    "url": "/css/mifi_index.0212e484.css"
  },
  {
    "revision": "f572453aefccb6242b4f",
    "url": "/js/mifi_index.4ad5c24e.js"
  },
  {
    "revision": "1a4f6dea71d18dd2fbf9",
    "url": "/css/mifi_layout.0a7c17e3.css"
  },
  {
    "revision": "1a4f6dea71d18dd2fbf9",
    "url": "/js/mifi_layout.eb5048e6.js"
  },
  {
    "revision": "3ec995dee35173a087ea",
    "url": "/css/mifi_order.27bb3351.css"
  },
  {
    "revision": "3ec995dee35173a087ea",
    "url": "/js/mifi_order.fa204ded.js"
  },
  {
    "revision": "70cc91a31ace483ac4f3",
    "url": "/css/mifi_order_wrapper.0b1217f1.css"
  },
  {
    "revision": "70cc91a31ace483ac4f3",
    "url": "/js/mifi_order_wrapper.0d7f411b.js"
  },
  {
    "revision": "47dd43015500be3f9ac4",
    "url": "/css/mifi_order~mifi_plan_group.9b72222a.css"
  },
  {
    "revision": "47dd43015500be3f9ac4",
    "url": "/js/mifi_order~mifi_plan_group.8b8989db.js"
  },
  {
    "revision": "e328fd43ca9dc6b8ad34",
    "url": "/css/mifi_plan_group.d5b61e31.css"
  },
  {
    "revision": "e328fd43ca9dc6b8ad34",
    "url": "/js/mifi_plan_group.92dfd200.js"
  },
  {
    "revision": "53f6cc31c09ad8e7b024",
    "url": "/css/mifi_plan_list.0f398b91.css"
  },
  {
    "revision": "53f6cc31c09ad8e7b024",
    "url": "/js/mifi_plan_list.99ea73cb.js"
  },
  {
    "revision": "7e5e5a5d1fbc58cda55a",
    "url": "/css/mifi_plan_usage.7827b738.css"
  },
  {
    "revision": "7e5e5a5d1fbc58cda55a",
    "url": "/js/mifi_plan_usage.c330b2e0.js"
  },
  {
    "revision": "ce2bc07e2623493d7081",
    "url": "/css/mifi_plan_wrapper.56a3339d.css"
  },
  {
    "revision": "ce2bc07e2623493d7081",
    "url": "/js/mifi_plan_wrapper.666c024b.js"
  },
  {
    "revision": "c64ee0336bbe15611264",
    "url": "/css/new_card_wrapper.9b92bcd2.css"
  },
  {
    "revision": "c64ee0336bbe15611264",
    "url": "/js/new_card_wrapper.def4274d.js"
  },
  {
    "revision": "27ddba4cf335045cdd03",
    "url": "/css/orderRecord.dc69b07b.css"
  },
  {
    "revision": "27ddba4cf335045cdd03",
    "url": "/js/orderRecord.118cdb31.js"
  },
  {
    "revision": "d1ed39cb6de868288abc",
    "url": "/css/plan_list.bc8cb400.css"
  },
  {
    "revision": "d1ed39cb6de868288abc",
    "url": "/js/plan_list.f83188fb.js"
  },
  {
    "revision": "638e37dc8d8c1b316143",
    "url": "/css/question.6a2c09ce.css"
  },
  {
    "revision": "638e37dc8d8c1b316143",
    "url": "/js/question.c4637d43.js"
  },
  {
    "revision": "cbcc6a4a015494c52dbe",
    "url": "/css/question_wrapper.ce3120d7.css"
  },
  {
    "revision": "cbcc6a4a015494c52dbe",
    "url": "/js/question_wrapper.9e157315.js"
  },
  {
    "revision": "02f7bc5340423964d648",
    "url": "/css/realNameCourse.777d1c09.css"
  },
  {
    "revision": "02f7bc5340423964d648",
    "url": "/js/realNameCourse.65e5c0ad.js"
  },
  {
    "revision": "485dac3a7b926ca94dbb",
    "url": "/css/real_name.af35d5a7.css"
  },
  {
    "revision": "485dac3a7b926ca94dbb",
    "url": "/js/real_name.18bb5be9.js"
  },
  {
    "revision": "4b8ab6bf0bdd16eff1d2",
    "url": "/css/recharge.f762bd9b.css"
  },
  {
    "revision": "4b8ab6bf0bdd16eff1d2",
    "url": "/js/recharge.c8d736a4.js"
  },
  {
    "revision": "711cb7224315fa381797",
    "url": "/css/recharge_callback.666bc365.css"
  },
  {
    "revision": "711cb7224315fa381797",
    "url": "/js/recharge_callback.9afd36d5.js"
  },
  {
    "revision": "30b8be4fa86f28484ca4",
    "url": "/js/Layout.9df1ec87.js"
  },
  {
    "revision": "aea18e1fc690e9682196",
    "url": "/js/Layout~card_usage.2893d1c4.js"
  },
  {
    "revision": "6e592ac3cefc71df3d3c",
    "url": "/css/refund_applying.27672571.css"
  },
  {
    "revision": "6e592ac3cefc71df3d3c",
    "url": "/js/refund_applying.e934e8f8.js"
  },
  {
    "revision": "1d0ac9d8026ab55e5e43",
    "url": "/css/refund_argument.e3b1e80b.css"
  },
  {
    "revision": "1d0ac9d8026ab55e5e43",
    "url": "/js/refund_argument.fbecd76f.js"
  },
  {
    "revision": "02e02ae259c768e6e1ab",
    "url": "/css/refund_plan.326f45ca.css"
  },
  {
    "revision": "02e02ae259c768e6e1ab",
    "url": "/js/refund_plan.5f40e39d.js"
  },
  {
    "revision": "b16e7d476a7505d44e95",
    "url": "/css/refund_wrapper.cff284d8.css"
  },
  {
    "revision": "b16e7d476a7505d44e95",
    "url": "/js/refund_wrapper.eac9cc81.js"
  },
  {
    "revision": "b866130def7318ef789f",
    "url": "/css/repeatRecharge.e3061b23.css"
  },
  {
    "revision": "b866130def7318ef789f",
    "url": "/js/repeatRecharge.438c99c8.js"
  },
  {
    "revision": "0d6d36fd07e357b1629f",
    "url": "/css/revoke_plan.77d4c022.css"
  },
  {
    "revision": "0d6d36fd07e357b1629f",
    "url": "/js/revoke_plan.833b058a.js"
  },
  {
    "revision": "cd73dafd7f0cd2e2afca",
    "url": "/css/speedup_500.24158936.css"
  },
  {
    "revision": "cd73dafd7f0cd2e2afca",
    "url": "/js/speedup_500.c6127e00.js"
  },
  {
    "revision": "2c1535e242b7fcf549e7",
    "url": "/css/speedup_80.863f4cd3.css"
  },
  {
    "revision": "2c1535e242b7fcf549e7",
    "url": "/js/speedup_80.a3200ff7.js"
  },
  {
    "revision": "41f28a5e876af9985e13",
    "url": "/css/speedup_wrapper.b45520a3.css"
  },
  {
    "revision": "41f28a5e876af9985e13",
    "url": "/js/speedup_wrapper.7b4cc455.js"
  },
  {
    "revision": "29fd6639dd4e065f25b0",
    "url": "/css/to_tb.7168a430.css"
  },
  {
    "revision": "29fd6639dd4e065f25b0",
    "url": "/js/to_tb.5ded00fa.js"
  },
  {
    "revision": "5aefa83ef8337f75f1a7",
    "url": "/css/transfer_url.932da114.css"
  },
  {
    "revision": "5aefa83ef8337f75f1a7",
    "url": "/js/transfer_url.066e4bbb.js"
  },
  {
    "revision": "d3a7e0ce5df3d09aae43",
    "url": "/css/userCenter.4ac4d827.css"
  },
  {
    "revision": "d3a7e0ce5df3d09aae43",
    "url": "/js/userCenter.7f2f1f69.js"
  },
  {
    "revision": "5b2fccdbd3e825676897",
    "url": "/css/userCenterWrap.dfb1d208.css"
  },
  {
    "revision": "5b2fccdbd3e825676897",
    "url": "/js/userCenterWrap.c9390b7b.js"
  },
  {
    "revision": "e4b411644706c29765eea3ffdd85ae39",
    "url": "/fonts/SourceHanSansCNRegular.e4b41164.woff"
  },
  {
    "revision": "834b022ab9ab0e6063904af32274e777",
    "url": "/fonts/SourceHanSansCNRegular.834b022a.eot"
  },
  {
    "revision": "f9509c5a10be7daaf1fa01922a7c6bc2",
    "url": "/fonts/SourceHanSansCNRegular.f9509c5a.ttf"
  },
  {
    "revision": "da0808e9fe85be160aab69c82dd8de1c",
    "url": "/img/SourceHanSansCNRegular.da0808e9.svg"
  },
  {
    "revision": "732389ded34cb9c52dd88271f1345af9",
    "url": "/fonts/element-icons.732389de.ttf"
  },
  {
    "revision": "535877f50039c0cb49a6196a5b7517cd",
    "url": "/fonts/element-icons.535877f5.woff"
  },
  {
    "revision": "0078f03c08066d51d64b92a13e194ebb",
    "url": "/img/balanceRefund.0078f03c.png"
  },
  {
    "revision": "af3ed0b3236bbfdbc3ad61b8d41c3dec",
    "url": "/img/changeBg.af3ed0b3.png"
  },
  {
    "revision": "6e5cee7393060b0ec3dcd587c2518b94",
    "url": "/img/bg_test.6e5cee73.png"
  },
  {
    "revision": "b70eddccd257b21777e71bb64c83b876",
    "url": "/img/bg.b70eddcc.jpeg"
  },
  {
    "revision": "909816c3d34e63a9ad86b8c179ab543c",
    "url": "/img/bar.909816c3.png"
  },
  {
    "revision": "e92f547ba0209da3b4342fa2b56ea9ae",
    "url": "/img/animater.e92f547b.png"
  },
  {
    "revision": "42c0fbd4915870e5e60452fd0ef2cbec",
    "url": "/img/orderTopBg@3x.42c0fbd4.png"
  },
  {
    "revision": "42c0fbd4915870e5e60452fd0ef2cbec",
    "url": "/img/orderTopBg@2x.42c0fbd4.png"
  },
  {
    "revision": "fff5af4325410621aeec4e60b3b92d9b",
    "url": "/img/mifi_binding_bg@3x.fff5af43.png"
  },
  {
    "revision": "fff5af4325410621aeec4e60b3b92d9b",
    "url": "/img/mifi_binding_bg@2x.fff5af43.png"
  },
  {
    "revision": "b899232b79ad9962c5ab5572775a0400",
    "url": "/img/card_index_bg@3x.b899232b.png"
  },
  {
    "revision": "b899232b79ad9962c5ab5572775a0400",
    "url": "/img/card_index_bg@2x.b899232b.png"
  },
  {
    "revision": "f5f322478286641bd9887a155e35f222",
    "url": "/img/btn.f5f32247.png"
  },
  {
    "revision": "d140650fa64e0f1fc771610dba62aed7",
    "url": "/img/bg.d140650f.png"
  },
  {
    "revision": "e625229e32d9deeb5f2909c314d8e609",
    "url": "/img/ios@2x.e625229e.png"
  },
  {
    "revision": "af8bbdfa0a90c4eed4563f8c06ce5ff8",
    "url": "/img/android@2x.af8bbdfa.png"
  },
  {
    "revision": "2c51a1e53c1ea0b35086d8d7261b4933",
    "url": "/img/bg_network@3x.2c51a1e5.png"
  },
  {
    "revision": "32d70c8fc305e3647098f3de0c71b618",
    "url": "/img/bg_network@2x.32d70c8f.png"
  },
  {
    "revision": "3f342771b9b81ab929e0fbcbcd0e6533",
    "url": "/img/bg-check-wrap@3x.3f342771.png"
  },
  {
    "revision": "9713b21819c4019befecd095069977df",
    "url": "/img/bg-check-wrap@2x.9713b218.png"
  },
  {
    "revision": "1d7515ee61c3f659227318b4050955ed",
    "url": "/img/mobile_sim@2x.1d7515ee.png"
  },
  {
    "revision": "0f980b79d9a52702004de9f652a68835",
    "url": "/img/telcom_sim@2x.0f980b79.png"
  },
  {
    "revision": "98141226a7e992e3072a280746a259c4",
    "url": "/img/mobile_sim@3x.98141226.png"
  },
  {
    "revision": "0c88168b284b92c37f3a873f26a97d69",
    "url": "/img/bg.0c88168b.jpg"
  },
  {
    "revision": "9e02095f31a07b972244f1c714c1dfe7",
    "url": "/img/telcom_sim@3x.9e02095f.png"
  },
  {
    "revision": "3d0fc424b703032ca595090e99f8354b",
    "url": "/img/login_bg@2x.3d0fc424.png"
  },
  {
    "revision": "11000d4e510a6df565eb69ba6f2c1dfc",
    "url": "/img/login_bg@3x.11000d4e.png"
  },
  {
    "revision": "114a6e12b42b9b48586dd341105188fe",
    "url": "/img/usedOrder@2x.114a6e12.png"
  },
  {
    "revision": "c0170ec299b2418256fd515ee7849055",
    "url": "/img/unUsedOrder@2x.c0170ec2.png"
  },
  {
    "revision": "d9e14058d30dd312519fcf2de38d742b",
    "url": "/img/unUsedOrder@3x.d9e14058.png"
  },
  {
    "revision": "4a5b90f8076955f289b3dcda6a5af6ff",
    "url": "/img/invaildedOrder@3x.4a5b90f8.png"
  },
  {
    "revision": "0d5a5158e67bcb7a4604124715ed6fbf",
    "url": "/img/usedOrder@3x.0d5a5158.png"
  },
  {
    "revision": "be0f1e33b2553e71b117d3d3f838d32f",
    "url": "/img/invaildedOrder@2x.be0f1e33.png"
  },
  {
    "revision": "91e1d2771efacd45e5e465d9a001f197",
    "url": "/img/liantong.91e1d277.png"
  },
  {
    "revision": "4a0cab0f33beb48ea985714d1b91fef7",
    "url": "/img/dianxin.4a0cab0f.png"
  },
  {
    "revision": "657033323334e91efb0011bbc18f8c04",
    "url": "/img/yidong.65703332.png"
  },
  {
    "revision": "8da3b83b73e44e54d6be4b2522bcb1f2",
    "url": "/img/pkgBg2.8da3b83b.png"
  },
  {
    "revision": "d3b42651f9f5048baeffb50c800913ec",
    "url": "/img/pkgBg1.d3b42651.png"
  },
  {
    "revision": "d461d18e42a310bd709b2ce97d159153",
    "url": "/img/pkgBg3.d461d18e.png"
  },
  {
    "revision": "014d354b9b25b67ae95857ba17e2f4cc",
    "url": "/img/activityPage.014d354b.png"
  },
  {
    "revision": "6dedd4943e4c5848638196fb6f0c4145",
    "url": "/img/bg.6dedd494.png"
  },
  {
    "revision": "2a67b73145562669220aa4639e1ad58f",
    "url": "/img/icon3.2a67b731.png"
  },
  {
    "revision": "813b5319e378dafdda952c16ad89906b",
    "url": "/img/icon2.813b5319.png"
  },
  {
    "revision": "01355f175bd20423ce45a838c1a998a9",
    "url": "/img/bg.01355f17.png"
  },
  {
    "revision": "a859e9ca4606d567c42b9c7bcd4fdce9",
    "url": "/img/iccid_bg@2x.a859e9ca.png"
  },
  {
    "revision": "fa9050c4e9870e8fc0cd184f8515af4a",
    "url": "/img/iccid_bg@3x.fa9050c4.png"
  },
  {
    "revision": "3603a35a49dbb8ad94ec1e57c4dad229",
    "url": "/img/scanTop2.3603a35a.png"
  },
  {
    "revision": "05775dd69c53d7273b27aaa7c6c523f7",
    "url": "/img/04.05775dd6.png"
  },
  {
    "revision": "541375e6bb7db2fba9e415be8045f5fb",
    "url": "/img/1.541375e6.png"
  },
  {
    "revision": "7c28431d304fa4f58f5070c59720683a",
    "url": "/img/2.7c28431d.png"
  },
  {
    "revision": "5a3428653945c17e1c146efeee81c987",
    "url": "/img/scanTop.5a342865.png"
  },
  {
    "revision": "824594523c01e48028f2b7eb4261134d",
    "url": "/img/unicom-logo.82459452.svg"
  },
  {
    "revision": "113f99e2189c2ca49db2168754fc2eb5",
    "url": "/img/mobile-logo.113f99e2.png"
  },
  {
    "revision": "0cba868fa977e09806638b9000636a36",
    "url": "/img/avatar.0cba868f.jpeg"
  },
  {
    "revision": "27158aa79eb0d4b89f317d076a801ca3",
    "url": "/img/coupon-log.27158aa7.png"
  },
  {
    "revision": "55d3f2f09efe17db6485d4c9f8f0c3b1",
    "url": "/img/icon-recharge_20181001.55d3f2f0.svg"
  },
  {
    "revision": "165beb68d8ba0d2b70df0fbb3769787a",
    "url": "/img/03.165beb68.png"
  },
  {
    "revision": "5f1f34037094c0613bccafa2ddd8cb3b",
    "url": "/img/telecom-logo.5f1f3403.svg"
  },
  {
    "revision": "0b3c3297decbd1152a314cce115f9632",
    "url": "/img/09.0b3c3297.png"
  },
  {
    "revision": "644e6e3cf5f33943747b116316694e28",
    "url": "/img/noData@2x.644e6e3c.png"
  },
  {
    "revision": "3e217df4202e41ad9b030aafc8cfcc24",
    "url": "/img/4.3e217df4.png"
  },
  {
    "revision": "aecc9531f2c3b1fd45338e7bf5084384",
    "url": "/img/bg_no_recharge.aecc9531.svg"
  },
  {
    "revision": "b0ffa4a0fd195a110ee4d4dabce3bc32",
    "url": "/img/08.b0ffa4a0.png"
  },
  {
    "revision": "96fab583abd57f2e7118324858fa3080",
    "url": "/img/05.96fab583.png"
  },
  {
    "revision": "9e8ecc7f7b760b55c56bddfab886da10",
    "url": "/img/3.9e8ecc7f.png"
  },
  {
    "revision": "275be51ae57c486bce58257febd6589f",
    "url": "/img/bg_no_plan.275be51a.svg"
  },
  {
    "revision": "a8272d2d742d9d50257e23dfac577def",
    "url": "/img/01.a8272d2d.png"
  },
  {
    "revision": "daa86b540bb9c2a6453ceac9bed77961",
    "url": "/img/07.daa86b54.png"
  },
  {
    "revision": "06385746a7cedb492d5539907631561c",
    "url": "/img/tip.06385746.png"
  },
  {
    "revision": "eacba58f9acf2b87cd801858146b2ba9",
    "url": "/img/02.eacba58f.png"
  },
  {
    "revision": "39d9e849fc1c724525f166646932a24d",
    "url": "/img/safari.39d9e849.png"
  },
  {
    "revision": "999589aae784a460b5e7c6ae9bbaa3d8",
    "url": "/img/06.999589aa.png"
  },
  {
    "revision": "942bd41631865c0c82c6615ff1b621f0",
    "url": "/index.html"
  },
  {
    "revision": "30b8be4fa86f28484ca4",
    "url": "/css/Layout.be4cf75c.css"
  },
  {
    "revision": "9ce16f441b39b493af8b96d7e97cce22",
    "url": "/MP_verify_dkzAKjxyVyJvsHMS.txt"
  },
  {
    "revision": "86c422d8c98b247235d04b49fb1c4b05",
    "url": "/MP_verify_bKSdn2qZlUSULliu.txt"
  },
  {
    "revision": "652317b098ca24e4511926c7fd57cbbe",
    "url": "/MP_verify_8JoCCldW78DygS5c.txt"
  },
  {
    "revision": "00bbf6b458bf7ea6bd01f443eb3045d9",
    "url": "/MP_verify_4r3DVk3KUjgWsQsG.txt"
  }
];