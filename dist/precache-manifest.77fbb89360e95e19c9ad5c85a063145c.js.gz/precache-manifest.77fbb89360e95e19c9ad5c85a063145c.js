self.__precacheManifest = [
  {
    "revision": "90e9338c3deb5fd373b6",
    "url": "/js/recharge_wrapper.83f14224.js"
  },
  {
    "revision": "b6216d61c03e6ce0c9aea6ca7808f7ca",
    "url": "/robots.txt"
  },
  {
    "revision": "73d4c8182be83985c645",
    "url": "/css/refundRules.522a2308.css"
  },
  {
    "revision": "486c88a173afee991629",
    "url": "/css/Layout~card_usage.c5af5c36.css"
  },
  {
    "revision": "f6fe50ccd582c459975e",
    "url": "/js/Layout~card_usage~eqReplaceMent~esim_plan_list~esim_usage~mifi_order~mifi_plan_list~mifi_plan_usage~~3166b5eb.91e2eec6.js"
  },
  {
    "revision": "29fa2271cd631de4db88",
    "url": "/css/Not_fund.e2fd00c5.css"
  },
  {
    "revision": "29fa2271cd631de4db88",
    "url": "/js/Not_fund.15ff5217.js"
  },
  {
    "revision": "51b19622d3e50ce36f80",
    "url": "/css/app.2608000f.css"
  },
  {
    "revision": "51b19622d3e50ce36f80",
    "url": "/js/app.f4a347bf.js"
  },
  {
    "revision": "c185900151efd6fcb935",
    "url": "/css/authority_middle.aaa01b3c.css"
  },
  {
    "revision": "c185900151efd6fcb935",
    "url": "/js/authority_middle.f2965761.js"
  },
  {
    "revision": "c80650524b78b120aa1a",
    "url": "/css/balanceIndex.ae729ff9.css"
  },
  {
    "revision": "c80650524b78b120aa1a",
    "url": "/js/balanceIndex.3ce05e92.js"
  },
  {
    "revision": "3aaca3c2bb04b693588e",
    "url": "/css/balanceRefund.2941cf62.css"
  },
  {
    "revision": "3aaca3c2bb04b693588e",
    "url": "/js/balanceRefund.061a58bc.js"
  },
  {
    "revision": "2682770c32b84ee41e43",
    "url": "/css/cardPackage.e90313c5.css"
  },
  {
    "revision": "2682770c32b84ee41e43",
    "url": "/js/cardPackage.b8074a7f.js"
  },
  {
    "revision": "770354dab07a9edcc004",
    "url": "/css/card_check.e0383461.css"
  },
  {
    "revision": "770354dab07a9edcc004",
    "url": "/js/card_check.dcc2efc9.js"
  },
  {
    "revision": "7a38382587d3f810d75f",
    "url": "/css/card_connection.b576c6c3.css"
  },
  {
    "revision": "7a38382587d3f810d75f",
    "url": "/js/card_connection.96bc9b76.js"
  },
  {
    "revision": "e054a71b9431de648063",
    "url": "/css/card_lookup.80488d14.css"
  },
  {
    "revision": "e054a71b9431de648063",
    "url": "/js/card_lookup.399174a7.js"
  },
  {
    "revision": "7659897ea19b6211f455",
    "url": "/css/card_more_flow.b52df8ea.css"
  },
  {
    "revision": "7659897ea19b6211f455",
    "url": "/js/card_more_flow.3c04bd67.js"
  },
  {
    "revision": "c407e1a4ecd912f6b868",
    "url": "/css/card_usage.3139af90.css"
  },
  {
    "revision": "c407e1a4ecd912f6b868",
    "url": "/js/card_usage.17e3131a.js"
  },
  {
    "revision": "57ea04cf4ea9f2d42499",
    "url": "/css/card_wrapper.5a54ff6c.css"
  },
  {
    "revision": "57ea04cf4ea9f2d42499",
    "url": "/js/card_wrapper.6e83ac25.js"
  },
  {
    "revision": "59f4ac443a2c17463ef7",
    "url": "/css/children_card.9d7e943b.css"
  },
  {
    "revision": "59f4ac443a2c17463ef7",
    "url": "/js/children_card.8e3b5d1b.js"
  },
  {
    "revision": "b5782244d9f91ed1daa8",
    "url": "/css/chunk-3d11f4f9.d4c62a7b.css"
  },
  {
    "revision": "b5782244d9f91ed1daa8",
    "url": "/js/chunk-3d11f4f9.7e644776.js"
  },
  {
    "revision": "c4d022a0a72ef3e058e6",
    "url": "/css/chunk-9f8fd7d4.e471d80a.css"
  },
  {
    "revision": "c4d022a0a72ef3e058e6",
    "url": "/js/chunk-9f8fd7d4.237cf6cf.js"
  },
  {
    "revision": "353ef19584d9dfdc1820",
    "url": "/css/chunk-vendors.187f45a9.css"
  },
  {
    "revision": "353ef19584d9dfdc1820",
    "url": "/js/chunk-vendors.8382c65f.js"
  },
  {
    "revision": "2d122bddff2d901e1df6",
    "url": "/css/commonProblem.16934f1e.css"
  },
  {
    "revision": "2d122bddff2d901e1df6",
    "url": "/js/commonProblem.87bd6b07.js"
  },
  {
    "revision": "0316fa5c02d8a6a152ff",
    "url": "/css/consumerRecord.fa42ce8a.css"
  },
  {
    "revision": "0316fa5c02d8a6a152ff",
    "url": "/js/consumerRecord.4f113c9b.js"
  },
  {
    "revision": "b4d4c2f1f34f1e073767",
    "url": "/css/coupon_normal.1a9a5f5b.css"
  },
  {
    "revision": "b4d4c2f1f34f1e073767",
    "url": "/js/coupon_normal.bdcd7643.js"
  },
  {
    "revision": "fa5cf3bf372c40c21b95",
    "url": "/css/coupon_telcom.3e944761.css"
  },
  {
    "revision": "fa5cf3bf372c40c21b95",
    "url": "/js/coupon_telcom.82cf3512.js"
  },
  {
    "revision": "7038396d09f71fff5727",
    "url": "/css/coupon_wrapper.ab43c2ce.css"
  },
  {
    "revision": "7038396d09f71fff5727",
    "url": "/js/coupon_wrapper.d9947991.js"
  },
  {
    "revision": "a5a8634fd8d27291f423",
    "url": "/css/currencyConversion.f65c76f3.css"
  },
  {
    "revision": "a5a8634fd8d27291f423",
    "url": "/js/currencyConversion.6d014834.js"
  },
  {
    "revision": "c013d45e760a3f1cfeb1",
    "url": "/css/eqReplaceMent.707c4d0a.css"
  },
  {
    "revision": "c013d45e760a3f1cfeb1",
    "url": "/js/eqReplaceMent.469854a6.js"
  },
  {
    "revision": "184d935e47d1b7dc1a51",
    "url": "/css/esim_plan_list.8d5537d4.css"
  },
  {
    "revision": "184d935e47d1b7dc1a51",
    "url": "/js/esim_plan_list.831dfc2a.js"
  },
  {
    "revision": "6d8c7d01fe8710548b72",
    "url": "/css/esim_usage.cccb02b2.css"
  },
  {
    "revision": "6d8c7d01fe8710548b72",
    "url": "/js/esim_usage.2ff249ee.js"
  },
  {
    "revision": "7948686cf61c3465eb3f",
    "url": "/css/find_plan.8469d7da.css"
  },
  {
    "revision": "7948686cf61c3465eb3f",
    "url": "/js/find_plan.ac5c0ea2.js"
  },
  {
    "revision": "f2850f560a4bfac0da91",
    "url": "/css/logical_page.412cdcf5.css"
  },
  {
    "revision": "f2850f560a4bfac0da91",
    "url": "/js/logical_page.0ba2d86f.js"
  },
  {
    "revision": "9af44f8dbedf696d523a",
    "url": "/css/login.db6eac3f.css"
  },
  {
    "revision": "9af44f8dbedf696d523a",
    "url": "/js/login.214a37a2.js"
  },
  {
    "revision": "6eb35db5c8070bad4b54",
    "url": "/css/lookup.a84a91e8.css"
  },
  {
    "revision": "6eb35db5c8070bad4b54",
    "url": "/js/lookup.c564a84e.js"
  },
  {
    "revision": "8daed29cf37a675d496c",
    "url": "/css/mifi_binding.24b68c5f.css"
  },
  {
    "revision": "8daed29cf37a675d496c",
    "url": "/js/mifi_binding.193b3849.js"
  },
  {
    "revision": "96c2290587725a69b575",
    "url": "/css/mifi_card_info.51068e21.css"
  },
  {
    "revision": "96c2290587725a69b575",
    "url": "/js/mifi_card_info.cba4892b.js"
  },
  {
    "revision": "d20b2fac7ea7c6016d9e",
    "url": "/css/mifi_card_lookup.fb21cc6f.css"
  },
  {
    "revision": "d20b2fac7ea7c6016d9e",
    "url": "/js/mifi_card_lookup.93766ddd.js"
  },
  {
    "revision": "ee876501682c4a2ec35a",
    "url": "/css/mifi_card_wrapper.d572d9dd.css"
  },
  {
    "revision": "ee876501682c4a2ec35a",
    "url": "/js/mifi_card_wrapper.a3e5eb15.js"
  },
  {
    "revision": "314c9b7e3ba162defcf5",
    "url": "/css/mifi_change_network.14a1a192.css"
  },
  {
    "revision": "314c9b7e3ba162defcf5",
    "url": "/js/mifi_change_network.36f255fe.js"
  },
  {
    "revision": "951df4c49f210285f7cd",
    "url": "/css/mifi_change_network_explanation.a5f99acb.css"
  },
  {
    "revision": "951df4c49f210285f7cd",
    "url": "/js/mifi_change_network_explanation.72f2c744.js"
  },
  {
    "revision": "558330101ed2e268d3d2",
    "url": "/css/mifi_coupon_index.fe4a3397.css"
  },
  {
    "revision": "558330101ed2e268d3d2",
    "url": "/js/mifi_coupon_index.d41f2cb6.js"
  },
  {
    "revision": "ce16eb19950bbc075d19",
    "url": "/css/mifi_coupon_wrapper.5ee9f40b.css"
  },
  {
    "revision": "ce16eb19950bbc075d19",
    "url": "/js/mifi_coupon_wrapper.791fdada.js"
  },
  {
    "revision": "43e61821f8a792539b1e",
    "url": "/css/mifi_index.ba5c3ed6.css"
  },
  {
    "revision": "43e61821f8a792539b1e",
    "url": "/js/mifi_index.c24b16a8.js"
  },
  {
    "revision": "4825a12b45a19e60f4d8",
    "url": "/css/mifi_layout.f1be9149.css"
  },
  {
    "revision": "4825a12b45a19e60f4d8",
    "url": "/js/mifi_layout.ef324738.js"
  },
  {
    "revision": "89a4e68f043bef4289eb",
    "url": "/css/mifi_order.cc663fbd.css"
  },
  {
    "revision": "89a4e68f043bef4289eb",
    "url": "/js/mifi_order.3964bff7.js"
  },
  {
    "revision": "e96276206e48270d0f1b",
    "url": "/css/mifi_order_wrapper.c537a243.css"
  },
  {
    "revision": "e96276206e48270d0f1b",
    "url": "/js/mifi_order_wrapper.45f1229c.js"
  },
  {
    "revision": "47dd43015500be3f9ac4",
    "url": "/css/mifi_order~mifi_plan_group.9b72222a.css"
  },
  {
    "revision": "47dd43015500be3f9ac4",
    "url": "/js/mifi_order~mifi_plan_group.8b8989db.js"
  },
  {
    "revision": "9c859d04c0677a7c92dd",
    "url": "/css/mifi_plan_group.976bed03.css"
  },
  {
    "revision": "9c859d04c0677a7c92dd",
    "url": "/js/mifi_plan_group.72471533.js"
  },
  {
    "revision": "2934d411711aa45804ba",
    "url": "/css/mifi_plan_list.465fea9b.css"
  },
  {
    "revision": "2934d411711aa45804ba",
    "url": "/js/mifi_plan_list.aa4131a3.js"
  },
  {
    "revision": "0541015620da39740d9d",
    "url": "/css/mifi_plan_usage.c50ed957.css"
  },
  {
    "revision": "0541015620da39740d9d",
    "url": "/js/mifi_plan_usage.b8777966.js"
  },
  {
    "revision": "4611a7071a5347669966",
    "url": "/css/mifi_plan_wrapper.8b393e56.css"
  },
  {
    "revision": "4611a7071a5347669966",
    "url": "/js/mifi_plan_wrapper.1355dd31.js"
  },
  {
    "revision": "2904cc856e9d9c7f0ad0",
    "url": "/css/new_card_wrapper.06a280b2.css"
  },
  {
    "revision": "2904cc856e9d9c7f0ad0",
    "url": "/js/new_card_wrapper.d31483c4.js"
  },
  {
    "revision": "d26ec8dbfc8a600cbdd5",
    "url": "/css/orderRecord.cb4c56f3.css"
  },
  {
    "revision": "d26ec8dbfc8a600cbdd5",
    "url": "/js/orderRecord.abf8d087.js"
  },
  {
    "revision": "7293d87bfc19a667a064",
    "url": "/css/plan_list.394f2231.css"
  },
  {
    "revision": "7293d87bfc19a667a064",
    "url": "/js/plan_list.22941832.js"
  },
  {
    "revision": "7127292609d9be94d23d",
    "url": "/css/question.b60f38fe.css"
  },
  {
    "revision": "7127292609d9be94d23d",
    "url": "/js/question.cda43f2b.js"
  },
  {
    "revision": "ce60d24fa749a307f15c",
    "url": "/css/question_wrapper.8ab9a0db.css"
  },
  {
    "revision": "ce60d24fa749a307f15c",
    "url": "/js/question_wrapper.133d9ef0.js"
  },
  {
    "revision": "f1b54ea5ce25447fde80",
    "url": "/css/realNameCourse.6bd3a228.css"
  },
  {
    "revision": "f1b54ea5ce25447fde80",
    "url": "/js/realNameCourse.6c4bd1dc.js"
  },
  {
    "revision": "1755553a39185da6305a",
    "url": "/css/real_name.2fd595b9.css"
  },
  {
    "revision": "1755553a39185da6305a",
    "url": "/js/real_name.297510d7.js"
  },
  {
    "revision": "1591260542bcba432ad2",
    "url": "/css/recharge.399abd51.css"
  },
  {
    "revision": "1591260542bcba432ad2",
    "url": "/js/recharge.4001e902.js"
  },
  {
    "revision": "ac7a6b5553d946841a8c",
    "url": "/css/rechargeOrder.96cb2d8d.css"
  },
  {
    "revision": "ac7a6b5553d946841a8c",
    "url": "/js/rechargeOrder.431a634a.js"
  },
  {
    "revision": "c38246e165d7f55092b7",
    "url": "/css/recharge_balance.af09dcc4.css"
  },
  {
    "revision": "c38246e165d7f55092b7",
    "url": "/js/recharge_balance.4f57cb66.js"
  },
  {
    "revision": "bae26ae9a2f58a5e6cee",
    "url": "/css/recharge_callback.c33c36e5.css"
  },
  {
    "revision": "bae26ae9a2f58a5e6cee",
    "url": "/js/recharge_callback.40303bbf.js"
  },
  {
    "revision": "90e9338c3deb5fd373b6",
    "url": "/css/recharge_wrapper.e8ef40fd.css"
  },
  {
    "revision": "3ef7698936209c8bd999",
    "url": "/js/Layout.72254531.js"
  },
  {
    "revision": "486c88a173afee991629",
    "url": "/js/Layout~card_usage.399408d8.js"
  },
  {
    "revision": "73d4c8182be83985c645",
    "url": "/js/refundRules.f95f5cd1.js"
  },
  {
    "revision": "2e6f28d93e05de5fbb2d",
    "url": "/css/refund_applying.9153be86.css"
  },
  {
    "revision": "2e6f28d93e05de5fbb2d",
    "url": "/js/refund_applying.7fe33ed8.js"
  },
  {
    "revision": "365b36d42032e92298c0",
    "url": "/css/refund_argument.134128d7.css"
  },
  {
    "revision": "365b36d42032e92298c0",
    "url": "/js/refund_argument.e3cb2f52.js"
  },
  {
    "revision": "50a2d3fe4b6d0481fe89",
    "url": "/css/refund_plan.300ce657.css"
  },
  {
    "revision": "50a2d3fe4b6d0481fe89",
    "url": "/js/refund_plan.4b57c93b.js"
  },
  {
    "revision": "19884767f8436f6be3e9",
    "url": "/css/refund_wrapper.f2324655.css"
  },
  {
    "revision": "19884767f8436f6be3e9",
    "url": "/js/refund_wrapper.c1c2bda7.js"
  },
  {
    "revision": "f7d5ac17d057b425a007",
    "url": "/css/repeatRecharge.8589a2c0.css"
  },
  {
    "revision": "f7d5ac17d057b425a007",
    "url": "/js/repeatRecharge.04cf60c1.js"
  },
  {
    "revision": "78f19ac834359b12f860",
    "url": "/css/revoke_plan.b047cad9.css"
  },
  {
    "revision": "78f19ac834359b12f860",
    "url": "/js/revoke_plan.f79a5ec0.js"
  },
  {
    "revision": "fcc9e2702809973c7f0d",
    "url": "/css/speedup_500.653f81f5.css"
  },
  {
    "revision": "fcc9e2702809973c7f0d",
    "url": "/js/speedup_500.28f35541.js"
  },
  {
    "revision": "6c9de49f6d4b80736abc",
    "url": "/css/speedup_80.0b0c3ab6.css"
  },
  {
    "revision": "6c9de49f6d4b80736abc",
    "url": "/js/speedup_80.30c07e27.js"
  },
  {
    "revision": "c4b5be14c484e98e12e1",
    "url": "/css/speedup_wrapper.707898e1.css"
  },
  {
    "revision": "c4b5be14c484e98e12e1",
    "url": "/js/speedup_wrapper.b4674906.js"
  },
  {
    "revision": "8c74c8157e678b035af3",
    "url": "/css/to_tb.03eb33ae.css"
  },
  {
    "revision": "8c74c8157e678b035af3",
    "url": "/js/to_tb.9d2365a3.js"
  },
  {
    "revision": "babf488b295c25e454db",
    "url": "/css/transfer_url.f90dd7e3.css"
  },
  {
    "revision": "babf488b295c25e454db",
    "url": "/js/transfer_url.29f578ea.js"
  },
  {
    "revision": "8d6650a3614f0ff5c778",
    "url": "/css/userCenter.3e24547d.css"
  },
  {
    "revision": "8d6650a3614f0ff5c778",
    "url": "/js/userCenter.b43834f3.js"
  },
  {
    "revision": "66da5a76c8350eabaf9b",
    "url": "/css/userCenterWrap.68383fe2.css"
  },
  {
    "revision": "66da5a76c8350eabaf9b",
    "url": "/js/userCenterWrap.8133be6f.js"
  },
  {
    "revision": "e4b411644706c29765eea3ffdd85ae39",
    "url": "/fonts/SourceHanSansCNRegular.e4b41164.woff"
  },
  {
    "revision": "834b022ab9ab0e6063904af32274e777",
    "url": "/fonts/SourceHanSansCNRegular.834b022a.eot"
  },
  {
    "revision": "f9509c5a10be7daaf1fa01922a7c6bc2",
    "url": "/fonts/SourceHanSansCNRegular.f9509c5a.ttf"
  },
  {
    "revision": "da0808e9fe85be160aab69c82dd8de1c",
    "url": "/img/SourceHanSansCNRegular.da0808e9.svg"
  },
  {
    "revision": "732389ded34cb9c52dd88271f1345af9",
    "url": "/fonts/element-icons.732389de.ttf"
  },
  {
    "revision": "535877f50039c0cb49a6196a5b7517cd",
    "url": "/fonts/element-icons.535877f5.woff"
  },
  {
    "revision": "f5f322478286641bd9887a155e35f222",
    "url": "/img/btn.f5f32247.png"
  },
  {
    "revision": "d140650fa64e0f1fc771610dba62aed7",
    "url": "/img/bg.d140650f.png"
  },
  {
    "revision": "fff5af4325410621aeec4e60b3b92d9b",
    "url": "/img/mifi_binding_bg@3x.fff5af43.png"
  },
  {
    "revision": "fff5af4325410621aeec4e60b3b92d9b",
    "url": "/img/mifi_binding_bg@2x.fff5af43.png"
  },
  {
    "revision": "e625229e32d9deeb5f2909c314d8e609",
    "url": "/img/ios@2x.e625229e.png"
  },
  {
    "revision": "af8bbdfa0a90c4eed4563f8c06ce5ff8",
    "url": "/img/android@2x.af8bbdfa.png"
  },
  {
    "revision": "4ecd943eb3a2c5c0890145b943c1c659",
    "url": "/img/85.4ecd943e.png"
  },
  {
    "revision": "fa855242805b87da42c65763acd64ac0",
    "url": "/img/bg-plan-type@2x.fa855242.png"
  },
  {
    "revision": "4a9ca192485effa8b8f4b5b2df5b9caf",
    "url": "/img/bg-plan-type@3x.4a9ca192.png"
  },
  {
    "revision": "1d7515ee61c3f659227318b4050955ed",
    "url": "/img/mobile_sim@2x.1d7515ee.png"
  },
  {
    "revision": "0f980b79d9a52702004de9f652a68835",
    "url": "/img/telcom_sim@2x.0f980b79.png"
  },
  {
    "revision": "98141226a7e992e3072a280746a259c4",
    "url": "/img/mobile_sim@3x.98141226.png"
  },
  {
    "revision": "0c88168b284b92c37f3a873f26a97d69",
    "url": "/img/bg.0c88168b.jpg"
  },
  {
    "revision": "9e02095f31a07b972244f1c714c1dfe7",
    "url": "/img/telcom_sim@3x.9e02095f.png"
  },
  {
    "revision": "3f342771b9b81ab929e0fbcbcd0e6533",
    "url": "/img/bg-check-wrap@3x.3f342771.png"
  },
  {
    "revision": "9713b21819c4019befecd095069977df",
    "url": "/img/bg-check-wrap@2x.9713b218.png"
  },
  {
    "revision": "b70eddccd257b21777e71bb64c83b876",
    "url": "/img/bg.b70eddcc.jpeg"
  },
  {
    "revision": "909816c3d34e63a9ad86b8c179ab543c",
    "url": "/img/bar.909816c3.png"
  },
  {
    "revision": "e92f547ba0209da3b4342fa2b56ea9ae",
    "url": "/img/animater.e92f547b.png"
  },
  {
    "revision": "3d0fc424b703032ca595090e99f8354b",
    "url": "/img/login_bg@2x.3d0fc424.png"
  },
  {
    "revision": "11000d4e510a6df565eb69ba6f2c1dfc",
    "url": "/img/login_bg@3x.11000d4e.png"
  },
  {
    "revision": "0f16389ec218c90cf8f657e233b745f2",
    "url": "/img/balanceBg1.0f16389e.png"
  },
  {
    "revision": "565459ef2ee8b71db421144ad21c23e3",
    "url": "/img/balanceBg2.565459ef.png"
  },
  {
    "revision": "91e1d2771efacd45e5e465d9a001f197",
    "url": "/img/liantong.91e1d277.png"
  },
  {
    "revision": "4a0cab0f33beb48ea985714d1b91fef7",
    "url": "/img/dianxin.4a0cab0f.png"
  },
  {
    "revision": "657033323334e91efb0011bbc18f8c04",
    "url": "/img/yidong.65703332.png"
  },
  {
    "revision": "8da3b83b73e44e54d6be4b2522bcb1f2",
    "url": "/img/pkgBg2.8da3b83b.png"
  },
  {
    "revision": "d3b42651f9f5048baeffb50c800913ec",
    "url": "/img/pkgBg1.d3b42651.png"
  },
  {
    "revision": "d461d18e42a310bd709b2ce97d159153",
    "url": "/img/pkgBg3.d461d18e.png"
  },
  {
    "revision": "014d354b9b25b67ae95857ba17e2f4cc",
    "url": "/img/activityPage.014d354b.png"
  },
  {
    "revision": "6dedd4943e4c5848638196fb6f0c4145",
    "url": "/img/bg.6dedd494.png"
  },
  {
    "revision": "0078f03c08066d51d64b92a13e194ebb",
    "url": "/img/balanceRefund.0078f03c.png"
  },
  {
    "revision": "af3ed0b3236bbfdbc3ad61b8d41c3dec",
    "url": "/img/changeBg.af3ed0b3.png"
  },
  {
    "revision": "2a67b73145562669220aa4639e1ad58f",
    "url": "/img/icon3.2a67b731.png"
  },
  {
    "revision": "813b5319e378dafdda952c16ad89906b",
    "url": "/img/icon2.813b5319.png"
  },
  {
    "revision": "f40c7e0b20fe25eb78a7658c3ae56312",
    "url": "/img/noData@3x.f40c7e0b.png"
  },
  {
    "revision": "644e6e3cf5f33943747b116316694e28",
    "url": "/img/noData@2x.644e6e3c.png"
  },
  {
    "revision": "42c0fbd4915870e5e60452fd0ef2cbec",
    "url": "/img/orderTopBg@3x.42c0fbd4.png"
  },
  {
    "revision": "42c0fbd4915870e5e60452fd0ef2cbec",
    "url": "/img/orderTopBg@2x.42c0fbd4.png"
  },
  {
    "revision": "01355f175bd20423ce45a838c1a998a9",
    "url": "/img/bg.01355f17.png"
  },
  {
    "revision": "b899232b79ad9962c5ab5572775a0400",
    "url": "/img/card_index_bg@3x.b899232b.png"
  },
  {
    "revision": "b899232b79ad9962c5ab5572775a0400",
    "url": "/img/card_index_bg@2x.b899232b.png"
  },
  {
    "revision": "6e5cee7393060b0ec3dcd587c2518b94",
    "url": "/img/bg_test.6e5cee73.png"
  },
  {
    "revision": "d0ccbc8a35180bb40e027b44dd26035a",
    "url": "/img/youku.d0ccbc8a.png"
  },
  {
    "revision": "a859e9ca4606d567c42b9c7bcd4fdce9",
    "url": "/img/iccid_bg@2x.a859e9ca.png"
  },
  {
    "revision": "fa9050c4e9870e8fc0cd184f8515af4a",
    "url": "/img/iccid_bg@3x.fa9050c4.png"
  },
  {
    "revision": "2c51a1e53c1ea0b35086d8d7261b4933",
    "url": "/img/bg_network@3x.2c51a1e5.png"
  },
  {
    "revision": "32d70c8fc305e3647098f3de0c71b618",
    "url": "/img/bg_network@2x.32d70c8f.png"
  },
  {
    "revision": "114a6e12b42b9b48586dd341105188fe",
    "url": "/img/usedOrder@2x.114a6e12.png"
  },
  {
    "revision": "c0170ec299b2418256fd515ee7849055",
    "url": "/img/unUsedOrder@2x.c0170ec2.png"
  },
  {
    "revision": "d9e14058d30dd312519fcf2de38d742b",
    "url": "/img/unUsedOrder@3x.d9e14058.png"
  },
  {
    "revision": "4a5b90f8076955f289b3dcda6a5af6ff",
    "url": "/img/invaildedOrder@3x.4a5b90f8.png"
  },
  {
    "revision": "0d5a5158e67bcb7a4604124715ed6fbf",
    "url": "/img/usedOrder@3x.0d5a5158.png"
  },
  {
    "revision": "be0f1e33b2553e71b117d3d3f838d32f",
    "url": "/img/invaildedOrder@2x.be0f1e33.png"
  },
  {
    "revision": "3603a35a49dbb8ad94ec1e57c4dad229",
    "url": "/img/scanTop2.3603a35a.png"
  },
  {
    "revision": "05775dd69c53d7273b27aaa7c6c523f7",
    "url": "/img/04.05775dd6.png"
  },
  {
    "revision": "541375e6bb7db2fba9e415be8045f5fb",
    "url": "/img/1.541375e6.png"
  },
  {
    "revision": "7c28431d304fa4f58f5070c59720683a",
    "url": "/img/2.7c28431d.png"
  },
  {
    "revision": "5a3428653945c17e1c146efeee81c987",
    "url": "/img/scanTop.5a342865.png"
  },
  {
    "revision": "824594523c01e48028f2b7eb4261134d",
    "url": "/img/unicom-logo.82459452.svg"
  },
  {
    "revision": "113f99e2189c2ca49db2168754fc2eb5",
    "url": "/img/mobile-logo.113f99e2.png"
  },
  {
    "revision": "0cba868fa977e09806638b9000636a36",
    "url": "/img/avatar.0cba868f.jpeg"
  },
  {
    "revision": "27158aa79eb0d4b89f317d076a801ca3",
    "url": "/img/coupon-log.27158aa7.png"
  },
  {
    "revision": "55d3f2f09efe17db6485d4c9f8f0c3b1",
    "url": "/img/icon-recharge_20181001.55d3f2f0.svg"
  },
  {
    "revision": "165beb68d8ba0d2b70df0fbb3769787a",
    "url": "/img/03.165beb68.png"
  },
  {
    "revision": "5f1f34037094c0613bccafa2ddd8cb3b",
    "url": "/img/telecom-logo.5f1f3403.svg"
  },
  {
    "revision": "0b3c3297decbd1152a314cce115f9632",
    "url": "/img/09.0b3c3297.png"
  },
  {
    "revision": "3e217df4202e41ad9b030aafc8cfcc24",
    "url": "/img/4.3e217df4.png"
  },
  {
    "revision": "aecc9531f2c3b1fd45338e7bf5084384",
    "url": "/img/bg_no_recharge.aecc9531.svg"
  },
  {
    "revision": "b0ffa4a0fd195a110ee4d4dabce3bc32",
    "url": "/img/08.b0ffa4a0.png"
  },
  {
    "revision": "96fab583abd57f2e7118324858fa3080",
    "url": "/img/05.96fab583.png"
  },
  {
    "revision": "9e8ecc7f7b760b55c56bddfab886da10",
    "url": "/img/3.9e8ecc7f.png"
  },
  {
    "revision": "275be51ae57c486bce58257febd6589f",
    "url": "/img/bg_no_plan.275be51a.svg"
  },
  {
    "revision": "a8272d2d742d9d50257e23dfac577def",
    "url": "/img/01.a8272d2d.png"
  },
  {
    "revision": "daa86b540bb9c2a6453ceac9bed77961",
    "url": "/img/07.daa86b54.png"
  },
  {
    "revision": "06385746a7cedb492d5539907631561c",
    "url": "/img/tip.06385746.png"
  },
  {
    "revision": "eacba58f9acf2b87cd801858146b2ba9",
    "url": "/img/02.eacba58f.png"
  },
  {
    "revision": "39d9e849fc1c724525f166646932a24d",
    "url": "/img/safari.39d9e849.png"
  },
  {
    "revision": "999589aae784a460b5e7c6ae9bbaa3d8",
    "url": "/img/06.999589aa.png"
  },
  {
    "revision": "701a18628210dd5e3727392de0e73edd",
    "url": "/index.html"
  },
  {
    "revision": "3ef7698936209c8bd999",
    "url": "/css/Layout.cb7ba494.css"
  },
  {
    "revision": "9ce16f441b39b493af8b96d7e97cce22",
    "url": "/MP_verify_dkzAKjxyVyJvsHMS.txt"
  },
  {
    "revision": "86c422d8c98b247235d04b49fb1c4b05",
    "url": "/MP_verify_bKSdn2qZlUSULliu.txt"
  },
  {
    "revision": "652317b098ca24e4511926c7fd57cbbe",
    "url": "/MP_verify_8JoCCldW78DygS5c.txt"
  },
  {
    "revision": "00bbf6b458bf7ea6bd01f443eb3045d9",
    "url": "/MP_verify_4r3DVk3KUjgWsQsG.txt"
  }
];