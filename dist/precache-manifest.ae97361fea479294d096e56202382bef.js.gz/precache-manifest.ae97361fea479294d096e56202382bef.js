self.__precacheManifest = [
  {
    "revision": "619b660c124be1285778",
    "url": "/js/recharge_wrapper.bd609ed7.js"
  },
  {
    "revision": "90a35463b685efaa3a84",
    "url": "/css/Layout.6f67a32f.css"
  },
  {
    "revision": "10679cd21017d22a21aa",
    "url": "/css/Layout~card_usage.8ac0b02d.css"
  },
  {
    "revision": "10679cd21017d22a21aa",
    "url": "/js/Layout~card_usage.20fe43c5.js"
  },
  {
    "revision": "f6fe50ccd582c459975e",
    "url": "/js/Layout~card_usage~eqReplaceMent~esim_plan_list~esim_usage~mifi_order~mifi_plan_list~mifi_plan_usage~~3166b5eb.91e2eec6.js"
  },
  {
    "revision": "469ba3f1f3cab05fab8c",
    "url": "/css/Not_fund.5c52a0eb.css"
  },
  {
    "revision": "469ba3f1f3cab05fab8c",
    "url": "/js/Not_fund.0c5ed069.js"
  },
  {
    "revision": "3f563faa601a742b6609",
    "url": "/css/app.72184c26.css"
  },
  {
    "revision": "3f563faa601a742b6609",
    "url": "/js/app.fae64163.js"
  },
  {
    "revision": "cfa32c570c3df3065414",
    "url": "/css/authority_middle.5c8a31a6.css"
  },
  {
    "revision": "cfa32c570c3df3065414",
    "url": "/js/authority_middle.06b0b293.js"
  },
  {
    "revision": "7e970cf903a173e6beee",
    "url": "/css/balanceIndex.979a25f6.css"
  },
  {
    "revision": "7e970cf903a173e6beee",
    "url": "/js/balanceIndex.d755cc04.js"
  },
  {
    "revision": "eee96561470ff32d59df",
    "url": "/css/balanceRefund.2941cf62.css"
  },
  {
    "revision": "eee96561470ff32d59df",
    "url": "/js/balanceRefund.87c1b985.js"
  },
  {
    "revision": "28b986e115b7bf423ae9",
    "url": "/css/cardPackage.66e3bbb5.css"
  },
  {
    "revision": "28b986e115b7bf423ae9",
    "url": "/js/cardPackage.6a053155.js"
  },
  {
    "revision": "b037e21a3f291766e113",
    "url": "/css/card_check.31896919.css"
  },
  {
    "revision": "b037e21a3f291766e113",
    "url": "/js/card_check.2d0dd6f1.js"
  },
  {
    "revision": "6792a75ed55d45ab1105",
    "url": "/css/card_connection.470ee167.css"
  },
  {
    "revision": "6792a75ed55d45ab1105",
    "url": "/js/card_connection.877f2d27.js"
  },
  {
    "revision": "91549cb251b6854e08ae",
    "url": "/css/card_lookup.5ad4c8c6.css"
  },
  {
    "revision": "91549cb251b6854e08ae",
    "url": "/js/card_lookup.e07e3fe7.js"
  },
  {
    "revision": "245edf6f0dee1e29dae1",
    "url": "/css/card_more_flow.299a007b.css"
  },
  {
    "revision": "245edf6f0dee1e29dae1",
    "url": "/js/card_more_flow.61cee28b.js"
  },
  {
    "revision": "e5a3fe144b5e3cac40f6",
    "url": "/css/card_usage.dea230c8.css"
  },
  {
    "revision": "e5a3fe144b5e3cac40f6",
    "url": "/js/card_usage.ed3caa87.js"
  },
  {
    "revision": "0e1039d3aa563473d5e0",
    "url": "/css/card_wrapper.3cc70882.css"
  },
  {
    "revision": "0e1039d3aa563473d5e0",
    "url": "/js/card_wrapper.4d60c1d1.js"
  },
  {
    "revision": "c3a4b710fb8102815a0c",
    "url": "/css/children_card.a8e1936c.css"
  },
  {
    "revision": "c3a4b710fb8102815a0c",
    "url": "/js/children_card.ff7b434a.js"
  },
  {
    "revision": "7471abcb4a365a54ed47",
    "url": "/css/chunk-3b5d1c5a.8a3eaae5.css"
  },
  {
    "revision": "7471abcb4a365a54ed47",
    "url": "/js/chunk-3b5d1c5a.43e50b1a.js"
  },
  {
    "revision": "bf74faa25cf58281beaf",
    "url": "/css/chunk-9efc694a.08caf37f.css"
  },
  {
    "revision": "bf74faa25cf58281beaf",
    "url": "/js/chunk-9efc694a.4705ddb1.js"
  },
  {
    "revision": "cd79ca3a12173f7fb9ec",
    "url": "/css/chunk-vendors.3b71a034.css"
  },
  {
    "revision": "cd79ca3a12173f7fb9ec",
    "url": "/js/chunk-vendors.10650154.js"
  },
  {
    "revision": "842962822122d757a4e1",
    "url": "/css/commonProblem.52e28e63.css"
  },
  {
    "revision": "842962822122d757a4e1",
    "url": "/js/commonProblem.19d565db.js"
  },
  {
    "revision": "b1bffc26a2a1aaa123f7",
    "url": "/css/consumerRecord.5f0837f3.css"
  },
  {
    "revision": "b1bffc26a2a1aaa123f7",
    "url": "/js/consumerRecord.eab9f2e0.js"
  },
  {
    "revision": "1b121c22631f8e78ebcc",
    "url": "/css/coupon_normal.758858d4.css"
  },
  {
    "revision": "1b121c22631f8e78ebcc",
    "url": "/js/coupon_normal.fb927bb6.js"
  },
  {
    "revision": "4ed4fd94ab32990d4247",
    "url": "/css/coupon_telcom.1a9a5f5b.css"
  },
  {
    "revision": "4ed4fd94ab32990d4247",
    "url": "/js/coupon_telcom.e0a12b9c.js"
  },
  {
    "revision": "849028204c921e6f7dad",
    "url": "/css/coupon_wrapper.7421536f.css"
  },
  {
    "revision": "849028204c921e6f7dad",
    "url": "/js/coupon_wrapper.367387ad.js"
  },
  {
    "revision": "cc55f3abbb91de84eb0a",
    "url": "/css/currencyConversion.f65c76f3.css"
  },
  {
    "revision": "cc55f3abbb91de84eb0a",
    "url": "/js/currencyConversion.584bae8e.js"
  },
  {
    "revision": "edd51174575c40a5ad21",
    "url": "/css/eqReplaceMent.d910c4a2.css"
  },
  {
    "revision": "edd51174575c40a5ad21",
    "url": "/js/eqReplaceMent.01e2bf3a.js"
  },
  {
    "revision": "7efd0b3556a0252dc0ae",
    "url": "/css/eqReplaceMent~recharge.ef42756d.css"
  },
  {
    "revision": "7efd0b3556a0252dc0ae",
    "url": "/js/eqReplaceMent~recharge.d4b8d088.js"
  },
  {
    "revision": "647c66b035334b0b9473",
    "url": "/css/esim_plan_list.3cc986ad.css"
  },
  {
    "revision": "647c66b035334b0b9473",
    "url": "/js/esim_plan_list.75ed3c1d.js"
  },
  {
    "revision": "df961810579d685d5f0d",
    "url": "/css/esim_usage.8f768238.css"
  },
  {
    "revision": "df961810579d685d5f0d",
    "url": "/js/esim_usage.1bf3d0d0.js"
  },
  {
    "revision": "5e77e0ae5dcc51376302",
    "url": "/css/find_plan.4e069844.css"
  },
  {
    "revision": "5e77e0ae5dcc51376302",
    "url": "/js/find_plan.71bb877a.js"
  },
  {
    "revision": "4ebe8d702e2f09b18225",
    "url": "/css/logical_page.2c75593d.css"
  },
  {
    "revision": "4ebe8d702e2f09b18225",
    "url": "/js/logical_page.cdb9e206.js"
  },
  {
    "revision": "975413163d6be16599a0",
    "url": "/css/login.96c40e5c.css"
  },
  {
    "revision": "975413163d6be16599a0",
    "url": "/js/login.59aa416f.js"
  },
  {
    "revision": "318e66f8ca418c28fe39",
    "url": "/css/lookup.ca3ad503.css"
  },
  {
    "revision": "318e66f8ca418c28fe39",
    "url": "/js/lookup.a89d2a0c.js"
  },
  {
    "revision": "7e4c8b120b911ef90b6d",
    "url": "/css/mifi_binding.41bda0b2.css"
  },
  {
    "revision": "7e4c8b120b911ef90b6d",
    "url": "/js/mifi_binding.0e97646a.js"
  },
  {
    "revision": "4dc4ba7a3f5e94fe0e71",
    "url": "/css/mifi_card_info.1dd44615.css"
  },
  {
    "revision": "4dc4ba7a3f5e94fe0e71",
    "url": "/js/mifi_card_info.0535f676.js"
  },
  {
    "revision": "f7acf710f0985fe5405b",
    "url": "/css/mifi_card_lookup.0967a44a.css"
  },
  {
    "revision": "f7acf710f0985fe5405b",
    "url": "/js/mifi_card_lookup.bf5f09c7.js"
  },
  {
    "revision": "170c9d70faf50533a612",
    "url": "/css/mifi_card_wrapper.eeb3aab7.css"
  },
  {
    "revision": "170c9d70faf50533a612",
    "url": "/js/mifi_card_wrapper.7a93668a.js"
  },
  {
    "revision": "2c62d3db7fe18c156406",
    "url": "/css/mifi_change_network.f8e58697.css"
  },
  {
    "revision": "2c62d3db7fe18c156406",
    "url": "/js/mifi_change_network.4bdd632d.js"
  },
  {
    "revision": "951df4c49f210285f7cd",
    "url": "/css/mifi_change_network_explanation.a5f99acb.css"
  },
  {
    "revision": "951df4c49f210285f7cd",
    "url": "/js/mifi_change_network_explanation.72f2c744.js"
  },
  {
    "revision": "1f91a5c9168cfc900560",
    "url": "/css/mifi_coupon_index.fe4a3397.css"
  },
  {
    "revision": "1f91a5c9168cfc900560",
    "url": "/js/mifi_coupon_index.e25cef3c.js"
  },
  {
    "revision": "ce16eb19950bbc075d19",
    "url": "/css/mifi_coupon_wrapper.5ee9f40b.css"
  },
  {
    "revision": "ce16eb19950bbc075d19",
    "url": "/js/mifi_coupon_wrapper.791fdada.js"
  },
  {
    "revision": "c261d2c9d4a278c458b7",
    "url": "/css/mifi_index.ad559168.css"
  },
  {
    "revision": "c261d2c9d4a278c458b7",
    "url": "/js/mifi_index.53b5a76b.js"
  },
  {
    "revision": "768f8ce529e0c1a0bb5c",
    "url": "/css/mifi_layout.64431227.css"
  },
  {
    "revision": "768f8ce529e0c1a0bb5c",
    "url": "/js/mifi_layout.4eabda6d.js"
  },
  {
    "revision": "0aa760137648280b38f0",
    "url": "/css/mifi_order.e3038562.css"
  },
  {
    "revision": "0aa760137648280b38f0",
    "url": "/js/mifi_order.fff989a8.js"
  },
  {
    "revision": "69758578002c114500c9",
    "url": "/css/mifi_order_wrapper.56a3339d.css"
  },
  {
    "revision": "69758578002c114500c9",
    "url": "/js/mifi_order_wrapper.9b6be3de.js"
  },
  {
    "revision": "a1058e8794fd3852102f",
    "url": "/css/mifi_plan_group.6b89e007.css"
  },
  {
    "revision": "a1058e8794fd3852102f",
    "url": "/js/mifi_plan_group.4d4cc3cd.js"
  },
  {
    "revision": "921c59e35ae6de7b8307",
    "url": "/css/mifi_plan_list.ef3617fd.css"
  },
  {
    "revision": "921c59e35ae6de7b8307",
    "url": "/js/mifi_plan_list.125fd9e4.js"
  },
  {
    "revision": "8571ca746327612ed633",
    "url": "/css/mifi_plan_usage.20d42f05.css"
  },
  {
    "revision": "8571ca746327612ed633",
    "url": "/js/mifi_plan_usage.fec31204.js"
  },
  {
    "revision": "c667e184a88fc64dafb3",
    "url": "/css/mifi_plan_wrapper.80fa7896.css"
  },
  {
    "revision": "c667e184a88fc64dafb3",
    "url": "/js/mifi_plan_wrapper.7fc8c82a.js"
  },
  {
    "revision": "9fe9b70dedfef1ba3922",
    "url": "/css/new_card_wrapper.552c75ad.css"
  },
  {
    "revision": "9fe9b70dedfef1ba3922",
    "url": "/js/new_card_wrapper.ba92a897.js"
  },
  {
    "revision": "f0e0aa1ebb5ac47d66f2",
    "url": "/css/orderRecord.22600eb7.css"
  },
  {
    "revision": "f0e0aa1ebb5ac47d66f2",
    "url": "/js/orderRecord.6a8f8249.js"
  },
  {
    "revision": "c27eb6f2c24975890977",
    "url": "/css/plan_list.b2f5a8a8.css"
  },
  {
    "revision": "c27eb6f2c24975890977",
    "url": "/js/plan_list.3aca79ce.js"
  },
  {
    "revision": "1dd6f990ae604a09ef98",
    "url": "/css/question.cdbd374f.css"
  },
  {
    "revision": "1dd6f990ae604a09ef98",
    "url": "/js/question.675b6bfd.js"
  },
  {
    "revision": "60800012c7c2271123a0",
    "url": "/css/question_wrapper.12696ad3.css"
  },
  {
    "revision": "60800012c7c2271123a0",
    "url": "/js/question_wrapper.b423f2e3.js"
  },
  {
    "revision": "512dc9577f9686ce3350",
    "url": "/css/realNameCourse.17a25c8d.css"
  },
  {
    "revision": "512dc9577f9686ce3350",
    "url": "/js/realNameCourse.683a7825.js"
  },
  {
    "revision": "830cb7db8527872ce230",
    "url": "/css/real_name.6fb4f04a.css"
  },
  {
    "revision": "830cb7db8527872ce230",
    "url": "/js/real_name.df32d8ea.js"
  },
  {
    "revision": "3ddeca3df90bdf3d89f0",
    "url": "/css/recharge.55841b6c.css"
  },
  {
    "revision": "3ddeca3df90bdf3d89f0",
    "url": "/js/recharge.407b8f4c.js"
  },
  {
    "revision": "e27fa1f9067e7bf2344c",
    "url": "/css/rechargeOrder.d4068f20.css"
  },
  {
    "revision": "e27fa1f9067e7bf2344c",
    "url": "/js/rechargeOrder.0388d7a5.js"
  },
  {
    "revision": "091a4b6656761f56df99",
    "url": "/css/recharge_balance.624f0a27.css"
  },
  {
    "revision": "091a4b6656761f56df99",
    "url": "/js/recharge_balance.ff934962.js"
  },
  {
    "revision": "9f034798e84decbd3345",
    "url": "/css/recharge_callback.1a6cf6aa.css"
  },
  {
    "revision": "9f034798e84decbd3345",
    "url": "/js/recharge_callback.e005cf87.js"
  },
  {
    "revision": "619b660c124be1285778",
    "url": "/css/recharge_wrapper.a4f6c950.css"
  },
  {
    "revision": "90a35463b685efaa3a84",
    "url": "/js/Layout.ffe69126.js"
  },
  {
    "revision": "509fcca0880128969718",
    "url": "/css/refundRules.4bbcf20a.css"
  },
  {
    "revision": "509fcca0880128969718",
    "url": "/js/refundRules.40b52e95.js"
  },
  {
    "revision": "c0c94f6d9f0a8d327248",
    "url": "/css/refund_applying.c0165179.css"
  },
  {
    "revision": "c0c94f6d9f0a8d327248",
    "url": "/js/refund_applying.5c887b22.js"
  },
  {
    "revision": "a056bbddc8f09df15510",
    "url": "/css/refund_argument.ea8a95cb.css"
  },
  {
    "revision": "a056bbddc8f09df15510",
    "url": "/js/refund_argument.4c8f902e.js"
  },
  {
    "revision": "3675dc0463a75d5bdf02",
    "url": "/css/refund_plan.19312613.css"
  },
  {
    "revision": "3675dc0463a75d5bdf02",
    "url": "/js/refund_plan.053571a2.js"
  },
  {
    "revision": "4a9aa49f4d70a5bbe990",
    "url": "/css/refund_wrapper.9829766a.css"
  },
  {
    "revision": "4a9aa49f4d70a5bbe990",
    "url": "/js/refund_wrapper.94315a82.js"
  },
  {
    "revision": "d73e371339f8181c1558",
    "url": "/css/repeatRecharge.f0851fc9.css"
  },
  {
    "revision": "d73e371339f8181c1558",
    "url": "/js/repeatRecharge.c0738bc5.js"
  },
  {
    "revision": "607a1cda6f4d44b356d7",
    "url": "/css/revoke_plan.e6cc5cca.css"
  },
  {
    "revision": "607a1cda6f4d44b356d7",
    "url": "/js/revoke_plan.06ff6f1b.js"
  },
  {
    "revision": "18e2666450e163ba3945",
    "url": "/css/speedup_500.0b0c3ab6.css"
  },
  {
    "revision": "18e2666450e163ba3945",
    "url": "/js/speedup_500.80acc22f.js"
  },
  {
    "revision": "bb1e29f33e82a2f5ef42",
    "url": "/css/speedup_80.f9c8f705.css"
  },
  {
    "revision": "bb1e29f33e82a2f5ef42",
    "url": "/js/speedup_80.83b09b78.js"
  },
  {
    "revision": "3e32ad13b7875319cf2f",
    "url": "/css/speedup_wrapper.31258838.css"
  },
  {
    "revision": "3e32ad13b7875319cf2f",
    "url": "/js/speedup_wrapper.c1f09ef8.js"
  },
  {
    "revision": "a9104f2ccf58d4665d9c",
    "url": "/css/to_tb.1a98473a.css"
  },
  {
    "revision": "a9104f2ccf58d4665d9c",
    "url": "/js/to_tb.469a8ae6.js"
  },
  {
    "revision": "f9b870e571202b37d0ef",
    "url": "/css/transfer_url.f6ebbdb1.css"
  },
  {
    "revision": "f9b870e571202b37d0ef",
    "url": "/js/transfer_url.ebb15ac8.js"
  },
  {
    "revision": "e2f8739b7f464d86151c",
    "url": "/css/userCenter.3e24547d.css"
  },
  {
    "revision": "e2f8739b7f464d86151c",
    "url": "/js/userCenter.e428365d.js"
  },
  {
    "revision": "d6e634e40c130bd70a92",
    "url": "/css/userCenterWrap.68383fe2.css"
  },
  {
    "revision": "d6e634e40c130bd70a92",
    "url": "/js/userCenterWrap.4f1962c2.js"
  },
  {
    "revision": "e4b411644706c29765eea3ffdd85ae39",
    "url": "/fonts/SourceHanSansCNRegular.e4b41164.woff"
  },
  {
    "revision": "834b022ab9ab0e6063904af32274e777",
    "url": "/fonts/SourceHanSansCNRegular.834b022a.eot"
  },
  {
    "revision": "f9509c5a10be7daaf1fa01922a7c6bc2",
    "url": "/fonts/SourceHanSansCNRegular.f9509c5a.ttf"
  },
  {
    "revision": "da0808e9fe85be160aab69c82dd8de1c",
    "url": "/img/SourceHanSansCNRegular.da0808e9.svg"
  },
  {
    "revision": "732389ded34cb9c52dd88271f1345af9",
    "url": "/fonts/element-icons.732389de.ttf"
  },
  {
    "revision": "535877f50039c0cb49a6196a5b7517cd",
    "url": "/fonts/element-icons.535877f5.woff"
  },
  {
    "revision": "0f16389ec218c90cf8f657e233b745f2",
    "url": "/img/balanceBg1.0f16389e.png"
  },
  {
    "revision": "565459ef2ee8b71db421144ad21c23e3",
    "url": "/img/balanceBg2.565459ef.png"
  },
  {
    "revision": "f5f322478286641bd9887a155e35f222",
    "url": "/img/btn.f5f32247.png"
  },
  {
    "revision": "d140650fa64e0f1fc771610dba62aed7",
    "url": "/img/bg.d140650f.png"
  },
  {
    "revision": "e625229e32d9deeb5f2909c314d8e609",
    "url": "/img/ios@2x.e625229e.png"
  },
  {
    "revision": "af8bbdfa0a90c4eed4563f8c06ce5ff8",
    "url": "/img/android@2x.af8bbdfa.png"
  },
  {
    "revision": "4ecd943eb3a2c5c0890145b943c1c659",
    "url": "/img/85.4ecd943e.png"
  },
  {
    "revision": "fa855242805b87da42c65763acd64ac0",
    "url": "/img/bg-plan-type@2x.fa855242.png"
  },
  {
    "revision": "4a9ca192485effa8b8f4b5b2df5b9caf",
    "url": "/img/bg-plan-type@3x.4a9ca192.png"
  },
  {
    "revision": "3f342771b9b81ab929e0fbcbcd0e6533",
    "url": "/img/bg-check-wrap@3x.3f342771.png"
  },
  {
    "revision": "9713b21819c4019befecd095069977df",
    "url": "/img/bg-check-wrap@2x.9713b218.png"
  },
  {
    "revision": "1d7515ee61c3f659227318b4050955ed",
    "url": "/img/mobile_sim@2x.1d7515ee.png"
  },
  {
    "revision": "0f980b79d9a52702004de9f652a68835",
    "url": "/img/telcom_sim@2x.0f980b79.png"
  },
  {
    "revision": "98141226a7e992e3072a280746a259c4",
    "url": "/img/mobile_sim@3x.98141226.png"
  },
  {
    "revision": "0c88168b284b92c37f3a873f26a97d69",
    "url": "/img/bg.0c88168b.jpg"
  },
  {
    "revision": "9e02095f31a07b972244f1c714c1dfe7",
    "url": "/img/telcom_sim@3x.9e02095f.png"
  },
  {
    "revision": "b70eddccd257b21777e71bb64c83b876",
    "url": "/img/bg.b70eddcc.jpeg"
  },
  {
    "revision": "909816c3d34e63a9ad86b8c179ab543c",
    "url": "/img/bar.909816c3.png"
  },
  {
    "revision": "e92f547ba0209da3b4342fa2b56ea9ae",
    "url": "/img/animater.e92f547b.png"
  },
  {
    "revision": "3d0fc424b703032ca595090e99f8354b",
    "url": "/img/login_bg@2x.3d0fc424.png"
  },
  {
    "revision": "11000d4e510a6df565eb69ba6f2c1dfc",
    "url": "/img/login_bg@3x.11000d4e.png"
  },
  {
    "revision": "91e1d2771efacd45e5e465d9a001f197",
    "url": "/img/liantong.91e1d277.png"
  },
  {
    "revision": "4a0cab0f33beb48ea985714d1b91fef7",
    "url": "/img/dianxin.4a0cab0f.png"
  },
  {
    "revision": "657033323334e91efb0011bbc18f8c04",
    "url": "/img/yidong.65703332.png"
  },
  {
    "revision": "8da3b83b73e44e54d6be4b2522bcb1f2",
    "url": "/img/pkgBg2.8da3b83b.png"
  },
  {
    "revision": "d3b42651f9f5048baeffb50c800913ec",
    "url": "/img/pkgBg1.d3b42651.png"
  },
  {
    "revision": "d461d18e42a310bd709b2ce97d159153",
    "url": "/img/pkgBg3.d461d18e.png"
  },
  {
    "revision": "6dedd4943e4c5848638196fb6f0c4145",
    "url": "/img/bg.6dedd494.png"
  },
  {
    "revision": "0078f03c08066d51d64b92a13e194ebb",
    "url": "/img/balanceRefund.0078f03c.png"
  },
  {
    "revision": "af3ed0b3236bbfdbc3ad61b8d41c3dec",
    "url": "/img/changeBg.af3ed0b3.png"
  },
  {
    "revision": "014d354b9b25b67ae95857ba17e2f4cc",
    "url": "/img/activityPage.014d354b.png"
  },
  {
    "revision": "f40c7e0b20fe25eb78a7658c3ae56312",
    "url": "/img/noData@3x.f40c7e0b.png"
  },
  {
    "revision": "644e6e3cf5f33943747b116316694e28",
    "url": "/img/noData@2x.644e6e3c.png"
  },
  {
    "revision": "2a67b73145562669220aa4639e1ad58f",
    "url": "/img/icon3.2a67b731.png"
  },
  {
    "revision": "813b5319e378dafdda952c16ad89906b",
    "url": "/img/icon2.813b5319.png"
  },
  {
    "revision": "42c0fbd4915870e5e60452fd0ef2cbec",
    "url": "/img/orderTopBg@3x.42c0fbd4.png"
  },
  {
    "revision": "42c0fbd4915870e5e60452fd0ef2cbec",
    "url": "/img/orderTopBg@2x.42c0fbd4.png"
  },
  {
    "revision": "01355f175bd20423ce45a838c1a998a9",
    "url": "/img/bg.01355f17.png"
  },
  {
    "revision": "a859e9ca4606d567c42b9c7bcd4fdce9",
    "url": "/img/iccid_bg@2x.a859e9ca.png"
  },
  {
    "revision": "fa9050c4e9870e8fc0cd184f8515af4a",
    "url": "/img/iccid_bg@3x.fa9050c4.png"
  },
  {
    "revision": "6e5cee7393060b0ec3dcd587c2518b94",
    "url": "/img/bg_test.6e5cee73.png"
  },
  {
    "revision": "d0ccbc8a35180bb40e027b44dd26035a",
    "url": "/img/youku.d0ccbc8a.png"
  },
  {
    "revision": "fff5af4325410621aeec4e60b3b92d9b",
    "url": "/img/mifi_binding_bg@3x.fff5af43.png"
  },
  {
    "revision": "fff5af4325410621aeec4e60b3b92d9b",
    "url": "/img/mifi_binding_bg@2x.fff5af43.png"
  },
  {
    "revision": "2c51a1e53c1ea0b35086d8d7261b4933",
    "url": "/img/bg_network@3x.2c51a1e5.png"
  },
  {
    "revision": "32d70c8fc305e3647098f3de0c71b618",
    "url": "/img/bg_network@2x.32d70c8f.png"
  },
  {
    "revision": "b899232b79ad9962c5ab5572775a0400",
    "url": "/img/card_index_bg@3x.b899232b.png"
  },
  {
    "revision": "b899232b79ad9962c5ab5572775a0400",
    "url": "/img/card_index_bg@2x.b899232b.png"
  },
  {
    "revision": "114a6e12b42b9b48586dd341105188fe",
    "url": "/img/usedOrder@2x.114a6e12.png"
  },
  {
    "revision": "c0170ec299b2418256fd515ee7849055",
    "url": "/img/unUsedOrder@2x.c0170ec2.png"
  },
  {
    "revision": "d9e14058d30dd312519fcf2de38d742b",
    "url": "/img/unUsedOrder@3x.d9e14058.png"
  },
  {
    "revision": "4a5b90f8076955f289b3dcda6a5af6ff",
    "url": "/img/invaildedOrder@3x.4a5b90f8.png"
  },
  {
    "revision": "0d5a5158e67bcb7a4604124715ed6fbf",
    "url": "/img/usedOrder@3x.0d5a5158.png"
  },
  {
    "revision": "be0f1e33b2553e71b117d3d3f838d32f",
    "url": "/img/invaildedOrder@2x.be0f1e33.png"
  },
  {
    "revision": "3603a35a49dbb8ad94ec1e57c4dad229",
    "url": "/img/scanTop2.3603a35a.png"
  },
  {
    "revision": "05775dd69c53d7273b27aaa7c6c523f7",
    "url": "/img/04.05775dd6.png"
  },
  {
    "revision": "541375e6bb7db2fba9e415be8045f5fb",
    "url": "/img/1.541375e6.png"
  },
  {
    "revision": "7c28431d304fa4f58f5070c59720683a",
    "url": "/img/2.7c28431d.png"
  },
  {
    "revision": "5a3428653945c17e1c146efeee81c987",
    "url": "/img/scanTop.5a342865.png"
  },
  {
    "revision": "824594523c01e48028f2b7eb4261134d",
    "url": "/img/unicom-logo.82459452.svg"
  },
  {
    "revision": "113f99e2189c2ca49db2168754fc2eb5",
    "url": "/img/mobile-logo.113f99e2.png"
  },
  {
    "revision": "0cba868fa977e09806638b9000636a36",
    "url": "/img/avatar.0cba868f.jpeg"
  },
  {
    "revision": "27158aa79eb0d4b89f317d076a801ca3",
    "url": "/img/coupon-log.27158aa7.png"
  },
  {
    "revision": "55d3f2f09efe17db6485d4c9f8f0c3b1",
    "url": "/img/icon-recharge_20181001.55d3f2f0.svg"
  },
  {
    "revision": "165beb68d8ba0d2b70df0fbb3769787a",
    "url": "/img/03.165beb68.png"
  },
  {
    "revision": "5f1f34037094c0613bccafa2ddd8cb3b",
    "url": "/img/telecom-logo.5f1f3403.svg"
  },
  {
    "revision": "0b3c3297decbd1152a314cce115f9632",
    "url": "/img/09.0b3c3297.png"
  },
  {
    "revision": "3e217df4202e41ad9b030aafc8cfcc24",
    "url": "/img/4.3e217df4.png"
  },
  {
    "revision": "aecc9531f2c3b1fd45338e7bf5084384",
    "url": "/img/bg_no_recharge.aecc9531.svg"
  },
  {
    "revision": "b0ffa4a0fd195a110ee4d4dabce3bc32",
    "url": "/img/08.b0ffa4a0.png"
  },
  {
    "revision": "96fab583abd57f2e7118324858fa3080",
    "url": "/img/05.96fab583.png"
  },
  {
    "revision": "9e8ecc7f7b760b55c56bddfab886da10",
    "url": "/img/3.9e8ecc7f.png"
  },
  {
    "revision": "275be51ae57c486bce58257febd6589f",
    "url": "/img/bg_no_plan.275be51a.svg"
  },
  {
    "revision": "a8272d2d742d9d50257e23dfac577def",
    "url": "/img/01.a8272d2d.png"
  },
  {
    "revision": "daa86b540bb9c2a6453ceac9bed77961",
    "url": "/img/07.daa86b54.png"
  },
  {
    "revision": "06385746a7cedb492d5539907631561c",
    "url": "/img/tip.06385746.png"
  },
  {
    "revision": "eacba58f9acf2b87cd801858146b2ba9",
    "url": "/img/02.eacba58f.png"
  },
  {
    "revision": "39d9e849fc1c724525f166646932a24d",
    "url": "/img/safari.39d9e849.png"
  },
  {
    "revision": "999589aae784a460b5e7c6ae9bbaa3d8",
    "url": "/img/06.999589aa.png"
  },
  {
    "revision": "971ead32c902f1a82f567b780eb9beb6",
    "url": "/index.html"
  },
  {
    "revision": "b6216d61c03e6ce0c9aea6ca7808f7ca",
    "url": "/robots.txt"
  },
  {
    "revision": "9ce16f441b39b493af8b96d7e97cce22",
    "url": "/MP_verify_dkzAKjxyVyJvsHMS.txt"
  },
  {
    "revision": "86c422d8c98b247235d04b49fb1c4b05",
    "url": "/MP_verify_bKSdn2qZlUSULliu.txt"
  },
  {
    "revision": "652317b098ca24e4511926c7fd57cbbe",
    "url": "/MP_verify_8JoCCldW78DygS5c.txt"
  },
  {
    "revision": "00bbf6b458bf7ea6bd01f443eb3045d9",
    "url": "/MP_verify_4r3DVk3KUjgWsQsG.txt"
  }
];