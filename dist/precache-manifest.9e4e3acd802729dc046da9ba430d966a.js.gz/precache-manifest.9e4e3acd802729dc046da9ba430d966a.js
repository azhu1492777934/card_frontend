self.__precacheManifest = [
  {
    "revision": "e713484558d26387b6b2",
    "url": "/css/recharge_callback.4776b260.css"
  },
  {
    "revision": "b6216d61c03e6ce0c9aea6ca7808f7ca",
    "url": "/robots.txt"
  },
  {
    "revision": "e713484558d26387b6b2",
    "url": "/js/recharge_callback.d8d3feaa.js"
  },
  {
    "revision": "94ca7005b150b74ce760",
    "url": "/css/Layout~card_usage.9a95a901.css"
  },
  {
    "revision": "78214ba34c5f1df936aa",
    "url": "/js/Layout~card_usage~eqReplaceMent~esim_plan_list~esim_usage~mifi_order~mifi_plan_list~mifi_plan_usage~~c6f87c36.6241bd21.js"
  },
  {
    "revision": "33bc8d7c0421214121c0",
    "url": "/css/Not_fund.441b338e.css"
  },
  {
    "revision": "33bc8d7c0421214121c0",
    "url": "/js/Not_fund.a6629d31.js"
  },
  {
    "revision": "4e92d3330fb3c0b44989",
    "url": "/css/app.2608000f.css"
  },
  {
    "revision": "4e92d3330fb3c0b44989",
    "url": "/js/app.79b30eb8.js"
  },
  {
    "revision": "a618aa5c3728c6857cea",
    "url": "/css/authority_middle.4be2bf2b.css"
  },
  {
    "revision": "a618aa5c3728c6857cea",
    "url": "/js/authority_middle.04ea2933.js"
  },
  {
    "revision": "73748b7530c4bf7b5232",
    "url": "/css/balanceRefund.2f5b8519.css"
  },
  {
    "revision": "73748b7530c4bf7b5232",
    "url": "/js/balanceRefund.6bde1082.js"
  },
  {
    "revision": "82afc28cbf63f449eb8a",
    "url": "/css/cardPackage.8d8aa7db.css"
  },
  {
    "revision": "82afc28cbf63f449eb8a",
    "url": "/js/cardPackage.ae29bce6.js"
  },
  {
    "revision": "1833f1382804bd785f33",
    "url": "/css/card_check.821d897a.css"
  },
  {
    "revision": "1833f1382804bd785f33",
    "url": "/js/card_check.ffdce633.js"
  },
  {
    "revision": "6abfec697671e6b3bf69",
    "url": "/css/card_connection.0c0041ec.css"
  },
  {
    "revision": "6abfec697671e6b3bf69",
    "url": "/js/card_connection.5047064d.js"
  },
  {
    "revision": "e0b040ad23dd978d680f",
    "url": "/css/card_lookup.e31cfec6.css"
  },
  {
    "revision": "e0b040ad23dd978d680f",
    "url": "/js/card_lookup.51d4a6eb.js"
  },
  {
    "revision": "7b7afb4c9c4fc681a282",
    "url": "/css/card_usage.f4f44e8c.css"
  },
  {
    "revision": "7b7afb4c9c4fc681a282",
    "url": "/js/card_usage.12cfedcb.js"
  },
  {
    "revision": "a55e48fcda6c116400b4",
    "url": "/css/card_wrapper.ab43c2ce.css"
  },
  {
    "revision": "a55e48fcda6c116400b4",
    "url": "/js/card_wrapper.e6eee6c6.js"
  },
  {
    "revision": "6047ccdf1c012e778edc",
    "url": "/css/children_card.c0bffb1e.css"
  },
  {
    "revision": "6047ccdf1c012e778edc",
    "url": "/js/children_card.e08c7d2c.js"
  },
  {
    "revision": "033780e5f88aaed4d6a8",
    "url": "/css/chunk-332ab7b4.71b82256.css"
  },
  {
    "revision": "033780e5f88aaed4d6a8",
    "url": "/js/chunk-332ab7b4.7bbb8d2d.js"
  },
  {
    "revision": "e7a074765a02a25bb99c",
    "url": "/css/chunk-b81a473a.f068f9c3.css"
  },
  {
    "revision": "e7a074765a02a25bb99c",
    "url": "/js/chunk-b81a473a.c9245e2c.js"
  },
  {
    "revision": "2ef2b4e8ff50a96098b7",
    "url": "/css/chunk-vendors.187f45a9.css"
  },
  {
    "revision": "2ef2b4e8ff50a96098b7",
    "url": "/js/chunk-vendors.589c6f09.js"
  },
  {
    "revision": "7d92b54cc15ed0ae222b",
    "url": "/css/commonProblem.a6a75547.css"
  },
  {
    "revision": "7d92b54cc15ed0ae222b",
    "url": "/js/commonProblem.d5097fca.js"
  },
  {
    "revision": "f92e5fd9c80e5a361dee",
    "url": "/css/consumerRecord.716c16f3.css"
  },
  {
    "revision": "f92e5fd9c80e5a361dee",
    "url": "/js/consumerRecord.8b0abb02.js"
  },
  {
    "revision": "23352b7d285a7565d120",
    "url": "/css/coupon_normal.94c7ba55.css"
  },
  {
    "revision": "23352b7d285a7565d120",
    "url": "/js/coupon_normal.e40ac141.js"
  },
  {
    "revision": "1c3ce6b90affe1918295",
    "url": "/css/coupon_telcom.72ee0bc0.css"
  },
  {
    "revision": "1c3ce6b90affe1918295",
    "url": "/js/coupon_telcom.c3c3f0a6.js"
  },
  {
    "revision": "3d29be284addf9ff5036",
    "url": "/css/coupon_wrapper.31258838.css"
  },
  {
    "revision": "3d29be284addf9ff5036",
    "url": "/js/coupon_wrapper.c1c14448.js"
  },
  {
    "revision": "28322336db4eddd54845",
    "url": "/css/currencyConversion.36d997da.css"
  },
  {
    "revision": "28322336db4eddd54845",
    "url": "/js/currencyConversion.1c46e475.js"
  },
  {
    "revision": "a5aa964d68de80c028ce",
    "url": "/css/eqReplaceMent.2dcf4e9c.css"
  },
  {
    "revision": "a5aa964d68de80c028ce",
    "url": "/js/eqReplaceMent.f1b34573.js"
  },
  {
    "revision": "d6c6b66d5d53f679104c",
    "url": "/css/esim_plan_list.973e0976.css"
  },
  {
    "revision": "d6c6b66d5d53f679104c",
    "url": "/js/esim_plan_list.da6ba28d.js"
  },
  {
    "revision": "a5c303848cc0fdcb8230",
    "url": "/css/esim_usage.890d5b7b.css"
  },
  {
    "revision": "a5c303848cc0fdcb8230",
    "url": "/js/esim_usage.411e99f6.js"
  },
  {
    "revision": "ab3588d86a9b4d4af8b1",
    "url": "/css/find_plan.2ec0236a.css"
  },
  {
    "revision": "ab3588d86a9b4d4af8b1",
    "url": "/js/find_plan.0402f7e6.js"
  },
  {
    "revision": "ebf281747123702454db",
    "url": "/css/logical_page.b1840a87.css"
  },
  {
    "revision": "ebf281747123702454db",
    "url": "/js/logical_page.63a74246.js"
  },
  {
    "revision": "9bec5100a3c06cee1327",
    "url": "/css/login.b710a567.css"
  },
  {
    "revision": "9bec5100a3c06cee1327",
    "url": "/js/login.a38200aa.js"
  },
  {
    "revision": "726343e8119cce824826",
    "url": "/css/lookup.a0fdfe26.css"
  },
  {
    "revision": "726343e8119cce824826",
    "url": "/js/lookup.9003e5be.js"
  },
  {
    "revision": "a1fae757c4c2d3dbdce0",
    "url": "/css/mifi_binding.d51dd9ee.css"
  },
  {
    "revision": "a1fae757c4c2d3dbdce0",
    "url": "/js/mifi_binding.8372e372.js"
  },
  {
    "revision": "d0b42688b6d4c5ac0a60",
    "url": "/css/mifi_card_info.d339e411.css"
  },
  {
    "revision": "d0b42688b6d4c5ac0a60",
    "url": "/js/mifi_card_info.f43c535b.js"
  },
  {
    "revision": "def74c01e23ebf846d57",
    "url": "/css/mifi_card_lookup.1216b9dd.css"
  },
  {
    "revision": "def74c01e23ebf846d57",
    "url": "/js/mifi_card_lookup.20eedad1.js"
  },
  {
    "revision": "ea0397017a8f773eef8a",
    "url": "/css/mifi_card_wrapper.9134afdd.css"
  },
  {
    "revision": "ea0397017a8f773eef8a",
    "url": "/js/mifi_card_wrapper.8d1acc0c.js"
  },
  {
    "revision": "31cc9d61ca79460ca929",
    "url": "/css/mifi_change_network.8f2e5bb1.css"
  },
  {
    "revision": "31cc9d61ca79460ca929",
    "url": "/js/mifi_change_network.79d18e83.js"
  },
  {
    "revision": "ebe11284316f8b38e1df",
    "url": "/css/mifi_coupon_index.64e0f7c2.css"
  },
  {
    "revision": "ebe11284316f8b38e1df",
    "url": "/js/mifi_coupon_index.c2406973.js"
  },
  {
    "revision": "ea994b4592c341a64f14",
    "url": "/css/mifi_coupon_wrapper.8b393e56.css"
  },
  {
    "revision": "ea994b4592c341a64f14",
    "url": "/js/mifi_coupon_wrapper.eca902c1.js"
  },
  {
    "revision": "967666943007e30a2ffe",
    "url": "/css/mifi_index.f1add01c.css"
  },
  {
    "revision": "967666943007e30a2ffe",
    "url": "/js/mifi_index.cf069db2.js"
  },
  {
    "revision": "7624215f553859d6690d",
    "url": "/css/mifi_layout.4ae65286.css"
  },
  {
    "revision": "7624215f553859d6690d",
    "url": "/js/mifi_layout.cfc4148f.js"
  },
  {
    "revision": "505070a31448ed69be34",
    "url": "/css/mifi_order.73477860.css"
  },
  {
    "revision": "505070a31448ed69be34",
    "url": "/js/mifi_order.d61b805d.js"
  },
  {
    "revision": "9d35cfac4afd5c4afecf",
    "url": "/css/mifi_order_wrapper.d572d9dd.css"
  },
  {
    "revision": "9d35cfac4afd5c4afecf",
    "url": "/js/mifi_order_wrapper.9f3cb832.js"
  },
  {
    "revision": "47dd43015500be3f9ac4",
    "url": "/css/mifi_order~mifi_plan_group.9b72222a.css"
  },
  {
    "revision": "47dd43015500be3f9ac4",
    "url": "/js/mifi_order~mifi_plan_group.8b8989db.js"
  },
  {
    "revision": "a93e37bd9fb1c26279d6",
    "url": "/css/mifi_plan_group.10dad95d.css"
  },
  {
    "revision": "a93e37bd9fb1c26279d6",
    "url": "/js/mifi_plan_group.f9b21598.js"
  },
  {
    "revision": "8ac618ba4bae0cd8692e",
    "url": "/css/mifi_plan_list.b37029af.css"
  },
  {
    "revision": "8ac618ba4bae0cd8692e",
    "url": "/js/mifi_plan_list.ffb70a70.js"
  },
  {
    "revision": "cba7c8a13cdaa05dddf1",
    "url": "/css/mifi_plan_usage.b624eefa.css"
  },
  {
    "revision": "cba7c8a13cdaa05dddf1",
    "url": "/js/mifi_plan_usage.3b324ca6.js"
  },
  {
    "revision": "2aceb9979f5c7596abba",
    "url": "/css/mifi_plan_wrapper.ad5b72f4.css"
  },
  {
    "revision": "2aceb9979f5c7596abba",
    "url": "/js/mifi_plan_wrapper.fd737b35.js"
  },
  {
    "revision": "139cf8d7765bde2f6eda",
    "url": "/css/new_card_wrapper.907108b0.css"
  },
  {
    "revision": "139cf8d7765bde2f6eda",
    "url": "/js/new_card_wrapper.58d4a208.js"
  },
  {
    "revision": "bf0c41729083caf5b7a4",
    "url": "/css/orderRecord.8d00b417.css"
  },
  {
    "revision": "bf0c41729083caf5b7a4",
    "url": "/js/orderRecord.4afe086d.js"
  },
  {
    "revision": "f270ba708afbe2b2adea",
    "url": "/css/plan_list.122a8610.css"
  },
  {
    "revision": "f270ba708afbe2b2adea",
    "url": "/js/plan_list.44cdbd58.js"
  },
  {
    "revision": "6de9bd91e61e1e721e5c",
    "url": "/css/question.6faada89.css"
  },
  {
    "revision": "6de9bd91e61e1e721e5c",
    "url": "/js/question.1f41e8a8.js"
  },
  {
    "revision": "a06f700330835789736e",
    "url": "/css/question_wrapper.09148f29.css"
  },
  {
    "revision": "a06f700330835789736e",
    "url": "/js/question_wrapper.e8fa6249.js"
  },
  {
    "revision": "c0a890d6e174659de255",
    "url": "/css/realNameCourse.c4765d59.css"
  },
  {
    "revision": "c0a890d6e174659de255",
    "url": "/js/realNameCourse.1f2f7c45.js"
  },
  {
    "revision": "4b16025298deb987149e",
    "url": "/css/real_name.d1375355.css"
  },
  {
    "revision": "4b16025298deb987149e",
    "url": "/js/real_name.266fc79a.js"
  },
  {
    "revision": "eecc92f033cb6d295ab1",
    "url": "/css/recharge.0098e359.css"
  },
  {
    "revision": "eecc92f033cb6d295ab1",
    "url": "/js/recharge.ffb5ccb7.js"
  },
  {
    "revision": "07d277b207085bac23a7",
    "url": "/js/Layout.ba768c4b.js"
  },
  {
    "revision": "94ca7005b150b74ce760",
    "url": "/js/Layout~card_usage.f569021f.js"
  },
  {
    "revision": "9feffacd2b7a96a33fbf",
    "url": "/css/recharge_wrapper.61f8e218.css"
  },
  {
    "revision": "9feffacd2b7a96a33fbf",
    "url": "/js/recharge_wrapper.9aba0f17.js"
  },
  {
    "revision": "03996bf673731b709211",
    "url": "/css/refund_applying.a765fb53.css"
  },
  {
    "revision": "03996bf673731b709211",
    "url": "/js/refund_applying.7231b31d.js"
  },
  {
    "revision": "81f6884079aa36b007e7",
    "url": "/css/refund_argument.69661661.css"
  },
  {
    "revision": "81f6884079aa36b007e7",
    "url": "/js/refund_argument.350e4fa4.js"
  },
  {
    "revision": "8227a6988716df97d06e",
    "url": "/css/refund_plan.a2b7dc2c.css"
  },
  {
    "revision": "8227a6988716df97d06e",
    "url": "/js/refund_plan.471f79f5.js"
  },
  {
    "revision": "18f3a926060dcd5647ed",
    "url": "/css/refund_wrapper.2ce7ebad.css"
  },
  {
    "revision": "18f3a926060dcd5647ed",
    "url": "/js/refund_wrapper.4b26b5da.js"
  },
  {
    "revision": "cd2bf9588b9ac263f7ff",
    "url": "/css/repeatRecharge.473e7482.css"
  },
  {
    "revision": "cd2bf9588b9ac263f7ff",
    "url": "/js/repeatRecharge.c59dd426.js"
  },
  {
    "revision": "6afdca472e42139a7ea1",
    "url": "/css/revoke_plan.0c04faff.css"
  },
  {
    "revision": "6afdca472e42139a7ea1",
    "url": "/js/revoke_plan.2c96f472.js"
  },
  {
    "revision": "a959d5c7550e78c3fec0",
    "url": "/css/speedup_500.863f4cd3.css"
  },
  {
    "revision": "a959d5c7550e78c3fec0",
    "url": "/js/speedup_500.a92938d9.js"
  },
  {
    "revision": "0836497c8880b098ea28",
    "url": "/css/speedup_80.d0292630.css"
  },
  {
    "revision": "0836497c8880b098ea28",
    "url": "/js/speedup_80.71a043f0.js"
  },
  {
    "revision": "e8e646590c22cdecfe1f",
    "url": "/css/speedup_wrapper.69b3dda0.css"
  },
  {
    "revision": "e8e646590c22cdecfe1f",
    "url": "/js/speedup_wrapper.27f3dbaf.js"
  },
  {
    "revision": "be25eba308641ea1c4e4",
    "url": "/css/to_tb.96081c85.css"
  },
  {
    "revision": "be25eba308641ea1c4e4",
    "url": "/js/to_tb.9319ee92.js"
  },
  {
    "revision": "64b5763c2c802433d89d",
    "url": "/css/transfer_url.5cad75d0.css"
  },
  {
    "revision": "64b5763c2c802433d89d",
    "url": "/js/transfer_url.db8c7445.js"
  },
  {
    "revision": "ed7e501ae7ecae7d9379",
    "url": "/css/userCenter.d6d94612.css"
  },
  {
    "revision": "ed7e501ae7ecae7d9379",
    "url": "/js/userCenter.44be9ec9.js"
  },
  {
    "revision": "09c564d83e0d4b148a8f",
    "url": "/css/userCenterWrap.42b11dd9.css"
  },
  {
    "revision": "09c564d83e0d4b148a8f",
    "url": "/js/userCenterWrap.a75cbf3b.js"
  },
  {
    "revision": "e4b411644706c29765eea3ffdd85ae39",
    "url": "/fonts/SourceHanSansCNRegular.e4b41164.woff"
  },
  {
    "revision": "834b022ab9ab0e6063904af32274e777",
    "url": "/fonts/SourceHanSansCNRegular.834b022a.eot"
  },
  {
    "revision": "f9509c5a10be7daaf1fa01922a7c6bc2",
    "url": "/fonts/SourceHanSansCNRegular.f9509c5a.ttf"
  },
  {
    "revision": "da0808e9fe85be160aab69c82dd8de1c",
    "url": "/img/SourceHanSansCNRegular.da0808e9.svg"
  },
  {
    "revision": "732389ded34cb9c52dd88271f1345af9",
    "url": "/fonts/element-icons.732389de.ttf"
  },
  {
    "revision": "535877f50039c0cb49a6196a5b7517cd",
    "url": "/fonts/element-icons.535877f5.woff"
  },
  {
    "revision": "4a0cab0f33beb48ea985714d1b91fef7",
    "url": "/img/dianxin.4a0cab0f.png"
  },
  {
    "revision": "d3b42651f9f5048baeffb50c800913ec",
    "url": "/img/pkgBg1.d3b42651.png"
  },
  {
    "revision": "0078f03c08066d51d64b92a13e194ebb",
    "url": "/img/balanceRefund.0078f03c.png"
  },
  {
    "revision": "af3ed0b3236bbfdbc3ad61b8d41c3dec",
    "url": "/img/changeBg.af3ed0b3.png"
  },
  {
    "revision": "b899232b79ad9962c5ab5572775a0400",
    "url": "/img/card_index_bg@3x.b899232b.png"
  },
  {
    "revision": "b899232b79ad9962c5ab5572775a0400",
    "url": "/img/card_index_bg@2x.b899232b.png"
  },
  {
    "revision": "2c51a1e53c1ea0b35086d8d7261b4933",
    "url": "/img/bg_network@3x.2c51a1e5.png"
  },
  {
    "revision": "32d70c8fc305e3647098f3de0c71b618",
    "url": "/img/bg_network@2x.32d70c8f.png"
  },
  {
    "revision": "fff5af4325410621aeec4e60b3b92d9b",
    "url": "/img/mifi_binding_bg@3x.fff5af43.png"
  },
  {
    "revision": "fff5af4325410621aeec4e60b3b92d9b",
    "url": "/img/mifi_binding_bg@2x.fff5af43.png"
  },
  {
    "revision": "3d0fc424b703032ca595090e99f8354b",
    "url": "/img/login_bg@2x.3d0fc424.png"
  },
  {
    "revision": "11000d4e510a6df565eb69ba6f2c1dfc",
    "url": "/img/login_bg@3x.11000d4e.png"
  },
  {
    "revision": "e625229e32d9deeb5f2909c314d8e609",
    "url": "/img/ios@2x.e625229e.png"
  },
  {
    "revision": "af8bbdfa0a90c4eed4563f8c06ce5ff8",
    "url": "/img/android@2x.af8bbdfa.png"
  },
  {
    "revision": "f5f322478286641bd9887a155e35f222",
    "url": "/img/btn.f5f32247.png"
  },
  {
    "revision": "d140650fa64e0f1fc771610dba62aed7",
    "url": "/img/bg.d140650f.png"
  },
  {
    "revision": "3f342771b9b81ab929e0fbcbcd0e6533",
    "url": "/img/bg-check-wrap@3x.3f342771.png"
  },
  {
    "revision": "9713b21819c4019befecd095069977df",
    "url": "/img/bg-check-wrap@2x.9713b218.png"
  },
  {
    "revision": "1d7515ee61c3f659227318b4050955ed",
    "url": "/img/mobile_sim@2x.1d7515ee.png"
  },
  {
    "revision": "0f980b79d9a52702004de9f652a68835",
    "url": "/img/telcom_sim@2x.0f980b79.png"
  },
  {
    "revision": "98141226a7e992e3072a280746a259c4",
    "url": "/img/mobile_sim@3x.98141226.png"
  },
  {
    "revision": "0c88168b284b92c37f3a873f26a97d69",
    "url": "/img/bg.0c88168b.jpg"
  },
  {
    "revision": "9e02095f31a07b972244f1c714c1dfe7",
    "url": "/img/telcom_sim@3x.9e02095f.png"
  },
  {
    "revision": "b70eddccd257b21777e71bb64c83b876",
    "url": "/img/bg.b70eddcc.jpeg"
  },
  {
    "revision": "909816c3d34e63a9ad86b8c179ab543c",
    "url": "/img/bar.909816c3.png"
  },
  {
    "revision": "e92f547ba0209da3b4342fa2b56ea9ae",
    "url": "/img/animater.e92f547b.png"
  },
  {
    "revision": "42c0fbd4915870e5e60452fd0ef2cbec",
    "url": "/img/orderTopBg@3x.42c0fbd4.png"
  },
  {
    "revision": "42c0fbd4915870e5e60452fd0ef2cbec",
    "url": "/img/orderTopBg@2x.42c0fbd4.png"
  },
  {
    "revision": "6dedd4943e4c5848638196fb6f0c4145",
    "url": "/img/bg.6dedd494.png"
  },
  {
    "revision": "014d354b9b25b67ae95857ba17e2f4cc",
    "url": "/img/activityPage.014d354b.png"
  },
  {
    "revision": "a859e9ca4606d567c42b9c7bcd4fdce9",
    "url": "/img/iccid_bg@2x.a859e9ca.png"
  },
  {
    "revision": "fa9050c4e9870e8fc0cd184f8515af4a",
    "url": "/img/iccid_bg@3x.fa9050c4.png"
  },
  {
    "revision": "6e5cee7393060b0ec3dcd587c2518b94",
    "url": "/img/bg_test.6e5cee73.png"
  },
  {
    "revision": "2a67b73145562669220aa4639e1ad58f",
    "url": "/img/icon3.2a67b731.png"
  },
  {
    "revision": "813b5319e378dafdda952c16ad89906b",
    "url": "/img/icon2.813b5319.png"
  },
  {
    "revision": "01355f175bd20423ce45a838c1a998a9",
    "url": "/img/bg.01355f17.png"
  },
  {
    "revision": "114a6e12b42b9b48586dd341105188fe",
    "url": "/img/usedOrder@2x.114a6e12.png"
  },
  {
    "revision": "c0170ec299b2418256fd515ee7849055",
    "url": "/img/unUsedOrder@2x.c0170ec2.png"
  },
  {
    "revision": "d9e14058d30dd312519fcf2de38d742b",
    "url": "/img/unUsedOrder@3x.d9e14058.png"
  },
  {
    "revision": "4a5b90f8076955f289b3dcda6a5af6ff",
    "url": "/img/invaildedOrder@3x.4a5b90f8.png"
  },
  {
    "revision": "0d5a5158e67bcb7a4604124715ed6fbf",
    "url": "/img/usedOrder@3x.0d5a5158.png"
  },
  {
    "revision": "be0f1e33b2553e71b117d3d3f838d32f",
    "url": "/img/invaildedOrder@2x.be0f1e33.png"
  },
  {
    "revision": "3603a35a49dbb8ad94ec1e57c4dad229",
    "url": "/img/scanTop2.3603a35a.png"
  },
  {
    "revision": "05775dd69c53d7273b27aaa7c6c523f7",
    "url": "/img/04.05775dd6.png"
  },
  {
    "revision": "5a3428653945c17e1c146efeee81c987",
    "url": "/img/scanTop.5a342865.png"
  },
  {
    "revision": "824594523c01e48028f2b7eb4261134d",
    "url": "/img/unicom-logo.82459452.svg"
  },
  {
    "revision": "113f99e2189c2ca49db2168754fc2eb5",
    "url": "/img/mobile-logo.113f99e2.png"
  },
  {
    "revision": "0cba868fa977e09806638b9000636a36",
    "url": "/img/avatar.0cba868f.jpeg"
  },
  {
    "revision": "27158aa79eb0d4b89f317d076a801ca3",
    "url": "/img/coupon-log.27158aa7.png"
  },
  {
    "revision": "55d3f2f09efe17db6485d4c9f8f0c3b1",
    "url": "/img/icon-recharge_20181001.55d3f2f0.svg"
  },
  {
    "revision": "165beb68d8ba0d2b70df0fbb3769787a",
    "url": "/img/03.165beb68.png"
  },
  {
    "revision": "5f1f34037094c0613bccafa2ddd8cb3b",
    "url": "/img/telecom-logo.5f1f3403.svg"
  },
  {
    "revision": "644e6e3cf5f33943747b116316694e28",
    "url": "/img/noData@2x.644e6e3c.png"
  },
  {
    "revision": "0b3c3297decbd1152a314cce115f9632",
    "url": "/img/09.0b3c3297.png"
  },
  {
    "revision": "4bdbe7dbdb6587c886a8290593100145",
    "url": "/img/recharge_callback_20181126.4bdbe7db.jpg"
  },
  {
    "revision": "aecc9531f2c3b1fd45338e7bf5084384",
    "url": "/img/bg_no_recharge.aecc9531.svg"
  },
  {
    "revision": "b0ffa4a0fd195a110ee4d4dabce3bc32",
    "url": "/img/08.b0ffa4a0.png"
  },
  {
    "revision": "96fab583abd57f2e7118324858fa3080",
    "url": "/img/05.96fab583.png"
  },
  {
    "revision": "275be51ae57c486bce58257febd6589f",
    "url": "/img/bg_no_plan.275be51a.svg"
  },
  {
    "revision": "a8272d2d742d9d50257e23dfac577def",
    "url": "/img/01.a8272d2d.png"
  },
  {
    "revision": "daa86b540bb9c2a6453ceac9bed77961",
    "url": "/img/07.daa86b54.png"
  },
  {
    "revision": "06385746a7cedb492d5539907631561c",
    "url": "/img/tip.06385746.png"
  },
  {
    "revision": "eacba58f9acf2b87cd801858146b2ba9",
    "url": "/img/02.eacba58f.png"
  },
  {
    "revision": "39d9e849fc1c724525f166646932a24d",
    "url": "/img/safari.39d9e849.png"
  },
  {
    "revision": "999589aae784a460b5e7c6ae9bbaa3d8",
    "url": "/img/06.999589aa.png"
  },
  {
    "revision": "18afcaf6e7c9b025e1a7e18a13af573d",
    "url": "/index.html"
  },
  {
    "revision": "07d277b207085bac23a7",
    "url": "/css/Layout.049d7384.css"
  },
  {
    "revision": "9ce16f441b39b493af8b96d7e97cce22",
    "url": "/MP_verify_dkzAKjxyVyJvsHMS.txt"
  },
  {
    "revision": "86c422d8c98b247235d04b49fb1c4b05",
    "url": "/MP_verify_bKSdn2qZlUSULliu.txt"
  },
  {
    "revision": "652317b098ca24e4511926c7fd57cbbe",
    "url": "/MP_verify_8JoCCldW78DygS5c.txt"
  },
  {
    "revision": "00bbf6b458bf7ea6bd01f443eb3045d9",
    "url": "/MP_verify_4r3DVk3KUjgWsQsG.txt"
  }
];