self.__precacheManifest = [
  {
    "revision": "78a25917c4ec7512a004",
    "url": "/js/recharge_wrapper.2ff45b44.js"
  },
  {
    "revision": "83209b10d48317569917",
    "url": "/css/Layout.ce14b775.css"
  },
  {
    "revision": "78214ba34c5f1df936aa",
    "url": "/js/Layout~card_usage~eqReplaceMent~esim_plan_list~esim_usage~mifi_order~mifi_plan_list~mifi_plan_usage~~c6f87c36.6241bd21.js"
  },
  {
    "revision": "3d7af4ce7ab59152de99",
    "url": "/css/Not_fund.7a23ff88.css"
  },
  {
    "revision": "3d7af4ce7ab59152de99",
    "url": "/js/Not_fund.d06dd485.js"
  },
  {
    "revision": "58529a0affb42c304649",
    "url": "/css/app.d1d8428f.css"
  },
  {
    "revision": "58529a0affb42c304649",
    "url": "/js/app.44a69b58.js"
  },
  {
    "revision": "d2bb4172ee786ba557e3",
    "url": "/css/authority_middle.21c85bb5.css"
  },
  {
    "revision": "d2bb4172ee786ba557e3",
    "url": "/js/authority_middle.3bcfe645.js"
  },
  {
    "revision": "fa1703e0f8a0a7a08248",
    "url": "/css/balanceIndex.057677b6.css"
  },
  {
    "revision": "fa1703e0f8a0a7a08248",
    "url": "/js/balanceIndex.35a205e5.js"
  },
  {
    "revision": "43671855eb1f6cd39890",
    "url": "/css/balanceRefund.dd2c10f8.css"
  },
  {
    "revision": "43671855eb1f6cd39890",
    "url": "/js/balanceRefund.f647b9e3.js"
  },
  {
    "revision": "8ab63b1421624c4bd67e",
    "url": "/css/cardPackage.987a4f6d.css"
  },
  {
    "revision": "8ab63b1421624c4bd67e",
    "url": "/js/cardPackage.d4f1f742.js"
  },
  {
    "revision": "69ccbfade0f7c1332f42",
    "url": "/css/card_check.5ead5d85.css"
  },
  {
    "revision": "69ccbfade0f7c1332f42",
    "url": "/js/card_check.bf5f4d84.js"
  },
  {
    "revision": "81ef04eed0281e133417",
    "url": "/css/card_connection.d7ecbb0a.css"
  },
  {
    "revision": "81ef04eed0281e133417",
    "url": "/js/card_connection.bf690acf.js"
  },
  {
    "revision": "226673da4293aa79fcb5",
    "url": "/css/card_lookup.393a8031.css"
  },
  {
    "revision": "226673da4293aa79fcb5",
    "url": "/js/card_lookup.02c19515.js"
  },
  {
    "revision": "efb84f8d91e10b09c02f",
    "url": "/css/card_lookup_notice.a05a1959.css"
  },
  {
    "revision": "efb84f8d91e10b09c02f",
    "url": "/js/card_lookup_notice.7fa8f405.js"
  },
  {
    "revision": "af09bb346e061cc700ba",
    "url": "/css/card_lookup~card_lookup_notice.1672d43e.css"
  },
  {
    "revision": "af09bb346e061cc700ba",
    "url": "/js/card_lookup~card_lookup_notice.02ff088a.js"
  },
  {
    "revision": "15ace611f8e150a9a788",
    "url": "/css/card_more_flow.c0333abd.css"
  },
  {
    "revision": "15ace611f8e150a9a788",
    "url": "/js/card_more_flow.110e4b2a.js"
  },
  {
    "revision": "10a7a4e6ae1688cd1485",
    "url": "/css/card_usage.d178b036.css"
  },
  {
    "revision": "10a7a4e6ae1688cd1485",
    "url": "/js/card_usage.0e041a9f.js"
  },
  {
    "revision": "5ef44a69ba4afda72ad0",
    "url": "/css/card_usage~plan_list.fd293231.css"
  },
  {
    "revision": "5ef44a69ba4afda72ad0",
    "url": "/js/card_usage~plan_list.3912bbe2.js"
  },
  {
    "revision": "dad8373d7760fffd522f",
    "url": "/css/card_wrapper.0f1a55fe.css"
  },
  {
    "revision": "dad8373d7760fffd522f",
    "url": "/js/card_wrapper.04265140.js"
  },
  {
    "revision": "29f98bcfe8bf3f4d105b",
    "url": "/css/children_card.3a2cb82e.css"
  },
  {
    "revision": "29f98bcfe8bf3f4d105b",
    "url": "/js/children_card.9f223721.js"
  },
  {
    "revision": "93186332f43166d53c0c",
    "url": "/css/chunk-137d2c96.0157994e.css"
  },
  {
    "revision": "93186332f43166d53c0c",
    "url": "/js/chunk-137d2c96.3ed2ec34.js"
  },
  {
    "revision": "e198ea19acbce8a2ef8c",
    "url": "/css/chunk-a8061550.d4189c7d.css"
  },
  {
    "revision": "e198ea19acbce8a2ef8c",
    "url": "/js/chunk-a8061550.3b106bcc.js"
  },
  {
    "revision": "894d31a9da0d57a178d3",
    "url": "/css/chunk-vendors.f4f950f2.css"
  },
  {
    "revision": "894d31a9da0d57a178d3",
    "url": "/js/chunk-vendors.4ec2dc53.js"
  },
  {
    "revision": "3087a9d2d72c507cfd86",
    "url": "/css/commonProblem.f3985972.css"
  },
  {
    "revision": "3087a9d2d72c507cfd86",
    "url": "/js/commonProblem.09d400b9.js"
  },
  {
    "revision": "69e000362b914aebee0d",
    "url": "/css/commonQuestion.edf258cf.css"
  },
  {
    "revision": "69e000362b914aebee0d",
    "url": "/js/commonQuestion.2d4a72e4.js"
  },
  {
    "revision": "d46250c1729ea17c05cb",
    "url": "/css/consumerRecord.ece5a486.css"
  },
  {
    "revision": "d46250c1729ea17c05cb",
    "url": "/js/consumerRecord.2716e3bc.js"
  },
  {
    "revision": "0a8a2e7d40a2df3e8e5f",
    "url": "/css/coupon_normal.c54db4c8.css"
  },
  {
    "revision": "0a8a2e7d40a2df3e8e5f",
    "url": "/js/coupon_normal.b3754913.js"
  },
  {
    "revision": "d7376fc132b6bf21b05b",
    "url": "/css/coupon_telcom.4910a9a6.css"
  },
  {
    "revision": "d7376fc132b6bf21b05b",
    "url": "/js/coupon_telcom.b5d3ed48.js"
  },
  {
    "revision": "b015aa59cc0a3e03fca4",
    "url": "/css/coupon_wrapper.ce3120d7.css"
  },
  {
    "revision": "b015aa59cc0a3e03fca4",
    "url": "/js/coupon_wrapper.c6753c26.js"
  },
  {
    "revision": "62735e6cac229a516eb6",
    "url": "/css/currencyConversion.c94302be.css"
  },
  {
    "revision": "62735e6cac229a516eb6",
    "url": "/js/currencyConversion.1d0d68eb.js"
  },
  {
    "revision": "a995b411711c191f3622",
    "url": "/css/customerFeedback.ec6bf509.css"
  },
  {
    "revision": "a995b411711c191f3622",
    "url": "/js/customerFeedback.2fdf4c7c.js"
  },
  {
    "revision": "a96be30b62b8e5f91461",
    "url": "/css/eqReplaceMent.618eff28.css"
  },
  {
    "revision": "a96be30b62b8e5f91461",
    "url": "/js/eqReplaceMent.3b316839.js"
  },
  {
    "revision": "a2ac358b5ba0d37e1f75",
    "url": "/css/eqReplaceMent~recharge.f6bbdfeb.css"
  },
  {
    "revision": "a2ac358b5ba0d37e1f75",
    "url": "/js/eqReplaceMent~recharge.0c032fb1.js"
  },
  {
    "revision": "fb5aff2b582811a7ff0b",
    "url": "/css/esim_plan_list.74104c35.css"
  },
  {
    "revision": "fb5aff2b582811a7ff0b",
    "url": "/js/esim_plan_list.f819dd6d.js"
  },
  {
    "revision": "80d047a81028cec14dee",
    "url": "/css/esim_usage.1c22b5fb.css"
  },
  {
    "revision": "80d047a81028cec14dee",
    "url": "/js/esim_usage.69299800.js"
  },
  {
    "revision": "432e1805b012d457deb9",
    "url": "/css/find_plan.ef489386.css"
  },
  {
    "revision": "432e1805b012d457deb9",
    "url": "/js/find_plan.758f39c9.js"
  },
  {
    "revision": "b840f8c322aa2bfe2276",
    "url": "/css/guardian.25be3c29.css"
  },
  {
    "revision": "b840f8c322aa2bfe2276",
    "url": "/js/guardian.480fbd5b.js"
  },
  {
    "revision": "d835ebccee561c885fb8",
    "url": "/css/logical_page.87dd27f0.css"
  },
  {
    "revision": "d835ebccee561c885fb8",
    "url": "/js/logical_page.95755e5c.js"
  },
  {
    "revision": "8faa8cedffad2c71caf8",
    "url": "/css/login.db13ac6f.css"
  },
  {
    "revision": "8faa8cedffad2c71caf8",
    "url": "/js/login.20a002f2.js"
  },
  {
    "revision": "d00f6f449ab145f2bccc",
    "url": "/css/lookup.72b835fa.css"
  },
  {
    "revision": "d00f6f449ab145f2bccc",
    "url": "/js/lookup.14e3fec9.js"
  },
  {
    "revision": "f286b82f532fccbbafce",
    "url": "/css/mifi_binding.e525351c.css"
  },
  {
    "revision": "f286b82f532fccbbafce",
    "url": "/js/mifi_binding.688eb803.js"
  },
  {
    "revision": "eab72c6e3a96951da4f0",
    "url": "/css/mifi_card_info.0eec3cb0.css"
  },
  {
    "revision": "eab72c6e3a96951da4f0",
    "url": "/js/mifi_card_info.832e9882.js"
  },
  {
    "revision": "d014a34604c15c384b79",
    "url": "/css/mifi_card_lookup.4b5be1df.css"
  },
  {
    "revision": "d014a34604c15c384b79",
    "url": "/js/mifi_card_lookup.4d937638.js"
  },
  {
    "revision": "f371bf63e539acd8621a",
    "url": "/css/mifi_card_wrapper.bb17a37b.css"
  },
  {
    "revision": "f371bf63e539acd8621a",
    "url": "/js/mifi_card_wrapper.200784bb.js"
  },
  {
    "revision": "4a0456865d856b50cab5",
    "url": "/css/mifi_change_network.07ed5108.css"
  },
  {
    "revision": "4a0456865d856b50cab5",
    "url": "/js/mifi_change_network.6cca195f.js"
  },
  {
    "revision": "faa466285c0041e18962",
    "url": "/css/mifi_change_network_explanation.4432b9c3.css"
  },
  {
    "revision": "faa466285c0041e18962",
    "url": "/js/mifi_change_network_explanation.9f185464.js"
  },
  {
    "revision": "ac3eef23592c9169d994",
    "url": "/css/mifi_coupon_index.60024ae6.css"
  },
  {
    "revision": "ac3eef23592c9169d994",
    "url": "/js/mifi_coupon_index.47705514.js"
  },
  {
    "revision": "9d0b15e789a46268bc30",
    "url": "/css/mifi_coupon_wrapper.abd3e347.css"
  },
  {
    "revision": "9d0b15e789a46268bc30",
    "url": "/js/mifi_coupon_wrapper.fe54fb30.js"
  },
  {
    "revision": "0e3f96853cf20bf02cd9",
    "url": "/css/mifi_index.fbca7f06.css"
  },
  {
    "revision": "0e3f96853cf20bf02cd9",
    "url": "/js/mifi_index.c3c6305f.js"
  },
  {
    "revision": "85729c0bf79272d1a5ab",
    "url": "/css/mifi_layout.c437464c.css"
  },
  {
    "revision": "85729c0bf79272d1a5ab",
    "url": "/js/mifi_layout.b5a752c4.js"
  },
  {
    "revision": "9967b6870c08de4fd0ea",
    "url": "/css/mifi_order.a4435ee7.css"
  },
  {
    "revision": "9967b6870c08de4fd0ea",
    "url": "/js/mifi_order.35ce2780.js"
  },
  {
    "revision": "e3dca9ce867e33bba531",
    "url": "/css/mifi_order_wrapper.034f9976.css"
  },
  {
    "revision": "e3dca9ce867e33bba531",
    "url": "/js/mifi_order_wrapper.cf9542bd.js"
  },
  {
    "revision": "1d75c79f124d3278daa0",
    "url": "/css/mifi_plan_group.c0e563d8.css"
  },
  {
    "revision": "1d75c79f124d3278daa0",
    "url": "/js/mifi_plan_group.ac522a93.js"
  },
  {
    "revision": "32bf6e17e219a41373ff",
    "url": "/css/mifi_plan_list.6696fc28.css"
  },
  {
    "revision": "32bf6e17e219a41373ff",
    "url": "/js/mifi_plan_list.6b2477cd.js"
  },
  {
    "revision": "9eb29e3a6471342da034",
    "url": "/css/mifi_plan_usage.0bd2776a.css"
  },
  {
    "revision": "9eb29e3a6471342da034",
    "url": "/js/mifi_plan_usage.096d8a6d.js"
  },
  {
    "revision": "f1ce7c6e96f9a2785d55",
    "url": "/css/mifi_plan_wrapper.ecfbd387.css"
  },
  {
    "revision": "f1ce7c6e96f9a2785d55",
    "url": "/js/mifi_plan_wrapper.15373068.js"
  },
  {
    "revision": "73d6116f00e19957e82f",
    "url": "/css/new_card_wrapper.fbadfe48.css"
  },
  {
    "revision": "73d6116f00e19957e82f",
    "url": "/js/new_card_wrapper.d8204c2d.js"
  },
  {
    "revision": "5cdf6f86dd0e8b1ecafe",
    "url": "/css/official_accounts.aa223422.css"
  },
  {
    "revision": "5cdf6f86dd0e8b1ecafe",
    "url": "/js/official_accounts.fcbbe0fe.js"
  },
  {
    "revision": "239dc6402517948d5154",
    "url": "/css/orderRecord.b0e4a965.css"
  },
  {
    "revision": "239dc6402517948d5154",
    "url": "/js/orderRecord.2e691d7c.js"
  },
  {
    "revision": "1bf99bcdde85478bc148",
    "url": "/css/plan_list.99398967.css"
  },
  {
    "revision": "1bf99bcdde85478bc148",
    "url": "/js/plan_list.30ed8fbe.js"
  },
  {
    "revision": "1b2886b393ffad8132ab",
    "url": "/css/question.19bb1af6.css"
  },
  {
    "revision": "1b2886b393ffad8132ab",
    "url": "/js/question.e03573b0.js"
  },
  {
    "revision": "151c0ab95096db5c2b3e",
    "url": "/css/question_wrapper.c09367ca.css"
  },
  {
    "revision": "151c0ab95096db5c2b3e",
    "url": "/js/question_wrapper.63a3102e.js"
  },
  {
    "revision": "a9bb431a7435cd46a061",
    "url": "/css/realNameCourse.e94a846e.css"
  },
  {
    "revision": "a9bb431a7435cd46a061",
    "url": "/js/realNameCourse.8aa673e9.js"
  },
  {
    "revision": "49f0245f76401c7140e9",
    "url": "/css/real_name.a7384119.css"
  },
  {
    "revision": "49f0245f76401c7140e9",
    "url": "/js/real_name.0329383d.js"
  },
  {
    "revision": "dca4278fdb0c199192d0",
    "url": "/css/recharge.ed6846e3.css"
  },
  {
    "revision": "dca4278fdb0c199192d0",
    "url": "/js/recharge.3eeff9f1.js"
  },
  {
    "revision": "75088da875aa103b00d9",
    "url": "/css/rechargeOrder.19f37743.css"
  },
  {
    "revision": "75088da875aa103b00d9",
    "url": "/js/rechargeOrder.b882eb43.js"
  },
  {
    "revision": "67340102ccc81ef13acf",
    "url": "/css/recharge_balance.60712b7b.css"
  },
  {
    "revision": "67340102ccc81ef13acf",
    "url": "/js/recharge_balance.f073904b.js"
  },
  {
    "revision": "3bd2dc613140519ada2c",
    "url": "/css/recharge_callback.311d4bba.css"
  },
  {
    "revision": "3bd2dc613140519ada2c",
    "url": "/js/recharge_callback.2221777a.js"
  },
  {
    "revision": "78a25917c4ec7512a004",
    "url": "/css/recharge_wrapper.3cc70882.css"
  },
  {
    "revision": "83209b10d48317569917",
    "url": "/js/Layout.824e9093.js"
  },
  {
    "revision": "69dd9c5ccc6b75429ea1",
    "url": "/css/refundRules.b03c649c.css"
  },
  {
    "revision": "69dd9c5ccc6b75429ea1",
    "url": "/js/refundRules.f677c89a.js"
  },
  {
    "revision": "c46254b8638490431fc6",
    "url": "/css/refund_applying.de0fd19f.css"
  },
  {
    "revision": "c46254b8638490431fc6",
    "url": "/js/refund_applying.4bc2f059.js"
  },
  {
    "revision": "135a98cb6a0510cbbcee",
    "url": "/css/refund_argument.8ad7d72d.css"
  },
  {
    "revision": "135a98cb6a0510cbbcee",
    "url": "/js/refund_argument.047d8248.js"
  },
  {
    "revision": "4c47edf96c4fbc09eff8",
    "url": "/css/refund_plan.55c317a9.css"
  },
  {
    "revision": "4c47edf96c4fbc09eff8",
    "url": "/js/refund_plan.4e9004c2.js"
  },
  {
    "revision": "33a43d6ce2e81bdd2012",
    "url": "/css/refund_wrapper.85e2e6da.css"
  },
  {
    "revision": "33a43d6ce2e81bdd2012",
    "url": "/js/refund_wrapper.24b30eba.js"
  },
  {
    "revision": "b8b0107a6ce82328f11f",
    "url": "/css/repeatRecharge.8ac8fde4.css"
  },
  {
    "revision": "b8b0107a6ce82328f11f",
    "url": "/js/repeatRecharge.a58e9ac7.js"
  },
  {
    "revision": "9acaaac8e6e54fc58b99",
    "url": "/css/revoke_plan.37ff9a23.css"
  },
  {
    "revision": "9acaaac8e6e54fc58b99",
    "url": "/js/revoke_plan.307c9d0c.js"
  },
  {
    "revision": "b35f91d99c05f55e3175",
    "url": "/css/speedup_500.c6366a0b.css"
  },
  {
    "revision": "b35f91d99c05f55e3175",
    "url": "/js/speedup_500.093c0b42.js"
  },
  {
    "revision": "1a53f482aed171e606d7",
    "url": "/css/speedup_80.57204c7c.css"
  },
  {
    "revision": "1a53f482aed171e606d7",
    "url": "/js/speedup_80.6b921442.js"
  },
  {
    "revision": "fcf5321d8c797a6d3702",
    "url": "/css/speedup_wrapper.fb951ea8.css"
  },
  {
    "revision": "fcf5321d8c797a6d3702",
    "url": "/js/speedup_wrapper.be3d7b3f.js"
  },
  {
    "revision": "bf1bf83d6fc3be1802e5",
    "url": "/css/to_tb.46e6e953.css"
  },
  {
    "revision": "bf1bf83d6fc3be1802e5",
    "url": "/js/to_tb.24c9dac3.js"
  },
  {
    "revision": "f3c8197b0ed70ba9e16e",
    "url": "/css/transfer_url.ec530465.css"
  },
  {
    "revision": "f3c8197b0ed70ba9e16e",
    "url": "/js/transfer_url.46cc5089.js"
  },
  {
    "revision": "d2e0fcc970a52936b552",
    "url": "/css/userCenter.954e649f.css"
  },
  {
    "revision": "d2e0fcc970a52936b552",
    "url": "/js/userCenter.24acaa9b.js"
  },
  {
    "revision": "c2ab7d64de07ac31a863",
    "url": "/css/userCenterWrap.a2460f56.css"
  },
  {
    "revision": "c2ab7d64de07ac31a863",
    "url": "/js/userCenterWrap.8f42cbad.js"
  },
  {
    "revision": "e4b411644706c29765eea3ffdd85ae39",
    "url": "/fonts/SourceHanSansCNRegular.e4b41164.woff"
  },
  {
    "revision": "834b022ab9ab0e6063904af32274e777",
    "url": "/fonts/SourceHanSansCNRegular.834b022a.eot"
  },
  {
    "revision": "f9509c5a10be7daaf1fa01922a7c6bc2",
    "url": "/fonts/SourceHanSansCNRegular.f9509c5a.ttf"
  },
  {
    "revision": "da0808e9fe85be160aab69c82dd8de1c",
    "url": "/img/SourceHanSansCNRegular.da0808e9.svg"
  },
  {
    "revision": "732389ded34cb9c52dd88271f1345af9",
    "url": "/fonts/element-icons.732389de.ttf"
  },
  {
    "revision": "535877f50039c0cb49a6196a5b7517cd",
    "url": "/fonts/element-icons.535877f5.woff"
  },
  {
    "revision": "0f16389ec218c90cf8f657e233b745f2",
    "url": "/img/balanceBg1.0f16389e.png"
  },
  {
    "revision": "565459ef2ee8b71db421144ad21c23e3",
    "url": "/img/balanceBg2.565459ef.png"
  },
  {
    "revision": "f5f322478286641bd9887a155e35f222",
    "url": "/img/btn.f5f32247.png"
  },
  {
    "revision": "d140650fa64e0f1fc771610dba62aed7",
    "url": "/img/bg.d140650f.png"
  },
  {
    "revision": "e625229e32d9deeb5f2909c314d8e609",
    "url": "/img/ios@2x.e625229e.png"
  },
  {
    "revision": "af8bbdfa0a90c4eed4563f8c06ce5ff8",
    "url": "/img/android@2x.af8bbdfa.png"
  },
  {
    "revision": "cc0636ca2944024fd3ebf33a5412ff35",
    "url": "/img/icon-right@3x.cc0636ca.png"
  },
  {
    "revision": "1b983020cfed6b7a8ca5c300c24ca186",
    "url": "/img/icon-left@3x.1b983020.png"
  },
  {
    "revision": "d796d97eb9ebb2e89bb966343e2362e9",
    "url": "/img/icon-left@2x.d796d97e.png"
  },
  {
    "revision": "ccb9865dadbc642b8c4dd0a1abc8e570",
    "url": "/img/recharge-word@2x.ccb9865d.png"
  },
  {
    "revision": "ccb9865dadbc642b8c4dd0a1abc8e570",
    "url": "/img/recharge-word@3x.ccb9865d.png"
  },
  {
    "revision": "41a8c268f703fe646d5d08099eb778ae",
    "url": "/img/icon-right@2x.41a8c268.png"
  },
  {
    "revision": "2d6d06f4da15fc1a748677c49c5f1854",
    "url": "/img/bg.2d6d06f4.png"
  },
  {
    "revision": "8cb139e0169560e725d23c2ab8d8310e",
    "url": "/img/advert.8cb139e0.gif"
  },
  {
    "revision": "3f342771b9b81ab929e0fbcbcd0e6533",
    "url": "/img/bg-check-wrap@3x.3f342771.png"
  },
  {
    "revision": "9713b21819c4019befecd095069977df",
    "url": "/img/bg-check-wrap@2x.9713b218.png"
  },
  {
    "revision": "fa855242805b87da42c65763acd64ac0",
    "url": "/img/bg-plan-type@2x.fa855242.png"
  },
  {
    "revision": "4a9ca192485effa8b8f4b5b2df5b9caf",
    "url": "/img/bg-plan-type@3x.4a9ca192.png"
  },
  {
    "revision": "1d7515ee61c3f659227318b4050955ed",
    "url": "/img/mobile_sim@2x.1d7515ee.png"
  },
  {
    "revision": "0f980b79d9a52702004de9f652a68835",
    "url": "/img/telcom_sim@2x.0f980b79.png"
  },
  {
    "revision": "98141226a7e992e3072a280746a259c4",
    "url": "/img/mobile_sim@3x.98141226.png"
  },
  {
    "revision": "0c88168b284b92c37f3a873f26a97d69",
    "url": "/img/bg.0c88168b.jpg"
  },
  {
    "revision": "9e02095f31a07b972244f1c714c1dfe7",
    "url": "/img/telcom_sim@3x.9e02095f.png"
  },
  {
    "revision": "e93b8c03293c5b6a311da784f9c19c8f",
    "url": "/img/bg.e93b8c03.jpeg"
  },
  {
    "revision": "ffb1612d9660e2ecd9d3872d57a8a2f9",
    "url": "/img/bar.ffb1612d.png"
  },
  {
    "revision": "3d0fc424b703032ca595090e99f8354b",
    "url": "/img/login_bg@2x.3d0fc424.png"
  },
  {
    "revision": "11000d4e510a6df565eb69ba6f2c1dfc",
    "url": "/img/login_bg@3x.11000d4e.png"
  },
  {
    "revision": "af3ed0b3236bbfdbc3ad61b8d41c3dec",
    "url": "/img/changeBg.af3ed0b3.png"
  },
  {
    "revision": "91e1d2771efacd45e5e465d9a001f197",
    "url": "/img/liantong.91e1d277.png"
  },
  {
    "revision": "4a0cab0f33beb48ea985714d1b91fef7",
    "url": "/img/dianxin.4a0cab0f.png"
  },
  {
    "revision": "657033323334e91efb0011bbc18f8c04",
    "url": "/img/yidong.65703332.png"
  },
  {
    "revision": "8da3b83b73e44e54d6be4b2522bcb1f2",
    "url": "/img/pkgBg2.8da3b83b.png"
  },
  {
    "revision": "d3b42651f9f5048baeffb50c800913ec",
    "url": "/img/pkgBg1.d3b42651.png"
  },
  {
    "revision": "d461d18e42a310bd709b2ce97d159153",
    "url": "/img/pkgBg3.d461d18e.png"
  },
  {
    "revision": "014d354b9b25b67ae95857ba17e2f4cc",
    "url": "/img/activityPage.014d354b.png"
  },
  {
    "revision": "6dedd4943e4c5848638196fb6f0c4145",
    "url": "/img/bg.6dedd494.png"
  },
  {
    "revision": "2a67b73145562669220aa4639e1ad58f",
    "url": "/img/icon3.2a67b731.png"
  },
  {
    "revision": "813b5319e378dafdda952c16ad89906b",
    "url": "/img/icon2.813b5319.png"
  },
  {
    "revision": "f40c7e0b20fe25eb78a7658c3ae56312",
    "url": "/img/noData@3x.f40c7e0b.png"
  },
  {
    "revision": "644e6e3cf5f33943747b116316694e28",
    "url": "/img/noData@2x.644e6e3c.png"
  },
  {
    "revision": "01355f175bd20423ce45a838c1a998a9",
    "url": "/img/bg.01355f17.png"
  },
  {
    "revision": "0078f03c08066d51d64b92a13e194ebb",
    "url": "/img/balanceRefund.0078f03c.png"
  },
  {
    "revision": "6e5cee7393060b0ec3dcd587c2518b94",
    "url": "/img/bg_test.6e5cee73.png"
  },
  {
    "revision": "a859e9ca4606d567c42b9c7bcd4fdce9",
    "url": "/img/iccid_bg@2x.a859e9ca.png"
  },
  {
    "revision": "fa9050c4e9870e8fc0cd184f8515af4a",
    "url": "/img/iccid_bg@3x.fa9050c4.png"
  },
  {
    "revision": "42c0fbd4915870e5e60452fd0ef2cbec",
    "url": "/img/orderTopBg@3x.42c0fbd4.png"
  },
  {
    "revision": "42c0fbd4915870e5e60452fd0ef2cbec",
    "url": "/img/orderTopBg@2x.42c0fbd4.png"
  },
  {
    "revision": "d0ccbc8a35180bb40e027b44dd26035a",
    "url": "/img/youku.d0ccbc8a.png"
  },
  {
    "revision": "b899232b79ad9962c5ab5572775a0400",
    "url": "/img/card_index_bg@3x.b899232b.png"
  },
  {
    "revision": "b899232b79ad9962c5ab5572775a0400",
    "url": "/img/card_index_bg@2x.b899232b.png"
  },
  {
    "revision": "2c51a1e53c1ea0b35086d8d7261b4933",
    "url": "/img/bg_network@3x.2c51a1e5.png"
  },
  {
    "revision": "32d70c8fc305e3647098f3de0c71b618",
    "url": "/img/bg_network@2x.32d70c8f.png"
  },
  {
    "revision": "fff5af4325410621aeec4e60b3b92d9b",
    "url": "/img/mifi_binding_bg@3x.fff5af43.png"
  },
  {
    "revision": "fff5af4325410621aeec4e60b3b92d9b",
    "url": "/img/mifi_binding_bg@2x.fff5af43.png"
  },
  {
    "revision": "6e5cee7393060b0ec3dcd587c2518b94",
    "url": "/img/bg_test@3x.6e5cee73.png"
  },
  {
    "revision": "114a6e12b42b9b48586dd341105188fe",
    "url": "/img/usedOrder@2x.114a6e12.png"
  },
  {
    "revision": "6e5cee7393060b0ec3dcd587c2518b94",
    "url": "/img/bg_test@2x.6e5cee73.png"
  },
  {
    "revision": "c0170ec299b2418256fd515ee7849055",
    "url": "/img/unUsedOrder@2x.c0170ec2.png"
  },
  {
    "revision": "d9e14058d30dd312519fcf2de38d742b",
    "url": "/img/unUsedOrder@3x.d9e14058.png"
  },
  {
    "revision": "4a5b90f8076955f289b3dcda6a5af6ff",
    "url": "/img/invaildedOrder@3x.4a5b90f8.png"
  },
  {
    "revision": "0d5a5158e67bcb7a4604124715ed6fbf",
    "url": "/img/usedOrder@3x.0d5a5158.png"
  },
  {
    "revision": "be0f1e33b2553e71b117d3d3f838d32f",
    "url": "/img/invaildedOrder@2x.be0f1e33.png"
  },
  {
    "revision": "3603a35a49dbb8ad94ec1e57c4dad229",
    "url": "/img/scanTop2.3603a35a.png"
  },
  {
    "revision": "05775dd69c53d7273b27aaa7c6c523f7",
    "url": "/img/04.05775dd6.png"
  },
  {
    "revision": "58a560568b7291ea926c2c7438035308",
    "url": "/img/subscribe@3x.58a56056.png"
  },
  {
    "revision": "541375e6bb7db2fba9e415be8045f5fb",
    "url": "/img/1.541375e6.png"
  },
  {
    "revision": "7c28431d304fa4f58f5070c59720683a",
    "url": "/img/2.7c28431d.png"
  },
  {
    "revision": "5a3428653945c17e1c146efeee81c987",
    "url": "/img/scanTop.5a342865.png"
  },
  {
    "revision": "0b9e0b5f4f28c68416f916ddce3fc7ef",
    "url": "/img/unicom-logo.0b9e0b5f.svg"
  },
  {
    "revision": "113f99e2189c2ca49db2168754fc2eb5",
    "url": "/img/mobile-logo.113f99e2.png"
  },
  {
    "revision": "0cba868fa977e09806638b9000636a36",
    "url": "/img/avatar.0cba868f.jpeg"
  },
  {
    "revision": "27158aa79eb0d4b89f317d076a801ca3",
    "url": "/img/coupon-log.27158aa7.png"
  },
  {
    "revision": "55d3f2f09efe17db6485d4c9f8f0c3b1",
    "url": "/img/icon-recharge_20181001.55d3f2f0.svg"
  },
  {
    "revision": "165beb68d8ba0d2b70df0fbb3769787a",
    "url": "/img/03.165beb68.png"
  },
  {
    "revision": "8c605ac88ca50357355da465f322d10a",
    "url": "/img/telecom-logo.8c605ac8.svg"
  },
  {
    "revision": "f7a51f1c554585b11d61499fd0a7520f",
    "url": "/img/only-box@3x.f7a51f1c.png"
  },
  {
    "revision": "89b99d16dd8a4a56746323a0ffbd754c",
    "url": "/img/migu.89b99d16.png"
  },
  {
    "revision": "0b3c3297decbd1152a314cce115f9632",
    "url": "/img/09.0b3c3297.png"
  },
  {
    "revision": "3e217df4202e41ad9b030aafc8cfcc24",
    "url": "/img/4.3e217df4.png"
  },
  {
    "revision": "34c67f6dfdb0ecc17c7a221aec74706f",
    "url": "/img/bg_no_recharge.34c67f6d.svg"
  },
  {
    "revision": "b0ffa4a0fd195a110ee4d4dabce3bc32",
    "url": "/img/08.b0ffa4a0.png"
  },
  {
    "revision": "96fab583abd57f2e7118324858fa3080",
    "url": "/img/05.96fab583.png"
  },
  {
    "revision": "9e8ecc7f7b760b55c56bddfab886da10",
    "url": "/img/3.9e8ecc7f.png"
  },
  {
    "revision": "f23d9d1f76147bc89b48902c36818f1e",
    "url": "/img/bg_no_plan.f23d9d1f.svg"
  },
  {
    "revision": "a8272d2d742d9d50257e23dfac577def",
    "url": "/img/01.a8272d2d.png"
  },
  {
    "revision": "daa86b540bb9c2a6453ceac9bed77961",
    "url": "/img/07.daa86b54.png"
  },
  {
    "revision": "687b6ce03f134f21173c949d79002960",
    "url": "/img/tip.687b6ce0.png"
  },
  {
    "revision": "a610420eab741be28278e60bc06387aa",
    "url": "/img/box-deco@3x.a610420e.png"
  },
  {
    "revision": "eacba58f9acf2b87cd801858146b2ba9",
    "url": "/img/02.eacba58f.png"
  },
  {
    "revision": "39d9e849fc1c724525f166646932a24d",
    "url": "/img/safari.39d9e849.png"
  },
  {
    "revision": "999589aae784a460b5e7c6ae9bbaa3d8",
    "url": "/img/06.999589aa.png"
  },
  {
    "revision": "bcd82b0a4f5a553d9adcbb2236d79655",
    "url": "/index.html"
  },
  {
    "revision": "735ab4f94fbcd57074377afca324c813",
    "url": "/robots.txt"
  },
  {
    "revision": "9ce16f441b39b493af8b96d7e97cce22",
    "url": "/MP_verify_dkzAKjxyVyJvsHMS.txt"
  },
  {
    "revision": "86c422d8c98b247235d04b49fb1c4b05",
    "url": "/MP_verify_bKSdn2qZlUSULliu.txt"
  },
  {
    "revision": "652317b098ca24e4511926c7fd57cbbe",
    "url": "/MP_verify_8JoCCldW78DygS5c.txt"
  },
  {
    "revision": "00bbf6b458bf7ea6bd01f443eb3045d9",
    "url": "/MP_verify_4r3DVk3KUjgWsQsG.txt"
  }
];