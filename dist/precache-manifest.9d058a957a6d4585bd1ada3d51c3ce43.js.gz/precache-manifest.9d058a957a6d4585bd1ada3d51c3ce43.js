self.__precacheManifest = [
  {
    "revision": "b47da50f055773f43901",
    "url": "/js/refundRules.1030bdf6.js"
  },
  {
    "revision": "b6216d61c03e6ce0c9aea6ca7808f7ca",
    "url": "/robots.txt"
  },
  {
    "revision": "7f0f046ff137202ebc23",
    "url": "/css/refund_applying.ff016f1b.css"
  },
  {
    "revision": "78214ba34c5f1df936aa",
    "url": "/js/Layout~card_usage~eqReplaceMent~esim_plan_list~esim_usage~mifi_order~mifi_plan_list~mifi_plan_usage~~c6f87c36.6241bd21.js"
  },
  {
    "revision": "bebf236814a177833788",
    "url": "/js/Not_fund.b1098bb1.js"
  },
  {
    "revision": "2b40de105dbcc37bf184",
    "url": "/js/userCenterWrap.6660e30d.js"
  },
  {
    "revision": "a43f0a3e161ba377beb9",
    "url": "/js/app.845c8aa6.js"
  },
  {
    "revision": "c4283452e70232f0e54e",
    "url": "/js/userCenter.b6d16efa.js"
  },
  {
    "revision": "e2a6c20d1a5a57d2b06f",
    "url": "/js/authority_middle.35294d0d.js"
  },
  {
    "revision": "b46bb9781c68977c6ea5",
    "url": "/js/transfer_url.0b20ba02.js"
  },
  {
    "revision": "5a14d933f7ffa891355b",
    "url": "/js/balanceIndex.cc1b415e.js"
  },
  {
    "revision": "ee2d8e6cbd82e792ca16",
    "url": "/js/to_tb.8b2876e9.js"
  },
  {
    "revision": "d62df7201c726f709131",
    "url": "/js/balanceRefund.24069b99.js"
  },
  {
    "revision": "3c2c10448e1c8334004b",
    "url": "/js/speedup_wrapper.c81ee763.js"
  },
  {
    "revision": "bce0c0f9b456edeff551",
    "url": "/js/cardPackage.5a543724.js"
  },
  {
    "revision": "cefa35a987e96ebe40c1",
    "url": "/js/speedup_80.265eb1c8.js"
  },
  {
    "revision": "f16a064d51c328f23243",
    "url": "/js/card_check.9224b550.js"
  },
  {
    "revision": "8eef84e37bc97894f853",
    "url": "/js/speedup_500.d77a1c61.js"
  },
  {
    "revision": "f4eb91d075873b57306d",
    "url": "/js/card_connection.cd6ce13e.js"
  },
  {
    "revision": "4835dbbdbea98fadda9c",
    "url": "/js/revoke_plan.fd5bc1c4.js"
  },
  {
    "revision": "18bddef87a1c8d1cbb6f",
    "url": "/js/card_lookup.f667913f.js"
  },
  {
    "revision": "aefec259cf08c19567e0",
    "url": "/js/repeatRecharge.02ba2be3.js"
  },
  {
    "revision": "bf090ececafb954d9751",
    "url": "/js/card_more_flow.0b87f380.js"
  },
  {
    "revision": "f5d3f5b4e9f064288085",
    "url": "/js/refund_wrapper.b6093663.js"
  },
  {
    "revision": "6cae8434413d29777755",
    "url": "/js/card_usage.792bdc5e.js"
  },
  {
    "revision": "7fa082bbeaa3650bd153",
    "url": "/js/refund_plan.5312f271.js"
  },
  {
    "revision": "9d280216356ef78a9590",
    "url": "/js/card_wrapper.92511b67.js"
  },
  {
    "revision": "50ef619911f91f94d356",
    "url": "/js/refund_argument.e2221a06.js"
  },
  {
    "revision": "2d720d7ba1d67544bbb9",
    "url": "/js/children_card.be523d57.js"
  },
  {
    "revision": "7f0f046ff137202ebc23",
    "url": "/js/refund_applying.7d09ae90.js"
  },
  {
    "revision": "3b63cc99d8f9772bd0ab",
    "url": "/js/chunk-68bb4772.9a96c441.js"
  },
  {
    "revision": "74c5cb4ff68ecedf8d57",
    "url": "/js/recharge_wrapper.9b60ea01.js"
  },
  {
    "revision": "5667afe33a550611fbe9",
    "url": "/js/chunk-7a806b55.ba65cdc7.js"
  },
  {
    "revision": "065d64b8a63e6a9f8f49",
    "url": "/js/recharge_callback.e17b05db.js"
  },
  {
    "revision": "7a37f1d32dcf31fafb6d",
    "url": "/js/chunk-vendors.6a1799b5.js"
  },
  {
    "revision": "2431152fda8df4e7fe10",
    "url": "/js/recharge_balance.ddc88150.js"
  },
  {
    "revision": "9d2607d9f5f4dad32ed8",
    "url": "/js/commonProblem.70f945f4.js"
  },
  {
    "revision": "06651f10688ed74183b6",
    "url": "/js/rechargeOrder.54980e9e.js"
  },
  {
    "revision": "c336ff6c5a602d68c215",
    "url": "/js/commonQuestion.5d876cec.js"
  },
  {
    "revision": "e8339626927508c009ee",
    "url": "/js/recharge.59240c85.js"
  },
  {
    "revision": "af61e9ba77b9edda772e",
    "url": "/js/consumerRecord.13fc5419.js"
  },
  {
    "revision": "07f59827cf8ed2816ac1",
    "url": "/js/real_name.c7cff0e5.js"
  },
  {
    "revision": "b04926488412c3fd8f62",
    "url": "/js/coupon_normal.fbe0391b.js"
  },
  {
    "revision": "8408bd051f74fe1e725f",
    "url": "/js/realNameCourse.0359140e.js"
  },
  {
    "revision": "0f642a655ea568f71ec4",
    "url": "/js/coupon_telcom.29278a1d.js"
  },
  {
    "revision": "cb24dd64b19c3a35e058",
    "url": "/js/question_wrapper.e0d321ab.js"
  },
  {
    "revision": "5342361134c2b540401b",
    "url": "/js/coupon_wrapper.c7352882.js"
  },
  {
    "revision": "1cc0eaa12df8bc1401cd",
    "url": "/js/question.0d83ef4d.js"
  },
  {
    "revision": "9affc1bb87f8685db1a0",
    "url": "/js/currencyConversion.31670cc1.js"
  },
  {
    "revision": "3456c304e8d0954562ab",
    "url": "/js/plan_list.3e6870e0.js"
  },
  {
    "revision": "111836324efbffcf4088",
    "url": "/js/customerFeedback.4d40a230.js"
  },
  {
    "revision": "2a49282132de0cfc7b13",
    "url": "/js/orderRecord.db31d33f.js"
  },
  {
    "revision": "5ac148a04f62112e9cfc",
    "url": "/js/eqReplaceMent.d4863b34.js"
  },
  {
    "revision": "3f34885f6c41b359ec45",
    "url": "/js/new_card_wrapper.d14d1549.js"
  },
  {
    "revision": "45f2e57f7f820c9d11aa",
    "url": "/js/eqReplaceMent~recharge.a9ad22af.js"
  },
  {
    "revision": "e4b7fb2072efd5a247e0",
    "url": "/js/mifi_plan_wrapper.de47db52.js"
  },
  {
    "revision": "96dca18954fac143a348",
    "url": "/js/esim_plan_list.f451dd3c.js"
  },
  {
    "revision": "7f3d9d897ec2d0df5923",
    "url": "/js/mifi_plan_usage.5a7e0caf.js"
  },
  {
    "revision": "f0a4b889a269ccf45789",
    "url": "/js/esim_usage.ddd1443a.js"
  },
  {
    "revision": "1c2753cfa5083616a760",
    "url": "/js/mifi_plan_list.d0719dfe.js"
  },
  {
    "revision": "abb023fec561a22cbaa1",
    "url": "/js/find_plan.5548a7c8.js"
  },
  {
    "revision": "ceb2d7fd3d11461c9d46",
    "url": "/js/mifi_plan_group.998f9a49.js"
  },
  {
    "revision": "7e119664feafb8e8a086",
    "url": "/js/logical_page.f9ed4e3d.js"
  },
  {
    "revision": "82e60e007c77e060983a",
    "url": "/js/mifi_order_wrapper.26f361ad.js"
  },
  {
    "revision": "9e88135934fc835a25f4",
    "url": "/js/login.4270bbb0.js"
  },
  {
    "revision": "e0077a4076d12b3b8140",
    "url": "/js/mifi_order.7e08bcad.js"
  },
  {
    "revision": "690670c1050786f67acf",
    "url": "/js/lookup.b4900b3e.js"
  },
  {
    "revision": "5dd8ffcbc7e5b012679c",
    "url": "/js/mifi_layout.d39943bf.js"
  },
  {
    "revision": "bdd9c65c7e094d8a23c4",
    "url": "/js/mifi_binding.03d99728.js"
  },
  {
    "revision": "fc44077e1fbf2c1eff56",
    "url": "/js/mifi_index.e7853d26.js"
  },
  {
    "revision": "06bad74eb46616419bcf",
    "url": "/js/mifi_card_info.9de2c3fe.js"
  },
  {
    "revision": "d76d36d361947539bb04",
    "url": "/js/mifi_coupon_wrapper.b37e46b4.js"
  },
  {
    "revision": "508aae8866c6c7c5188b",
    "url": "/js/mifi_card_lookup.f8e8efff.js"
  },
  {
    "revision": "2b662fb55e00cc78ca4d",
    "url": "/js/mifi_coupon_index.7a4145a1.js"
  },
  {
    "revision": "2cbf76e31147215d809c",
    "url": "/js/mifi_card_wrapper.12249149.js"
  },
  {
    "revision": "68936d96668c6591d057",
    "url": "/js/mifi_change_network_explanation.cffade75.js"
  },
  {
    "revision": "dcc53c50f113df2961f2",
    "url": "/js/mifi_change_network.a9f57ba9.js"
  },
  {
    "revision": "b899232b79ad9962c5ab5572775a0400",
    "url": "/img/card_index_bg@2x.b899232b.png"
  },
  {
    "revision": "68936d96668c6591d057",
    "url": "/css/mifi_change_network_explanation.14d7ccfc.css"
  },
  {
    "revision": "2b662fb55e00cc78ca4d",
    "url": "/css/mifi_coupon_index.77bf2c8f.css"
  },
  {
    "revision": "769cba75c0f65a50769717671fb5a865",
    "url": "/index.html"
  },
  {
    "revision": "d76d36d361947539bb04",
    "url": "/css/mifi_coupon_wrapper.bd47aa9c.css"
  },
  {
    "revision": "999589aae784a460b5e7c6ae9bbaa3d8",
    "url": "/img/06.999589aa.png"
  },
  {
    "revision": "fc44077e1fbf2c1eff56",
    "url": "/css/mifi_index.6440bda3.css"
  },
  {
    "revision": "39d9e849fc1c724525f166646932a24d",
    "url": "/img/safari.39d9e849.png"
  },
  {
    "revision": "5dd8ffcbc7e5b012679c",
    "url": "/css/mifi_layout.e07adb32.css"
  },
  {
    "revision": "eacba58f9acf2b87cd801858146b2ba9",
    "url": "/img/02.eacba58f.png"
  },
  {
    "revision": "e0077a4076d12b3b8140",
    "url": "/css/mifi_order.8e6ccafc.css"
  },
  {
    "revision": "a610420eab741be28278e60bc06387aa",
    "url": "/img/box-deco@3x.a610420e.png"
  },
  {
    "revision": "82e60e007c77e060983a",
    "url": "/css/mifi_order_wrapper.cfb1fd47.css"
  },
  {
    "revision": "687b6ce03f134f21173c949d79002960",
    "url": "/img/tip.687b6ce0.png"
  },
  {
    "revision": "ceb2d7fd3d11461c9d46",
    "url": "/css/mifi_plan_group.f1e5be8e.css"
  },
  {
    "revision": "daa86b540bb9c2a6453ceac9bed77961",
    "url": "/img/07.daa86b54.png"
  },
  {
    "revision": "1c2753cfa5083616a760",
    "url": "/css/mifi_plan_list.91b50446.css"
  },
  {
    "revision": "a8272d2d742d9d50257e23dfac577def",
    "url": "/img/01.a8272d2d.png"
  },
  {
    "revision": "7f3d9d897ec2d0df5923",
    "url": "/css/mifi_plan_usage.ba2cccc7.css"
  },
  {
    "revision": "275be51ae57c486bce58257febd6589f",
    "url": "/img/bg_no_plan.275be51a.svg"
  },
  {
    "revision": "e4b7fb2072efd5a247e0",
    "url": "/css/mifi_plan_wrapper.9e98768f.css"
  },
  {
    "revision": "9e8ecc7f7b760b55c56bddfab886da10",
    "url": "/img/3.9e8ecc7f.png"
  },
  {
    "revision": "3f34885f6c41b359ec45",
    "url": "/css/new_card_wrapper.b45520a3.css"
  },
  {
    "revision": "96fab583abd57f2e7118324858fa3080",
    "url": "/img/05.96fab583.png"
  },
  {
    "revision": "2a49282132de0cfc7b13",
    "url": "/css/orderRecord.0c2690d8.css"
  },
  {
    "revision": "b0ffa4a0fd195a110ee4d4dabce3bc32",
    "url": "/img/08.b0ffa4a0.png"
  },
  {
    "revision": "3456c304e8d0954562ab",
    "url": "/css/plan_list.17a0699e.css"
  },
  {
    "revision": "aecc9531f2c3b1fd45338e7bf5084384",
    "url": "/img/bg_no_recharge.aecc9531.svg"
  },
  {
    "revision": "1cc0eaa12df8bc1401cd",
    "url": "/css/question.1157bdde.css"
  },
  {
    "revision": "3e217df4202e41ad9b030aafc8cfcc24",
    "url": "/img/4.3e217df4.png"
  },
  {
    "revision": "cb24dd64b19c3a35e058",
    "url": "/css/question_wrapper.f2324655.css"
  },
  {
    "revision": "0b3c3297decbd1152a314cce115f9632",
    "url": "/img/09.0b3c3297.png"
  },
  {
    "revision": "8408bd051f74fe1e725f",
    "url": "/css/realNameCourse.a069652c.css"
  },
  {
    "revision": "f7a51f1c554585b11d61499fd0a7520f",
    "url": "/img/only-box@3x.f7a51f1c.png"
  },
  {
    "revision": "07f59827cf8ed2816ac1",
    "url": "/css/real_name.c849c204.css"
  },
  {
    "revision": "5f1f34037094c0613bccafa2ddd8cb3b",
    "url": "/img/telecom-logo.5f1f3403.svg"
  },
  {
    "revision": "e8339626927508c009ee",
    "url": "/css/recharge.f0d89eef.css"
  },
  {
    "revision": "165beb68d8ba0d2b70df0fbb3769787a",
    "url": "/img/03.165beb68.png"
  },
  {
    "revision": "06651f10688ed74183b6",
    "url": "/css/rechargeOrder.72cc1c44.css"
  },
  {
    "revision": "55d3f2f09efe17db6485d4c9f8f0c3b1",
    "url": "/img/icon-recharge_20181001.55d3f2f0.svg"
  },
  {
    "revision": "2431152fda8df4e7fe10",
    "url": "/css/recharge_balance.890b9b10.css"
  },
  {
    "revision": "27158aa79eb0d4b89f317d076a801ca3",
    "url": "/img/coupon-log.27158aa7.png"
  },
  {
    "revision": "065d64b8a63e6a9f8f49",
    "url": "/css/recharge_callback.5b466417.css"
  },
  {
    "revision": "0cba868fa977e09806638b9000636a36",
    "url": "/img/avatar.0cba868f.jpeg"
  },
  {
    "revision": "74c5cb4ff68ecedf8d57",
    "url": "/css/recharge_wrapper.b10840ae.css"
  },
  {
    "revision": "113f99e2189c2ca49db2168754fc2eb5",
    "url": "/img/mobile-logo.113f99e2.png"
  },
  {
    "revision": "b47da50f055773f43901",
    "url": "/css/refundRules.60a3087c.css"
  },
  {
    "revision": "4c81f0ba1cd5873a1ef9",
    "url": "/js/Layout.61d37b88.js"
  },
  {
    "revision": "824594523c01e48028f2b7eb4261134d",
    "url": "/img/unicom-logo.82459452.svg"
  },
  {
    "revision": "5a3428653945c17e1c146efeee81c987",
    "url": "/img/scanTop.5a342865.png"
  },
  {
    "revision": "50ef619911f91f94d356",
    "url": "/css/refund_argument.c341d992.css"
  },
  {
    "revision": "7c28431d304fa4f58f5070c59720683a",
    "url": "/img/2.7c28431d.png"
  },
  {
    "revision": "7fa082bbeaa3650bd153",
    "url": "/css/refund_plan.500b8ced.css"
  },
  {
    "revision": "541375e6bb7db2fba9e415be8045f5fb",
    "url": "/img/1.541375e6.png"
  },
  {
    "revision": "f5d3f5b4e9f064288085",
    "url": "/css/refund_wrapper.56a3339d.css"
  },
  {
    "revision": "58a560568b7291ea926c2c7438035308",
    "url": "/img/subscribe@3x.58a56056.png"
  },
  {
    "revision": "aefec259cf08c19567e0",
    "url": "/css/repeatRecharge.3fff9c06.css"
  },
  {
    "revision": "05775dd69c53d7273b27aaa7c6c523f7",
    "url": "/img/04.05775dd6.png"
  },
  {
    "revision": "4835dbbdbea98fadda9c",
    "url": "/css/revoke_plan.70001df5.css"
  },
  {
    "revision": "3603a35a49dbb8ad94ec1e57c4dad229",
    "url": "/img/scanTop2.3603a35a.png"
  },
  {
    "revision": "8eef84e37bc97894f853",
    "url": "/css/speedup_500.f69a7633.css"
  },
  {
    "revision": "be0f1e33b2553e71b117d3d3f838d32f",
    "url": "/img/invaildedOrder@2x.be0f1e33.png"
  },
  {
    "revision": "cefa35a987e96ebe40c1",
    "url": "/css/speedup_80.dfe6eff5.css"
  },
  {
    "revision": "0d5a5158e67bcb7a4604124715ed6fbf",
    "url": "/img/usedOrder@3x.0d5a5158.png"
  },
  {
    "revision": "3c2c10448e1c8334004b",
    "url": "/css/speedup_wrapper.8710c11d.css"
  },
  {
    "revision": "4a5b90f8076955f289b3dcda6a5af6ff",
    "url": "/img/invaildedOrder@3x.4a5b90f8.png"
  },
  {
    "revision": "ee2d8e6cbd82e792ca16",
    "url": "/css/to_tb.3b475e88.css"
  },
  {
    "revision": "d9e14058d30dd312519fcf2de38d742b",
    "url": "/img/unUsedOrder@3x.d9e14058.png"
  },
  {
    "revision": "b46bb9781c68977c6ea5",
    "url": "/css/transfer_url.3e9efb9e.css"
  },
  {
    "revision": "c0170ec299b2418256fd515ee7849055",
    "url": "/img/unUsedOrder@2x.c0170ec2.png"
  },
  {
    "revision": "c4283452e70232f0e54e",
    "url": "/css/userCenter.63f51fec.css"
  },
  {
    "revision": "114a6e12b42b9b48586dd341105188fe",
    "url": "/img/usedOrder@2x.114a6e12.png"
  },
  {
    "revision": "2b40de105dbcc37bf184",
    "url": "/css/userCenterWrap.7b926a3e.css"
  },
  {
    "revision": "fa9050c4e9870e8fc0cd184f8515af4a",
    "url": "/img/iccid_bg@3x.fa9050c4.png"
  },
  {
    "revision": "e4b411644706c29765eea3ffdd85ae39",
    "url": "/fonts/SourceHanSansCNRegular.e4b41164.woff"
  },
  {
    "revision": "834b022ab9ab0e6063904af32274e777",
    "url": "/fonts/SourceHanSansCNRegular.834b022a.eot"
  },
  {
    "revision": "f9509c5a10be7daaf1fa01922a7c6bc2",
    "url": "/fonts/SourceHanSansCNRegular.f9509c5a.ttf"
  },
  {
    "revision": "da0808e9fe85be160aab69c82dd8de1c",
    "url": "/img/SourceHanSansCNRegular.da0808e9.svg"
  },
  {
    "revision": "732389ded34cb9c52dd88271f1345af9",
    "url": "/fonts/element-icons.732389de.ttf"
  },
  {
    "revision": "535877f50039c0cb49a6196a5b7517cd",
    "url": "/fonts/element-icons.535877f5.woff"
  },
  {
    "revision": "42c0fbd4915870e5e60452fd0ef2cbec",
    "url": "/img/orderTopBg@3x.42c0fbd4.png"
  },
  {
    "revision": "42c0fbd4915870e5e60452fd0ef2cbec",
    "url": "/img/orderTopBg@2x.42c0fbd4.png"
  },
  {
    "revision": "fff5af4325410621aeec4e60b3b92d9b",
    "url": "/img/mifi_binding_bg@3x.fff5af43.png"
  },
  {
    "revision": "fff5af4325410621aeec4e60b3b92d9b",
    "url": "/img/mifi_binding_bg@2x.fff5af43.png"
  },
  {
    "revision": "b899232b79ad9962c5ab5572775a0400",
    "url": "/img/card_index_bg@3x.b899232b.png"
  },
  {
    "revision": "a859e9ca4606d567c42b9c7bcd4fdce9",
    "url": "/img/iccid_bg@2x.a859e9ca.png"
  },
  {
    "revision": "2c51a1e53c1ea0b35086d8d7261b4933",
    "url": "/img/bg_network@3x.2c51a1e5.png"
  },
  {
    "revision": "32d70c8fc305e3647098f3de0c71b618",
    "url": "/img/bg_network@2x.32d70c8f.png"
  },
  {
    "revision": "f5f322478286641bd9887a155e35f222",
    "url": "/img/btn.f5f32247.png"
  },
  {
    "revision": "d140650fa64e0f1fc771610dba62aed7",
    "url": "/img/bg.d140650f.png"
  },
  {
    "revision": "6e5cee7393060b0ec3dcd587c2518b94",
    "url": "/img/bg_test.6e5cee73.png"
  },
  {
    "revision": "d0ccbc8a35180bb40e027b44dd26035a",
    "url": "/img/youku.d0ccbc8a.png"
  },
  {
    "revision": "e625229e32d9deeb5f2909c314d8e609",
    "url": "/img/ios@2x.e625229e.png"
  },
  {
    "revision": "af8bbdfa0a90c4eed4563f8c06ce5ff8",
    "url": "/img/android@2x.af8bbdfa.png"
  },
  {
    "revision": "cc0636ca2944024fd3ebf33a5412ff35",
    "url": "/img/icon-right@3x.cc0636ca.png"
  },
  {
    "revision": "1b983020cfed6b7a8ca5c300c24ca186",
    "url": "/img/icon-left@3x.1b983020.png"
  },
  {
    "revision": "d796d97eb9ebb2e89bb966343e2362e9",
    "url": "/img/icon-left@2x.d796d97e.png"
  },
  {
    "revision": "ccb9865dadbc642b8c4dd0a1abc8e570",
    "url": "/img/recharge-word@2x.ccb9865d.png"
  },
  {
    "revision": "ccb9865dadbc642b8c4dd0a1abc8e570",
    "url": "/img/recharge-word@3x.ccb9865d.png"
  },
  {
    "revision": "41a8c268f703fe646d5d08099eb778ae",
    "url": "/img/icon-right@2x.41a8c268.png"
  },
  {
    "revision": "2d6d06f4da15fc1a748677c49c5f1854",
    "url": "/img/bg.2d6d06f4.png"
  },
  {
    "revision": "3f342771b9b81ab929e0fbcbcd0e6533",
    "url": "/img/bg-check-wrap@3x.3f342771.png"
  },
  {
    "revision": "9713b21819c4019befecd095069977df",
    "url": "/img/bg-check-wrap@2x.9713b218.png"
  },
  {
    "revision": "fa855242805b87da42c65763acd64ac0",
    "url": "/img/bg-plan-type@2x.fa855242.png"
  },
  {
    "revision": "4a9ca192485effa8b8f4b5b2df5b9caf",
    "url": "/img/bg-plan-type@3x.4a9ca192.png"
  },
  {
    "revision": "1d7515ee61c3f659227318b4050955ed",
    "url": "/img/mobile_sim@2x.1d7515ee.png"
  },
  {
    "revision": "0f980b79d9a52702004de9f652a68835",
    "url": "/img/telcom_sim@2x.0f980b79.png"
  },
  {
    "revision": "98141226a7e992e3072a280746a259c4",
    "url": "/img/mobile_sim@3x.98141226.png"
  },
  {
    "revision": "0c88168b284b92c37f3a873f26a97d69",
    "url": "/img/bg.0c88168b.jpg"
  },
  {
    "revision": "9e02095f31a07b972244f1c714c1dfe7",
    "url": "/img/telcom_sim@3x.9e02095f.png"
  },
  {
    "revision": "3d0fc424b703032ca595090e99f8354b",
    "url": "/img/login_bg@2x.3d0fc424.png"
  },
  {
    "revision": "11000d4e510a6df565eb69ba6f2c1dfc",
    "url": "/img/login_bg@3x.11000d4e.png"
  },
  {
    "revision": "014d354b9b25b67ae95857ba17e2f4cc",
    "url": "/img/activityPage.014d354b.png"
  },
  {
    "revision": "2a67b73145562669220aa4639e1ad58f",
    "url": "/img/icon3.2a67b731.png"
  },
  {
    "revision": "813b5319e378dafdda952c16ad89906b",
    "url": "/img/icon2.813b5319.png"
  },
  {
    "revision": "f40c7e0b20fe25eb78a7658c3ae56312",
    "url": "/img/noData@3x.f40c7e0b.png"
  },
  {
    "revision": "644e6e3cf5f33943747b116316694e28",
    "url": "/img/noData@2x.644e6e3c.png"
  },
  {
    "revision": "0f16389ec218c90cf8f657e233b745f2",
    "url": "/img/balanceBg1.0f16389e.png"
  },
  {
    "revision": "565459ef2ee8b71db421144ad21c23e3",
    "url": "/img/balanceBg2.565459ef.png"
  },
  {
    "revision": "91e1d2771efacd45e5e465d9a001f197",
    "url": "/img/liantong.91e1d277.png"
  },
  {
    "revision": "4a0cab0f33beb48ea985714d1b91fef7",
    "url": "/img/dianxin.4a0cab0f.png"
  },
  {
    "revision": "657033323334e91efb0011bbc18f8c04",
    "url": "/img/yidong.65703332.png"
  },
  {
    "revision": "8da3b83b73e44e54d6be4b2522bcb1f2",
    "url": "/img/pkgBg2.8da3b83b.png"
  },
  {
    "revision": "d3b42651f9f5048baeffb50c800913ec",
    "url": "/img/pkgBg1.d3b42651.png"
  },
  {
    "revision": "d461d18e42a310bd709b2ce97d159153",
    "url": "/img/pkgBg3.d461d18e.png"
  },
  {
    "revision": "01355f175bd20423ce45a838c1a998a9",
    "url": "/img/bg.01355f17.png"
  },
  {
    "revision": "6dedd4943e4c5848638196fb6f0c4145",
    "url": "/img/bg.6dedd494.png"
  },
  {
    "revision": "0078f03c08066d51d64b92a13e194ebb",
    "url": "/img/balanceRefund.0078f03c.png"
  },
  {
    "revision": "af3ed0b3236bbfdbc3ad61b8d41c3dec",
    "url": "/img/changeBg.af3ed0b3.png"
  },
  {
    "revision": "0f642a655ea568f71ec4",
    "url": "/css/coupon_telcom.dd59f798.css"
  },
  {
    "revision": "dcc53c50f113df2961f2",
    "url": "/css/mifi_change_network.6a65b098.css"
  },
  {
    "revision": "5342361134c2b540401b",
    "url": "/css/coupon_wrapper.50c34f6c.css"
  },
  {
    "revision": "e2a6c20d1a5a57d2b06f",
    "url": "/css/authority_middle.3e84aa6f.css"
  },
  {
    "revision": "d62df7201c726f709131",
    "url": "/css/balanceRefund.6390149a.css"
  },
  {
    "revision": "bce0c0f9b456edeff551",
    "url": "/css/cardPackage.148104cb.css"
  },
  {
    "revision": "f16a064d51c328f23243",
    "url": "/css/card_check.d552e4f3.css"
  },
  {
    "revision": "f4eb91d075873b57306d",
    "url": "/css/card_connection.39d25408.css"
  },
  {
    "revision": "18bddef87a1c8d1cbb6f",
    "url": "/css/card_lookup.4695ceda.css"
  },
  {
    "revision": "bf090ececafb954d9751",
    "url": "/css/card_more_flow.f8261ebe.css"
  },
  {
    "revision": "6cae8434413d29777755",
    "url": "/css/card_usage.860d6785.css"
  },
  {
    "revision": "9d280216356ef78a9590",
    "url": "/css/card_wrapper.192c4d2a.css"
  },
  {
    "revision": "2d720d7ba1d67544bbb9",
    "url": "/css/children_card.1775f585.css"
  },
  {
    "revision": "3b63cc99d8f9772bd0ab",
    "url": "/css/chunk-68bb4772.d01d0c9f.css"
  },
  {
    "revision": "2cbf76e31147215d809c",
    "url": "/css/mifi_card_wrapper.02a09f97.css"
  },
  {
    "revision": "5667afe33a550611fbe9",
    "url": "/css/chunk-7a806b55.4282b53d.css"
  },
  {
    "revision": "7a37f1d32dcf31fafb6d",
    "url": "/css/chunk-vendors.4dda4045.css"
  },
  {
    "revision": "9d2607d9f5f4dad32ed8",
    "url": "/css/commonProblem.5e8824ed.css"
  },
  {
    "revision": "c336ff6c5a602d68c215",
    "url": "/css/commonQuestion.73b98bd3.css"
  },
  {
    "revision": "af61e9ba77b9edda772e",
    "url": "/css/consumerRecord.791fa7e8.css"
  },
  {
    "revision": "b04926488412c3fd8f62",
    "url": "/css/coupon_normal.e093da77.css"
  },
  {
    "revision": "508aae8866c6c7c5188b",
    "url": "/css/mifi_card_lookup.321bb0cb.css"
  },
  {
    "revision": "5a14d933f7ffa891355b",
    "url": "/css/balanceIndex.8d965d1d.css"
  },
  {
    "revision": "9affc1bb87f8685db1a0",
    "url": "/css/currencyConversion.aef5dc98.css"
  },
  {
    "revision": "111836324efbffcf4088",
    "url": "/css/customerFeedback.078f3095.css"
  },
  {
    "revision": "5ac148a04f62112e9cfc",
    "url": "/css/eqReplaceMent.d2fb3809.css"
  },
  {
    "revision": "45f2e57f7f820c9d11aa",
    "url": "/css/eqReplaceMent~recharge.d2dc69b7.css"
  },
  {
    "revision": "96dca18954fac143a348",
    "url": "/css/esim_plan_list.f44216c0.css"
  },
  {
    "revision": "f0a4b889a269ccf45789",
    "url": "/css/esim_usage.04997451.css"
  },
  {
    "revision": "abb023fec561a22cbaa1",
    "url": "/css/find_plan.e1ccaf2f.css"
  },
  {
    "revision": "7e119664feafb8e8a086",
    "url": "/css/logical_page.e4446a97.css"
  },
  {
    "revision": "9e88135934fc835a25f4",
    "url": "/css/login.c8ea4d93.css"
  },
  {
    "revision": "690670c1050786f67acf",
    "url": "/css/lookup.5b2812e1.css"
  },
  {
    "revision": "bdd9c65c7e094d8a23c4",
    "url": "/css/mifi_binding.7386ab19.css"
  },
  {
    "revision": "06bad74eb46616419bcf",
    "url": "/css/mifi_card_info.52368584.css"
  },
  {
    "revision": "a43f0a3e161ba377beb9",
    "url": "/css/app.0ccacaf2.css"
  },
  {
    "revision": "bebf236814a177833788",
    "url": "/css/Not_fund.e732a7c9.css"
  },
  {
    "revision": "4c81f0ba1cd5873a1ef9",
    "url": "/css/Layout.c0426652.css"
  },
  {
    "revision": "9ce16f441b39b493af8b96d7e97cce22",
    "url": "/MP_verify_dkzAKjxyVyJvsHMS.txt"
  },
  {
    "revision": "86c422d8c98b247235d04b49fb1c4b05",
    "url": "/MP_verify_bKSdn2qZlUSULliu.txt"
  },
  {
    "revision": "652317b098ca24e4511926c7fd57cbbe",
    "url": "/MP_verify_8JoCCldW78DygS5c.txt"
  },
  {
    "revision": "00bbf6b458bf7ea6bd01f443eb3045d9",
    "url": "/MP_verify_4r3DVk3KUjgWsQsG.txt"
  }
];