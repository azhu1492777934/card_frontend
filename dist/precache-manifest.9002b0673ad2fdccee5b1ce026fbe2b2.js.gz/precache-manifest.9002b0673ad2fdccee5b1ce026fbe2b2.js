self.__precacheManifest = [
  {
    "revision": "619b660c124be1285778",
    "url": "/css/recharge_wrapper.a4f6c950.css"
  },
  {
    "revision": "25da758518d6afed5cbb",
    "url": "/css/Layout.6f67a32f.css"
  },
  {
    "revision": "10679cd21017d22a21aa",
    "url": "/css/Layout~card_usage.8ac0b02d.css"
  },
  {
    "revision": "10679cd21017d22a21aa",
    "url": "/js/Layout~card_usage.20fe43c5.js"
  },
  {
    "revision": "f6fe50ccd582c459975e",
    "url": "/js/Layout~card_usage~eqReplaceMent~esim_plan_list~esim_usage~mifi_order~mifi_plan_list~mifi_plan_usage~~3166b5eb.91e2eec6.js"
  },
  {
    "revision": "469ba3f1f3cab05fab8c",
    "url": "/css/Not_fund.5c52a0eb.css"
  },
  {
    "revision": "469ba3f1f3cab05fab8c",
    "url": "/js/Not_fund.0c5ed069.js"
  },
  {
    "revision": "e3d2c9888a1e9adbe5a9",
    "url": "/css/app.72184c26.css"
  },
  {
    "revision": "e3d2c9888a1e9adbe5a9",
    "url": "/js/app.f007f815.js"
  },
  {
    "revision": "bb4b1e1c012baf42e3c3",
    "url": "/css/authority_middle.5c8a31a6.css"
  },
  {
    "revision": "bb4b1e1c012baf42e3c3",
    "url": "/js/authority_middle.44ca5295.js"
  },
  {
    "revision": "84690e94392583d855c6",
    "url": "/css/balanceIndex.3a3d3e38.css"
  },
  {
    "revision": "84690e94392583d855c6",
    "url": "/js/balanceIndex.82e44fe4.js"
  },
  {
    "revision": "9351781311fcc65137e9",
    "url": "/css/balanceRefund.ee7b6283.css"
  },
  {
    "revision": "9351781311fcc65137e9",
    "url": "/js/balanceRefund.662a3291.js"
  },
  {
    "revision": "755398a52f3157b054c1",
    "url": "/css/cardPackage.69acac42.css"
  },
  {
    "revision": "755398a52f3157b054c1",
    "url": "/js/cardPackage.ed69cbfc.js"
  },
  {
    "revision": "2a6fec425fcc441e2aec",
    "url": "/css/card_check.31896919.css"
  },
  {
    "revision": "2a6fec425fcc441e2aec",
    "url": "/js/card_check.a5fa06a2.js"
  },
  {
    "revision": "54badd1bf6fec4f90799",
    "url": "/css/card_connection.470ee167.css"
  },
  {
    "revision": "54badd1bf6fec4f90799",
    "url": "/js/card_connection.734b358e.js"
  },
  {
    "revision": "f4b34996414d58e2bdab",
    "url": "/css/card_lookup.41d60d9b.css"
  },
  {
    "revision": "f4b34996414d58e2bdab",
    "url": "/js/card_lookup.21020d2e.js"
  },
  {
    "revision": "7619edbb37a5ef4477d9",
    "url": "/css/card_more_flow.299a007b.css"
  },
  {
    "revision": "7619edbb37a5ef4477d9",
    "url": "/js/card_more_flow.ef1569e6.js"
  },
  {
    "revision": "78fa5727fcdab774d7f4",
    "url": "/css/card_usage.dea230c8.css"
  },
  {
    "revision": "78fa5727fcdab774d7f4",
    "url": "/js/card_usage.f18a3144.js"
  },
  {
    "revision": "0e1039d3aa563473d5e0",
    "url": "/css/card_wrapper.3cc70882.css"
  },
  {
    "revision": "0e1039d3aa563473d5e0",
    "url": "/js/card_wrapper.4d60c1d1.js"
  },
  {
    "revision": "bec1ca77a4bc3fec5438",
    "url": "/css/children_card.e0cfd6c9.css"
  },
  {
    "revision": "bec1ca77a4bc3fec5438",
    "url": "/js/children_card.e50418d6.js"
  },
  {
    "revision": "0f5daca184d6999bc529",
    "url": "/css/chunk-3f1ca40d.ded2705d.css"
  },
  {
    "revision": "0f5daca184d6999bc529",
    "url": "/js/chunk-3f1ca40d.d88594d9.js"
  },
  {
    "revision": "5068ab5b319bcc313fd8",
    "url": "/css/chunk-62202508.9b0212b1.css"
  },
  {
    "revision": "5068ab5b319bcc313fd8",
    "url": "/js/chunk-62202508.bd634981.js"
  },
  {
    "revision": "1ebe53c6e16039d4061b",
    "url": "/css/chunk-vendors.1d24696d.css"
  },
  {
    "revision": "1ebe53c6e16039d4061b",
    "url": "/js/chunk-vendors.33a8c1c6.js"
  },
  {
    "revision": "842962822122d757a4e1",
    "url": "/css/commonProblem.52e28e63.css"
  },
  {
    "revision": "842962822122d757a4e1",
    "url": "/js/commonProblem.19d565db.js"
  },
  {
    "revision": "c379f4597940d8674c88",
    "url": "/css/consumerRecord.54e23488.css"
  },
  {
    "revision": "c379f4597940d8674c88",
    "url": "/js/consumerRecord.ab6e6e9b.js"
  },
  {
    "revision": "768f6d750bf92e268fc5",
    "url": "/css/coupon_normal.758858d4.css"
  },
  {
    "revision": "768f6d750bf92e268fc5",
    "url": "/js/coupon_normal.0c82ce3b.js"
  },
  {
    "revision": "47f8a3beaa569a39a174",
    "url": "/css/coupon_telcom.1a9a5f5b.css"
  },
  {
    "revision": "47f8a3beaa569a39a174",
    "url": "/js/coupon_telcom.7c3fccdd.js"
  },
  {
    "revision": "849028204c921e6f7dad",
    "url": "/css/coupon_wrapper.7421536f.css"
  },
  {
    "revision": "849028204c921e6f7dad",
    "url": "/js/coupon_wrapper.367387ad.js"
  },
  {
    "revision": "fd0cfd939bc23de870a4",
    "url": "/css/currencyConversion.cfbe8dc2.css"
  },
  {
    "revision": "fd0cfd939bc23de870a4",
    "url": "/js/currencyConversion.90ed3e1b.js"
  },
  {
    "revision": "d519069ce3efa365b952",
    "url": "/css/eqReplaceMent.129e55b4.css"
  },
  {
    "revision": "d519069ce3efa365b952",
    "url": "/js/eqReplaceMent.9adbe5ef.js"
  },
  {
    "revision": "88105325033a3717bf7d",
    "url": "/css/esim_plan_list.ba0cc15b.css"
  },
  {
    "revision": "88105325033a3717bf7d",
    "url": "/js/esim_plan_list.8634d82c.js"
  },
  {
    "revision": "58525d7b9f77b8329eb1",
    "url": "/css/esim_usage.8f768238.css"
  },
  {
    "revision": "58525d7b9f77b8329eb1",
    "url": "/js/esim_usage.e8551c20.js"
  },
  {
    "revision": "5b5e1377ebfa8b2d0767",
    "url": "/css/find_plan.f6cd935e.css"
  },
  {
    "revision": "5b5e1377ebfa8b2d0767",
    "url": "/js/find_plan.7710e993.js"
  },
  {
    "revision": "53afd88de3c449b4de85",
    "url": "/css/logical_page.2c75593d.css"
  },
  {
    "revision": "53afd88de3c449b4de85",
    "url": "/js/logical_page.4d762ef3.js"
  },
  {
    "revision": "469ea95b22a00a1f70b8",
    "url": "/css/login.96c40e5c.css"
  },
  {
    "revision": "469ea95b22a00a1f70b8",
    "url": "/js/login.697745a0.js"
  },
  {
    "revision": "318e66f8ca418c28fe39",
    "url": "/css/lookup.ca3ad503.css"
  },
  {
    "revision": "318e66f8ca418c28fe39",
    "url": "/js/lookup.a89d2a0c.js"
  },
  {
    "revision": "899e818efa2fcaa980ad",
    "url": "/css/mifi_binding.41bda0b2.css"
  },
  {
    "revision": "899e818efa2fcaa980ad",
    "url": "/js/mifi_binding.311f3242.js"
  },
  {
    "revision": "cdc3379a6110da8d0268",
    "url": "/css/mifi_card_info.1dd44615.css"
  },
  {
    "revision": "cdc3379a6110da8d0268",
    "url": "/js/mifi_card_info.77b3c878.js"
  },
  {
    "revision": "a119211d94e588d22811",
    "url": "/css/mifi_card_lookup.b8848c87.css"
  },
  {
    "revision": "a119211d94e588d22811",
    "url": "/js/mifi_card_lookup.bd9f84d9.js"
  },
  {
    "revision": "170c9d70faf50533a612",
    "url": "/css/mifi_card_wrapper.eeb3aab7.css"
  },
  {
    "revision": "170c9d70faf50533a612",
    "url": "/js/mifi_card_wrapper.7a93668a.js"
  },
  {
    "revision": "e8b714da4c2bb2f941a8",
    "url": "/css/mifi_change_network.f8e58697.css"
  },
  {
    "revision": "e8b714da4c2bb2f941a8",
    "url": "/js/mifi_change_network.55826567.js"
  },
  {
    "revision": "45666ae0b5f5a9216043",
    "url": "/css/mifi_change_network_explanation.f69e1110.css"
  },
  {
    "revision": "45666ae0b5f5a9216043",
    "url": "/js/mifi_change_network_explanation.27b1ca43.js"
  },
  {
    "revision": "412a54feb9d22d59883d",
    "url": "/css/mifi_coupon_index.9da999d7.css"
  },
  {
    "revision": "412a54feb9d22d59883d",
    "url": "/js/mifi_coupon_index.0933e7fb.js"
  },
  {
    "revision": "b171d3c5782c4cf2f919",
    "url": "/css/mifi_coupon_wrapper.2bfbaf9a.css"
  },
  {
    "revision": "b171d3c5782c4cf2f919",
    "url": "/js/mifi_coupon_wrapper.6576b10a.js"
  },
  {
    "revision": "57b85ee2d302681ae0de",
    "url": "/css/mifi_index.ad559168.css"
  },
  {
    "revision": "57b85ee2d302681ae0de",
    "url": "/js/mifi_index.abb1c06f.js"
  },
  {
    "revision": "4653c86b88762bc8f817",
    "url": "/css/mifi_layout.64431227.css"
  },
  {
    "revision": "4653c86b88762bc8f817",
    "url": "/js/mifi_layout.8f5c12bd.js"
  },
  {
    "revision": "fc7b63a443de261f0530",
    "url": "/css/mifi_order.9eeb724c.css"
  },
  {
    "revision": "fc7b63a443de261f0530",
    "url": "/js/mifi_order.77371200.js"
  },
  {
    "revision": "69758578002c114500c9",
    "url": "/css/mifi_order_wrapper.56a3339d.css"
  },
  {
    "revision": "69758578002c114500c9",
    "url": "/js/mifi_order_wrapper.9b6be3de.js"
  },
  {
    "revision": "0e3374b5b87d7be5ae97",
    "url": "/css/mifi_order~mifi_plan_group.649e1a31.css"
  },
  {
    "revision": "0e3374b5b87d7be5ae97",
    "url": "/js/mifi_order~mifi_plan_group.2b2aed2a.js"
  },
  {
    "revision": "eb498fb585625188a14b",
    "url": "/css/mifi_plan_group.8d5d5f47.css"
  },
  {
    "revision": "eb498fb585625188a14b",
    "url": "/js/mifi_plan_group.bbdb3d61.js"
  },
  {
    "revision": "4a91fea129c474097b3b",
    "url": "/css/mifi_plan_list.24319321.css"
  },
  {
    "revision": "4a91fea129c474097b3b",
    "url": "/js/mifi_plan_list.00cc12bb.js"
  },
  {
    "revision": "ae4592eb2c4cd78b13cf",
    "url": "/css/mifi_plan_usage.6b219cee.css"
  },
  {
    "revision": "ae4592eb2c4cd78b13cf",
    "url": "/js/mifi_plan_usage.5732b95d.js"
  },
  {
    "revision": "c667e184a88fc64dafb3",
    "url": "/css/mifi_plan_wrapper.80fa7896.css"
  },
  {
    "revision": "c667e184a88fc64dafb3",
    "url": "/js/mifi_plan_wrapper.7fc8c82a.js"
  },
  {
    "revision": "9fe9b70dedfef1ba3922",
    "url": "/css/new_card_wrapper.552c75ad.css"
  },
  {
    "revision": "9fe9b70dedfef1ba3922",
    "url": "/js/new_card_wrapper.ba92a897.js"
  },
  {
    "revision": "b6f203167035803a9550",
    "url": "/css/orderRecord.7e656b17.css"
  },
  {
    "revision": "b6f203167035803a9550",
    "url": "/js/orderRecord.e77d94bc.js"
  },
  {
    "revision": "00f10c49339fdbb5c10d",
    "url": "/css/plan_list.789949cf.css"
  },
  {
    "revision": "00f10c49339fdbb5c10d",
    "url": "/js/plan_list.cec92e27.js"
  },
  {
    "revision": "284ea73ff1b8cd184ea7",
    "url": "/css/question.b7dd2ad2.css"
  },
  {
    "revision": "284ea73ff1b8cd184ea7",
    "url": "/js/question.35d9c9a9.js"
  },
  {
    "revision": "60800012c7c2271123a0",
    "url": "/css/question_wrapper.12696ad3.css"
  },
  {
    "revision": "60800012c7c2271123a0",
    "url": "/js/question_wrapper.b423f2e3.js"
  },
  {
    "revision": "512dc9577f9686ce3350",
    "url": "/css/realNameCourse.17a25c8d.css"
  },
  {
    "revision": "512dc9577f9686ce3350",
    "url": "/js/realNameCourse.683a7825.js"
  },
  {
    "revision": "ec5d54fc3631f982a360",
    "url": "/css/real_name.6fb4f04a.css"
  },
  {
    "revision": "ec5d54fc3631f982a360",
    "url": "/js/real_name.96b06e89.js"
  },
  {
    "revision": "cb78c060adbc0a5fc5ae",
    "url": "/css/recharge.041addd1.css"
  },
  {
    "revision": "cb78c060adbc0a5fc5ae",
    "url": "/js/recharge.04c6a56a.js"
  },
  {
    "revision": "afa9a44d7ffe4d428d31",
    "url": "/css/rechargeOrder.e4a58424.css"
  },
  {
    "revision": "afa9a44d7ffe4d428d31",
    "url": "/js/rechargeOrder.ec0553bb.js"
  },
  {
    "revision": "e90bcd3c9b2e9f01f082",
    "url": "/css/recharge_balance.624f0a27.css"
  },
  {
    "revision": "e90bcd3c9b2e9f01f082",
    "url": "/js/recharge_balance.369357c4.js"
  },
  {
    "revision": "b972f297670d7f3ec6fa",
    "url": "/css/recharge_callback.1a6cf6aa.css"
  },
  {
    "revision": "b972f297670d7f3ec6fa",
    "url": "/js/recharge_callback.e0f5b46f.js"
  },
  {
    "revision": "25da758518d6afed5cbb",
    "url": "/js/Layout.511f7ad0.js"
  },
  {
    "revision": "619b660c124be1285778",
    "url": "/js/recharge_wrapper.bd609ed7.js"
  },
  {
    "revision": "a1ab4fa923ab72375be9",
    "url": "/css/refundRules.1bf2644d.css"
  },
  {
    "revision": "a1ab4fa923ab72375be9",
    "url": "/js/refundRules.4c42e486.js"
  },
  {
    "revision": "b23410f73e668f105683",
    "url": "/css/refund_applying.572081e9.css"
  },
  {
    "revision": "b23410f73e668f105683",
    "url": "/js/refund_applying.5936834c.js"
  },
  {
    "revision": "a056bbddc8f09df15510",
    "url": "/css/refund_argument.ea8a95cb.css"
  },
  {
    "revision": "a056bbddc8f09df15510",
    "url": "/js/refund_argument.4c8f902e.js"
  },
  {
    "revision": "da1d31daa734bec616e7",
    "url": "/css/refund_plan.27895f86.css"
  },
  {
    "revision": "da1d31daa734bec616e7",
    "url": "/js/refund_plan.bd90ea48.js"
  },
  {
    "revision": "4a9aa49f4d70a5bbe990",
    "url": "/css/refund_wrapper.9829766a.css"
  },
  {
    "revision": "4a9aa49f4d70a5bbe990",
    "url": "/js/refund_wrapper.94315a82.js"
  },
  {
    "revision": "29bec0eaa98eb89d57a1",
    "url": "/css/repeatRecharge.a10eeb45.css"
  },
  {
    "revision": "29bec0eaa98eb89d57a1",
    "url": "/js/repeatRecharge.b592382e.js"
  },
  {
    "revision": "36663aa820820697858f",
    "url": "/css/revoke_plan.87b02ca7.css"
  },
  {
    "revision": "36663aa820820697858f",
    "url": "/js/revoke_plan.ec9990e9.js"
  },
  {
    "revision": "cfec471c732c52b5c726",
    "url": "/css/speedup_500.0b0c3ab6.css"
  },
  {
    "revision": "cfec471c732c52b5c726",
    "url": "/js/speedup_500.0fa19a69.js"
  },
  {
    "revision": "fd8fb4903103cc9ddeff",
    "url": "/css/speedup_80.f9c8f705.css"
  },
  {
    "revision": "fd8fb4903103cc9ddeff",
    "url": "/js/speedup_80.6c6672f4.js"
  },
  {
    "revision": "3e32ad13b7875319cf2f",
    "url": "/css/speedup_wrapper.31258838.css"
  },
  {
    "revision": "3e32ad13b7875319cf2f",
    "url": "/js/speedup_wrapper.c1f09ef8.js"
  },
  {
    "revision": "e09e5223db8f78005125",
    "url": "/css/to_tb.1a98473a.css"
  },
  {
    "revision": "e09e5223db8f78005125",
    "url": "/js/to_tb.acae7fb5.js"
  },
  {
    "revision": "f9b870e571202b37d0ef",
    "url": "/css/transfer_url.f6ebbdb1.css"
  },
  {
    "revision": "f9b870e571202b37d0ef",
    "url": "/js/transfer_url.ebb15ac8.js"
  },
  {
    "revision": "f75105a442efd5b9af33",
    "url": "/css/userCenter.6c2204af.css"
  },
  {
    "revision": "f75105a442efd5b9af33",
    "url": "/js/userCenter.ea6e90b1.js"
  },
  {
    "revision": "f6dc2d4b6e6dddb03f62",
    "url": "/css/userCenterWrap.16447e10.css"
  },
  {
    "revision": "f6dc2d4b6e6dddb03f62",
    "url": "/js/userCenterWrap.8be5dcea.js"
  },
  {
    "revision": "e4b411644706c29765eea3ffdd85ae39",
    "url": "/fonts/SourceHanSansCNRegular.e4b41164.woff"
  },
  {
    "revision": "834b022ab9ab0e6063904af32274e777",
    "url": "/fonts/SourceHanSansCNRegular.834b022a.eot"
  },
  {
    "revision": "f9509c5a10be7daaf1fa01922a7c6bc2",
    "url": "/fonts/SourceHanSansCNRegular.f9509c5a.ttf"
  },
  {
    "revision": "da0808e9fe85be160aab69c82dd8de1c",
    "url": "/img/SourceHanSansCNRegular.da0808e9.svg"
  },
  {
    "revision": "732389ded34cb9c52dd88271f1345af9",
    "url": "/fonts/element-icons.732389de.ttf"
  },
  {
    "revision": "535877f50039c0cb49a6196a5b7517cd",
    "url": "/fonts/element-icons.535877f5.woff"
  },
  {
    "revision": "0f16389ec218c90cf8f657e233b745f2",
    "url": "/img/balanceBg1.0f16389e.png"
  },
  {
    "revision": "565459ef2ee8b71db421144ad21c23e3",
    "url": "/img/balanceBg2.565459ef.png"
  },
  {
    "revision": "e625229e32d9deeb5f2909c314d8e609",
    "url": "/img/ios@2x.e625229e.png"
  },
  {
    "revision": "af8bbdfa0a90c4eed4563f8c06ce5ff8",
    "url": "/img/android@2x.af8bbdfa.png"
  },
  {
    "revision": "f5f322478286641bd9887a155e35f222",
    "url": "/img/btn.f5f32247.png"
  },
  {
    "revision": "d140650fa64e0f1fc771610dba62aed7",
    "url": "/img/bg.d140650f.png"
  },
  {
    "revision": "3f342771b9b81ab929e0fbcbcd0e6533",
    "url": "/img/bg-check-wrap@3x.3f342771.png"
  },
  {
    "revision": "9713b21819c4019befecd095069977df",
    "url": "/img/bg-check-wrap@2x.9713b218.png"
  },
  {
    "revision": "fa855242805b87da42c65763acd64ac0",
    "url": "/img/bg-plan-type@2x.fa855242.png"
  },
  {
    "revision": "4a9ca192485effa8b8f4b5b2df5b9caf",
    "url": "/img/bg-plan-type@3x.4a9ca192.png"
  },
  {
    "revision": "1d7515ee61c3f659227318b4050955ed",
    "url": "/img/mobile_sim@2x.1d7515ee.png"
  },
  {
    "revision": "0f980b79d9a52702004de9f652a68835",
    "url": "/img/telcom_sim@2x.0f980b79.png"
  },
  {
    "revision": "98141226a7e992e3072a280746a259c4",
    "url": "/img/mobile_sim@3x.98141226.png"
  },
  {
    "revision": "0c88168b284b92c37f3a873f26a97d69",
    "url": "/img/bg.0c88168b.jpg"
  },
  {
    "revision": "9e02095f31a07b972244f1c714c1dfe7",
    "url": "/img/telcom_sim@3x.9e02095f.png"
  },
  {
    "revision": "b70eddccd257b21777e71bb64c83b876",
    "url": "/img/bg.b70eddcc.jpeg"
  },
  {
    "revision": "909816c3d34e63a9ad86b8c179ab543c",
    "url": "/img/bar.909816c3.png"
  },
  {
    "revision": "e92f547ba0209da3b4342fa2b56ea9ae",
    "url": "/img/animater.e92f547b.png"
  },
  {
    "revision": "3d0fc424b703032ca595090e99f8354b",
    "url": "/img/login_bg@2x.3d0fc424.png"
  },
  {
    "revision": "11000d4e510a6df565eb69ba6f2c1dfc",
    "url": "/img/login_bg@3x.11000d4e.png"
  },
  {
    "revision": "91e1d2771efacd45e5e465d9a001f197",
    "url": "/img/liantong.91e1d277.png"
  },
  {
    "revision": "4a0cab0f33beb48ea985714d1b91fef7",
    "url": "/img/dianxin.4a0cab0f.png"
  },
  {
    "revision": "657033323334e91efb0011bbc18f8c04",
    "url": "/img/yidong.65703332.png"
  },
  {
    "revision": "8da3b83b73e44e54d6be4b2522bcb1f2",
    "url": "/img/pkgBg2.8da3b83b.png"
  },
  {
    "revision": "d3b42651f9f5048baeffb50c800913ec",
    "url": "/img/pkgBg1.d3b42651.png"
  },
  {
    "revision": "d461d18e42a310bd709b2ce97d159153",
    "url": "/img/pkgBg3.d461d18e.png"
  },
  {
    "revision": "014d354b9b25b67ae95857ba17e2f4cc",
    "url": "/img/activityPage.014d354b.png"
  },
  {
    "revision": "0078f03c08066d51d64b92a13e194ebb",
    "url": "/img/balanceRefund.0078f03c.png"
  },
  {
    "revision": "af3ed0b3236bbfdbc3ad61b8d41c3dec",
    "url": "/img/changeBg.af3ed0b3.png"
  },
  {
    "revision": "6dedd4943e4c5848638196fb6f0c4145",
    "url": "/img/bg.6dedd494.png"
  },
  {
    "revision": "2a67b73145562669220aa4639e1ad58f",
    "url": "/img/icon3.2a67b731.png"
  },
  {
    "revision": "813b5319e378dafdda952c16ad89906b",
    "url": "/img/icon2.813b5319.png"
  },
  {
    "revision": "f40c7e0b20fe25eb78a7658c3ae56312",
    "url": "/img/noData@3x.f40c7e0b.png"
  },
  {
    "revision": "644e6e3cf5f33943747b116316694e28",
    "url": "/img/noData@2x.644e6e3c.png"
  },
  {
    "revision": "01355f175bd20423ce45a838c1a998a9",
    "url": "/img/bg.01355f17.png"
  },
  {
    "revision": "42c0fbd4915870e5e60452fd0ef2cbec",
    "url": "/img/orderTopBg@3x.42c0fbd4.png"
  },
  {
    "revision": "42c0fbd4915870e5e60452fd0ef2cbec",
    "url": "/img/orderTopBg@2x.42c0fbd4.png"
  },
  {
    "revision": "a859e9ca4606d567c42b9c7bcd4fdce9",
    "url": "/img/iccid_bg@2x.a859e9ca.png"
  },
  {
    "revision": "fa9050c4e9870e8fc0cd184f8515af4a",
    "url": "/img/iccid_bg@3x.fa9050c4.png"
  },
  {
    "revision": "6e5cee7393060b0ec3dcd587c2518b94",
    "url": "/img/bg_test.6e5cee73.png"
  },
  {
    "revision": "d0ccbc8a35180bb40e027b44dd26035a",
    "url": "/img/youku.d0ccbc8a.png"
  },
  {
    "revision": "b899232b79ad9962c5ab5572775a0400",
    "url": "/img/card_index_bg@3x.b899232b.png"
  },
  {
    "revision": "b899232b79ad9962c5ab5572775a0400",
    "url": "/img/card_index_bg@2x.b899232b.png"
  },
  {
    "revision": "fff5af4325410621aeec4e60b3b92d9b",
    "url": "/img/mifi_binding_bg@3x.fff5af43.png"
  },
  {
    "revision": "fff5af4325410621aeec4e60b3b92d9b",
    "url": "/img/mifi_binding_bg@2x.fff5af43.png"
  },
  {
    "revision": "2c51a1e53c1ea0b35086d8d7261b4933",
    "url": "/img/bg_network@3x.2c51a1e5.png"
  },
  {
    "revision": "32d70c8fc305e3647098f3de0c71b618",
    "url": "/img/bg_network@2x.32d70c8f.png"
  },
  {
    "revision": "114a6e12b42b9b48586dd341105188fe",
    "url": "/img/usedOrder@2x.114a6e12.png"
  },
  {
    "revision": "c0170ec299b2418256fd515ee7849055",
    "url": "/img/unUsedOrder@2x.c0170ec2.png"
  },
  {
    "revision": "d9e14058d30dd312519fcf2de38d742b",
    "url": "/img/unUsedOrder@3x.d9e14058.png"
  },
  {
    "revision": "4a5b90f8076955f289b3dcda6a5af6ff",
    "url": "/img/invaildedOrder@3x.4a5b90f8.png"
  },
  {
    "revision": "0d5a5158e67bcb7a4604124715ed6fbf",
    "url": "/img/usedOrder@3x.0d5a5158.png"
  },
  {
    "revision": "be0f1e33b2553e71b117d3d3f838d32f",
    "url": "/img/invaildedOrder@2x.be0f1e33.png"
  },
  {
    "revision": "3603a35a49dbb8ad94ec1e57c4dad229",
    "url": "/img/scanTop2.3603a35a.png"
  },
  {
    "revision": "05775dd69c53d7273b27aaa7c6c523f7",
    "url": "/img/04.05775dd6.png"
  },
  {
    "revision": "541375e6bb7db2fba9e415be8045f5fb",
    "url": "/img/1.541375e6.png"
  },
  {
    "revision": "7c28431d304fa4f58f5070c59720683a",
    "url": "/img/2.7c28431d.png"
  },
  {
    "revision": "5a3428653945c17e1c146efeee81c987",
    "url": "/img/scanTop.5a342865.png"
  },
  {
    "revision": "824594523c01e48028f2b7eb4261134d",
    "url": "/img/unicom-logo.82459452.svg"
  },
  {
    "revision": "113f99e2189c2ca49db2168754fc2eb5",
    "url": "/img/mobile-logo.113f99e2.png"
  },
  {
    "revision": "0cba868fa977e09806638b9000636a36",
    "url": "/img/avatar.0cba868f.jpeg"
  },
  {
    "revision": "27158aa79eb0d4b89f317d076a801ca3",
    "url": "/img/coupon-log.27158aa7.png"
  },
  {
    "revision": "55d3f2f09efe17db6485d4c9f8f0c3b1",
    "url": "/img/icon-recharge_20181001.55d3f2f0.svg"
  },
  {
    "revision": "165beb68d8ba0d2b70df0fbb3769787a",
    "url": "/img/03.165beb68.png"
  },
  {
    "revision": "5f1f34037094c0613bccafa2ddd8cb3b",
    "url": "/img/telecom-logo.5f1f3403.svg"
  },
  {
    "revision": "aecc9531f2c3b1fd45338e7bf5084384",
    "url": "/img/bg_no_recharge.aecc9531.svg"
  },
  {
    "revision": "b0ffa4a0fd195a110ee4d4dabce3bc32",
    "url": "/img/08.b0ffa4a0.png"
  },
  {
    "revision": "96fab583abd57f2e7118324858fa3080",
    "url": "/img/05.96fab583.png"
  },
  {
    "revision": "9e8ecc7f7b760b55c56bddfab886da10",
    "url": "/img/3.9e8ecc7f.png"
  },
  {
    "revision": "275be51ae57c486bce58257febd6589f",
    "url": "/img/bg_no_plan.275be51a.svg"
  },
  {
    "revision": "a8272d2d742d9d50257e23dfac577def",
    "url": "/img/01.a8272d2d.png"
  },
  {
    "revision": "daa86b540bb9c2a6453ceac9bed77961",
    "url": "/img/07.daa86b54.png"
  },
  {
    "revision": "06385746a7cedb492d5539907631561c",
    "url": "/img/tip.06385746.png"
  },
  {
    "revision": "eacba58f9acf2b87cd801858146b2ba9",
    "url": "/img/02.eacba58f.png"
  },
  {
    "revision": "39d9e849fc1c724525f166646932a24d",
    "url": "/img/safari.39d9e849.png"
  },
  {
    "revision": "999589aae784a460b5e7c6ae9bbaa3d8",
    "url": "/img/06.999589aa.png"
  },
  {
    "revision": "0b3c3297decbd1152a314cce115f9632",
    "url": "/img/09.0b3c3297.png"
  },
  {
    "revision": "3e217df4202e41ad9b030aafc8cfcc24",
    "url": "/img/4.3e217df4.png"
  },
  {
    "revision": "56af3fc35e2550c1e8545511a5daf9ec",
    "url": "/index.html"
  },
  {
    "revision": "b6216d61c03e6ce0c9aea6ca7808f7ca",
    "url": "/robots.txt"
  },
  {
    "revision": "9ce16f441b39b493af8b96d7e97cce22",
    "url": "/MP_verify_dkzAKjxyVyJvsHMS.txt"
  },
  {
    "revision": "86c422d8c98b247235d04b49fb1c4b05",
    "url": "/MP_verify_bKSdn2qZlUSULliu.txt"
  },
  {
    "revision": "652317b098ca24e4511926c7fd57cbbe",
    "url": "/MP_verify_8JoCCldW78DygS5c.txt"
  },
  {
    "revision": "00bbf6b458bf7ea6bd01f443eb3045d9",
    "url": "/MP_verify_4r3DVk3KUjgWsQsG.txt"
  }
];