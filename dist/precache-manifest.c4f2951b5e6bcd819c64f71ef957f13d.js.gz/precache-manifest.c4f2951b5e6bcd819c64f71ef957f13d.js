self.__precacheManifest = [
  {
    "revision": "2bf416076e4daecef2e7",
    "url": "/css/refundRules.2dbf09a5.css"
  },
  {
    "revision": "735ab4f94fbcd57074377afca324c813",
    "url": "/robots.txt"
  },
  {
    "revision": "2bf416076e4daecef2e7",
    "url": "/js/refundRules.6ae1a5ba.js"
  },
  {
    "revision": "78214ba34c5f1df936aa",
    "url": "/js/Layout~card_usage~eqReplaceMent~esim_plan_list~esim_usage~mifi_order~mifi_plan_list~mifi_plan_usage~~c6f87c36.6241bd21.js"
  },
  {
    "revision": "4031a33769eb9570b2be",
    "url": "/js/Not_fund.ebd54317.js"
  },
  {
    "revision": "4d7d27cdcda6331977f5",
    "url": "/js/userCenterWrap.2a137128.js"
  },
  {
    "revision": "e9203141ef77adc93a6d",
    "url": "/js/app.af0cf254.js"
  },
  {
    "revision": "ad21f6d79e4a6622128a",
    "url": "/js/userCenter.f079c039.js"
  },
  {
    "revision": "dfc4ab08e6c054796780",
    "url": "/js/authority_middle.063490b9.js"
  },
  {
    "revision": "f3c8197b0ed70ba9e16e",
    "url": "/js/transfer_url.46cc5089.js"
  },
  {
    "revision": "cea9418e8c7b0228fb06",
    "url": "/js/balanceIndex.9e6a99e4.js"
  },
  {
    "revision": "bf1bf83d6fc3be1802e5",
    "url": "/js/to_tb.24c9dac3.js"
  },
  {
    "revision": "d03fa150e7b9eec7ee47",
    "url": "/js/balanceRefund.b28cf7c7.js"
  },
  {
    "revision": "fcf5321d8c797a6d3702",
    "url": "/js/speedup_wrapper.be3d7b3f.js"
  },
  {
    "revision": "658e83746d6de710af25",
    "url": "/js/cardPackage.3756cabe.js"
  },
  {
    "revision": "b47f7fe09893660e7df6",
    "url": "/js/speedup_80.c92788a3.js"
  },
  {
    "revision": "0ee5e273edcd8130dac5",
    "url": "/js/card_check.04c3f534.js"
  },
  {
    "revision": "1072a68f3a57f1b33598",
    "url": "/js/speedup_500.3d4f713f.js"
  },
  {
    "revision": "b91c327e413d440da20c",
    "url": "/js/card_connection.918cb517.js"
  },
  {
    "revision": "d01ae3c3c843ef6c6a6b",
    "url": "/js/revoke_plan.7b1d791c.js"
  },
  {
    "revision": "069ae2e8b588f1242600",
    "url": "/js/card_lookup.2d1e01e4.js"
  },
  {
    "revision": "dcdea2ab2ca4a9b29067",
    "url": "/js/repeatRecharge.e5949cf7.js"
  },
  {
    "revision": "6a0f2bc5628beac9918f",
    "url": "/js/card_more_flow.f373fe00.js"
  },
  {
    "revision": "86b4de88a49a47d670cb",
    "url": "/js/refund_wrapper.e3445f06.js"
  },
  {
    "revision": "8f7a725b8335e281424a",
    "url": "/js/card_usage.1ecb82f7.js"
  },
  {
    "revision": "fa3d88c80b9bc813f1c1",
    "url": "/js/refund_plan.6cc54102.js"
  },
  {
    "revision": "5ef44a69ba4afda72ad0",
    "url": "/js/card_usage~plan_list.3912bbe2.js"
  },
  {
    "revision": "cd538f910f0016493fd9",
    "url": "/js/refund_argument.2dd0af35.js"
  },
  {
    "revision": "dad8373d7760fffd522f",
    "url": "/js/card_wrapper.04265140.js"
  },
  {
    "revision": "548e4af67d6352d2d9d3",
    "url": "/js/refund_applying.3c626bda.js"
  },
  {
    "revision": "a553314594d4e9c6e19a",
    "url": "/js/children_card.ba095ab8.js"
  },
  {
    "revision": "78a25917c4ec7512a004",
    "url": "/js/recharge_wrapper.2ff45b44.js"
  },
  {
    "revision": "fadde9afed829c78134e",
    "url": "/js/chunk-518bd018.b56ef8df.js"
  },
  {
    "revision": "3bd2dc613140519ada2c",
    "url": "/js/recharge_callback.2221777a.js"
  },
  {
    "revision": "6dc4af86b76b2bedb51b",
    "url": "/js/chunk-b243290a.27a79d2a.js"
  },
  {
    "revision": "67340102ccc81ef13acf",
    "url": "/js/recharge_balance.f073904b.js"
  },
  {
    "revision": "894d31a9da0d57a178d3",
    "url": "/js/chunk-vendors.4ec2dc53.js"
  },
  {
    "revision": "3b7af43709483076f711",
    "url": "/js/rechargeOrder.50a88e12.js"
  },
  {
    "revision": "b7d5197a9c1171efeca4",
    "url": "/js/commonProblem.9c86b3dc.js"
  },
  {
    "revision": "7edc88694cd14f96ac6d",
    "url": "/js/recharge.40cb08d6.js"
  },
  {
    "revision": "ff80e5ec3f4f0830c1e3",
    "url": "/js/commonQuestion.5304aec2.js"
  },
  {
    "revision": "489b7c56b3fb6ec0f1b1",
    "url": "/js/real_name.411b4054.js"
  },
  {
    "revision": "1c9d5b179fea27ca379d",
    "url": "/js/consumerRecord.746b6bef.js"
  },
  {
    "revision": "5e4e2466787b89fad922",
    "url": "/js/realNameCourse.7c4f91f3.js"
  },
  {
    "revision": "0a8a2e7d40a2df3e8e5f",
    "url": "/js/coupon_normal.b3754913.js"
  },
  {
    "revision": "e13d9698ddc9907b8736",
    "url": "/js/question_wrapper.97f9b797.js"
  },
  {
    "revision": "d7376fc132b6bf21b05b",
    "url": "/js/coupon_telcom.b5d3ed48.js"
  },
  {
    "revision": "61b6b6167a8d28d949d7",
    "url": "/js/question.1f48e76a.js"
  },
  {
    "revision": "b015aa59cc0a3e03fca4",
    "url": "/js/coupon_wrapper.c6753c26.js"
  },
  {
    "revision": "ee985bd0d2a3902070d9",
    "url": "/js/plan_list.38ba1b3f.js"
  },
  {
    "revision": "92c7ef5c2b96f2259ae3",
    "url": "/js/currencyConversion.76eb9862.js"
  },
  {
    "revision": "b7f4a977849e52034384",
    "url": "/js/orderRecord.55b103f3.js"
  },
  {
    "revision": "65640b5027cee9c87284",
    "url": "/js/customerFeedback.570fd8fc.js"
  },
  {
    "revision": "5cdf6f86dd0e8b1ecafe",
    "url": "/js/official_accounts.fcbbe0fe.js"
  },
  {
    "revision": "04d5570d412eccb6ec80",
    "url": "/js/eqReplaceMent.30954f2d.js"
  },
  {
    "revision": "73d6116f00e19957e82f",
    "url": "/js/new_card_wrapper.d8204c2d.js"
  },
  {
    "revision": "a2ac358b5ba0d37e1f75",
    "url": "/js/eqReplaceMent~recharge.0c032fb1.js"
  },
  {
    "revision": "70f936dafafc88cffd35",
    "url": "/js/mifi_plan_wrapper.9cb7afe4.js"
  },
  {
    "revision": "6d979624e843e53e0189",
    "url": "/js/esim_plan_list.11469ea0.js"
  },
  {
    "revision": "bc862ea253c53a05292d",
    "url": "/js/mifi_plan_usage.c0d976db.js"
  },
  {
    "revision": "a08d7e8d7492cf9e5182",
    "url": "/js/esim_usage.397de141.js"
  },
  {
    "revision": "acc65153867b48f86da7",
    "url": "/js/mifi_plan_list.d2bfa298.js"
  },
  {
    "revision": "eae54a6f44ecb2a53f1a",
    "url": "/js/find_plan.185de43d.js"
  },
  {
    "revision": "d174235926b8eb3fc156",
    "url": "/js/mifi_plan_group.13957413.js"
  },
  {
    "revision": "c281fc54336ce3c7049e",
    "url": "/js/guardian.ad7cb68e.js"
  },
  {
    "revision": "bb072377ff3ccefceb7b",
    "url": "/js/mifi_order_wrapper.a70482d6.js"
  },
  {
    "revision": "e2e1b972254a35ac449d",
    "url": "/js/logical_page.35b1c546.js"
  },
  {
    "revision": "2de1c570fdbf8156a4d4",
    "url": "/js/mifi_order.50efb414.js"
  },
  {
    "revision": "8faa8cedffad2c71caf8",
    "url": "/js/login.20a002f2.js"
  },
  {
    "revision": "85729c0bf79272d1a5ab",
    "url": "/js/mifi_layout.b5a752c4.js"
  },
  {
    "revision": "d00f6f449ab145f2bccc",
    "url": "/js/lookup.14e3fec9.js"
  },
  {
    "revision": "812d03bedd7428b178fc",
    "url": "/js/mifi_index.9ae91a5b.js"
  },
  {
    "revision": "261eef52c39a693344c6",
    "url": "/js/mifi_binding.bcf6b424.js"
  },
  {
    "revision": "20358593289dbd4e43d3",
    "url": "/js/mifi_coupon_wrapper.3dd2458b.js"
  },
  {
    "revision": "49fdaa895ca8b990a5b8",
    "url": "/js/mifi_card_info.b5d12177.js"
  },
  {
    "revision": "9230218cb0ddfb36511d",
    "url": "/js/mifi_coupon_index.7dc805cc.js"
  },
  {
    "revision": "04440f1b96eebc41a332",
    "url": "/js/mifi_card_lookup.16cfc3d6.js"
  },
  {
    "revision": "ce269fe744052fe127c2",
    "url": "/js/mifi_change_network_explanation.521737b3.js"
  },
  {
    "revision": "ae9941cec92ff331f618",
    "url": "/js/mifi_card_wrapper.7fbbc97c.js"
  },
  {
    "revision": "927065ca259d7e6369c5",
    "url": "/js/mifi_change_network.a0d3a7be.js"
  },
  {
    "revision": "f5f322478286641bd9887a155e35f222",
    "url": "/img/btn.f5f32247.png"
  },
  {
    "revision": "927065ca259d7e6369c5",
    "url": "/css/mifi_change_network.d2c5452c.css"
  },
  {
    "revision": "535d69151fe7f92d82a53056c2f2ef2c",
    "url": "/index.html"
  },
  {
    "revision": "9230218cb0ddfb36511d",
    "url": "/css/mifi_coupon_index.1b53422e.css"
  },
  {
    "revision": "999589aae784a460b5e7c6ae9bbaa3d8",
    "url": "/img/06.999589aa.png"
  },
  {
    "revision": "20358593289dbd4e43d3",
    "url": "/css/mifi_coupon_wrapper.3db278e7.css"
  },
  {
    "revision": "39d9e849fc1c724525f166646932a24d",
    "url": "/img/safari.39d9e849.png"
  },
  {
    "revision": "812d03bedd7428b178fc",
    "url": "/css/mifi_index.780eacab.css"
  },
  {
    "revision": "eacba58f9acf2b87cd801858146b2ba9",
    "url": "/img/02.eacba58f.png"
  },
  {
    "revision": "85729c0bf79272d1a5ab",
    "url": "/css/mifi_layout.c437464c.css"
  },
  {
    "revision": "a610420eab741be28278e60bc06387aa",
    "url": "/img/box-deco@3x.a610420e.png"
  },
  {
    "revision": "2de1c570fdbf8156a4d4",
    "url": "/css/mifi_order.51527581.css"
  },
  {
    "revision": "687b6ce03f134f21173c949d79002960",
    "url": "/img/tip.687b6ce0.png"
  },
  {
    "revision": "bb072377ff3ccefceb7b",
    "url": "/css/mifi_order_wrapper.f10d3bed.css"
  },
  {
    "revision": "daa86b540bb9c2a6453ceac9bed77961",
    "url": "/img/07.daa86b54.png"
  },
  {
    "revision": "d174235926b8eb3fc156",
    "url": "/css/mifi_plan_group.e5867a88.css"
  },
  {
    "revision": "a8272d2d742d9d50257e23dfac577def",
    "url": "/img/01.a8272d2d.png"
  },
  {
    "revision": "acc65153867b48f86da7",
    "url": "/css/mifi_plan_list.b2aad62f.css"
  },
  {
    "revision": "f23d9d1f76147bc89b48902c36818f1e",
    "url": "/img/bg_no_plan.f23d9d1f.svg"
  },
  {
    "revision": "bc862ea253c53a05292d",
    "url": "/css/mifi_plan_usage.3708b38f.css"
  },
  {
    "revision": "9e8ecc7f7b760b55c56bddfab886da10",
    "url": "/img/3.9e8ecc7f.png"
  },
  {
    "revision": "70f936dafafc88cffd35",
    "url": "/css/mifi_plan_wrapper.034f9976.css"
  },
  {
    "revision": "96fab583abd57f2e7118324858fa3080",
    "url": "/img/05.96fab583.png"
  },
  {
    "revision": "73d6116f00e19957e82f",
    "url": "/css/new_card_wrapper.fbadfe48.css"
  },
  {
    "revision": "b0ffa4a0fd195a110ee4d4dabce3bc32",
    "url": "/img/08.b0ffa4a0.png"
  },
  {
    "revision": "5cdf6f86dd0e8b1ecafe",
    "url": "/css/official_accounts.aa223422.css"
  },
  {
    "revision": "34c67f6dfdb0ecc17c7a221aec74706f",
    "url": "/img/bg_no_recharge.34c67f6d.svg"
  },
  {
    "revision": "b7f4a977849e52034384",
    "url": "/css/orderRecord.f31eec10.css"
  },
  {
    "revision": "3e217df4202e41ad9b030aafc8cfcc24",
    "url": "/img/4.3e217df4.png"
  },
  {
    "revision": "ee985bd0d2a3902070d9",
    "url": "/css/plan_list.12b02888.css"
  },
  {
    "revision": "0b3c3297decbd1152a314cce115f9632",
    "url": "/img/09.0b3c3297.png"
  },
  {
    "revision": "61b6b6167a8d28d949d7",
    "url": "/css/question.b6b432e6.css"
  },
  {
    "revision": "89b99d16dd8a4a56746323a0ffbd754c",
    "url": "/img/migu.89b99d16.png"
  },
  {
    "revision": "e13d9698ddc9907b8736",
    "url": "/css/question_wrapper.1dddf2fc.css"
  },
  {
    "revision": "f7a51f1c554585b11d61499fd0a7520f",
    "url": "/img/only-box@3x.f7a51f1c.png"
  },
  {
    "revision": "5e4e2466787b89fad922",
    "url": "/css/realNameCourse.cca1ebeb.css"
  },
  {
    "revision": "8c605ac88ca50357355da465f322d10a",
    "url": "/img/telecom-logo.8c605ac8.svg"
  },
  {
    "revision": "489b7c56b3fb6ec0f1b1",
    "url": "/css/real_name.a7384119.css"
  },
  {
    "revision": "165beb68d8ba0d2b70df0fbb3769787a",
    "url": "/img/03.165beb68.png"
  },
  {
    "revision": "7edc88694cd14f96ac6d",
    "url": "/css/recharge.12721058.css"
  },
  {
    "revision": "55d3f2f09efe17db6485d4c9f8f0c3b1",
    "url": "/img/icon-recharge_20181001.55d3f2f0.svg"
  },
  {
    "revision": "3b7af43709483076f711",
    "url": "/css/rechargeOrder.51a413f9.css"
  },
  {
    "revision": "27158aa79eb0d4b89f317d076a801ca3",
    "url": "/img/coupon-log.27158aa7.png"
  },
  {
    "revision": "67340102ccc81ef13acf",
    "url": "/css/recharge_balance.60712b7b.css"
  },
  {
    "revision": "0cba868fa977e09806638b9000636a36",
    "url": "/img/avatar.0cba868f.jpeg"
  },
  {
    "revision": "3bd2dc613140519ada2c",
    "url": "/css/recharge_callback.311d4bba.css"
  },
  {
    "revision": "113f99e2189c2ca49db2168754fc2eb5",
    "url": "/img/mobile-logo.113f99e2.png"
  },
  {
    "revision": "78a25917c4ec7512a004",
    "url": "/css/recharge_wrapper.3cc70882.css"
  },
  {
    "revision": "0b9e0b5f4f28c68416f916ddce3fc7ef",
    "url": "/img/unicom-logo.0b9e0b5f.svg"
  },
  {
    "revision": "fe349c0eccd231c36f35",
    "url": "/js/Layout.5937417b.js"
  },
  {
    "revision": "5a3428653945c17e1c146efeee81c987",
    "url": "/img/scanTop.5a342865.png"
  },
  {
    "revision": "548e4af67d6352d2d9d3",
    "url": "/css/refund_applying.60824256.css"
  },
  {
    "revision": "7c28431d304fa4f58f5070c59720683a",
    "url": "/img/2.7c28431d.png"
  },
  {
    "revision": "cd538f910f0016493fd9",
    "url": "/css/refund_argument.9b90ba42.css"
  },
  {
    "revision": "541375e6bb7db2fba9e415be8045f5fb",
    "url": "/img/1.541375e6.png"
  },
  {
    "revision": "fa3d88c80b9bc813f1c1",
    "url": "/css/refund_plan.a6df1d09.css"
  },
  {
    "revision": "58a560568b7291ea926c2c7438035308",
    "url": "/img/subscribe@3x.58a56056.png"
  },
  {
    "revision": "86b4de88a49a47d670cb",
    "url": "/css/refund_wrapper.2bfbaf9a.css"
  },
  {
    "revision": "05775dd69c53d7273b27aaa7c6c523f7",
    "url": "/img/04.05775dd6.png"
  },
  {
    "revision": "dcdea2ab2ca4a9b29067",
    "url": "/css/repeatRecharge.c5d0bb68.css"
  },
  {
    "revision": "3603a35a49dbb8ad94ec1e57c4dad229",
    "url": "/img/scanTop2.3603a35a.png"
  },
  {
    "revision": "d01ae3c3c843ef6c6a6b",
    "url": "/css/revoke_plan.5e865a04.css"
  },
  {
    "revision": "be0f1e33b2553e71b117d3d3f838d32f",
    "url": "/img/invaildedOrder@2x.be0f1e33.png"
  },
  {
    "revision": "1072a68f3a57f1b33598",
    "url": "/css/speedup_500.c6366a0b.css"
  },
  {
    "revision": "0d5a5158e67bcb7a4604124715ed6fbf",
    "url": "/img/usedOrder@3x.0d5a5158.png"
  },
  {
    "revision": "b47f7fe09893660e7df6",
    "url": "/css/speedup_80.57204c7c.css"
  },
  {
    "revision": "4a5b90f8076955f289b3dcda6a5af6ff",
    "url": "/img/invaildedOrder@3x.4a5b90f8.png"
  },
  {
    "revision": "fcf5321d8c797a6d3702",
    "url": "/css/speedup_wrapper.fb951ea8.css"
  },
  {
    "revision": "d9e14058d30dd312519fcf2de38d742b",
    "url": "/img/unUsedOrder@3x.d9e14058.png"
  },
  {
    "revision": "bf1bf83d6fc3be1802e5",
    "url": "/css/to_tb.46e6e953.css"
  },
  {
    "revision": "c0170ec299b2418256fd515ee7849055",
    "url": "/img/unUsedOrder@2x.c0170ec2.png"
  },
  {
    "revision": "f3c8197b0ed70ba9e16e",
    "url": "/css/transfer_url.ec530465.css"
  },
  {
    "revision": "6e5cee7393060b0ec3dcd587c2518b94",
    "url": "/img/bg_test@2x.6e5cee73.png"
  },
  {
    "revision": "ad21f6d79e4a6622128a",
    "url": "/css/userCenter.11c78d79.css"
  },
  {
    "revision": "114a6e12b42b9b48586dd341105188fe",
    "url": "/img/usedOrder@2x.114a6e12.png"
  },
  {
    "revision": "4d7d27cdcda6331977f5",
    "url": "/css/userCenterWrap.1098fc92.css"
  },
  {
    "revision": "6e5cee7393060b0ec3dcd587c2518b94",
    "url": "/img/bg_test@3x.6e5cee73.png"
  },
  {
    "revision": "e4b411644706c29765eea3ffdd85ae39",
    "url": "/fonts/SourceHanSansCNRegular.e4b41164.woff"
  },
  {
    "revision": "834b022ab9ab0e6063904af32274e777",
    "url": "/fonts/SourceHanSansCNRegular.834b022a.eot"
  },
  {
    "revision": "f9509c5a10be7daaf1fa01922a7c6bc2",
    "url": "/fonts/SourceHanSansCNRegular.f9509c5a.ttf"
  },
  {
    "revision": "da0808e9fe85be160aab69c82dd8de1c",
    "url": "/img/SourceHanSansCNRegular.da0808e9.svg"
  },
  {
    "revision": "732389ded34cb9c52dd88271f1345af9",
    "url": "/fonts/element-icons.732389de.ttf"
  },
  {
    "revision": "535877f50039c0cb49a6196a5b7517cd",
    "url": "/fonts/element-icons.535877f5.woff"
  },
  {
    "revision": "0f16389ec218c90cf8f657e233b745f2",
    "url": "/img/balanceBg1.0f16389e.png"
  },
  {
    "revision": "565459ef2ee8b71db421144ad21c23e3",
    "url": "/img/balanceBg2.565459ef.png"
  },
  {
    "revision": "fff5af4325410621aeec4e60b3b92d9b",
    "url": "/img/mifi_binding_bg@3x.fff5af43.png"
  },
  {
    "revision": "fff5af4325410621aeec4e60b3b92d9b",
    "url": "/img/mifi_binding_bg@2x.fff5af43.png"
  },
  {
    "revision": "b899232b79ad9962c5ab5572775a0400",
    "url": "/img/card_index_bg@3x.b899232b.png"
  },
  {
    "revision": "b899232b79ad9962c5ab5572775a0400",
    "url": "/img/card_index_bg@2x.b899232b.png"
  },
  {
    "revision": "ce269fe744052fe127c2",
    "url": "/css/mifi_change_network_explanation.36f1504f.css"
  },
  {
    "revision": "d140650fa64e0f1fc771610dba62aed7",
    "url": "/img/bg.d140650f.png"
  },
  {
    "revision": "e625229e32d9deeb5f2909c314d8e609",
    "url": "/img/ios@2x.e625229e.png"
  },
  {
    "revision": "af8bbdfa0a90c4eed4563f8c06ce5ff8",
    "url": "/img/android@2x.af8bbdfa.png"
  },
  {
    "revision": "cc0636ca2944024fd3ebf33a5412ff35",
    "url": "/img/icon-right@3x.cc0636ca.png"
  },
  {
    "revision": "1b983020cfed6b7a8ca5c300c24ca186",
    "url": "/img/icon-left@3x.1b983020.png"
  },
  {
    "revision": "d796d97eb9ebb2e89bb966343e2362e9",
    "url": "/img/icon-left@2x.d796d97e.png"
  },
  {
    "revision": "ccb9865dadbc642b8c4dd0a1abc8e570",
    "url": "/img/recharge-word@2x.ccb9865d.png"
  },
  {
    "revision": "ccb9865dadbc642b8c4dd0a1abc8e570",
    "url": "/img/recharge-word@3x.ccb9865d.png"
  },
  {
    "revision": "41a8c268f703fe646d5d08099eb778ae",
    "url": "/img/icon-right@2x.41a8c268.png"
  },
  {
    "revision": "2d6d06f4da15fc1a748677c49c5f1854",
    "url": "/img/bg.2d6d06f4.png"
  },
  {
    "revision": "3f342771b9b81ab929e0fbcbcd0e6533",
    "url": "/img/bg-check-wrap@3x.3f342771.png"
  },
  {
    "revision": "9713b21819c4019befecd095069977df",
    "url": "/img/bg-check-wrap@2x.9713b218.png"
  },
  {
    "revision": "fa855242805b87da42c65763acd64ac0",
    "url": "/img/bg-plan-type@2x.fa855242.png"
  },
  {
    "revision": "4a9ca192485effa8b8f4b5b2df5b9caf",
    "url": "/img/bg-plan-type@3x.4a9ca192.png"
  },
  {
    "revision": "e93b8c03293c5b6a311da784f9c19c8f",
    "url": "/img/bg.e93b8c03.jpeg"
  },
  {
    "revision": "ffb1612d9660e2ecd9d3872d57a8a2f9",
    "url": "/img/bar.ffb1612d.png"
  },
  {
    "revision": "1d7515ee61c3f659227318b4050955ed",
    "url": "/img/mobile_sim@2x.1d7515ee.png"
  },
  {
    "revision": "0f980b79d9a52702004de9f652a68835",
    "url": "/img/telcom_sim@2x.0f980b79.png"
  },
  {
    "revision": "98141226a7e992e3072a280746a259c4",
    "url": "/img/mobile_sim@3x.98141226.png"
  },
  {
    "revision": "0c88168b284b92c37f3a873f26a97d69",
    "url": "/img/bg.0c88168b.jpg"
  },
  {
    "revision": "9e02095f31a07b972244f1c714c1dfe7",
    "url": "/img/telcom_sim@3x.9e02095f.png"
  },
  {
    "revision": "014d354b9b25b67ae95857ba17e2f4cc",
    "url": "/img/activityPage.014d354b.png"
  },
  {
    "revision": "3d0fc424b703032ca595090e99f8354b",
    "url": "/img/login_bg@2x.3d0fc424.png"
  },
  {
    "revision": "11000d4e510a6df565eb69ba6f2c1dfc",
    "url": "/img/login_bg@3x.11000d4e.png"
  },
  {
    "revision": "2a67b73145562669220aa4639e1ad58f",
    "url": "/img/icon3.2a67b731.png"
  },
  {
    "revision": "813b5319e378dafdda952c16ad89906b",
    "url": "/img/icon2.813b5319.png"
  },
  {
    "revision": "f40c7e0b20fe25eb78a7658c3ae56312",
    "url": "/img/noData@3x.f40c7e0b.png"
  },
  {
    "revision": "644e6e3cf5f33943747b116316694e28",
    "url": "/img/noData@2x.644e6e3c.png"
  },
  {
    "revision": "91e1d2771efacd45e5e465d9a001f197",
    "url": "/img/liantong.91e1d277.png"
  },
  {
    "revision": "4a0cab0f33beb48ea985714d1b91fef7",
    "url": "/img/dianxin.4a0cab0f.png"
  },
  {
    "revision": "657033323334e91efb0011bbc18f8c04",
    "url": "/img/yidong.65703332.png"
  },
  {
    "revision": "8da3b83b73e44e54d6be4b2522bcb1f2",
    "url": "/img/pkgBg2.8da3b83b.png"
  },
  {
    "revision": "d3b42651f9f5048baeffb50c800913ec",
    "url": "/img/pkgBg1.d3b42651.png"
  },
  {
    "revision": "d461d18e42a310bd709b2ce97d159153",
    "url": "/img/pkgBg3.d461d18e.png"
  },
  {
    "revision": "01355f175bd20423ce45a838c1a998a9",
    "url": "/img/bg.01355f17.png"
  },
  {
    "revision": "6e5cee7393060b0ec3dcd587c2518b94",
    "url": "/img/bg_test.6e5cee73.png"
  },
  {
    "revision": "af3ed0b3236bbfdbc3ad61b8d41c3dec",
    "url": "/img/changeBg.af3ed0b3.png"
  },
  {
    "revision": "0078f03c08066d51d64b92a13e194ebb",
    "url": "/img/balanceRefund.0078f03c.png"
  },
  {
    "revision": "6dedd4943e4c5848638196fb6f0c4145",
    "url": "/img/bg.6dedd494.png"
  },
  {
    "revision": "42c0fbd4915870e5e60452fd0ef2cbec",
    "url": "/img/orderTopBg@3x.42c0fbd4.png"
  },
  {
    "revision": "42c0fbd4915870e5e60452fd0ef2cbec",
    "url": "/img/orderTopBg@2x.42c0fbd4.png"
  },
  {
    "revision": "d0ccbc8a35180bb40e027b44dd26035a",
    "url": "/img/youku.d0ccbc8a.png"
  },
  {
    "revision": "a859e9ca4606d567c42b9c7bcd4fdce9",
    "url": "/img/iccid_bg@2x.a859e9ca.png"
  },
  {
    "revision": "fa9050c4e9870e8fc0cd184f8515af4a",
    "url": "/img/iccid_bg@3x.fa9050c4.png"
  },
  {
    "revision": "2c51a1e53c1ea0b35086d8d7261b4933",
    "url": "/img/bg_network@3x.2c51a1e5.png"
  },
  {
    "revision": "32d70c8fc305e3647098f3de0c71b618",
    "url": "/img/bg_network@2x.32d70c8f.png"
  },
  {
    "revision": "d7376fc132b6bf21b05b",
    "url": "/css/coupon_telcom.4910a9a6.css"
  },
  {
    "revision": "e9203141ef77adc93a6d",
    "url": "/css/app.d1d8428f.css"
  },
  {
    "revision": "cea9418e8c7b0228fb06",
    "url": "/css/balanceIndex.bec7dc8e.css"
  },
  {
    "revision": "d03fa150e7b9eec7ee47",
    "url": "/css/balanceRefund.e96ad6e2.css"
  },
  {
    "revision": "658e83746d6de710af25",
    "url": "/css/cardPackage.8b67822b.css"
  },
  {
    "revision": "0ee5e273edcd8130dac5",
    "url": "/css/card_check.ffc9fd37.css"
  },
  {
    "revision": "b91c327e413d440da20c",
    "url": "/css/card_connection.7591204b.css"
  },
  {
    "revision": "069ae2e8b588f1242600",
    "url": "/css/card_lookup.3eecde91.css"
  },
  {
    "revision": "6a0f2bc5628beac9918f",
    "url": "/css/card_more_flow.c9f99c6b.css"
  },
  {
    "revision": "8f7a725b8335e281424a",
    "url": "/css/card_usage.25969ea8.css"
  },
  {
    "revision": "5ef44a69ba4afda72ad0",
    "url": "/css/card_usage~plan_list.fd293231.css"
  },
  {
    "revision": "dad8373d7760fffd522f",
    "url": "/css/card_wrapper.0f1a55fe.css"
  },
  {
    "revision": "a553314594d4e9c6e19a",
    "url": "/css/children_card.9d36d083.css"
  },
  {
    "revision": "ae9941cec92ff331f618",
    "url": "/css/mifi_card_wrapper.9e98768f.css"
  },
  {
    "revision": "fadde9afed829c78134e",
    "url": "/css/chunk-518bd018.d8190d8a.css"
  },
  {
    "revision": "6dc4af86b76b2bedb51b",
    "url": "/css/chunk-b243290a.238d0466.css"
  },
  {
    "revision": "894d31a9da0d57a178d3",
    "url": "/css/chunk-vendors.f4f950f2.css"
  },
  {
    "revision": "b7d5197a9c1171efeca4",
    "url": "/css/commonProblem.86197c81.css"
  },
  {
    "revision": "ff80e5ec3f4f0830c1e3",
    "url": "/css/commonQuestion.b6d9c7f8.css"
  },
  {
    "revision": "1c9d5b179fea27ca379d",
    "url": "/css/consumerRecord.c274c84b.css"
  },
  {
    "revision": "0a8a2e7d40a2df3e8e5f",
    "url": "/css/coupon_normal.c54db4c8.css"
  },
  {
    "revision": "dfc4ab08e6c054796780",
    "url": "/css/authority_middle.2a9ffeee.css"
  },
  {
    "revision": "b015aa59cc0a3e03fca4",
    "url": "/css/coupon_wrapper.ce3120d7.css"
  },
  {
    "revision": "92c7ef5c2b96f2259ae3",
    "url": "/css/currencyConversion.b3f24442.css"
  },
  {
    "revision": "65640b5027cee9c87284",
    "url": "/css/customerFeedback.9a3535d8.css"
  },
  {
    "revision": "04d5570d412eccb6ec80",
    "url": "/css/eqReplaceMent.76e83cb8.css"
  },
  {
    "revision": "a2ac358b5ba0d37e1f75",
    "url": "/css/eqReplaceMent~recharge.f6bbdfeb.css"
  },
  {
    "revision": "6d979624e843e53e0189",
    "url": "/css/esim_plan_list.ecb54d48.css"
  },
  {
    "revision": "a08d7e8d7492cf9e5182",
    "url": "/css/esim_usage.1147dd20.css"
  },
  {
    "revision": "eae54a6f44ecb2a53f1a",
    "url": "/css/find_plan.e0756b43.css"
  },
  {
    "revision": "c281fc54336ce3c7049e",
    "url": "/css/guardian.39c53b10.css"
  },
  {
    "revision": "e2e1b972254a35ac449d",
    "url": "/css/logical_page.490e2744.css"
  },
  {
    "revision": "8faa8cedffad2c71caf8",
    "url": "/css/login.db13ac6f.css"
  },
  {
    "revision": "d00f6f449ab145f2bccc",
    "url": "/css/lookup.72b835fa.css"
  },
  {
    "revision": "261eef52c39a693344c6",
    "url": "/css/mifi_binding.5dc64e23.css"
  },
  {
    "revision": "49fdaa895ca8b990a5b8",
    "url": "/css/mifi_card_info.5e23b2d2.css"
  },
  {
    "revision": "04440f1b96eebc41a332",
    "url": "/css/mifi_card_lookup.abed5849.css"
  },
  {
    "revision": "4031a33769eb9570b2be",
    "url": "/css/Not_fund.bb75cfdc.css"
  },
  {
    "revision": "fe349c0eccd231c36f35",
    "url": "/css/Layout.ce14b775.css"
  },
  {
    "revision": "9ce16f441b39b493af8b96d7e97cce22",
    "url": "/MP_verify_dkzAKjxyVyJvsHMS.txt"
  },
  {
    "revision": "86c422d8c98b247235d04b49fb1c4b05",
    "url": "/MP_verify_bKSdn2qZlUSULliu.txt"
  },
  {
    "revision": "652317b098ca24e4511926c7fd57cbbe",
    "url": "/MP_verify_8JoCCldW78DygS5c.txt"
  },
  {
    "revision": "00bbf6b458bf7ea6bd01f443eb3045d9",
    "url": "/MP_verify_4r3DVk3KUjgWsQsG.txt"
  }
];