self.__precacheManifest = [
  {
    "revision": "c20cb109b41818ad6ec5",
    "url": "/js/refundRules.d5993076.js"
  },
  {
    "revision": "8e08ef8d1d086d6c8151",
    "url": "/css/Layout.c92f6dbd.css"
  },
  {
    "revision": "78214ba34c5f1df936aa",
    "url": "/js/Layout~card_usage~eqReplaceMent~esim_plan_list~esim_usage~mifi_order~mifi_plan_list~mifi_plan_usage~~c6f87c36.6241bd21.js"
  },
  {
    "revision": "39e7704b426ecec37122",
    "url": "/css/Not_fund.afe02751.css"
  },
  {
    "revision": "39e7704b426ecec37122",
    "url": "/js/Not_fund.34b1afa6.js"
  },
  {
    "revision": "f84f642fbff74826a450",
    "url": "/css/app.d1d8428f.css"
  },
  {
    "revision": "f84f642fbff74826a450",
    "url": "/js/app.a82365dd.js"
  },
  {
    "revision": "c61f0d555ab8bd12ce1c",
    "url": "/css/authority_middle.9e4a863a.css"
  },
  {
    "revision": "c61f0d555ab8bd12ce1c",
    "url": "/js/authority_middle.c172d3e3.js"
  },
  {
    "revision": "316aad516a7c539b4ba8",
    "url": "/css/balanceIndex.951e0ba1.css"
  },
  {
    "revision": "316aad516a7c539b4ba8",
    "url": "/js/balanceIndex.48cc2a43.js"
  },
  {
    "revision": "0b7cbef0d31dd786ad96",
    "url": "/css/balanceRefund.539eb031.css"
  },
  {
    "revision": "0b7cbef0d31dd786ad96",
    "url": "/js/balanceRefund.58557fb0.js"
  },
  {
    "revision": "60710e0a4d3f3d934218",
    "url": "/css/cardPackage.69352085.css"
  },
  {
    "revision": "60710e0a4d3f3d934218",
    "url": "/js/cardPackage.9484a1a2.js"
  },
  {
    "revision": "d77a6227ae717bec30c7",
    "url": "/css/card_check.0c40cc40.css"
  },
  {
    "revision": "d77a6227ae717bec30c7",
    "url": "/js/card_check.7cf5dfeb.js"
  },
  {
    "revision": "502c1b159011d7926031",
    "url": "/css/card_connection.a88e086c.css"
  },
  {
    "revision": "502c1b159011d7926031",
    "url": "/js/card_connection.41cfeac4.js"
  },
  {
    "revision": "772578a5dda2072e648c",
    "url": "/css/card_lookup.bd76bb8d.css"
  },
  {
    "revision": "772578a5dda2072e648c",
    "url": "/js/card_lookup.6fbdb0d0.js"
  },
  {
    "revision": "d4b5edc0c502fc6fdac5",
    "url": "/css/card_lookup_notice.e096305a.css"
  },
  {
    "revision": "d4b5edc0c502fc6fdac5",
    "url": "/js/card_lookup_notice.3984ec09.js"
  },
  {
    "revision": "af09bb346e061cc700ba",
    "url": "/css/card_lookup~card_lookup_notice.1672d43e.css"
  },
  {
    "revision": "af09bb346e061cc700ba",
    "url": "/js/card_lookup~card_lookup_notice.02ff088a.js"
  },
  {
    "revision": "34f870904b74ef3b3d8c",
    "url": "/css/card_more_flow.4280b81a.css"
  },
  {
    "revision": "34f870904b74ef3b3d8c",
    "url": "/js/card_more_flow.6c7f8885.js"
  },
  {
    "revision": "37de9a49465b467715cf",
    "url": "/css/card_usage.ec7daca6.css"
  },
  {
    "revision": "37de9a49465b467715cf",
    "url": "/js/card_usage.693ed1be.js"
  },
  {
    "revision": "8b3b7fd4a1c328f11699",
    "url": "/css/card_usage~plan_list.71eabe6e.css"
  },
  {
    "revision": "8b3b7fd4a1c328f11699",
    "url": "/js/card_usage~plan_list.8a49ec20.js"
  },
  {
    "revision": "1de6908d94a745995e8d",
    "url": "/css/card_wrapper.4208fca5.css"
  },
  {
    "revision": "1de6908d94a745995e8d",
    "url": "/js/card_wrapper.91cfe956.js"
  },
  {
    "revision": "90ac4521f3a2785a5b8b",
    "url": "/css/children_card.5cce31ab.css"
  },
  {
    "revision": "90ac4521f3a2785a5b8b",
    "url": "/js/children_card.8d969209.js"
  },
  {
    "revision": "2ea3a0e7063d90a077c3",
    "url": "/css/chunk-5e1abf10.809dc900.css"
  },
  {
    "revision": "2ea3a0e7063d90a077c3",
    "url": "/js/chunk-5e1abf10.785e0e20.js"
  },
  {
    "revision": "2aeef521d122263dbf77",
    "url": "/css/chunk-96f59f1a.8c89b940.css"
  },
  {
    "revision": "2aeef521d122263dbf77",
    "url": "/js/chunk-96f59f1a.13ae49f1.js"
  },
  {
    "revision": "2fa8d67a06c77fea899d",
    "url": "/css/chunk-vendors.b8da327d.css"
  },
  {
    "revision": "2fa8d67a06c77fea899d",
    "url": "/js/chunk-vendors.4ec2dc53.js"
  },
  {
    "revision": "5ba512b8930c47785378",
    "url": "/css/commonProblem.4770494b.css"
  },
  {
    "revision": "5ba512b8930c47785378",
    "url": "/js/commonProblem.f28a7358.js"
  },
  {
    "revision": "858d03802ab296d8432d",
    "url": "/css/commonQuestion.7dde70f0.css"
  },
  {
    "revision": "858d03802ab296d8432d",
    "url": "/js/commonQuestion.f0ebc467.js"
  },
  {
    "revision": "b9e5fcc7b1e02258dce3",
    "url": "/css/consumerRecord.979afe5b.css"
  },
  {
    "revision": "b9e5fcc7b1e02258dce3",
    "url": "/js/consumerRecord.4d99e4b1.js"
  },
  {
    "revision": "080b857943b348986d21",
    "url": "/css/coupon_normal.b9ac90b4.css"
  },
  {
    "revision": "080b857943b348986d21",
    "url": "/js/coupon_normal.de0e7ac3.js"
  },
  {
    "revision": "15bd7b1c9dcf06e0b474",
    "url": "/css/coupon_telcom.15c27d7b.css"
  },
  {
    "revision": "15bd7b1c9dcf06e0b474",
    "url": "/js/coupon_telcom.47e44e37.js"
  },
  {
    "revision": "a84f0dae3d9689acc895",
    "url": "/css/coupon_wrapper.12696ad3.css"
  },
  {
    "revision": "a84f0dae3d9689acc895",
    "url": "/js/coupon_wrapper.d827f700.js"
  },
  {
    "revision": "3cef6255188b7886ec0b",
    "url": "/css/currencyConversion.31a1da10.css"
  },
  {
    "revision": "3cef6255188b7886ec0b",
    "url": "/js/currencyConversion.457f533d.js"
  },
  {
    "revision": "78a1179abc60cac744d5",
    "url": "/css/customerFeedback.b76bb58f.css"
  },
  {
    "revision": "78a1179abc60cac744d5",
    "url": "/js/customerFeedback.6219efba.js"
  },
  {
    "revision": "bb073f99128a800edaa3",
    "url": "/css/eqReplaceMent.d1d98c1b.css"
  },
  {
    "revision": "bb073f99128a800edaa3",
    "url": "/js/eqReplaceMent.9095ab69.js"
  },
  {
    "revision": "07548b1348756f10c7ec",
    "url": "/css/eqReplaceMent~recharge.ecb4d199.css"
  },
  {
    "revision": "07548b1348756f10c7ec",
    "url": "/js/eqReplaceMent~recharge.afed2e86.js"
  },
  {
    "revision": "e810830b9a6c4b22b09c",
    "url": "/css/esim_plan_list.d6aee0d8.css"
  },
  {
    "revision": "e810830b9a6c4b22b09c",
    "url": "/js/esim_plan_list.9c28e005.js"
  },
  {
    "revision": "908004f3623942710c20",
    "url": "/css/esim_usage.52c6bd7b.css"
  },
  {
    "revision": "908004f3623942710c20",
    "url": "/js/esim_usage.3fce86fe.js"
  },
  {
    "revision": "e76201cae8c2cbf9dc1a",
    "url": "/css/find_plan.1c804033.css"
  },
  {
    "revision": "e76201cae8c2cbf9dc1a",
    "url": "/js/find_plan.6b914a1d.js"
  },
  {
    "revision": "75e2c50e4edc94332e3a",
    "url": "/css/guardian.e6badfe1.css"
  },
  {
    "revision": "75e2c50e4edc94332e3a",
    "url": "/js/guardian.5ef9dd13.js"
  },
  {
    "revision": "d8cbc88dc4e1d846ae9f",
    "url": "/css/logical_page.a2074deb.css"
  },
  {
    "revision": "d8cbc88dc4e1d846ae9f",
    "url": "/js/logical_page.a536b1b7.js"
  },
  {
    "revision": "b5445c4032a001aa35ac",
    "url": "/css/login.c488e06a.css"
  },
  {
    "revision": "b5445c4032a001aa35ac",
    "url": "/js/login.768d5201.js"
  },
  {
    "revision": "4ddcbe0a8a7bf85bccd2",
    "url": "/css/lookup.9de2d9d0.css"
  },
  {
    "revision": "4ddcbe0a8a7bf85bccd2",
    "url": "/js/lookup.b74f6014.js"
  },
  {
    "revision": "f191d4258e449d4e592d",
    "url": "/css/mifi_binding.6be213dd.css"
  },
  {
    "revision": "f191d4258e449d4e592d",
    "url": "/js/mifi_binding.12f6a56a.js"
  },
  {
    "revision": "bec1bb60b4fb35bdbd1e",
    "url": "/css/mifi_card_info.b05314ef.css"
  },
  {
    "revision": "bec1bb60b4fb35bdbd1e",
    "url": "/js/mifi_card_info.f413f57d.js"
  },
  {
    "revision": "105412594e354a5d980e",
    "url": "/css/mifi_card_lookup.a93ab904.css"
  },
  {
    "revision": "105412594e354a5d980e",
    "url": "/js/mifi_card_lookup.87242412.js"
  },
  {
    "revision": "e50b8afe2b1a14bef75c",
    "url": "/css/mifi_card_wrapper.f10d3bed.css"
  },
  {
    "revision": "e50b8afe2b1a14bef75c",
    "url": "/js/mifi_card_wrapper.34ec5976.js"
  },
  {
    "revision": "dec7bf074a0945572b22",
    "url": "/css/mifi_change_network.d16b63b2.css"
  },
  {
    "revision": "dec7bf074a0945572b22",
    "url": "/js/mifi_change_network.92d86462.js"
  },
  {
    "revision": "c047948216d7eaced88b",
    "url": "/css/mifi_change_network_explanation.dac8cf11.css"
  },
  {
    "revision": "c047948216d7eaced88b",
    "url": "/js/mifi_change_network_explanation.3587b77f.js"
  },
  {
    "revision": "c789b4382f3db7730921",
    "url": "/css/mifi_coupon_index.d8366e08.css"
  },
  {
    "revision": "c789b4382f3db7730921",
    "url": "/js/mifi_coupon_index.d7ea1e94.js"
  },
  {
    "revision": "d5fa61ebe9912d1fd14c",
    "url": "/css/mifi_coupon_wrapper.2bcf9a83.css"
  },
  {
    "revision": "d5fa61ebe9912d1fd14c",
    "url": "/js/mifi_coupon_wrapper.098a70bd.js"
  },
  {
    "revision": "0198fd4d798d4af7a113",
    "url": "/css/mifi_index.92b20949.css"
  },
  {
    "revision": "0198fd4d798d4af7a113",
    "url": "/js/mifi_index.13f09592.js"
  },
  {
    "revision": "ba60e2494add34b5421b",
    "url": "/css/mifi_layout.9cfcef76.css"
  },
  {
    "revision": "ba60e2494add34b5421b",
    "url": "/js/mifi_layout.03168e5e.js"
  },
  {
    "revision": "b39bf54cf77905feab2e",
    "url": "/css/mifi_order.7beb0300.css"
  },
  {
    "revision": "b39bf54cf77905feab2e",
    "url": "/js/mifi_order.464f469a.js"
  },
  {
    "revision": "44f29be597c86a758ccf",
    "url": "/css/mifi_order_wrapper.ecfbd387.css"
  },
  {
    "revision": "44f29be597c86a758ccf",
    "url": "/js/mifi_order_wrapper.cf62594c.js"
  },
  {
    "revision": "4d6a9c3d01bb6055ae51",
    "url": "/css/mifi_plan_group.a93d410c.css"
  },
  {
    "revision": "4d6a9c3d01bb6055ae51",
    "url": "/js/mifi_plan_group.d9d7b62f.js"
  },
  {
    "revision": "60a20fa3b6bdff925d2e",
    "url": "/css/mifi_plan_list.d4b17f3a.css"
  },
  {
    "revision": "60a20fa3b6bdff925d2e",
    "url": "/js/mifi_plan_list.30f82870.js"
  },
  {
    "revision": "474edd88c73b59ff0deb",
    "url": "/css/mifi_plan_usage.0d06e6eb.css"
  },
  {
    "revision": "474edd88c73b59ff0deb",
    "url": "/js/mifi_plan_usage.0a05cf22.js"
  },
  {
    "revision": "38409b3d9018a6018d0d",
    "url": "/css/mifi_plan_wrapper.3db278e7.css"
  },
  {
    "revision": "38409b3d9018a6018d0d",
    "url": "/js/mifi_plan_wrapper.51657335.js"
  },
  {
    "revision": "149e2779bff727feb91b",
    "url": "/css/new_card_wrapper.98fed2fc.css"
  },
  {
    "revision": "149e2779bff727feb91b",
    "url": "/js/new_card_wrapper.a0734559.js"
  },
  {
    "revision": "7ff1477f12f309bce2e3",
    "url": "/css/official_accounts.26961ede.css"
  },
  {
    "revision": "7ff1477f12f309bce2e3",
    "url": "/js/official_accounts.24ade329.js"
  },
  {
    "revision": "62d43a3a7bb609bc12c6",
    "url": "/css/orderRecord.03cbe61e.css"
  },
  {
    "revision": "62d43a3a7bb609bc12c6",
    "url": "/js/orderRecord.d28242e9.js"
  },
  {
    "revision": "809c8a3c8fbd5d74088b",
    "url": "/css/plan_list.90a01e71.css"
  },
  {
    "revision": "809c8a3c8fbd5d74088b",
    "url": "/js/plan_list.7c2ddac7.js"
  },
  {
    "revision": "5ea7a5e7e22d1175598e",
    "url": "/css/question.4b37ef71.css"
  },
  {
    "revision": "5ea7a5e7e22d1175598e",
    "url": "/js/question.18460a24.js"
  },
  {
    "revision": "902669215db2a9add4fc",
    "url": "/css/question_wrapper.eeb3aab7.css"
  },
  {
    "revision": "902669215db2a9add4fc",
    "url": "/js/question_wrapper.76550024.js"
  },
  {
    "revision": "d1cb7e6cd094f19439e7",
    "url": "/css/realNameCourse.9ca9b0f6.css"
  },
  {
    "revision": "d1cb7e6cd094f19439e7",
    "url": "/js/realNameCourse.e4e3501c.js"
  },
  {
    "revision": "49ee20b749c685f4f426",
    "url": "/css/real_name.4001841e.css"
  },
  {
    "revision": "49ee20b749c685f4f426",
    "url": "/js/real_name.aff38510.js"
  },
  {
    "revision": "f91f2d15c815e84958ea",
    "url": "/css/recharge.d8d2a8ce.css"
  },
  {
    "revision": "f91f2d15c815e84958ea",
    "url": "/js/recharge.348f4c35.js"
  },
  {
    "revision": "63105f0da56ffe83d375",
    "url": "/css/rechargeOrder.fc6e5fdd.css"
  },
  {
    "revision": "63105f0da56ffe83d375",
    "url": "/js/rechargeOrder.9e9b369e.js"
  },
  {
    "revision": "5aae7f25bed7bf7ee752",
    "url": "/css/rechargeOrder~whiteSearch.9312635a.css"
  },
  {
    "revision": "5aae7f25bed7bf7ee752",
    "url": "/js/rechargeOrder~whiteSearch.eb33013c.js"
  },
  {
    "revision": "ee3d95e6c1c6d1a21670",
    "url": "/css/recharge_balance.b69eb50e.css"
  },
  {
    "revision": "ee3d95e6c1c6d1a21670",
    "url": "/js/recharge_balance.67c3ed06.js"
  },
  {
    "revision": "c420320bf829334845cf",
    "url": "/css/recharge_callback.9c32a9b2.css"
  },
  {
    "revision": "c420320bf829334845cf",
    "url": "/js/recharge_callback.62241034.js"
  },
  {
    "revision": "ec2c3f664fd10a55ca31",
    "url": "/css/recharge_wrapper.1a8d30f5.css"
  },
  {
    "revision": "ec2c3f664fd10a55ca31",
    "url": "/js/recharge_wrapper.b5c1d688.js"
  },
  {
    "revision": "c20cb109b41818ad6ec5",
    "url": "/css/refundRules.7d8883fe.css"
  },
  {
    "revision": "8e08ef8d1d086d6c8151",
    "url": "/js/Layout.2aa9b219.js"
  },
  {
    "revision": "93b01e136c186bbe79fb",
    "url": "/css/refund_applying.5e0a9890.css"
  },
  {
    "revision": "93b01e136c186bbe79fb",
    "url": "/js/refund_applying.501b0343.js"
  },
  {
    "revision": "b14953936ab281c88f60",
    "url": "/css/refund_argument.55e7517b.css"
  },
  {
    "revision": "b14953936ab281c88f60",
    "url": "/js/refund_argument.2f50c7bb.js"
  },
  {
    "revision": "b37fe1ca2abdbc41ee16",
    "url": "/css/refund_plan.87947d21.css"
  },
  {
    "revision": "b37fe1ca2abdbc41ee16",
    "url": "/js/refund_plan.cec22412.js"
  },
  {
    "revision": "66680a90e05d9c1c40d8",
    "url": "/css/refund_wrapper.02a09f97.css"
  },
  {
    "revision": "66680a90e05d9c1c40d8",
    "url": "/js/refund_wrapper.238f980f.js"
  },
  {
    "revision": "4bb9a1767950beeb0f32",
    "url": "/css/repeatRecharge.f2bea36d.css"
  },
  {
    "revision": "4bb9a1767950beeb0f32",
    "url": "/js/repeatRecharge.e92357ce.js"
  },
  {
    "revision": "c43183ad8a3fcdefa742",
    "url": "/css/revoke_plan.0b610632.css"
  },
  {
    "revision": "c43183ad8a3fcdefa742",
    "url": "/js/revoke_plan.c5243e1d.js"
  },
  {
    "revision": "51d911734c62e7274e4b",
    "url": "/css/speedup_500.f46392b8.css"
  },
  {
    "revision": "51d911734c62e7274e4b",
    "url": "/js/speedup_500.e86f1e64.js"
  },
  {
    "revision": "4b3134baed5560b3aa62",
    "url": "/css/speedup_80.8f563437.css"
  },
  {
    "revision": "4b3134baed5560b3aa62",
    "url": "/js/speedup_80.1f7e346b.js"
  },
  {
    "revision": "6d7eef8e811cab4a3ab5",
    "url": "/css/speedup_wrapper.09148f29.css"
  },
  {
    "revision": "6d7eef8e811cab4a3ab5",
    "url": "/js/speedup_wrapper.5777af2f.js"
  },
  {
    "revision": "1e1382cb157c64d438fd",
    "url": "/css/to_tb.f225e1b1.css"
  },
  {
    "revision": "1e1382cb157c64d438fd",
    "url": "/js/to_tb.d45507e7.js"
  },
  {
    "revision": "d079d4bee6c36134e540",
    "url": "/css/transfer_url.b51702ce.css"
  },
  {
    "revision": "d079d4bee6c36134e540",
    "url": "/js/transfer_url.5b3a1961.js"
  },
  {
    "revision": "d98eb1da7595c0d0c632",
    "url": "/css/userCenter.ea0496ce.css"
  },
  {
    "revision": "d98eb1da7595c0d0c632",
    "url": "/js/userCenter.c2be4c97.js"
  },
  {
    "revision": "6b9327f45464ec9a898a",
    "url": "/css/userCenterWrap.e1efacf4.css"
  },
  {
    "revision": "6b9327f45464ec9a898a",
    "url": "/js/userCenterWrap.8be28fd0.js"
  },
  {
    "revision": "ec84ea3cd7c00b835148",
    "url": "/css/whiteListsWrapper.de43f5e2.css"
  },
  {
    "revision": "ec84ea3cd7c00b835148",
    "url": "/js/whiteListsWrapper.544dbd29.js"
  },
  {
    "revision": "ba7b842a62fdf91d6ef8",
    "url": "/css/whiteNewlist.9d3e444c.css"
  },
  {
    "revision": "ba7b842a62fdf91d6ef8",
    "url": "/js/whiteNewlist.c6d9c6ce.js"
  },
  {
    "revision": "5e3f0e096998cdf02c61",
    "url": "/css/whiteSearch.5439064e.css"
  },
  {
    "revision": "5e3f0e096998cdf02c61",
    "url": "/js/whiteSearch.c40eb960.js"
  },
  {
    "revision": "e4b411644706c29765eea3ffdd85ae39",
    "url": "/fonts/SourceHanSansCNRegular.e4b41164.woff"
  },
  {
    "revision": "834b022ab9ab0e6063904af32274e777",
    "url": "/fonts/SourceHanSansCNRegular.834b022a.eot"
  },
  {
    "revision": "f9509c5a10be7daaf1fa01922a7c6bc2",
    "url": "/fonts/SourceHanSansCNRegular.f9509c5a.ttf"
  },
  {
    "revision": "da0808e9fe85be160aab69c82dd8de1c",
    "url": "/img/SourceHanSansCNRegular.da0808e9.svg"
  },
  {
    "revision": "732389ded34cb9c52dd88271f1345af9",
    "url": "/fonts/element-icons.732389de.ttf"
  },
  {
    "revision": "535877f50039c0cb49a6196a5b7517cd",
    "url": "/fonts/element-icons.535877f5.woff"
  },
  {
    "revision": "0f16389ec218c90cf8f657e233b745f2",
    "url": "/img/balanceBg1.0f16389e.png"
  },
  {
    "revision": "565459ef2ee8b71db421144ad21c23e3",
    "url": "/img/balanceBg2.565459ef.png"
  },
  {
    "revision": "6dedd4943e4c5848638196fb6f0c4145",
    "url": "/img/bg.6dedd494.png"
  },
  {
    "revision": "8cb139e0169560e725d23c2ab8d8310e",
    "url": "/img/advert.8cb139e0.gif"
  },
  {
    "revision": "fa855242805b87da42c65763acd64ac0",
    "url": "/img/bg-plan-type@2x.fa855242.png"
  },
  {
    "revision": "4a9ca192485effa8b8f4b5b2df5b9caf",
    "url": "/img/bg-plan-type@3x.4a9ca192.png"
  },
  {
    "revision": "cc0636ca2944024fd3ebf33a5412ff35",
    "url": "/img/icon-right@3x.cc0636ca.png"
  },
  {
    "revision": "1b983020cfed6b7a8ca5c300c24ca186",
    "url": "/img/icon-left@3x.1b983020.png"
  },
  {
    "revision": "e93b8c03293c5b6a311da784f9c19c8f",
    "url": "/img/bg.e93b8c03.jpeg"
  },
  {
    "revision": "d796d97eb9ebb2e89bb966343e2362e9",
    "url": "/img/icon-left@2x.d796d97e.png"
  },
  {
    "revision": "ccb9865dadbc642b8c4dd0a1abc8e570",
    "url": "/img/recharge-word@2x.ccb9865d.png"
  },
  {
    "revision": "ccb9865dadbc642b8c4dd0a1abc8e570",
    "url": "/img/recharge-word@3x.ccb9865d.png"
  },
  {
    "revision": "ffb1612d9660e2ecd9d3872d57a8a2f9",
    "url": "/img/bar.ffb1612d.png"
  },
  {
    "revision": "41a8c268f703fe646d5d08099eb778ae",
    "url": "/img/icon-right@2x.41a8c268.png"
  },
  {
    "revision": "2d6d06f4da15fc1a748677c49c5f1854",
    "url": "/img/bg.2d6d06f4.png"
  },
  {
    "revision": "91e1d2771efacd45e5e465d9a001f197",
    "url": "/img/liantong.91e1d277.png"
  },
  {
    "revision": "4a0cab0f33beb48ea985714d1b91fef7",
    "url": "/img/dianxin.4a0cab0f.png"
  },
  {
    "revision": "657033323334e91efb0011bbc18f8c04",
    "url": "/img/yidong.65703332.png"
  },
  {
    "revision": "8da3b83b73e44e54d6be4b2522bcb1f2",
    "url": "/img/pkgBg2.8da3b83b.png"
  },
  {
    "revision": "d3b42651f9f5048baeffb50c800913ec",
    "url": "/img/pkgBg1.d3b42651.png"
  },
  {
    "revision": "d461d18e42a310bd709b2ce97d159153",
    "url": "/img/pkgBg3.d461d18e.png"
  },
  {
    "revision": "0078f03c08066d51d64b92a13e194ebb",
    "url": "/img/balanceRefund.0078f03c.png"
  },
  {
    "revision": "f5f322478286641bd9887a155e35f222",
    "url": "/img/btn.f5f32247.png"
  },
  {
    "revision": "d140650fa64e0f1fc771610dba62aed7",
    "url": "/img/bg.d140650f.png"
  },
  {
    "revision": "af3ed0b3236bbfdbc3ad61b8d41c3dec",
    "url": "/img/changeBg.af3ed0b3.png"
  },
  {
    "revision": "e625229e32d9deeb5f2909c314d8e609",
    "url": "/img/ios@2x.e625229e.png"
  },
  {
    "revision": "af8bbdfa0a90c4eed4563f8c06ce5ff8",
    "url": "/img/android@2x.af8bbdfa.png"
  },
  {
    "revision": "f40c7e0b20fe25eb78a7658c3ae56312",
    "url": "/img/noData@3x.f40c7e0b.png"
  },
  {
    "revision": "644e6e3cf5f33943747b116316694e28",
    "url": "/img/noData@2x.644e6e3c.png"
  },
  {
    "revision": "3f342771b9b81ab929e0fbcbcd0e6533",
    "url": "/img/bg-check-wrap@3x.3f342771.png"
  },
  {
    "revision": "9713b21819c4019befecd095069977df",
    "url": "/img/bg-check-wrap@2x.9713b218.png"
  },
  {
    "revision": "1d7515ee61c3f659227318b4050955ed",
    "url": "/img/mobile_sim@2x.1d7515ee.png"
  },
  {
    "revision": "0f980b79d9a52702004de9f652a68835",
    "url": "/img/telcom_sim@2x.0f980b79.png"
  },
  {
    "revision": "98141226a7e992e3072a280746a259c4",
    "url": "/img/mobile_sim@3x.98141226.png"
  },
  {
    "revision": "0c88168b284b92c37f3a873f26a97d69",
    "url": "/img/bg.0c88168b.jpg"
  },
  {
    "revision": "9e02095f31a07b972244f1c714c1dfe7",
    "url": "/img/telcom_sim@3x.9e02095f.png"
  },
  {
    "revision": "014d354b9b25b67ae95857ba17e2f4cc",
    "url": "/img/activityPage.014d354b.png"
  },
  {
    "revision": "6e5cee7393060b0ec3dcd587c2518b94",
    "url": "/img/bg_test.6e5cee73.png"
  },
  {
    "revision": "3d0fc424b703032ca595090e99f8354b",
    "url": "/img/login_bg@2x.3d0fc424.png"
  },
  {
    "revision": "11000d4e510a6df565eb69ba6f2c1dfc",
    "url": "/img/login_bg@3x.11000d4e.png"
  },
  {
    "revision": "42c0fbd4915870e5e60452fd0ef2cbec",
    "url": "/img/orderTopBg@3x.42c0fbd4.png"
  },
  {
    "revision": "42c0fbd4915870e5e60452fd0ef2cbec",
    "url": "/img/orderTopBg@2x.42c0fbd4.png"
  },
  {
    "revision": "a859e9ca4606d567c42b9c7bcd4fdce9",
    "url": "/img/iccid_bg@2x.a859e9ca.png"
  },
  {
    "revision": "fa9050c4e9870e8fc0cd184f8515af4a",
    "url": "/img/iccid_bg@3x.fa9050c4.png"
  },
  {
    "revision": "2a67b73145562669220aa4639e1ad58f",
    "url": "/img/icon3.2a67b731.png"
  },
  {
    "revision": "813b5319e378dafdda952c16ad89906b",
    "url": "/img/icon2.813b5319.png"
  },
  {
    "revision": "b899232b79ad9962c5ab5572775a0400",
    "url": "/img/card_index_bg@3x.b899232b.png"
  },
  {
    "revision": "b899232b79ad9962c5ab5572775a0400",
    "url": "/img/card_index_bg@2x.b899232b.png"
  },
  {
    "revision": "01355f175bd20423ce45a838c1a998a9",
    "url": "/img/bg.01355f17.png"
  },
  {
    "revision": "2c51a1e53c1ea0b35086d8d7261b4933",
    "url": "/img/bg_network@3x.2c51a1e5.png"
  },
  {
    "revision": "32d70c8fc305e3647098f3de0c71b618",
    "url": "/img/bg_network@2x.32d70c8f.png"
  },
  {
    "revision": "fff5af4325410621aeec4e60b3b92d9b",
    "url": "/img/mifi_binding_bg@3x.fff5af43.png"
  },
  {
    "revision": "fff5af4325410621aeec4e60b3b92d9b",
    "url": "/img/mifi_binding_bg@2x.fff5af43.png"
  },
  {
    "revision": "d0ccbc8a35180bb40e027b44dd26035a",
    "url": "/img/youku.d0ccbc8a.png"
  },
  {
    "revision": "6e5cee7393060b0ec3dcd587c2518b94",
    "url": "/img/bg_test@3x.6e5cee73.png"
  },
  {
    "revision": "114a6e12b42b9b48586dd341105188fe",
    "url": "/img/usedOrder@2x.114a6e12.png"
  },
  {
    "revision": "6e5cee7393060b0ec3dcd587c2518b94",
    "url": "/img/bg_test@2x.6e5cee73.png"
  },
  {
    "revision": "c0170ec299b2418256fd515ee7849055",
    "url": "/img/unUsedOrder@2x.c0170ec2.png"
  },
  {
    "revision": "d9e14058d30dd312519fcf2de38d742b",
    "url": "/img/unUsedOrder@3x.d9e14058.png"
  },
  {
    "revision": "4a5b90f8076955f289b3dcda6a5af6ff",
    "url": "/img/invaildedOrder@3x.4a5b90f8.png"
  },
  {
    "revision": "0d5a5158e67bcb7a4604124715ed6fbf",
    "url": "/img/usedOrder@3x.0d5a5158.png"
  },
  {
    "revision": "be0f1e33b2553e71b117d3d3f838d32f",
    "url": "/img/invaildedOrder@2x.be0f1e33.png"
  },
  {
    "revision": "3603a35a49dbb8ad94ec1e57c4dad229",
    "url": "/img/scanTop2.3603a35a.png"
  },
  {
    "revision": "05775dd69c53d7273b27aaa7c6c523f7",
    "url": "/img/04.05775dd6.png"
  },
  {
    "revision": "58a560568b7291ea926c2c7438035308",
    "url": "/img/subscribe@3x.58a56056.png"
  },
  {
    "revision": "541375e6bb7db2fba9e415be8045f5fb",
    "url": "/img/1.541375e6.png"
  },
  {
    "revision": "7c28431d304fa4f58f5070c59720683a",
    "url": "/img/2.7c28431d.png"
  },
  {
    "revision": "5a3428653945c17e1c146efeee81c987",
    "url": "/img/scanTop.5a342865.png"
  },
  {
    "revision": "0b9e0b5f4f28c68416f916ddce3fc7ef",
    "url": "/img/unicom-logo.0b9e0b5f.svg"
  },
  {
    "revision": "113f99e2189c2ca49db2168754fc2eb5",
    "url": "/img/mobile-logo.113f99e2.png"
  },
  {
    "revision": "0cba868fa977e09806638b9000636a36",
    "url": "/img/avatar.0cba868f.jpeg"
  },
  {
    "revision": "27158aa79eb0d4b89f317d076a801ca3",
    "url": "/img/coupon-log.27158aa7.png"
  },
  {
    "revision": "55d3f2f09efe17db6485d4c9f8f0c3b1",
    "url": "/img/icon-recharge_20181001.55d3f2f0.svg"
  },
  {
    "revision": "165beb68d8ba0d2b70df0fbb3769787a",
    "url": "/img/03.165beb68.png"
  },
  {
    "revision": "8c605ac88ca50357355da465f322d10a",
    "url": "/img/telecom-logo.8c605ac8.svg"
  },
  {
    "revision": "f7a51f1c554585b11d61499fd0a7520f",
    "url": "/img/only-box@3x.f7a51f1c.png"
  },
  {
    "revision": "89b99d16dd8a4a56746323a0ffbd754c",
    "url": "/img/migu.89b99d16.png"
  },
  {
    "revision": "0b3c3297decbd1152a314cce115f9632",
    "url": "/img/09.0b3c3297.png"
  },
  {
    "revision": "3e217df4202e41ad9b030aafc8cfcc24",
    "url": "/img/4.3e217df4.png"
  },
  {
    "revision": "34c67f6dfdb0ecc17c7a221aec74706f",
    "url": "/img/bg_no_recharge.34c67f6d.svg"
  },
  {
    "revision": "b0ffa4a0fd195a110ee4d4dabce3bc32",
    "url": "/img/08.b0ffa4a0.png"
  },
  {
    "revision": "96fab583abd57f2e7118324858fa3080",
    "url": "/img/05.96fab583.png"
  },
  {
    "revision": "9e8ecc7f7b760b55c56bddfab886da10",
    "url": "/img/3.9e8ecc7f.png"
  },
  {
    "revision": "f23d9d1f76147bc89b48902c36818f1e",
    "url": "/img/bg_no_plan.f23d9d1f.svg"
  },
  {
    "revision": "a8272d2d742d9d50257e23dfac577def",
    "url": "/img/01.a8272d2d.png"
  },
  {
    "revision": "daa86b540bb9c2a6453ceac9bed77961",
    "url": "/img/07.daa86b54.png"
  },
  {
    "revision": "687b6ce03f134f21173c949d79002960",
    "url": "/img/tip.687b6ce0.png"
  },
  {
    "revision": "a610420eab741be28278e60bc06387aa",
    "url": "/img/box-deco@3x.a610420e.png"
  },
  {
    "revision": "eacba58f9acf2b87cd801858146b2ba9",
    "url": "/img/02.eacba58f.png"
  },
  {
    "revision": "39d9e849fc1c724525f166646932a24d",
    "url": "/img/safari.39d9e849.png"
  },
  {
    "revision": "999589aae784a460b5e7c6ae9bbaa3d8",
    "url": "/img/06.999589aa.png"
  },
  {
    "revision": "a6cf72e90a9787a9653d7eb6d42fbf73",
    "url": "/index.html"
  },
  {
    "revision": "735ab4f94fbcd57074377afca324c813",
    "url": "/robots.txt"
  },
  {
    "revision": "9ce16f441b39b493af8b96d7e97cce22",
    "url": "/MP_verify_dkzAKjxyVyJvsHMS.txt"
  },
  {
    "revision": "86c422d8c98b247235d04b49fb1c4b05",
    "url": "/MP_verify_bKSdn2qZlUSULliu.txt"
  },
  {
    "revision": "652317b098ca24e4511926c7fd57cbbe",
    "url": "/MP_verify_8JoCCldW78DygS5c.txt"
  },
  {
    "revision": "00bbf6b458bf7ea6bd01f443eb3045d9",
    "url": "/MP_verify_4r3DVk3KUjgWsQsG.txt"
  }
];