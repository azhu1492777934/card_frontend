self.__precacheManifest = [
  {
    "revision": "89adb11e9d500931e91d",
    "url": "/css/Layout.49ea1feb.css"
  },
  {
    "revision": "89adb11e9d500931e91d",
    "url": "/js/Layout.2b96bc10.js"
  },
  {
    "revision": "78214ba34c5f1df936aa",
    "url": "/js/Layout~card_usage~eqReplaceMent~esim_plan_list~esim_usage~mifi_order~mifi_plan_list~mifi_plan_usage~~c6f87c36.6241bd21.js"
  },
  {
    "revision": "dcac0edbddfe556cfb12",
    "url": "/css/Not_fund.335e4433.css"
  },
  {
    "revision": "dcac0edbddfe556cfb12",
    "url": "/js/Not_fund.924f05b4.js"
  },
  {
    "revision": "a1524f548a771e691b7a",
    "url": "/css/app.0ccacaf2.css"
  },
  {
    "revision": "a1524f548a771e691b7a",
    "url": "/js/app.3b2dcfef.js"
  },
  {
    "revision": "fb46bd0d9ab4b37a3e20",
    "url": "/css/authority_middle.f2c167a9.css"
  },
  {
    "revision": "fb46bd0d9ab4b37a3e20",
    "url": "/js/authority_middle.1234ad4a.js"
  },
  {
    "revision": "00c947e149ccfad87ab0",
    "url": "/css/balanceIndex.7a56af75.css"
  },
  {
    "revision": "00c947e149ccfad87ab0",
    "url": "/js/balanceIndex.b9fdfb73.js"
  },
  {
    "revision": "87e123a7e2b2c424aecf",
    "url": "/css/balanceRefund.9786d2b0.css"
  },
  {
    "revision": "87e123a7e2b2c424aecf",
    "url": "/js/balanceRefund.5eb6e599.js"
  },
  {
    "revision": "3ce63111ff954cf95a49",
    "url": "/css/cardPackage.01597c2b.css"
  },
  {
    "revision": "3ce63111ff954cf95a49",
    "url": "/js/cardPackage.8b6b008e.js"
  },
  {
    "revision": "a071469cb7038e0ac19f",
    "url": "/css/card_check.ac37fada.css"
  },
  {
    "revision": "a071469cb7038e0ac19f",
    "url": "/js/card_check.f1b0c738.js"
  },
  {
    "revision": "80e9314466cc3bf6dded",
    "url": "/css/card_connection.a284fb1d.css"
  },
  {
    "revision": "80e9314466cc3bf6dded",
    "url": "/js/card_connection.fde8daaf.js"
  },
  {
    "revision": "59d474539f00a2c272cc",
    "url": "/css/card_lookup.d378bcb9.css"
  },
  {
    "revision": "59d474539f00a2c272cc",
    "url": "/js/card_lookup.a2928a47.js"
  },
  {
    "revision": "37afd1f0210aa78db47c",
    "url": "/css/card_more_flow.bc94bc7c.css"
  },
  {
    "revision": "37afd1f0210aa78db47c",
    "url": "/js/card_more_flow.c475ee8a.js"
  },
  {
    "revision": "33ec4c4a85d86c09986c",
    "url": "/css/card_usage.19c4d050.css"
  },
  {
    "revision": "33ec4c4a85d86c09986c",
    "url": "/js/card_usage.a3ab9d6a.js"
  },
  {
    "revision": "292247d75875e790bb49",
    "url": "/css/card_usage~plan_list.c0e200ee.css"
  },
  {
    "revision": "292247d75875e790bb49",
    "url": "/js/card_usage~plan_list.23c2aa46.js"
  },
  {
    "revision": "04bec028724e7b4ce328",
    "url": "/css/card_wrapper.57946dac.css"
  },
  {
    "revision": "04bec028724e7b4ce328",
    "url": "/js/card_wrapper.2f6b0aef.js"
  },
  {
    "revision": "89394d7968463420dfb5",
    "url": "/css/children_card.9c71b5bf.css"
  },
  {
    "revision": "89394d7968463420dfb5",
    "url": "/js/children_card.fc1aebb0.js"
  },
  {
    "revision": "3eb82a263346c45c980c",
    "url": "/css/chunk-3527d1c0.36e67b84.css"
  },
  {
    "revision": "3eb82a263346c45c980c",
    "url": "/js/chunk-3527d1c0.3e67c7c7.js"
  },
  {
    "revision": "c88eb8ac3911259d9cba",
    "url": "/css/chunk-4a4d2551.c74ec2b8.css"
  },
  {
    "revision": "c88eb8ac3911259d9cba",
    "url": "/js/chunk-4a4d2551.1eaec513.js"
  },
  {
    "revision": "42076e74994a14476813",
    "url": "/css/chunk-vendors.1db0edb8.css"
  },
  {
    "revision": "42076e74994a14476813",
    "url": "/js/chunk-vendors.b2d2dce4.js"
  },
  {
    "revision": "0fcfc0830dcfb435a3da",
    "url": "/css/commonProblem.d1777633.css"
  },
  {
    "revision": "0fcfc0830dcfb435a3da",
    "url": "/js/commonProblem.1c3e2697.js"
  },
  {
    "revision": "62c24bb09d399d9eff1e",
    "url": "/css/commonQuestion.5da74062.css"
  },
  {
    "revision": "62c24bb09d399d9eff1e",
    "url": "/js/commonQuestion.1ed91c62.js"
  },
  {
    "revision": "538b85b8ca8cd4bb58da",
    "url": "/css/consumerRecord.41a75160.css"
  },
  {
    "revision": "538b85b8ca8cd4bb58da",
    "url": "/js/consumerRecord.f8d7e004.js"
  },
  {
    "revision": "1bc238fa2237971c50fd",
    "url": "/css/coupon_normal.dd59f798.css"
  },
  {
    "revision": "1bc238fa2237971c50fd",
    "url": "/js/coupon_normal.38db1cd2.js"
  },
  {
    "revision": "ff0eb6a85149aad87822",
    "url": "/css/coupon_telcom.34e8c6e5.css"
  },
  {
    "revision": "ff0eb6a85149aad87822",
    "url": "/js/coupon_telcom.0ee34293.js"
  },
  {
    "revision": "bfdaa28b33c708d76347",
    "url": "/css/coupon_wrapper.fb951ea8.css"
  },
  {
    "revision": "bfdaa28b33c708d76347",
    "url": "/js/coupon_wrapper.b7d4521b.js"
  },
  {
    "revision": "2fb48d52d7f17e20e564",
    "url": "/css/currencyConversion.29ba4fc2.css"
  },
  {
    "revision": "2fb48d52d7f17e20e564",
    "url": "/js/currencyConversion.6f7b6e5b.js"
  },
  {
    "revision": "f8b1bd41605ad2e95d8b",
    "url": "/css/customerFeedback.cbb25c4e.css"
  },
  {
    "revision": "f8b1bd41605ad2e95d8b",
    "url": "/js/customerFeedback.fc0f3ec9.js"
  },
  {
    "revision": "522e2c104d0bcc7bd845",
    "url": "/css/eqReplaceMent.2bc7c758.css"
  },
  {
    "revision": "522e2c104d0bcc7bd845",
    "url": "/js/eqReplaceMent.984d8036.js"
  },
  {
    "revision": "06afb61799b6a589f943",
    "url": "/css/eqReplaceMent~recharge.d2dc69b7.css"
  },
  {
    "revision": "06afb61799b6a589f943",
    "url": "/js/eqReplaceMent~recharge.654e6b53.js"
  },
  {
    "revision": "5166888bd1530cf8eef7",
    "url": "/css/esim_plan_list.e9b80c28.css"
  },
  {
    "revision": "5166888bd1530cf8eef7",
    "url": "/js/esim_plan_list.5a348469.js"
  },
  {
    "revision": "3f175a8a61409385f249",
    "url": "/css/esim_usage.3a894732.css"
  },
  {
    "revision": "3f175a8a61409385f249",
    "url": "/js/esim_usage.353affe7.js"
  },
  {
    "revision": "6281fa818b6ba23d7d75",
    "url": "/css/find_plan.0ae10738.css"
  },
  {
    "revision": "6281fa818b6ba23d7d75",
    "url": "/js/find_plan.3a736810.js"
  },
  {
    "revision": "1b4ada4deade3effe5a6",
    "url": "/css/logical_page.738e621a.css"
  },
  {
    "revision": "1b4ada4deade3effe5a6",
    "url": "/js/logical_page.e2365e54.js"
  },
  {
    "revision": "d4fbecef83997711b3b6",
    "url": "/css/login.85191a19.css"
  },
  {
    "revision": "d4fbecef83997711b3b6",
    "url": "/js/login.7797a1a1.js"
  },
  {
    "revision": "5c1af837ab3dc48f231e",
    "url": "/css/lookup.4ddf5191.css"
  },
  {
    "revision": "5c1af837ab3dc48f231e",
    "url": "/js/lookup.4411e0b1.js"
  },
  {
    "revision": "ba0d13d8d2f5ec50b075",
    "url": "/css/mifi_binding.4d63be72.css"
  },
  {
    "revision": "ba0d13d8d2f5ec50b075",
    "url": "/js/mifi_binding.26fe3849.js"
  },
  {
    "revision": "1d467789465080643c78",
    "url": "/css/mifi_card_info.f7882b8a.css"
  },
  {
    "revision": "1d467789465080643c78",
    "url": "/js/mifi_card_info.c83b92b4.js"
  },
  {
    "revision": "bff3ed8aa9f3bc101775",
    "url": "/css/mifi_card_lookup.6c8c9ae4.css"
  },
  {
    "revision": "bff3ed8aa9f3bc101775",
    "url": "/js/mifi_card_lookup.3c8b4ec6.js"
  },
  {
    "revision": "005404feb011c01bebaa",
    "url": "/css/mifi_card_wrapper.6ed40a32.css"
  },
  {
    "revision": "005404feb011c01bebaa",
    "url": "/js/mifi_card_wrapper.b6d766cc.js"
  },
  {
    "revision": "535b642b802297cdd127",
    "url": "/css/mifi_change_network.3299a9ba.css"
  },
  {
    "revision": "535b642b802297cdd127",
    "url": "/js/mifi_change_network.35142efb.js"
  },
  {
    "revision": "9c2c7d2ca72bf73e86f9",
    "url": "/css/mifi_change_network_explanation.f0a09fde.css"
  },
  {
    "revision": "9c2c7d2ca72bf73e86f9",
    "url": "/js/mifi_change_network_explanation.a50ccd47.js"
  },
  {
    "revision": "1bb9b3f68529d8928c7e",
    "url": "/css/mifi_coupon_index.12917432.css"
  },
  {
    "revision": "1bb9b3f68529d8928c7e",
    "url": "/js/mifi_coupon_index.eda54db6.js"
  },
  {
    "revision": "0dd51422430c37e3a77a",
    "url": "/css/mifi_coupon_wrapper.034f9976.css"
  },
  {
    "revision": "0dd51422430c37e3a77a",
    "url": "/js/mifi_coupon_wrapper.c5edd298.js"
  },
  {
    "revision": "62460d5a048858460738",
    "url": "/css/mifi_index.8a8969f9.css"
  },
  {
    "revision": "62460d5a048858460738",
    "url": "/js/mifi_index.e6091e14.js"
  },
  {
    "revision": "6b9c87ec22969394f129",
    "url": "/css/mifi_layout.4df9ee19.css"
  },
  {
    "revision": "6b9c87ec22969394f129",
    "url": "/js/mifi_layout.c70da013.js"
  },
  {
    "revision": "1fad8fcc09b1665416dc",
    "url": "/css/mifi_order.e477f019.css"
  },
  {
    "revision": "1fad8fcc09b1665416dc",
    "url": "/js/mifi_order.00e8bb59.js"
  },
  {
    "revision": "32febb1c95bbd0465b95",
    "url": "/css/mifi_order_wrapper.9e98768f.css"
  },
  {
    "revision": "32febb1c95bbd0465b95",
    "url": "/js/mifi_order_wrapper.852ea2d8.js"
  },
  {
    "revision": "480effe5837d5db78cb6",
    "url": "/css/mifi_plan_group.95776026.css"
  },
  {
    "revision": "480effe5837d5db78cb6",
    "url": "/js/mifi_plan_group.1da63b96.js"
  },
  {
    "revision": "c38c6ead0504e93ddacd",
    "url": "/css/mifi_plan_list.79575d4e.css"
  },
  {
    "revision": "c38c6ead0504e93ddacd",
    "url": "/js/mifi_plan_list.da4f772b.js"
  },
  {
    "revision": "07a0994f77e4f565a6c3",
    "url": "/css/mifi_plan_usage.9a5dbac9.css"
  },
  {
    "revision": "07a0994f77e4f565a6c3",
    "url": "/js/mifi_plan_usage.74450faa.js"
  },
  {
    "revision": "870f373a0c4d8cecd330",
    "url": "/css/mifi_plan_wrapper.bb17a37b.css"
  },
  {
    "revision": "870f373a0c4d8cecd330",
    "url": "/js/mifi_plan_wrapper.05d0d105.js"
  },
  {
    "revision": "fcc6a2b9af03e66d285a",
    "url": "/css/new_card_wrapper.482349c9.css"
  },
  {
    "revision": "fcc6a2b9af03e66d285a",
    "url": "/js/new_card_wrapper.91d82310.js"
  },
  {
    "revision": "639de5d96e966c9b2184",
    "url": "/css/orderRecord.d9954b8a.css"
  },
  {
    "revision": "639de5d96e966c9b2184",
    "url": "/js/orderRecord.0981002d.js"
  },
  {
    "revision": "076fa0c17b1d2e469ee6",
    "url": "/css/plan_list.94a80eac.css"
  },
  {
    "revision": "076fa0c17b1d2e469ee6",
    "url": "/js/plan_list.af22831f.js"
  },
  {
    "revision": "08e2c056baae3658d06e",
    "url": "/css/question.37682d53.css"
  },
  {
    "revision": "08e2c056baae3658d06e",
    "url": "/js/question.acb2c064.js"
  },
  {
    "revision": "c8935e9c60fa6489f8c2",
    "url": "/css/question_wrapper.f7ae0bf9.css"
  },
  {
    "revision": "c8935e9c60fa6489f8c2",
    "url": "/js/question_wrapper.dacde4d4.js"
  },
  {
    "revision": "fd0bf5ca688402c0f60b",
    "url": "/css/realNameCourse.45285408.css"
  },
  {
    "revision": "fd0bf5ca688402c0f60b",
    "url": "/js/realNameCourse.d102635e.js"
  },
  {
    "revision": "6bf72fb77d5340c7a031",
    "url": "/css/real_name.7e98b293.css"
  },
  {
    "revision": "6bf72fb77d5340c7a031",
    "url": "/js/real_name.d15f9e9c.js"
  },
  {
    "revision": "617d76a146a8e56d506c",
    "url": "/css/recharge.69d0e58d.css"
  },
  {
    "revision": "617d76a146a8e56d506c",
    "url": "/js/recharge.b6e64057.js"
  },
  {
    "revision": "a54adabaebad5ef83407",
    "url": "/css/rechargeOrder.69857186.css"
  },
  {
    "revision": "a54adabaebad5ef83407",
    "url": "/js/rechargeOrder.00afbb23.js"
  },
  {
    "revision": "7333c6848366f2a4402f",
    "url": "/css/recharge_balance.02c61443.css"
  },
  {
    "revision": "7333c6848366f2a4402f",
    "url": "/js/recharge_balance.5d4269ee.js"
  },
  {
    "revision": "41c8f00d97af69bda54d",
    "url": "/css/recharge_callback.9a4944a2.css"
  },
  {
    "revision": "41c8f00d97af69bda54d",
    "url": "/js/recharge_callback.24bb4df9.js"
  },
  {
    "revision": "db89e3736d673cee1a8e",
    "url": "/css/recharge_wrapper.373da779.css"
  },
  {
    "revision": "db89e3736d673cee1a8e",
    "url": "/js/recharge_wrapper.618b27b3.js"
  },
  {
    "revision": "00286518d8b64af6ddc1",
    "url": "/css/refundRules.e033034d.css"
  },
  {
    "revision": "00286518d8b64af6ddc1",
    "url": "/js/refundRules.2176d290.js"
  },
  {
    "revision": "591c935777fd3b9d2c43",
    "url": "/css/refund_applying.bd5c8016.css"
  },
  {
    "revision": "591c935777fd3b9d2c43",
    "url": "/js/refund_applying.8501f95b.js"
  },
  {
    "revision": "ba4c63940e0618e7b279",
    "url": "/css/refund_argument.97c8d922.css"
  },
  {
    "revision": "ba4c63940e0618e7b279",
    "url": "/js/refund_argument.db5db9b0.js"
  },
  {
    "revision": "9629a01ea632c1697b79",
    "url": "/css/refund_plan.f45e5548.css"
  },
  {
    "revision": "9629a01ea632c1697b79",
    "url": "/js/refund_plan.e60f14a3.js"
  },
  {
    "revision": "7247f383d2a4de8225b7",
    "url": "/css/refund_wrapper.80fa7896.css"
  },
  {
    "revision": "7247f383d2a4de8225b7",
    "url": "/js/refund_wrapper.b9404eaa.js"
  },
  {
    "revision": "c747025753cdb7d24200",
    "url": "/css/repeatRecharge.77c0bfc7.css"
  },
  {
    "revision": "c747025753cdb7d24200",
    "url": "/js/repeatRecharge.5a3b1265.js"
  },
  {
    "revision": "f447c71fa3d986a0709c",
    "url": "/css/revoke_plan.e130cf54.css"
  },
  {
    "revision": "f447c71fa3d986a0709c",
    "url": "/js/revoke_plan.2476993e.js"
  },
  {
    "revision": "4f173fe9a38bf8f9f227",
    "url": "/css/speedup_500.51fe9728.css"
  },
  {
    "revision": "4f173fe9a38bf8f9f227",
    "url": "/js/speedup_500.d6ac9bc2.js"
  },
  {
    "revision": "4b3126a41f7f0f3498ad",
    "url": "/css/speedup_80.f69a7633.css"
  },
  {
    "revision": "4b3126a41f7f0f3498ad",
    "url": "/js/speedup_80.476c98b1.js"
  },
  {
    "revision": "caef79234b389fdbb91a",
    "url": "/css/speedup_wrapper.016d9434.css"
  },
  {
    "revision": "caef79234b389fdbb91a",
    "url": "/js/speedup_wrapper.f9bf09e9.js"
  },
  {
    "revision": "13883b670d16e5efa421",
    "url": "/css/to_tb.8169aeee.css"
  },
  {
    "revision": "13883b670d16e5efa421",
    "url": "/js/to_tb.686be78e.js"
  },
  {
    "revision": "3e4326b47036b26b3f2c",
    "url": "/css/transfer_url.f5aabf1d.css"
  },
  {
    "revision": "3e4326b47036b26b3f2c",
    "url": "/js/transfer_url.2b199077.js"
  },
  {
    "revision": "dd1a89f901a027824ba4",
    "url": "/css/userCenter.7c6534b4.css"
  },
  {
    "revision": "dd1a89f901a027824ba4",
    "url": "/js/userCenter.839af264.js"
  },
  {
    "revision": "bbd139ac10465cd03f32",
    "url": "/css/userCenterWrap.87e05186.css"
  },
  {
    "revision": "bbd139ac10465cd03f32",
    "url": "/js/userCenterWrap.a58e79dd.js"
  },
  {
    "revision": "e4b411644706c29765eea3ffdd85ae39",
    "url": "/fonts/SourceHanSansCNRegular.e4b41164.woff"
  },
  {
    "revision": "834b022ab9ab0e6063904af32274e777",
    "url": "/fonts/SourceHanSansCNRegular.834b022a.eot"
  },
  {
    "revision": "f9509c5a10be7daaf1fa01922a7c6bc2",
    "url": "/fonts/SourceHanSansCNRegular.f9509c5a.ttf"
  },
  {
    "revision": "da0808e9fe85be160aab69c82dd8de1c",
    "url": "/img/SourceHanSansCNRegular.da0808e9.svg"
  },
  {
    "revision": "732389ded34cb9c52dd88271f1345af9",
    "url": "/fonts/element-icons.732389de.ttf"
  },
  {
    "revision": "535877f50039c0cb49a6196a5b7517cd",
    "url": "/fonts/element-icons.535877f5.woff"
  },
  {
    "revision": "91e1d2771efacd45e5e465d9a001f197",
    "url": "/img/liantong.91e1d277.png"
  },
  {
    "revision": "4a0cab0f33beb48ea985714d1b91fef7",
    "url": "/img/dianxin.4a0cab0f.png"
  },
  {
    "revision": "657033323334e91efb0011bbc18f8c04",
    "url": "/img/yidong.65703332.png"
  },
  {
    "revision": "8da3b83b73e44e54d6be4b2522bcb1f2",
    "url": "/img/pkgBg2.8da3b83b.png"
  },
  {
    "revision": "d3b42651f9f5048baeffb50c800913ec",
    "url": "/img/pkgBg1.d3b42651.png"
  },
  {
    "revision": "d461d18e42a310bd709b2ce97d159153",
    "url": "/img/pkgBg3.d461d18e.png"
  },
  {
    "revision": "6dedd4943e4c5848638196fb6f0c4145",
    "url": "/img/bg.6dedd494.png"
  },
  {
    "revision": "fff5af4325410621aeec4e60b3b92d9b",
    "url": "/img/mifi_binding_bg@3x.fff5af43.png"
  },
  {
    "revision": "fff5af4325410621aeec4e60b3b92d9b",
    "url": "/img/mifi_binding_bg@2x.fff5af43.png"
  },
  {
    "revision": "a859e9ca4606d567c42b9c7bcd4fdce9",
    "url": "/img/iccid_bg@2x.a859e9ca.png"
  },
  {
    "revision": "fa9050c4e9870e8fc0cd184f8515af4a",
    "url": "/img/iccid_bg@3x.fa9050c4.png"
  },
  {
    "revision": "6e5cee7393060b0ec3dcd587c2518b94",
    "url": "/img/bg_test.6e5cee73.png"
  },
  {
    "revision": "d0ccbc8a35180bb40e027b44dd26035a",
    "url": "/img/youku.d0ccbc8a.png"
  },
  {
    "revision": "42c0fbd4915870e5e60452fd0ef2cbec",
    "url": "/img/orderTopBg@3x.42c0fbd4.png"
  },
  {
    "revision": "42c0fbd4915870e5e60452fd0ef2cbec",
    "url": "/img/orderTopBg@2x.42c0fbd4.png"
  },
  {
    "revision": "2c51a1e53c1ea0b35086d8d7261b4933",
    "url": "/img/bg_network@3x.2c51a1e5.png"
  },
  {
    "revision": "32d70c8fc305e3647098f3de0c71b618",
    "url": "/img/bg_network@2x.32d70c8f.png"
  },
  {
    "revision": "b899232b79ad9962c5ab5572775a0400",
    "url": "/img/card_index_bg@3x.b899232b.png"
  },
  {
    "revision": "b899232b79ad9962c5ab5572775a0400",
    "url": "/img/card_index_bg@2x.b899232b.png"
  },
  {
    "revision": "f5f322478286641bd9887a155e35f222",
    "url": "/img/btn.f5f32247.png"
  },
  {
    "revision": "d140650fa64e0f1fc771610dba62aed7",
    "url": "/img/bg.d140650f.png"
  },
  {
    "revision": "e625229e32d9deeb5f2909c314d8e609",
    "url": "/img/ios@2x.e625229e.png"
  },
  {
    "revision": "af8bbdfa0a90c4eed4563f8c06ce5ff8",
    "url": "/img/android@2x.af8bbdfa.png"
  },
  {
    "revision": "cc0636ca2944024fd3ebf33a5412ff35",
    "url": "/img/icon-right@3x.cc0636ca.png"
  },
  {
    "revision": "1b983020cfed6b7a8ca5c300c24ca186",
    "url": "/img/icon-left@3x.1b983020.png"
  },
  {
    "revision": "d796d97eb9ebb2e89bb966343e2362e9",
    "url": "/img/icon-left@2x.d796d97e.png"
  },
  {
    "revision": "ccb9865dadbc642b8c4dd0a1abc8e570",
    "url": "/img/recharge-word@2x.ccb9865d.png"
  },
  {
    "revision": "ccb9865dadbc642b8c4dd0a1abc8e570",
    "url": "/img/recharge-word@3x.ccb9865d.png"
  },
  {
    "revision": "41a8c268f703fe646d5d08099eb778ae",
    "url": "/img/icon-right@2x.41a8c268.png"
  },
  {
    "revision": "2d6d06f4da15fc1a748677c49c5f1854",
    "url": "/img/bg.2d6d06f4.png"
  },
  {
    "revision": "1d7515ee61c3f659227318b4050955ed",
    "url": "/img/mobile_sim@2x.1d7515ee.png"
  },
  {
    "revision": "0f980b79d9a52702004de9f652a68835",
    "url": "/img/telcom_sim@2x.0f980b79.png"
  },
  {
    "revision": "98141226a7e992e3072a280746a259c4",
    "url": "/img/mobile_sim@3x.98141226.png"
  },
  {
    "revision": "0c88168b284b92c37f3a873f26a97d69",
    "url": "/img/bg.0c88168b.jpg"
  },
  {
    "revision": "9e02095f31a07b972244f1c714c1dfe7",
    "url": "/img/telcom_sim@3x.9e02095f.png"
  },
  {
    "revision": "3d0fc424b703032ca595090e99f8354b",
    "url": "/img/login_bg@2x.3d0fc424.png"
  },
  {
    "revision": "11000d4e510a6df565eb69ba6f2c1dfc",
    "url": "/img/login_bg@3x.11000d4e.png"
  },
  {
    "revision": "fa855242805b87da42c65763acd64ac0",
    "url": "/img/bg-plan-type@2x.fa855242.png"
  },
  {
    "revision": "4a9ca192485effa8b8f4b5b2df5b9caf",
    "url": "/img/bg-plan-type@3x.4a9ca192.png"
  },
  {
    "revision": "3f342771b9b81ab929e0fbcbcd0e6533",
    "url": "/img/bg-check-wrap@3x.3f342771.png"
  },
  {
    "revision": "9713b21819c4019befecd095069977df",
    "url": "/img/bg-check-wrap@2x.9713b218.png"
  },
  {
    "revision": "114a6e12b42b9b48586dd341105188fe",
    "url": "/img/usedOrder@2x.114a6e12.png"
  },
  {
    "revision": "c0170ec299b2418256fd515ee7849055",
    "url": "/img/unUsedOrder@2x.c0170ec2.png"
  },
  {
    "revision": "d9e14058d30dd312519fcf2de38d742b",
    "url": "/img/unUsedOrder@3x.d9e14058.png"
  },
  {
    "revision": "4a5b90f8076955f289b3dcda6a5af6ff",
    "url": "/img/invaildedOrder@3x.4a5b90f8.png"
  },
  {
    "revision": "0d5a5158e67bcb7a4604124715ed6fbf",
    "url": "/img/usedOrder@3x.0d5a5158.png"
  },
  {
    "revision": "be0f1e33b2553e71b117d3d3f838d32f",
    "url": "/img/invaildedOrder@2x.be0f1e33.png"
  },
  {
    "revision": "0f16389ec218c90cf8f657e233b745f2",
    "url": "/img/balanceBg1.0f16389e.png"
  },
  {
    "revision": "565459ef2ee8b71db421144ad21c23e3",
    "url": "/img/balanceBg2.565459ef.png"
  },
  {
    "revision": "f40c7e0b20fe25eb78a7658c3ae56312",
    "url": "/img/noData@3x.f40c7e0b.png"
  },
  {
    "revision": "644e6e3cf5f33943747b116316694e28",
    "url": "/img/noData@2x.644e6e3c.png"
  },
  {
    "revision": "af3ed0b3236bbfdbc3ad61b8d41c3dec",
    "url": "/img/changeBg.af3ed0b3.png"
  },
  {
    "revision": "0078f03c08066d51d64b92a13e194ebb",
    "url": "/img/balanceRefund.0078f03c.png"
  },
  {
    "revision": "01355f175bd20423ce45a838c1a998a9",
    "url": "/img/bg.01355f17.png"
  },
  {
    "revision": "2a67b73145562669220aa4639e1ad58f",
    "url": "/img/icon3.2a67b731.png"
  },
  {
    "revision": "813b5319e378dafdda952c16ad89906b",
    "url": "/img/icon2.813b5319.png"
  },
  {
    "revision": "014d354b9b25b67ae95857ba17e2f4cc",
    "url": "/img/activityPage.014d354b.png"
  },
  {
    "revision": "3603a35a49dbb8ad94ec1e57c4dad229",
    "url": "/img/scanTop2.3603a35a.png"
  },
  {
    "revision": "05775dd69c53d7273b27aaa7c6c523f7",
    "url": "/img/04.05775dd6.png"
  },
  {
    "revision": "58a560568b7291ea926c2c7438035308",
    "url": "/img/subscribe@3x.58a56056.png"
  },
  {
    "revision": "541375e6bb7db2fba9e415be8045f5fb",
    "url": "/img/1.541375e6.png"
  },
  {
    "revision": "7c28431d304fa4f58f5070c59720683a",
    "url": "/img/2.7c28431d.png"
  },
  {
    "revision": "5a3428653945c17e1c146efeee81c987",
    "url": "/img/scanTop.5a342865.png"
  },
  {
    "revision": "824594523c01e48028f2b7eb4261134d",
    "url": "/img/unicom-logo.82459452.svg"
  },
  {
    "revision": "113f99e2189c2ca49db2168754fc2eb5",
    "url": "/img/mobile-logo.113f99e2.png"
  },
  {
    "revision": "0cba868fa977e09806638b9000636a36",
    "url": "/img/avatar.0cba868f.jpeg"
  },
  {
    "revision": "27158aa79eb0d4b89f317d076a801ca3",
    "url": "/img/coupon-log.27158aa7.png"
  },
  {
    "revision": "55d3f2f09efe17db6485d4c9f8f0c3b1",
    "url": "/img/icon-recharge_20181001.55d3f2f0.svg"
  },
  {
    "revision": "165beb68d8ba0d2b70df0fbb3769787a",
    "url": "/img/03.165beb68.png"
  },
  {
    "revision": "5f1f34037094c0613bccafa2ddd8cb3b",
    "url": "/img/telecom-logo.5f1f3403.svg"
  },
  {
    "revision": "f7a51f1c554585b11d61499fd0a7520f",
    "url": "/img/only-box@3x.f7a51f1c.png"
  },
  {
    "revision": "89b99d16dd8a4a56746323a0ffbd754c",
    "url": "/img/migu.89b99d16.png"
  },
  {
    "revision": "a8272d2d742d9d50257e23dfac577def",
    "url": "/img/01.a8272d2d.png"
  },
  {
    "revision": "0b3c3297decbd1152a314cce115f9632",
    "url": "/img/09.0b3c3297.png"
  },
  {
    "revision": "3e217df4202e41ad9b030aafc8cfcc24",
    "url": "/img/4.3e217df4.png"
  },
  {
    "revision": "aecc9531f2c3b1fd45338e7bf5084384",
    "url": "/img/bg_no_recharge.aecc9531.svg"
  },
  {
    "revision": "b0ffa4a0fd195a110ee4d4dabce3bc32",
    "url": "/img/08.b0ffa4a0.png"
  },
  {
    "revision": "96fab583abd57f2e7118324858fa3080",
    "url": "/img/05.96fab583.png"
  },
  {
    "revision": "9e8ecc7f7b760b55c56bddfab886da10",
    "url": "/img/3.9e8ecc7f.png"
  },
  {
    "revision": "275be51ae57c486bce58257febd6589f",
    "url": "/img/bg_no_plan.275be51a.svg"
  },
  {
    "revision": "daa86b540bb9c2a6453ceac9bed77961",
    "url": "/img/07.daa86b54.png"
  },
  {
    "revision": "687b6ce03f134f21173c949d79002960",
    "url": "/img/tip.687b6ce0.png"
  },
  {
    "revision": "a610420eab741be28278e60bc06387aa",
    "url": "/img/box-deco@3x.a610420e.png"
  },
  {
    "revision": "eacba58f9acf2b87cd801858146b2ba9",
    "url": "/img/02.eacba58f.png"
  },
  {
    "revision": "39d9e849fc1c724525f166646932a24d",
    "url": "/img/safari.39d9e849.png"
  },
  {
    "revision": "999589aae784a460b5e7c6ae9bbaa3d8",
    "url": "/img/06.999589aa.png"
  },
  {
    "revision": "b46f62b53dd56fac719a2efe9ede53b0",
    "url": "/index.html"
  },
  {
    "revision": "00bbf6b458bf7ea6bd01f443eb3045d9",
    "url": "/MP_verify_4r3DVk3KUjgWsQsG.txt"
  },
  {
    "revision": "86c422d8c98b247235d04b49fb1c4b05",
    "url": "/MP_verify_bKSdn2qZlUSULliu.txt"
  },
  {
    "revision": "9ce16f441b39b493af8b96d7e97cce22",
    "url": "/MP_verify_dkzAKjxyVyJvsHMS.txt"
  },
  {
    "revision": "b6216d61c03e6ce0c9aea6ca7808f7ca",
    "url": "/robots.txt"
  },
  {
    "revision": "652317b098ca24e4511926c7fd57cbbe",
    "url": "/MP_verify_8JoCCldW78DygS5c.txt"
  }
];