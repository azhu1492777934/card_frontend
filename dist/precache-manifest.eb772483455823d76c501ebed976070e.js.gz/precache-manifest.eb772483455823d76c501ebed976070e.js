self.__precacheManifest = [
  {
    "revision": "d0807160aa68c6ae8bfb",
    "url": "/css/refundRules.8b525a1d.css"
  },
  {
    "revision": "22d35353279cbc6b99c3",
    "url": "/css/Layout.43b3cc9d.css"
  },
  {
    "revision": "78214ba34c5f1df936aa",
    "url": "/js/Layout~card_usage~eqReplaceMent~esim_plan_list~esim_usage~mifi_order~mifi_plan_list~mifi_plan_usage~~c6f87c36.6241bd21.js"
  },
  {
    "revision": "f4a9b622fff3863ccad2",
    "url": "/css/Not_fund.662737d2.css"
  },
  {
    "revision": "f4a9b622fff3863ccad2",
    "url": "/js/Not_fund.e60cbd1c.js"
  },
  {
    "revision": "7b850e2f26b055a0bcb6",
    "url": "/css/app.15f7a604.css"
  },
  {
    "revision": "7b850e2f26b055a0bcb6",
    "url": "/js/app.52a49a1e.js"
  },
  {
    "revision": "4870ae7c74df08066e23",
    "url": "/css/authority_middle.eca69a04.css"
  },
  {
    "revision": "4870ae7c74df08066e23",
    "url": "/js/authority_middle.7b856a71.js"
  },
  {
    "revision": "ef2afc35c4cf79087897",
    "url": "/css/balanceIndex.7fdb84f3.css"
  },
  {
    "revision": "ef2afc35c4cf79087897",
    "url": "/js/balanceIndex.5ce8fba2.js"
  },
  {
    "revision": "c6282def744974fe7758",
    "url": "/css/balanceRefund.1f0c9dac.css"
  },
  {
    "revision": "c6282def744974fe7758",
    "url": "/js/balanceRefund.56096739.js"
  },
  {
    "revision": "bc14718fd4d14c9b0185",
    "url": "/css/cardPackage.7cbd78ff.css"
  },
  {
    "revision": "bc14718fd4d14c9b0185",
    "url": "/js/cardPackage.5b781a78.js"
  },
  {
    "revision": "8d1cc73d05e9dbe43fe9",
    "url": "/css/card_check.1852dbcd.css"
  },
  {
    "revision": "8d1cc73d05e9dbe43fe9",
    "url": "/js/card_check.3cee7c7c.js"
  },
  {
    "revision": "9864af1c63884eb16757",
    "url": "/css/card_connection.3d383672.css"
  },
  {
    "revision": "9864af1c63884eb16757",
    "url": "/js/card_connection.019390a4.js"
  },
  {
    "revision": "39b36454a9c85920853a",
    "url": "/css/card_lookup.4787f142.css"
  },
  {
    "revision": "39b36454a9c85920853a",
    "url": "/js/card_lookup.54ab571a.js"
  },
  {
    "revision": "c5a47521f64b73108c0c",
    "url": "/css/card_more_flow.ce48287d.css"
  },
  {
    "revision": "c5a47521f64b73108c0c",
    "url": "/js/card_more_flow.f08b650d.js"
  },
  {
    "revision": "d2fbbead8aaffec64be7",
    "url": "/css/card_usage.454414a3.css"
  },
  {
    "revision": "d2fbbead8aaffec64be7",
    "url": "/js/card_usage.602fb7f8.js"
  },
  {
    "revision": "06875344dcb3f362b823",
    "url": "/css/card_usage~plan_list.c1b5e3ba.css"
  },
  {
    "revision": "06875344dcb3f362b823",
    "url": "/js/card_usage~plan_list.3dfbf672.js"
  },
  {
    "revision": "d3445531f127891a4d6b",
    "url": "/css/card_wrapper.b31b0763.css"
  },
  {
    "revision": "d3445531f127891a4d6b",
    "url": "/js/card_wrapper.69558088.js"
  },
  {
    "revision": "80c8bfc6a4e27255ccac",
    "url": "/css/children_card.be68bf52.css"
  },
  {
    "revision": "80c8bfc6a4e27255ccac",
    "url": "/js/children_card.953b68a6.js"
  },
  {
    "revision": "fe8f8773fb0e4b66e5ad",
    "url": "/css/chunk-2bdf0330.b9d2a4b3.css"
  },
  {
    "revision": "fe8f8773fb0e4b66e5ad",
    "url": "/js/chunk-2bdf0330.4cae919f.js"
  },
  {
    "revision": "03dc19614db93f17068b",
    "url": "/css/chunk-7dea1c93.7619ae85.css"
  },
  {
    "revision": "03dc19614db93f17068b",
    "url": "/js/chunk-7dea1c93.61189475.js"
  },
  {
    "revision": "7a37f1d32dcf31fafb6d",
    "url": "/css/chunk-vendors.4dda4045.css"
  },
  {
    "revision": "7a37f1d32dcf31fafb6d",
    "url": "/js/chunk-vendors.6a1799b5.js"
  },
  {
    "revision": "c12ddcbbb6bb7208f716",
    "url": "/css/commonProblem.0fc9e52f.css"
  },
  {
    "revision": "c12ddcbbb6bb7208f716",
    "url": "/js/commonProblem.d48086ce.js"
  },
  {
    "revision": "e3ff9d34440c324308d6",
    "url": "/css/commonQuestion.a1ed9720.css"
  },
  {
    "revision": "e3ff9d34440c324308d6",
    "url": "/js/commonQuestion.61631662.js"
  },
  {
    "revision": "eb7efa857e9c4d6f08cc",
    "url": "/css/consumerRecord.f329859b.css"
  },
  {
    "revision": "eb7efa857e9c4d6f08cc",
    "url": "/js/consumerRecord.c005bbcf.js"
  },
  {
    "revision": "ac0a5dfb20c010b1d47c",
    "url": "/css/coupon_normal.0749aa31.css"
  },
  {
    "revision": "ac0a5dfb20c010b1d47c",
    "url": "/js/coupon_normal.f3402156.js"
  },
  {
    "revision": "866d178779671b9e969a",
    "url": "/css/coupon_telcom.c54db4c8.css"
  },
  {
    "revision": "866d178779671b9e969a",
    "url": "/js/coupon_telcom.64836143.js"
  },
  {
    "revision": "e6dbc2669cff8ed95998",
    "url": "/css/coupon_wrapper.09148f29.css"
  },
  {
    "revision": "e6dbc2669cff8ed95998",
    "url": "/js/coupon_wrapper.0a92ab5a.js"
  },
  {
    "revision": "3f2128b5e6b4ff6e784e",
    "url": "/css/currencyConversion.b3443fb0.css"
  },
  {
    "revision": "3f2128b5e6b4ff6e784e",
    "url": "/js/currencyConversion.b8281d14.js"
  },
  {
    "revision": "bd988ffe433f8611db43",
    "url": "/css/customerFeedback.67d79ec4.css"
  },
  {
    "revision": "bd988ffe433f8611db43",
    "url": "/js/customerFeedback.26fa250d.js"
  },
  {
    "revision": "5deab31f228b3089fca8",
    "url": "/css/eqReplaceMent.01281939.css"
  },
  {
    "revision": "5deab31f228b3089fca8",
    "url": "/js/eqReplaceMent.cf01274f.js"
  },
  {
    "revision": "b1124b16093a74dc5550",
    "url": "/css/eqReplaceMent~recharge.1395966c.css"
  },
  {
    "revision": "b1124b16093a74dc5550",
    "url": "/js/eqReplaceMent~recharge.3e20714b.js"
  },
  {
    "revision": "98925c193c026045610d",
    "url": "/css/esim_plan_list.d2992a6d.css"
  },
  {
    "revision": "98925c193c026045610d",
    "url": "/js/esim_plan_list.7df45ae5.js"
  },
  {
    "revision": "5cbf650ec73cfcfd3ef1",
    "url": "/css/esim_usage.5d5b6dcf.css"
  },
  {
    "revision": "5cbf650ec73cfcfd3ef1",
    "url": "/js/esim_usage.c361fbd0.js"
  },
  {
    "revision": "1bd58cc07eec2f0c924f",
    "url": "/css/find_plan.e130cf54.css"
  },
  {
    "revision": "1bd58cc07eec2f0c924f",
    "url": "/js/find_plan.461c63ef.js"
  },
  {
    "revision": "8381da9ce8de3c3f9520",
    "url": "/css/logical_page.f9063ea0.css"
  },
  {
    "revision": "8381da9ce8de3c3f9520",
    "url": "/js/logical_page.951013fb.js"
  },
  {
    "revision": "263908c8a0235177f9cc",
    "url": "/css/login.92c7a795.css"
  },
  {
    "revision": "263908c8a0235177f9cc",
    "url": "/js/login.3b857092.js"
  },
  {
    "revision": "61b144e59241da3125bf",
    "url": "/css/lookup.85e42abf.css"
  },
  {
    "revision": "61b144e59241da3125bf",
    "url": "/js/lookup.e660f3cf.js"
  },
  {
    "revision": "4bd40ac72524f73ad506",
    "url": "/css/mifi_binding.7ef2308e.css"
  },
  {
    "revision": "4bd40ac72524f73ad506",
    "url": "/js/mifi_binding.95788280.js"
  },
  {
    "revision": "d4ae0dd4f8dece15dab2",
    "url": "/css/mifi_card_info.b51f72d4.css"
  },
  {
    "revision": "d4ae0dd4f8dece15dab2",
    "url": "/js/mifi_card_info.793329d6.js"
  },
  {
    "revision": "1a61d4fa4c010e88c38c",
    "url": "/css/mifi_card_lookup.8dbba1d7.css"
  },
  {
    "revision": "1a61d4fa4c010e88c38c",
    "url": "/js/mifi_card_lookup.0b3bb1e9.js"
  },
  {
    "revision": "fec37e7555637826dde8",
    "url": "/css/mifi_card_wrapper.3c21dde6.css"
  },
  {
    "revision": "fec37e7555637826dde8",
    "url": "/js/mifi_card_wrapper.f17ddcff.js"
  },
  {
    "revision": "51273be306b1ea422d79",
    "url": "/css/mifi_change_network.d418bf2f.css"
  },
  {
    "revision": "51273be306b1ea422d79",
    "url": "/js/mifi_change_network.18be76e5.js"
  },
  {
    "revision": "4db92d3f7b278c770c37",
    "url": "/css/mifi_change_network_explanation.85f470d6.css"
  },
  {
    "revision": "4db92d3f7b278c770c37",
    "url": "/js/mifi_change_network_explanation.39ce809c.js"
  },
  {
    "revision": "d033b07a933bc9f02d1e",
    "url": "/css/mifi_coupon_index.38895232.css"
  },
  {
    "revision": "d033b07a933bc9f02d1e",
    "url": "/js/mifi_coupon_index.b31c7ac3.js"
  },
  {
    "revision": "11303cabf216f67d1f95",
    "url": "/css/mifi_coupon_wrapper.0b3e62e0.css"
  },
  {
    "revision": "11303cabf216f67d1f95",
    "url": "/js/mifi_coupon_wrapper.b3f42e5c.js"
  },
  {
    "revision": "c59ad6fdc209c077ce3b",
    "url": "/css/mifi_index.de3fd730.css"
  },
  {
    "revision": "c59ad6fdc209c077ce3b",
    "url": "/js/mifi_index.0f23f78a.js"
  },
  {
    "revision": "9744e0d659d4d5dbb8fd",
    "url": "/css/mifi_layout.4d5939c7.css"
  },
  {
    "revision": "9744e0d659d4d5dbb8fd",
    "url": "/js/mifi_layout.f2050a00.js"
  },
  {
    "revision": "060d9ff7a54bfcadf513",
    "url": "/css/mifi_order.59ea4dc0.css"
  },
  {
    "revision": "060d9ff7a54bfcadf513",
    "url": "/js/mifi_order.ddebeb8c.js"
  },
  {
    "revision": "d2277115fddf1c46bee4",
    "url": "/css/mifi_order_wrapper.d9cb9826.css"
  },
  {
    "revision": "d2277115fddf1c46bee4",
    "url": "/js/mifi_order_wrapper.7d680a2b.js"
  },
  {
    "revision": "c102fd4e5e3a5f717efd",
    "url": "/css/mifi_plan_group.5e66e5c3.css"
  },
  {
    "revision": "c102fd4e5e3a5f717efd",
    "url": "/js/mifi_plan_group.76db0313.js"
  },
  {
    "revision": "1e02714c5180bb514ba5",
    "url": "/css/mifi_plan_list.c37fd401.css"
  },
  {
    "revision": "1e02714c5180bb514ba5",
    "url": "/js/mifi_plan_list.5c0db40d.js"
  },
  {
    "revision": "753da7a6bbab95c1ce8b",
    "url": "/css/mifi_plan_usage.7f6a07e1.css"
  },
  {
    "revision": "753da7a6bbab95c1ce8b",
    "url": "/js/mifi_plan_usage.10f166fe.js"
  },
  {
    "revision": "44c2cfa1c557e24a2b21",
    "url": "/css/mifi_plan_wrapper.e7857e6f.css"
  },
  {
    "revision": "44c2cfa1c557e24a2b21",
    "url": "/js/mifi_plan_wrapper.b93dc200.js"
  },
  {
    "revision": "80079da3809eb8fc4191",
    "url": "/css/new_card_wrapper.707898e1.css"
  },
  {
    "revision": "80079da3809eb8fc4191",
    "url": "/js/new_card_wrapper.7d4dc7a4.js"
  },
  {
    "revision": "ced716a5883d11195180",
    "url": "/css/official_accounts.9943c62d.css"
  },
  {
    "revision": "ced716a5883d11195180",
    "url": "/js/official_accounts.adf3c2aa.js"
  },
  {
    "revision": "3193220a72311754733a",
    "url": "/css/orderRecord.a0f02cae.css"
  },
  {
    "revision": "3193220a72311754733a",
    "url": "/js/orderRecord.64da0659.js"
  },
  {
    "revision": "44cc2949692d9947b9d6",
    "url": "/css/plan_list.63bf4f83.css"
  },
  {
    "revision": "44cc2949692d9947b9d6",
    "url": "/js/plan_list.8f933e9d.js"
  },
  {
    "revision": "802dd1746e35640a3981",
    "url": "/css/question.9a39012b.css"
  },
  {
    "revision": "802dd1746e35640a3981",
    "url": "/js/question.d55d713d.js"
  },
  {
    "revision": "b93b8a3ec5375f50b269",
    "url": "/css/question_wrapper.efcdaad9.css"
  },
  {
    "revision": "b93b8a3ec5375f50b269",
    "url": "/js/question_wrapper.9a017604.js"
  },
  {
    "revision": "9e320c3e876a4e638d42",
    "url": "/css/realNameCourse.34607b75.css"
  },
  {
    "revision": "9e320c3e876a4e638d42",
    "url": "/js/realNameCourse.1737ce52.js"
  },
  {
    "revision": "134f9be41ee692eebf7c",
    "url": "/css/real_name.9d3b5a12.css"
  },
  {
    "revision": "134f9be41ee692eebf7c",
    "url": "/js/real_name.32db1072.js"
  },
  {
    "revision": "fe4fd5780b7ad6222cf3",
    "url": "/css/recharge.22d45486.css"
  },
  {
    "revision": "fe4fd5780b7ad6222cf3",
    "url": "/js/recharge.74be4782.js"
  },
  {
    "revision": "6ebc399f56a817ae9c7a",
    "url": "/css/rechargeOrder.7a5f3980.css"
  },
  {
    "revision": "6ebc399f56a817ae9c7a",
    "url": "/js/rechargeOrder.ba13e7cc.js"
  },
  {
    "revision": "95264cf03c93c80cbbfc",
    "url": "/css/recharge_balance.56255f8f.css"
  },
  {
    "revision": "95264cf03c93c80cbbfc",
    "url": "/js/recharge_balance.1412cb5c.js"
  },
  {
    "revision": "bbe3d02cc6771d7b7522",
    "url": "/css/recharge_callback.e80f5a3d.css"
  },
  {
    "revision": "bbe3d02cc6771d7b7522",
    "url": "/js/recharge_callback.dd7a7c30.js"
  },
  {
    "revision": "f4bb0d93b41e14866a76",
    "url": "/css/recharge_wrapper.c3676c82.css"
  },
  {
    "revision": "f4bb0d93b41e14866a76",
    "url": "/js/recharge_wrapper.8c5878fa.js"
  },
  {
    "revision": "22d35353279cbc6b99c3",
    "url": "/js/Layout.b6dd6b9b.js"
  },
  {
    "revision": "d0807160aa68c6ae8bfb",
    "url": "/js/refundRules.d1c069c0.js"
  },
  {
    "revision": "943c9ff950d2d341e639",
    "url": "/css/refund_applying.98f0faaa.css"
  },
  {
    "revision": "943c9ff950d2d341e639",
    "url": "/js/refund_applying.1f487773.js"
  },
  {
    "revision": "93bf9afa03718252ee5e",
    "url": "/css/refund_argument.8bf332a8.css"
  },
  {
    "revision": "93bf9afa03718252ee5e",
    "url": "/js/refund_argument.386123a9.js"
  },
  {
    "revision": "68d1ed65138f403228b3",
    "url": "/css/refund_plan.3da361c5.css"
  },
  {
    "revision": "68d1ed65138f403228b3",
    "url": "/js/refund_plan.da39c05c.js"
  },
  {
    "revision": "04e747471527a8a856bf",
    "url": "/css/refund_wrapper.8b393e56.css"
  },
  {
    "revision": "04e747471527a8a856bf",
    "url": "/js/refund_wrapper.7401540d.js"
  },
  {
    "revision": "d339ac563cebc4dbbba8",
    "url": "/css/repeatRecharge.4d8bb120.css"
  },
  {
    "revision": "d339ac563cebc4dbbba8",
    "url": "/js/repeatRecharge.4ac9e9ae.js"
  },
  {
    "revision": "4b982963960496cc022b",
    "url": "/css/revoke_plan.d06c9459.css"
  },
  {
    "revision": "4b982963960496cc022b",
    "url": "/js/revoke_plan.1cd73f21.js"
  },
  {
    "revision": "6b4d3f1c54bb4b269fb8",
    "url": "/css/speedup_500.57204c7c.css"
  },
  {
    "revision": "6b4d3f1c54bb4b269fb8",
    "url": "/js/speedup_500.3094aeb4.js"
  },
  {
    "revision": "9eb6bbf7614a6df15b40",
    "url": "/css/speedup_80.9a0a827a.css"
  },
  {
    "revision": "9eb6bbf7614a6df15b40",
    "url": "/js/speedup_80.9f545f4f.js"
  },
  {
    "revision": "20a272b4261c285095b6",
    "url": "/css/speedup_wrapper.50c34f6c.css"
  },
  {
    "revision": "20a272b4261c285095b6",
    "url": "/js/speedup_wrapper.29359a47.js"
  },
  {
    "revision": "a08250285d7697ba0ac0",
    "url": "/css/to_tb.4499e46c.css"
  },
  {
    "revision": "a08250285d7697ba0ac0",
    "url": "/js/to_tb.e8657bd9.js"
  },
  {
    "revision": "d74d29373504fad89b4d",
    "url": "/css/transfer_url.4be7520f.css"
  },
  {
    "revision": "d74d29373504fad89b4d",
    "url": "/js/transfer_url.7d20eb8e.js"
  },
  {
    "revision": "6f71506271369012fad7",
    "url": "/css/userCenter.a92db948.css"
  },
  {
    "revision": "6f71506271369012fad7",
    "url": "/js/userCenter.cc74955d.js"
  },
  {
    "revision": "383408f5ecb27738c75f",
    "url": "/css/userCenterWrap.39017211.css"
  },
  {
    "revision": "383408f5ecb27738c75f",
    "url": "/js/userCenterWrap.19135768.js"
  },
  {
    "revision": "e4b411644706c29765eea3ffdd85ae39",
    "url": "/fonts/SourceHanSansCNRegular.e4b41164.woff"
  },
  {
    "revision": "834b022ab9ab0e6063904af32274e777",
    "url": "/fonts/SourceHanSansCNRegular.834b022a.eot"
  },
  {
    "revision": "f9509c5a10be7daaf1fa01922a7c6bc2",
    "url": "/fonts/SourceHanSansCNRegular.f9509c5a.ttf"
  },
  {
    "revision": "da0808e9fe85be160aab69c82dd8de1c",
    "url": "/img/SourceHanSansCNRegular.da0808e9.svg"
  },
  {
    "revision": "732389ded34cb9c52dd88271f1345af9",
    "url": "/fonts/element-icons.732389de.ttf"
  },
  {
    "revision": "535877f50039c0cb49a6196a5b7517cd",
    "url": "/fonts/element-icons.535877f5.woff"
  },
  {
    "revision": "0f16389ec218c90cf8f657e233b745f2",
    "url": "/img/balanceBg1.0f16389e.png"
  },
  {
    "revision": "565459ef2ee8b71db421144ad21c23e3",
    "url": "/img/balanceBg2.565459ef.png"
  },
  {
    "revision": "fff5af4325410621aeec4e60b3b92d9b",
    "url": "/img/mifi_binding_bg@3x.fff5af43.png"
  },
  {
    "revision": "fff5af4325410621aeec4e60b3b92d9b",
    "url": "/img/mifi_binding_bg@2x.fff5af43.png"
  },
  {
    "revision": "b899232b79ad9962c5ab5572775a0400",
    "url": "/img/card_index_bg@3x.b899232b.png"
  },
  {
    "revision": "b899232b79ad9962c5ab5572775a0400",
    "url": "/img/card_index_bg@2x.b899232b.png"
  },
  {
    "revision": "2c51a1e53c1ea0b35086d8d7261b4933",
    "url": "/img/bg_network@3x.2c51a1e5.png"
  },
  {
    "revision": "32d70c8fc305e3647098f3de0c71b618",
    "url": "/img/bg_network@2x.32d70c8f.png"
  },
  {
    "revision": "f5f322478286641bd9887a155e35f222",
    "url": "/img/btn.f5f32247.png"
  },
  {
    "revision": "d140650fa64e0f1fc771610dba62aed7",
    "url": "/img/bg.d140650f.png"
  },
  {
    "revision": "e625229e32d9deeb5f2909c314d8e609",
    "url": "/img/ios@2x.e625229e.png"
  },
  {
    "revision": "af8bbdfa0a90c4eed4563f8c06ce5ff8",
    "url": "/img/android@2x.af8bbdfa.png"
  },
  {
    "revision": "cc0636ca2944024fd3ebf33a5412ff35",
    "url": "/img/icon-right@3x.cc0636ca.png"
  },
  {
    "revision": "1b983020cfed6b7a8ca5c300c24ca186",
    "url": "/img/icon-left@3x.1b983020.png"
  },
  {
    "revision": "d796d97eb9ebb2e89bb966343e2362e9",
    "url": "/img/icon-left@2x.d796d97e.png"
  },
  {
    "revision": "ccb9865dadbc642b8c4dd0a1abc8e570",
    "url": "/img/recharge-word@2x.ccb9865d.png"
  },
  {
    "revision": "ccb9865dadbc642b8c4dd0a1abc8e570",
    "url": "/img/recharge-word@3x.ccb9865d.png"
  },
  {
    "revision": "41a8c268f703fe646d5d08099eb778ae",
    "url": "/img/icon-right@2x.41a8c268.png"
  },
  {
    "revision": "2d6d06f4da15fc1a748677c49c5f1854",
    "url": "/img/bg.2d6d06f4.png"
  },
  {
    "revision": "fa855242805b87da42c65763acd64ac0",
    "url": "/img/bg-plan-type@2x.fa855242.png"
  },
  {
    "revision": "4a9ca192485effa8b8f4b5b2df5b9caf",
    "url": "/img/bg-plan-type@3x.4a9ca192.png"
  },
  {
    "revision": "3f342771b9b81ab929e0fbcbcd0e6533",
    "url": "/img/bg-check-wrap@3x.3f342771.png"
  },
  {
    "revision": "9713b21819c4019befecd095069977df",
    "url": "/img/bg-check-wrap@2x.9713b218.png"
  },
  {
    "revision": "e93b8c03293c5b6a311da784f9c19c8f",
    "url": "/img/bg.e93b8c03.jpeg"
  },
  {
    "revision": "ffb1612d9660e2ecd9d3872d57a8a2f9",
    "url": "/img/bar.ffb1612d.png"
  },
  {
    "revision": "1d7515ee61c3f659227318b4050955ed",
    "url": "/img/mobile_sim@2x.1d7515ee.png"
  },
  {
    "revision": "0f980b79d9a52702004de9f652a68835",
    "url": "/img/telcom_sim@2x.0f980b79.png"
  },
  {
    "revision": "98141226a7e992e3072a280746a259c4",
    "url": "/img/mobile_sim@3x.98141226.png"
  },
  {
    "revision": "0c88168b284b92c37f3a873f26a97d69",
    "url": "/img/bg.0c88168b.jpg"
  },
  {
    "revision": "9e02095f31a07b972244f1c714c1dfe7",
    "url": "/img/telcom_sim@3x.9e02095f.png"
  },
  {
    "revision": "3d0fc424b703032ca595090e99f8354b",
    "url": "/img/login_bg@2x.3d0fc424.png"
  },
  {
    "revision": "11000d4e510a6df565eb69ba6f2c1dfc",
    "url": "/img/login_bg@3x.11000d4e.png"
  },
  {
    "revision": "014d354b9b25b67ae95857ba17e2f4cc",
    "url": "/img/activityPage.014d354b.png"
  },
  {
    "revision": "f40c7e0b20fe25eb78a7658c3ae56312",
    "url": "/img/noData@3x.f40c7e0b.png"
  },
  {
    "revision": "644e6e3cf5f33943747b116316694e28",
    "url": "/img/noData@2x.644e6e3c.png"
  },
  {
    "revision": "2a67b73145562669220aa4639e1ad58f",
    "url": "/img/icon3.2a67b731.png"
  },
  {
    "revision": "813b5319e378dafdda952c16ad89906b",
    "url": "/img/icon2.813b5319.png"
  },
  {
    "revision": "91e1d2771efacd45e5e465d9a001f197",
    "url": "/img/liantong.91e1d277.png"
  },
  {
    "revision": "4a0cab0f33beb48ea985714d1b91fef7",
    "url": "/img/dianxin.4a0cab0f.png"
  },
  {
    "revision": "657033323334e91efb0011bbc18f8c04",
    "url": "/img/yidong.65703332.png"
  },
  {
    "revision": "8da3b83b73e44e54d6be4b2522bcb1f2",
    "url": "/img/pkgBg2.8da3b83b.png"
  },
  {
    "revision": "d3b42651f9f5048baeffb50c800913ec",
    "url": "/img/pkgBg1.d3b42651.png"
  },
  {
    "revision": "d461d18e42a310bd709b2ce97d159153",
    "url": "/img/pkgBg3.d461d18e.png"
  },
  {
    "revision": "01355f175bd20423ce45a838c1a998a9",
    "url": "/img/bg.01355f17.png"
  },
  {
    "revision": "6dedd4943e4c5848638196fb6f0c4145",
    "url": "/img/bg.6dedd494.png"
  },
  {
    "revision": "6e5cee7393060b0ec3dcd587c2518b94",
    "url": "/img/bg_test.6e5cee73.png"
  },
  {
    "revision": "0078f03c08066d51d64b92a13e194ebb",
    "url": "/img/balanceRefund.0078f03c.png"
  },
  {
    "revision": "af3ed0b3236bbfdbc3ad61b8d41c3dec",
    "url": "/img/changeBg.af3ed0b3.png"
  },
  {
    "revision": "42c0fbd4915870e5e60452fd0ef2cbec",
    "url": "/img/orderTopBg@3x.42c0fbd4.png"
  },
  {
    "revision": "42c0fbd4915870e5e60452fd0ef2cbec",
    "url": "/img/orderTopBg@2x.42c0fbd4.png"
  },
  {
    "revision": "d0ccbc8a35180bb40e027b44dd26035a",
    "url": "/img/youku.d0ccbc8a.png"
  },
  {
    "revision": "a859e9ca4606d567c42b9c7bcd4fdce9",
    "url": "/img/iccid_bg@2x.a859e9ca.png"
  },
  {
    "revision": "fa9050c4e9870e8fc0cd184f8515af4a",
    "url": "/img/iccid_bg@3x.fa9050c4.png"
  },
  {
    "revision": "114a6e12b42b9b48586dd341105188fe",
    "url": "/img/usedOrder@2x.114a6e12.png"
  },
  {
    "revision": "c0170ec299b2418256fd515ee7849055",
    "url": "/img/unUsedOrder@2x.c0170ec2.png"
  },
  {
    "revision": "d9e14058d30dd312519fcf2de38d742b",
    "url": "/img/unUsedOrder@3x.d9e14058.png"
  },
  {
    "revision": "4a5b90f8076955f289b3dcda6a5af6ff",
    "url": "/img/invaildedOrder@3x.4a5b90f8.png"
  },
  {
    "revision": "0d5a5158e67bcb7a4604124715ed6fbf",
    "url": "/img/usedOrder@3x.0d5a5158.png"
  },
  {
    "revision": "be0f1e33b2553e71b117d3d3f838d32f",
    "url": "/img/invaildedOrder@2x.be0f1e33.png"
  },
  {
    "revision": "3603a35a49dbb8ad94ec1e57c4dad229",
    "url": "/img/scanTop2.3603a35a.png"
  },
  {
    "revision": "05775dd69c53d7273b27aaa7c6c523f7",
    "url": "/img/04.05775dd6.png"
  },
  {
    "revision": "58a560568b7291ea926c2c7438035308",
    "url": "/img/subscribe@3x.58a56056.png"
  },
  {
    "revision": "541375e6bb7db2fba9e415be8045f5fb",
    "url": "/img/1.541375e6.png"
  },
  {
    "revision": "7c28431d304fa4f58f5070c59720683a",
    "url": "/img/2.7c28431d.png"
  },
  {
    "revision": "5a3428653945c17e1c146efeee81c987",
    "url": "/img/scanTop.5a342865.png"
  },
  {
    "revision": "0b9e0b5f4f28c68416f916ddce3fc7ef",
    "url": "/img/unicom-logo.0b9e0b5f.svg"
  },
  {
    "revision": "113f99e2189c2ca49db2168754fc2eb5",
    "url": "/img/mobile-logo.113f99e2.png"
  },
  {
    "revision": "0cba868fa977e09806638b9000636a36",
    "url": "/img/avatar.0cba868f.jpeg"
  },
  {
    "revision": "27158aa79eb0d4b89f317d076a801ca3",
    "url": "/img/coupon-log.27158aa7.png"
  },
  {
    "revision": "55d3f2f09efe17db6485d4c9f8f0c3b1",
    "url": "/img/icon-recharge_20181001.55d3f2f0.svg"
  },
  {
    "revision": "165beb68d8ba0d2b70df0fbb3769787a",
    "url": "/img/03.165beb68.png"
  },
  {
    "revision": "8c605ac88ca50357355da465f322d10a",
    "url": "/img/telecom-logo.8c605ac8.svg"
  },
  {
    "revision": "f7a51f1c554585b11d61499fd0a7520f",
    "url": "/img/only-box@3x.f7a51f1c.png"
  },
  {
    "revision": "89b99d16dd8a4a56746323a0ffbd754c",
    "url": "/img/migu.89b99d16.png"
  },
  {
    "revision": "0b3c3297decbd1152a314cce115f9632",
    "url": "/img/09.0b3c3297.png"
  },
  {
    "revision": "3e217df4202e41ad9b030aafc8cfcc24",
    "url": "/img/4.3e217df4.png"
  },
  {
    "revision": "34c67f6dfdb0ecc17c7a221aec74706f",
    "url": "/img/bg_no_recharge.34c67f6d.svg"
  },
  {
    "revision": "b0ffa4a0fd195a110ee4d4dabce3bc32",
    "url": "/img/08.b0ffa4a0.png"
  },
  {
    "revision": "96fab583abd57f2e7118324858fa3080",
    "url": "/img/05.96fab583.png"
  },
  {
    "revision": "9e8ecc7f7b760b55c56bddfab886da10",
    "url": "/img/3.9e8ecc7f.png"
  },
  {
    "revision": "f23d9d1f76147bc89b48902c36818f1e",
    "url": "/img/bg_no_plan.f23d9d1f.svg"
  },
  {
    "revision": "a8272d2d742d9d50257e23dfac577def",
    "url": "/img/01.a8272d2d.png"
  },
  {
    "revision": "daa86b540bb9c2a6453ceac9bed77961",
    "url": "/img/07.daa86b54.png"
  },
  {
    "revision": "687b6ce03f134f21173c949d79002960",
    "url": "/img/tip.687b6ce0.png"
  },
  {
    "revision": "a610420eab741be28278e60bc06387aa",
    "url": "/img/box-deco@3x.a610420e.png"
  },
  {
    "revision": "eacba58f9acf2b87cd801858146b2ba9",
    "url": "/img/02.eacba58f.png"
  },
  {
    "revision": "39d9e849fc1c724525f166646932a24d",
    "url": "/img/safari.39d9e849.png"
  },
  {
    "revision": "999589aae784a460b5e7c6ae9bbaa3d8",
    "url": "/img/06.999589aa.png"
  },
  {
    "revision": "23e5c1dc46e905711daef09f0840267c",
    "url": "/index.html"
  },
  {
    "revision": "735ab4f94fbcd57074377afca324c813",
    "url": "/robots.txt"
  },
  {
    "revision": "9ce16f441b39b493af8b96d7e97cce22",
    "url": "/MP_verify_dkzAKjxyVyJvsHMS.txt"
  },
  {
    "revision": "86c422d8c98b247235d04b49fb1c4b05",
    "url": "/MP_verify_bKSdn2qZlUSULliu.txt"
  },
  {
    "revision": "652317b098ca24e4511926c7fd57cbbe",
    "url": "/MP_verify_8JoCCldW78DygS5c.txt"
  },
  {
    "revision": "00bbf6b458bf7ea6bd01f443eb3045d9",
    "url": "/MP_verify_4r3DVk3KUjgWsQsG.txt"
  }
];