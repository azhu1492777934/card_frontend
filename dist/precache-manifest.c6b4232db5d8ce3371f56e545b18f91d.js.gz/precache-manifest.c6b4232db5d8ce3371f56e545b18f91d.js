self.__precacheManifest = [
  {
    "revision": "939bee85aa39891e4fd1",
    "url": "/css/Layout.90135afe.css"
  },
  {
    "revision": "939bee85aa39891e4fd1",
    "url": "/js/Layout.e309c5e9.js"
  },
  {
    "revision": "cb71e88bd43ec65f574f",
    "url": "/js/Layout~card_usage~eqReplaceMent~esim_plan_list~esim_usage~jdReplaceMent~mifi_order~mifi_plan_list~mi~504954e7.f06824d4.js"
  },
  {
    "revision": "b407f9f2359a3d636087",
    "url": "/css/Layout~card_usage~plan_list.2a355dc0.css"
  },
  {
    "revision": "b407f9f2359a3d636087",
    "url": "/js/Layout~card_usage~plan_list.e977c7f1.js"
  },
  {
    "revision": "f6865155e040ff156ab8",
    "url": "/css/Not_fund.49a1680b.css"
  },
  {
    "revision": "f6865155e040ff156ab8",
    "url": "/js/Not_fund.16285675.js"
  },
  {
    "revision": "fcb562764d0bf9530834",
    "url": "/css/app.097110e6.css"
  },
  {
    "revision": "fcb562764d0bf9530834",
    "url": "/js/app.9b82a1e3.js"
  },
  {
    "revision": "ea8842aa178839b499ea",
    "url": "/css/authority_middle.6f34fd52.css"
  },
  {
    "revision": "ea8842aa178839b499ea",
    "url": "/js/authority_middle.ddb3c419.js"
  },
  {
    "revision": "cd62b267ad7c4b156c59",
    "url": "/css/balanceIndex.7899cc40.css"
  },
  {
    "revision": "cd62b267ad7c4b156c59",
    "url": "/js/balanceIndex.a117a1ef.js"
  },
  {
    "revision": "3fe06eb616e26a487fdc",
    "url": "/css/balanceRefund.8c89b392.css"
  },
  {
    "revision": "3fe06eb616e26a487fdc",
    "url": "/js/balanceRefund.67f5e61e.js"
  },
  {
    "revision": "037c114282ea94f67a5d",
    "url": "/css/cardPackage.882bd3b3.css"
  },
  {
    "revision": "037c114282ea94f67a5d",
    "url": "/js/cardPackage.2f8709bb.js"
  },
  {
    "revision": "f4e797d0f88fafd26977",
    "url": "/css/card_check.f916e826.css"
  },
  {
    "revision": "f4e797d0f88fafd26977",
    "url": "/js/card_check.b0d8c5b2.js"
  },
  {
    "revision": "6d2b6c2d5c0021fcbc6d",
    "url": "/css/card_connection.15510de0.css"
  },
  {
    "revision": "6d2b6c2d5c0021fcbc6d",
    "url": "/js/card_connection.0b8b32a1.js"
  },
  {
    "revision": "e1ed9e422eb1c423d4f1",
    "url": "/css/card_invoice.a5cf8b99.css"
  },
  {
    "revision": "e1ed9e422eb1c423d4f1",
    "url": "/js/card_invoice.2837a79a.js"
  },
  {
    "revision": "de76541420d7cdc7d275",
    "url": "/css/card_invoice~customerFeedback~eqReplaceMent~jdReplaceMent~mifi_plan_group~recharge.1662a141.css"
  },
  {
    "revision": "de76541420d7cdc7d275",
    "url": "/js/card_invoice~customerFeedback~eqReplaceMent~jdReplaceMent~mifi_plan_group~recharge.2d81ed42.js"
  },
  {
    "revision": "f1d637c5d018712e85b7",
    "url": "/js/card_invoice~eqReplaceMent~jdReplaceMent.9e04ff78.js"
  },
  {
    "revision": "f7cabea4cb120221d9ee",
    "url": "/css/card_lookup.82c89cf4.css"
  },
  {
    "revision": "f7cabea4cb120221d9ee",
    "url": "/js/card_lookup.329c4a8c.js"
  },
  {
    "revision": "1d7ec2e8c822e6a7f01e",
    "url": "/css/card_lookup_notice.a53365c6.css"
  },
  {
    "revision": "1d7ec2e8c822e6a7f01e",
    "url": "/js/card_lookup_notice.cc51b980.js"
  },
  {
    "revision": "0bedc31033ba4562d5d2",
    "url": "/css/card_lookup~card_lookup_notice.c536ca70.css"
  },
  {
    "revision": "0bedc31033ba4562d5d2",
    "url": "/js/card_lookup~card_lookup_notice.73428632.js"
  },
  {
    "revision": "43e6cf46dbca754c21c9",
    "url": "/css/card_more_flow.96dad439.css"
  },
  {
    "revision": "43e6cf46dbca754c21c9",
    "url": "/js/card_more_flow.993b8eae.js"
  },
  {
    "revision": "c916a44cb3e54fcac150",
    "url": "/css/card_usage.4849faee.css"
  },
  {
    "revision": "c916a44cb3e54fcac150",
    "url": "/js/card_usage.afe99b6d.js"
  },
  {
    "revision": "a5e61b460f64166e0bec",
    "url": "/css/card_wrapper.910fa9ea.css"
  },
  {
    "revision": "a5e61b460f64166e0bec",
    "url": "/js/card_wrapper.264a5f80.js"
  },
  {
    "revision": "5ba05bf304fc623d17ed",
    "url": "/css/children_card.1f00d12d.css"
  },
  {
    "revision": "5ba05bf304fc623d17ed",
    "url": "/js/children_card.066cca0c.js"
  },
  {
    "revision": "65a08ca25cf646374b56",
    "url": "/css/chunk-3527d1ff.1d70d445.css"
  },
  {
    "revision": "65a08ca25cf646374b56",
    "url": "/js/chunk-3527d1ff.9f72eec2.js"
  },
  {
    "revision": "469f663ccc87b953ffeb",
    "url": "/css/chunk-659a819c.15554e3a.css"
  },
  {
    "revision": "469f663ccc87b953ffeb",
    "url": "/js/chunk-659a819c.d504896c.js"
  },
  {
    "revision": "2c7914532f8347f9c82a",
    "url": "/css/chunk-vendors.3bcdc4d8.css"
  },
  {
    "revision": "2c7914532f8347f9c82a",
    "url": "/js/chunk-vendors.9a72f089.js"
  },
  {
    "revision": "7913780ffaaa72faa747",
    "url": "/css/commonProblem.a7821a06.css"
  },
  {
    "revision": "7913780ffaaa72faa747",
    "url": "/js/commonProblem.d9ee07cc.js"
  },
  {
    "revision": "2ef8e0a9690a9de8d432",
    "url": "/css/commonQuestion.22eae5cf.css"
  },
  {
    "revision": "2ef8e0a9690a9de8d432",
    "url": "/js/commonQuestion.0c340639.js"
  },
  {
    "revision": "c6df0d33db41f7c730da",
    "url": "/css/consumerRecord.10ae0f97.css"
  },
  {
    "revision": "c6df0d33db41f7c730da",
    "url": "/js/consumerRecord.9febc310.js"
  },
  {
    "revision": "bf736d7d254060c2a403",
    "url": "/css/coupon_normal.46713ac9.css"
  },
  {
    "revision": "bf736d7d254060c2a403",
    "url": "/js/coupon_normal.d13faea9.js"
  },
  {
    "revision": "16f36bdc2caec2ca731b",
    "url": "/css/coupon_telcom.76570194.css"
  },
  {
    "revision": "16f36bdc2caec2ca731b",
    "url": "/js/coupon_telcom.d4de76b5.js"
  },
  {
    "revision": "b8af619eb99def47e667",
    "url": "/css/coupon_wrapper.2ce7ebad.css"
  },
  {
    "revision": "b8af619eb99def47e667",
    "url": "/js/coupon_wrapper.ea2d87a7.js"
  },
  {
    "revision": "71bdbeb23bbb9c71f9f8",
    "url": "/css/currencyConversion.5d59a809.css"
  },
  {
    "revision": "71bdbeb23bbb9c71f9f8",
    "url": "/js/currencyConversion.b71e8f60.js"
  },
  {
    "revision": "81e1e1567c2cc5d3b7c1",
    "url": "/css/customerFeedback.044063ad.css"
  },
  {
    "revision": "81e1e1567c2cc5d3b7c1",
    "url": "/js/customerFeedback.c3789883.js"
  },
  {
    "revision": "94e8806e65473050c921",
    "url": "/css/eqReplaceMent.08525830.css"
  },
  {
    "revision": "94e8806e65473050c921",
    "url": "/js/eqReplaceMent.4f5d54bf.js"
  },
  {
    "revision": "cfa44d08385c3bb1db6c",
    "url": "/css/esim_plan_list.8c53bced.css"
  },
  {
    "revision": "cfa44d08385c3bb1db6c",
    "url": "/js/esim_plan_list.634048fd.js"
  },
  {
    "revision": "7ec1ab04661497592944",
    "url": "/css/esim_usage.0504a5d1.css"
  },
  {
    "revision": "7ec1ab04661497592944",
    "url": "/js/esim_usage.5cd3436a.js"
  },
  {
    "revision": "5a39fd0ab7ad9aa77764",
    "url": "/css/find_plan.11aacc3e.css"
  },
  {
    "revision": "5a39fd0ab7ad9aa77764",
    "url": "/js/find_plan.bea66b68.js"
  },
  {
    "revision": "47a47b705c08cfa002c4",
    "url": "/css/guardian.df130473.css"
  },
  {
    "revision": "47a47b705c08cfa002c4",
    "url": "/js/guardian.a53f040d.js"
  },
  {
    "revision": "9125c8c4859bcef4cca7",
    "url": "/css/jdReplaceMent.65ba1b8c.css"
  },
  {
    "revision": "9125c8c4859bcef4cca7",
    "url": "/js/jdReplaceMent.72c6f391.js"
  },
  {
    "revision": "1469d4493298fc6ed9a7",
    "url": "/css/jdWrapper.5698fee5.css"
  },
  {
    "revision": "1469d4493298fc6ed9a7",
    "url": "/js/jdWrapper.0ca39594.js"
  },
  {
    "revision": "ce73b7dacf1ba8b14455",
    "url": "/css/logical_page.d59fdd88.css"
  },
  {
    "revision": "ce73b7dacf1ba8b14455",
    "url": "/js/logical_page.a8e17ff6.js"
  },
  {
    "revision": "13b6c0c6ae1a932d2cd2",
    "url": "/css/login.b9122fb9.css"
  },
  {
    "revision": "13b6c0c6ae1a932d2cd2",
    "url": "/js/login.2b92a85e.js"
  },
  {
    "revision": "15fb894877bd5ae793a1",
    "url": "/css/lookup.8145050e.css"
  },
  {
    "revision": "15fb894877bd5ae793a1",
    "url": "/js/lookup.a2715824.js"
  },
  {
    "revision": "6dde7013a8c18fdc4026",
    "url": "/css/mifi_binding.46753625.css"
  },
  {
    "revision": "6dde7013a8c18fdc4026",
    "url": "/js/mifi_binding.4a9be745.js"
  },
  {
    "revision": "fca6173b7c46f3bf595e",
    "url": "/css/mifi_card_info.e2527324.css"
  },
  {
    "revision": "fca6173b7c46f3bf595e",
    "url": "/js/mifi_card_info.0b4cb746.js"
  },
  {
    "revision": "d96d0b9f2afa20e771d9",
    "url": "/css/mifi_card_lookup.0f541945.css"
  },
  {
    "revision": "d96d0b9f2afa20e771d9",
    "url": "/js/mifi_card_lookup.01179807.js"
  },
  {
    "revision": "e772052ebec71dae34f8",
    "url": "/css/mifi_card_wrapper.328cf5ee.css"
  },
  {
    "revision": "e772052ebec71dae34f8",
    "url": "/js/mifi_card_wrapper.5ece8454.js"
  },
  {
    "revision": "0cb7cdf3fb68b8813955",
    "url": "/css/mifi_change_network.cfe84503.css"
  },
  {
    "revision": "0cb7cdf3fb68b8813955",
    "url": "/js/mifi_change_network.914c20c3.js"
  },
  {
    "revision": "51ff7bb6af1a3b5e8ac8",
    "url": "/css/mifi_change_network_explanation.1d4b08ea.css"
  },
  {
    "revision": "51ff7bb6af1a3b5e8ac8",
    "url": "/js/mifi_change_network_explanation.f810a660.js"
  },
  {
    "revision": "1eb09a9aab86c8755d1d",
    "url": "/css/mifi_coupon_index.63a727eb.css"
  },
  {
    "revision": "1eb09a9aab86c8755d1d",
    "url": "/js/mifi_coupon_index.cbbf295b.js"
  },
  {
    "revision": "fee1614edce75849d67b",
    "url": "/css/mifi_coupon_wrapper.84c0fd4f.css"
  },
  {
    "revision": "fee1614edce75849d67b",
    "url": "/js/mifi_coupon_wrapper.e5cd5262.js"
  },
  {
    "revision": "13e8143bc4392e0070c9",
    "url": "/css/mifi_index.cb9ccea9.css"
  },
  {
    "revision": "13e8143bc4392e0070c9",
    "url": "/js/mifi_index.4b276c98.js"
  },
  {
    "revision": "ad39f515c161859857f4",
    "url": "/css/mifi_layout.97aac86e.css"
  },
  {
    "revision": "ad39f515c161859857f4",
    "url": "/js/mifi_layout.71fc4df3.js"
  },
  {
    "revision": "afd1d9eb355336a6537e",
    "url": "/css/mifi_lookupKeFu.8990c71f.css"
  },
  {
    "revision": "afd1d9eb355336a6537e",
    "url": "/js/mifi_lookupKeFu.3fbe5b3a.js"
  },
  {
    "revision": "cac6a7aa2621084cd10c",
    "url": "/css/mifi_order.f8ffc14b.css"
  },
  {
    "revision": "cac6a7aa2621084cd10c",
    "url": "/js/mifi_order.70ca395a.js"
  },
  {
    "revision": "fa09bd24c9e4875196cf",
    "url": "/css/mifi_order_wrapper.9fad4617.css"
  },
  {
    "revision": "fa09bd24c9e4875196cf",
    "url": "/js/mifi_order_wrapper.0a10aa2e.js"
  },
  {
    "revision": "ae357fe7fd2279a5ed90",
    "url": "/css/mifi_plan_group.c16bb2ae.css"
  },
  {
    "revision": "ae357fe7fd2279a5ed90",
    "url": "/js/mifi_plan_group.4d05c229.js"
  },
  {
    "revision": "d60e1dbcb76f8af8fb54",
    "url": "/css/mifi_plan_list.fe1f9fa6.css"
  },
  {
    "revision": "d60e1dbcb76f8af8fb54",
    "url": "/js/mifi_plan_list.8f2868fc.js"
  },
  {
    "revision": "a163a31c79a3a6666c1a",
    "url": "/css/mifi_plan_usage.ee882357.css"
  },
  {
    "revision": "a163a31c79a3a6666c1a",
    "url": "/js/mifi_plan_usage.8c114635.js"
  },
  {
    "revision": "a9240e8604422ffdaeee",
    "url": "/css/mifi_plan_wrapper.148ed23b.css"
  },
  {
    "revision": "a9240e8604422ffdaeee",
    "url": "/js/mifi_plan_wrapper.4ecc30b6.js"
  },
  {
    "revision": "924dfc1b122c81eaf87c",
    "url": "/css/new_card_wrapper.016d9434.css"
  },
  {
    "revision": "924dfc1b122c81eaf87c",
    "url": "/js/new_card_wrapper.203f0ea1.js"
  },
  {
    "revision": "7c74463e2dd2149fe007",
    "url": "/css/official_accounts.997e4bf7.css"
  },
  {
    "revision": "7c74463e2dd2149fe007",
    "url": "/js/official_accounts.c31038c7.js"
  },
  {
    "revision": "4c186e1033f53f3e8167",
    "url": "/css/orderRecord.57482cee.css"
  },
  {
    "revision": "4c186e1033f53f3e8167",
    "url": "/js/orderRecord.0340c9e4.js"
  },
  {
    "revision": "451b539e32cc367ae3f4",
    "url": "/css/plan_list.0b711791.css"
  },
  {
    "revision": "451b539e32cc367ae3f4",
    "url": "/js/plan_list.cd754bf0.js"
  },
  {
    "revision": "3540ac0531f9712a9c62",
    "url": "/css/question.694257a8.css"
  },
  {
    "revision": "3540ac0531f9712a9c62",
    "url": "/js/question.222ee36a.js"
  },
  {
    "revision": "d8efe0c60dfa0b66dac3",
    "url": "/css/question_wrapper.80fa7896.css"
  },
  {
    "revision": "d8efe0c60dfa0b66dac3",
    "url": "/js/question_wrapper.cab65505.js"
  },
  {
    "revision": "f5f9b753c55458f5709d",
    "url": "/css/realNameCourse.25a3aa26.css"
  },
  {
    "revision": "f5f9b753c55458f5709d",
    "url": "/js/realNameCourse.32d91df3.js"
  },
  {
    "revision": "b7cd10cc34f0ac231448",
    "url": "/css/real_name.3437a89f.css"
  },
  {
    "revision": "b7cd10cc34f0ac231448",
    "url": "/js/real_name.deaccf4e.js"
  },
  {
    "revision": "1e129caa7a647d169f73",
    "url": "/css/recharge.8bf84cf9.css"
  },
  {
    "revision": "1e129caa7a647d169f73",
    "url": "/js/recharge.7a705bd6.js"
  },
  {
    "revision": "c5ac7da1cfdb78470ae0",
    "url": "/css/rechargeOrder.be1a1cde.css"
  },
  {
    "revision": "c5ac7da1cfdb78470ae0",
    "url": "/js/rechargeOrder.a8983f55.js"
  },
  {
    "revision": "1be826a5e5e00e24fd51",
    "url": "/css/rechargeOrder~whiteSearch.5e5693c8.css"
  },
  {
    "revision": "1be826a5e5e00e24fd51",
    "url": "/js/rechargeOrder~whiteSearch.48f03a86.js"
  },
  {
    "revision": "c4ad49934eed84f5080b",
    "url": "/css/recharge_balance.3359088d.css"
  },
  {
    "revision": "c4ad49934eed84f5080b",
    "url": "/js/recharge_balance.c8264ee0.js"
  },
  {
    "revision": "7f6d8f122b9cb4e3cbcd",
    "url": "/css/recharge_callback.7a8571cb.css"
  },
  {
    "revision": "7f6d8f122b9cb4e3cbcd",
    "url": "/js/recharge_callback.572163ac.js"
  },
  {
    "revision": "eb4428ef691ed082845d",
    "url": "/css/recharge_wrapper.b6c5f12a.css"
  },
  {
    "revision": "eb4428ef691ed082845d",
    "url": "/js/recharge_wrapper.1dde8bc4.js"
  },
  {
    "revision": "06012a7f2a200bec62d3",
    "url": "/css/refundRules.587474f6.css"
  },
  {
    "revision": "06012a7f2a200bec62d3",
    "url": "/js/refundRules.7ba5a5fd.js"
  },
  {
    "revision": "37d456609f12692dbbb7",
    "url": "/css/refund_applying.cc2b4549.css"
  },
  {
    "revision": "37d456609f12692dbbb7",
    "url": "/js/refund_applying.2f07de64.js"
  },
  {
    "revision": "6eec3f5830fb30fc034b",
    "url": "/css/refund_argument.f00ac72b.css"
  },
  {
    "revision": "6eec3f5830fb30fc034b",
    "url": "/js/refund_argument.fbe8e71a.js"
  },
  {
    "revision": "1870d8bf8df079da33ee",
    "url": "/css/refund_plan.4a79b702.css"
  },
  {
    "revision": "1870d8bf8df079da33ee",
    "url": "/js/refund_plan.d3fa00e7.js"
  },
  {
    "revision": "92693a4240135dc20db5",
    "url": "/css/refund_wrapper.d9cb9826.css"
  },
  {
    "revision": "92693a4240135dc20db5",
    "url": "/js/refund_wrapper.9da5c3e8.js"
  },
  {
    "revision": "1dafe794a708164575fc",
    "url": "/css/repeatRecharge.c49f61fa.css"
  },
  {
    "revision": "1dafe794a708164575fc",
    "url": "/js/repeatRecharge.d9a7b48b.js"
  },
  {
    "revision": "e26b06598c2446b53edb",
    "url": "/css/revoke_plan.545e3df4.css"
  },
  {
    "revision": "e26b06598c2446b53edb",
    "url": "/js/revoke_plan.80d7fbc5.js"
  },
  {
    "revision": "08165cd097498e94ca0f",
    "url": "/css/speedup_500.78765fd3.css"
  },
  {
    "revision": "08165cd097498e94ca0f",
    "url": "/js/speedup_500.b749d4c3.js"
  },
  {
    "revision": "274c2f2419d3782a9f4f",
    "url": "/css/speedup_80.beaed54e.css"
  },
  {
    "revision": "274c2f2419d3782a9f4f",
    "url": "/js/speedup_80.3e1a1527.js"
  },
  {
    "revision": "869651d3e8fb20077fa9",
    "url": "/css/speedup_wrapper.8ab9a0db.css"
  },
  {
    "revision": "869651d3e8fb20077fa9",
    "url": "/js/speedup_wrapper.0233ebd7.js"
  },
  {
    "revision": "af596f69b51a78f471b7",
    "url": "/css/to_tb.0332f15e.css"
  },
  {
    "revision": "af596f69b51a78f471b7",
    "url": "/js/to_tb.b5f7c324.js"
  },
  {
    "revision": "ed4ce79c52259d5fe696",
    "url": "/css/transfer_url.551c58fa.css"
  },
  {
    "revision": "ed4ce79c52259d5fe696",
    "url": "/js/transfer_url.5a1c48ed.js"
  },
  {
    "revision": "3298a15f4bec28041b50",
    "url": "/css/userCenter.71fcf97f.css"
  },
  {
    "revision": "3298a15f4bec28041b50",
    "url": "/js/userCenter.aa4df337.js"
  },
  {
    "revision": "c44221ebc16eab4234d7",
    "url": "/css/userCenterWrap.54590424.css"
  },
  {
    "revision": "c44221ebc16eab4234d7",
    "url": "/js/userCenterWrap.dc83c3c5.js"
  },
  {
    "revision": "17a0ed2e8655be9691ce",
    "url": "/css/whiteListsWrapper.f0e37d5a.css"
  },
  {
    "revision": "17a0ed2e8655be9691ce",
    "url": "/js/whiteListsWrapper.14adeba8.js"
  },
  {
    "revision": "43d28f43c3cb4a086d2b",
    "url": "/css/whiteNewlist.2a0af822.css"
  },
  {
    "revision": "43d28f43c3cb4a086d2b",
    "url": "/js/whiteNewlist.64e36590.js"
  },
  {
    "revision": "346f57c25c1f3d74d882",
    "url": "/css/whiteSearch.e70f83a4.css"
  },
  {
    "revision": "346f57c25c1f3d74d882",
    "url": "/js/whiteSearch.95ea2d2e.js"
  },
  {
    "revision": "e4b411644706c29765eea3ffdd85ae39",
    "url": "/fonts/SourceHanSansCNRegular.e4b41164.woff"
  },
  {
    "revision": "834b022ab9ab0e6063904af32274e777",
    "url": "/fonts/SourceHanSansCNRegular.834b022a.eot"
  },
  {
    "revision": "f9509c5a10be7daaf1fa01922a7c6bc2",
    "url": "/fonts/SourceHanSansCNRegular.f9509c5a.ttf"
  },
  {
    "revision": "da0808e9fe85be160aab69c82dd8de1c",
    "url": "/img/SourceHanSansCNRegular.da0808e9.svg"
  },
  {
    "revision": "732389ded34cb9c52dd88271f1345af9",
    "url": "/fonts/element-icons.732389de.ttf"
  },
  {
    "revision": "535877f50039c0cb49a6196a5b7517cd",
    "url": "/fonts/element-icons.535877f5.woff"
  },
  {
    "revision": "fff5af4325410621aeec4e60b3b92d9b",
    "url": "/img/mifi_binding_bg@3x.fff5af43.png"
  },
  {
    "revision": "fff5af4325410621aeec4e60b3b92d9b",
    "url": "/img/mifi_binding_bg@2x.fff5af43.png"
  },
  {
    "revision": "f5f322478286641bd9887a155e35f222",
    "url": "/img/btn.f5f32247.png"
  },
  {
    "revision": "d140650fa64e0f1fc771610dba62aed7",
    "url": "/img/bg.d140650f.png"
  },
  {
    "revision": "8cb139e0169560e725d23c2ab8d8310e",
    "url": "/img/advert.8cb139e0.gif"
  },
  {
    "revision": "42c0fbd4915870e5e60452fd0ef2cbec",
    "url": "/img/orderTopBg@3x.42c0fbd4.png"
  },
  {
    "revision": "42c0fbd4915870e5e60452fd0ef2cbec",
    "url": "/img/orderTopBg@2x.42c0fbd4.png"
  },
  {
    "revision": "b899232b79ad9962c5ab5572775a0400",
    "url": "/img/card_index_bg@3x.b899232b.png"
  },
  {
    "revision": "b899232b79ad9962c5ab5572775a0400",
    "url": "/img/card_index_bg@2x.b899232b.png"
  },
  {
    "revision": "2c51a1e53c1ea0b35086d8d7261b4933",
    "url": "/img/bg_network@3x.2c51a1e5.png"
  },
  {
    "revision": "32d70c8fc305e3647098f3de0c71b618",
    "url": "/img/bg_network@2x.32d70c8f.png"
  },
  {
    "revision": "cc0636ca2944024fd3ebf33a5412ff35",
    "url": "/img/icon-right@3x.cc0636ca.png"
  },
  {
    "revision": "1b983020cfed6b7a8ca5c300c24ca186",
    "url": "/img/icon-left@3x.1b983020.png"
  },
  {
    "revision": "d796d97eb9ebb2e89bb966343e2362e9",
    "url": "/img/icon-left@2x.d796d97e.png"
  },
  {
    "revision": "ccb9865dadbc642b8c4dd0a1abc8e570",
    "url": "/img/recharge-word@2x.ccb9865d.png"
  },
  {
    "revision": "ccb9865dadbc642b8c4dd0a1abc8e570",
    "url": "/img/recharge-word@3x.ccb9865d.png"
  },
  {
    "revision": "41a8c268f703fe646d5d08099eb778ae",
    "url": "/img/icon-right@2x.41a8c268.png"
  },
  {
    "revision": "2d6d06f4da15fc1a748677c49c5f1854",
    "url": "/img/bg.2d6d06f4.png"
  },
  {
    "revision": "e93b8c03293c5b6a311da784f9c19c8f",
    "url": "/img/bg.e93b8c03.jpeg"
  },
  {
    "revision": "ffb1612d9660e2ecd9d3872d57a8a2f9",
    "url": "/img/bar.ffb1612d.png"
  },
  {
    "revision": "e625229e32d9deeb5f2909c314d8e609",
    "url": "/img/ios@2x.e625229e.png"
  },
  {
    "revision": "af8bbdfa0a90c4eed4563f8c06ce5ff8",
    "url": "/img/android@2x.af8bbdfa.png"
  },
  {
    "revision": "3d0fc424b703032ca595090e99f8354b",
    "url": "/img/login_bg@2x.3d0fc424.png"
  },
  {
    "revision": "11000d4e510a6df565eb69ba6f2c1dfc",
    "url": "/img/login_bg@3x.11000d4e.png"
  },
  {
    "revision": "1d7515ee61c3f659227318b4050955ed",
    "url": "/img/mobile_sim@2x.1d7515ee.png"
  },
  {
    "revision": "0f980b79d9a52702004de9f652a68835",
    "url": "/img/telcom_sim@2x.0f980b79.png"
  },
  {
    "revision": "98141226a7e992e3072a280746a259c4",
    "url": "/img/mobile_sim@3x.98141226.png"
  },
  {
    "revision": "0c88168b284b92c37f3a873f26a97d69",
    "url": "/img/bg.0c88168b.jpg"
  },
  {
    "revision": "9e02095f31a07b972244f1c714c1dfe7",
    "url": "/img/telcom_sim@3x.9e02095f.png"
  },
  {
    "revision": "3f342771b9b81ab929e0fbcbcd0e6533",
    "url": "/img/bg-check-wrap@3x.3f342771.png"
  },
  {
    "revision": "9713b21819c4019befecd095069977df",
    "url": "/img/bg-check-wrap@2x.9713b218.png"
  },
  {
    "revision": "fa855242805b87da42c65763acd64ac0",
    "url": "/img/bg-plan-type@2x.fa855242.png"
  },
  {
    "revision": "4a9ca192485effa8b8f4b5b2df5b9caf",
    "url": "/img/bg-plan-type@3x.4a9ca192.png"
  },
  {
    "revision": "af3ed0b3236bbfdbc3ad61b8d41c3dec",
    "url": "/img/changeBg.af3ed0b3.png"
  },
  {
    "revision": "0078f03c08066d51d64b92a13e194ebb",
    "url": "/img/balanceRefund.0078f03c.png"
  },
  {
    "revision": "0f16389ec218c90cf8f657e233b745f2",
    "url": "/img/balanceBg1.0f16389e.png"
  },
  {
    "revision": "565459ef2ee8b71db421144ad21c23e3",
    "url": "/img/balanceBg2.565459ef.png"
  },
  {
    "revision": "f40c7e0b20fe25eb78a7658c3ae56312",
    "url": "/img/noData@3x.f40c7e0b.png"
  },
  {
    "revision": "644e6e3cf5f33943747b116316694e28",
    "url": "/img/noData@2x.644e6e3c.png"
  },
  {
    "revision": "91e1d2771efacd45e5e465d9a001f197",
    "url": "/img/liantong.91e1d277.png"
  },
  {
    "revision": "4a0cab0f33beb48ea985714d1b91fef7",
    "url": "/img/dianxin.4a0cab0f.png"
  },
  {
    "revision": "657033323334e91efb0011bbc18f8c04",
    "url": "/img/yidong.65703332.png"
  },
  {
    "revision": "8da3b83b73e44e54d6be4b2522bcb1f2",
    "url": "/img/pkgBg2.8da3b83b.png"
  },
  {
    "revision": "d3b42651f9f5048baeffb50c800913ec",
    "url": "/img/pkgBg1.d3b42651.png"
  },
  {
    "revision": "d461d18e42a310bd709b2ce97d159153",
    "url": "/img/pkgBg3.d461d18e.png"
  },
  {
    "revision": "2a67b73145562669220aa4639e1ad58f",
    "url": "/img/icon3.2a67b731.png"
  },
  {
    "revision": "813b5319e378dafdda952c16ad89906b",
    "url": "/img/icon2.813b5319.png"
  },
  {
    "revision": "01355f175bd20423ce45a838c1a998a9",
    "url": "/img/bg.01355f17.png"
  },
  {
    "revision": "6dedd4943e4c5848638196fb6f0c4145",
    "url": "/img/bg.6dedd494.png"
  },
  {
    "revision": "6e5cee7393060b0ec3dcd587c2518b94",
    "url": "/img/bg_test.6e5cee73.png"
  },
  {
    "revision": "a859e9ca4606d567c42b9c7bcd4fdce9",
    "url": "/img/iccid_bg@2x.a859e9ca.png"
  },
  {
    "revision": "fa9050c4e9870e8fc0cd184f8515af4a",
    "url": "/img/iccid_bg@3x.fa9050c4.png"
  },
  {
    "revision": "d0ccbc8a35180bb40e027b44dd26035a",
    "url": "/img/youku.d0ccbc8a.png"
  },
  {
    "revision": "014d354b9b25b67ae95857ba17e2f4cc",
    "url": "/img/activityPage.014d354b.png"
  },
  {
    "revision": "6e5cee7393060b0ec3dcd587c2518b94",
    "url": "/img/bg_test@3x.6e5cee73.png"
  },
  {
    "revision": "114a6e12b42b9b48586dd341105188fe",
    "url": "/img/usedOrder@2x.114a6e12.png"
  },
  {
    "revision": "6e5cee7393060b0ec3dcd587c2518b94",
    "url": "/img/bg_test@2x.6e5cee73.png"
  },
  {
    "revision": "c0170ec299b2418256fd515ee7849055",
    "url": "/img/unUsedOrder@2x.c0170ec2.png"
  },
  {
    "revision": "d9e14058d30dd312519fcf2de38d742b",
    "url": "/img/unUsedOrder@3x.d9e14058.png"
  },
  {
    "revision": "4a5b90f8076955f289b3dcda6a5af6ff",
    "url": "/img/invaildedOrder@3x.4a5b90f8.png"
  },
  {
    "revision": "0d5a5158e67bcb7a4604124715ed6fbf",
    "url": "/img/usedOrder@3x.0d5a5158.png"
  },
  {
    "revision": "be0f1e33b2553e71b117d3d3f838d32f",
    "url": "/img/invaildedOrder@2x.be0f1e33.png"
  },
  {
    "revision": "3603a35a49dbb8ad94ec1e57c4dad229",
    "url": "/img/scanTop2.3603a35a.png"
  },
  {
    "revision": "05775dd69c53d7273b27aaa7c6c523f7",
    "url": "/img/04.05775dd6.png"
  },
  {
    "revision": "58a560568b7291ea926c2c7438035308",
    "url": "/img/subscribe@3x.58a56056.png"
  },
  {
    "revision": "541375e6bb7db2fba9e415be8045f5fb",
    "url": "/img/1.541375e6.png"
  },
  {
    "revision": "5a3428653945c17e1c146efeee81c987",
    "url": "/img/scanTop.5a342865.png"
  },
  {
    "revision": "0b9e0b5f4f28c68416f916ddce3fc7ef",
    "url": "/img/unicom-logo.0b9e0b5f.svg"
  },
  {
    "revision": "113f99e2189c2ca49db2168754fc2eb5",
    "url": "/img/mobile-logo.113f99e2.png"
  },
  {
    "revision": "0cba868fa977e09806638b9000636a36",
    "url": "/img/avatar.0cba868f.jpeg"
  },
  {
    "revision": "27158aa79eb0d4b89f317d076a801ca3",
    "url": "/img/coupon-log.27158aa7.png"
  },
  {
    "revision": "55d3f2f09efe17db6485d4c9f8f0c3b1",
    "url": "/img/icon-recharge_20181001.55d3f2f0.svg"
  },
  {
    "revision": "165beb68d8ba0d2b70df0fbb3769787a",
    "url": "/img/03.165beb68.png"
  },
  {
    "revision": "8c605ac88ca50357355da465f322d10a",
    "url": "/img/telecom-logo.8c605ac8.svg"
  },
  {
    "revision": "f7a51f1c554585b11d61499fd0a7520f",
    "url": "/img/only-box@3x.f7a51f1c.png"
  },
  {
    "revision": "89b99d16dd8a4a56746323a0ffbd754c",
    "url": "/img/migu.89b99d16.png"
  },
  {
    "revision": "0b3c3297decbd1152a314cce115f9632",
    "url": "/img/09.0b3c3297.png"
  },
  {
    "revision": "34c67f6dfdb0ecc17c7a221aec74706f",
    "url": "/img/bg_no_recharge.34c67f6d.svg"
  },
  {
    "revision": "b0ffa4a0fd195a110ee4d4dabce3bc32",
    "url": "/img/08.b0ffa4a0.png"
  },
  {
    "revision": "96fab583abd57f2e7118324858fa3080",
    "url": "/img/05.96fab583.png"
  },
  {
    "revision": "9e8ecc7f7b760b55c56bddfab886da10",
    "url": "/img/3.9e8ecc7f.png"
  },
  {
    "revision": "f23d9d1f76147bc89b48902c36818f1e",
    "url": "/img/bg_no_plan.f23d9d1f.svg"
  },
  {
    "revision": "a8272d2d742d9d50257e23dfac577def",
    "url": "/img/01.a8272d2d.png"
  },
  {
    "revision": "daa86b540bb9c2a6453ceac9bed77961",
    "url": "/img/07.daa86b54.png"
  },
  {
    "revision": "687b6ce03f134f21173c949d79002960",
    "url": "/img/tip.687b6ce0.png"
  },
  {
    "revision": "a610420eab741be28278e60bc06387aa",
    "url": "/img/box-deco@3x.a610420e.png"
  },
  {
    "revision": "eacba58f9acf2b87cd801858146b2ba9",
    "url": "/img/02.eacba58f.png"
  },
  {
    "revision": "39d9e849fc1c724525f166646932a24d",
    "url": "/img/safari.39d9e849.png"
  },
  {
    "revision": "999589aae784a460b5e7c6ae9bbaa3d8",
    "url": "/img/06.999589aa.png"
  },
  {
    "revision": "7c28431d304fa4f58f5070c59720683a",
    "url": "/img/2.7c28431d.png"
  },
  {
    "revision": "3e217df4202e41ad9b030aafc8cfcc24",
    "url": "/img/4.3e217df4.png"
  },
  {
    "revision": "e6f168195dbe2e90ec646987ec9597fd",
    "url": "/index.html"
  },
  {
    "revision": "00bbf6b458bf7ea6bd01f443eb3045d9",
    "url": "/MP_verify_4r3DVk3KUjgWsQsG.txt"
  },
  {
    "revision": "652317b098ca24e4511926c7fd57cbbe",
    "url": "/MP_verify_8JoCCldW78DygS5c.txt"
  },
  {
    "revision": "86c422d8c98b247235d04b49fb1c4b05",
    "url": "/MP_verify_bKSdn2qZlUSULliu.txt"
  },
  {
    "revision": "9ce16f441b39b493af8b96d7e97cce22",
    "url": "/MP_verify_dkzAKjxyVyJvsHMS.txt"
  },
  {
    "revision": "735ab4f94fbcd57074377afca324c813",
    "url": "/robots.txt"
  }
];