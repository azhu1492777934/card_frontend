self.__precacheManifest = [
  {
    "revision": "bf22d99e9ae3debb876b",
    "url": "/js/recharge_callback.d8237c4b.js"
  },
  {
    "revision": "b6216d61c03e6ce0c9aea6ca7808f7ca",
    "url": "/robots.txt"
  },
  {
    "revision": "dde103bffdd71d2acd48",
    "url": "/css/recharge_wrapper.ecb61e58.css"
  },
  {
    "revision": "be40bca99df105cbae95",
    "url": "/css/Layout~card_usage.cb0d2a22.css"
  },
  {
    "revision": "78214ba34c5f1df936aa",
    "url": "/js/Layout~card_usage~eqReplaceMent~esim_plan_list~esim_usage~mifi_order~mifi_plan_list~mifi_plan_usage~~c6f87c36.6241bd21.js"
  },
  {
    "revision": "33bc8d7c0421214121c0",
    "url": "/css/Not_fund.441b338e.css"
  },
  {
    "revision": "33bc8d7c0421214121c0",
    "url": "/js/Not_fund.a6629d31.js"
  },
  {
    "revision": "e3f67d5582a9ab174df2",
    "url": "/css/app.72184c26.css"
  },
  {
    "revision": "e3f67d5582a9ab174df2",
    "url": "/js/app.1bdbeb8f.js"
  },
  {
    "revision": "9f5767044d21c4e964bd",
    "url": "/css/authority_middle.4be2bf2b.css"
  },
  {
    "revision": "9f5767044d21c4e964bd",
    "url": "/js/authority_middle.aaa7f970.js"
  },
  {
    "revision": "c23074ee20cbb36bf17e",
    "url": "/css/balanceRefund.676b3239.css"
  },
  {
    "revision": "c23074ee20cbb36bf17e",
    "url": "/js/balanceRefund.72c9c9a9.js"
  },
  {
    "revision": "6484a8da371dab3e64af",
    "url": "/css/cardPackage.f190f1fa.css"
  },
  {
    "revision": "6484a8da371dab3e64af",
    "url": "/js/cardPackage.fa43ab7b.js"
  },
  {
    "revision": "939f72331f814ad4ccde",
    "url": "/css/card_check.821d897a.css"
  },
  {
    "revision": "939f72331f814ad4ccde",
    "url": "/js/card_check.6aedaa2b.js"
  },
  {
    "revision": "9ce864f080a0a5d24a8e",
    "url": "/css/card_connection.0c0041ec.css"
  },
  {
    "revision": "9ce864f080a0a5d24a8e",
    "url": "/js/card_connection.a2c34b27.js"
  },
  {
    "revision": "dd2e2689ed889ba5cba4",
    "url": "/css/card_lookup.b29ceb0f.css"
  },
  {
    "revision": "dd2e2689ed889ba5cba4",
    "url": "/js/card_lookup.fbae840e.js"
  },
  {
    "revision": "7808b45487cc0010b005",
    "url": "/css/card_usage.f4f44e8c.css"
  },
  {
    "revision": "7808b45487cc0010b005",
    "url": "/js/card_usage.89fa1d27.js"
  },
  {
    "revision": "59768519318b6230e09a",
    "url": "/css/card_wrapper.373da779.css"
  },
  {
    "revision": "59768519318b6230e09a",
    "url": "/js/card_wrapper.11810a6e.js"
  },
  {
    "revision": "9deff391ee683a15a75c",
    "url": "/css/children_card.c0bffb1e.css"
  },
  {
    "revision": "9deff391ee683a15a75c",
    "url": "/js/children_card.42f8e920.js"
  },
  {
    "revision": "1b2654434bccec43ff53",
    "url": "/css/chunk-369468f2.950f239c.css"
  },
  {
    "revision": "1b2654434bccec43ff53",
    "url": "/js/chunk-369468f2.8159dbfc.js"
  },
  {
    "revision": "36ad47a07c94f5d86454",
    "url": "/css/chunk-67169821.479f5e40.css"
  },
  {
    "revision": "36ad47a07c94f5d86454",
    "url": "/js/chunk-67169821.27319cc5.js"
  },
  {
    "revision": "cd79ca3a12173f7fb9ec",
    "url": "/css/chunk-vendors.3b71a034.css"
  },
  {
    "revision": "cd79ca3a12173f7fb9ec",
    "url": "/js/chunk-vendors.10650154.js"
  },
  {
    "revision": "070018232df4695874b4",
    "url": "/css/commonProblem.a6a75547.css"
  },
  {
    "revision": "070018232df4695874b4",
    "url": "/js/commonProblem.d96b79ae.js"
  },
  {
    "revision": "8c3fd93e64f3b95e29d1",
    "url": "/css/consumerRecord.08d5cc3b.css"
  },
  {
    "revision": "8c3fd93e64f3b95e29d1",
    "url": "/js/consumerRecord.99160958.js"
  },
  {
    "revision": "23352b7d285a7565d120",
    "url": "/css/coupon_normal.94c7ba55.css"
  },
  {
    "revision": "23352b7d285a7565d120",
    "url": "/js/coupon_normal.e40ac141.js"
  },
  {
    "revision": "1c3ce6b90affe1918295",
    "url": "/css/coupon_telcom.72ee0bc0.css"
  },
  {
    "revision": "1c3ce6b90affe1918295",
    "url": "/js/coupon_telcom.c3c3f0a6.js"
  },
  {
    "revision": "3d29be284addf9ff5036",
    "url": "/css/coupon_wrapper.31258838.css"
  },
  {
    "revision": "3d29be284addf9ff5036",
    "url": "/js/coupon_wrapper.c1c14448.js"
  },
  {
    "revision": "3d3df1335cd9dfa5a2a5",
    "url": "/css/currencyConversion.9b86fdcd.css"
  },
  {
    "revision": "3d3df1335cd9dfa5a2a5",
    "url": "/js/currencyConversion.d72753d1.js"
  },
  {
    "revision": "fe93e1cd5b81b3afff90",
    "url": "/css/eqReplaceMent.21e5a828.css"
  },
  {
    "revision": "fe93e1cd5b81b3afff90",
    "url": "/js/eqReplaceMent.0e28b0fa.js"
  },
  {
    "revision": "2a0b4568d54890cdb05d",
    "url": "/css/esim_plan_list.93e26022.css"
  },
  {
    "revision": "2a0b4568d54890cdb05d",
    "url": "/js/esim_plan_list.253da27c.js"
  },
  {
    "revision": "c7e2a9d5310b34a33537",
    "url": "/css/esim_usage.d9734e83.css"
  },
  {
    "revision": "c7e2a9d5310b34a33537",
    "url": "/js/esim_usage.8482e7f2.js"
  },
  {
    "revision": "ab3588d86a9b4d4af8b1",
    "url": "/css/find_plan.2ec0236a.css"
  },
  {
    "revision": "ab3588d86a9b4d4af8b1",
    "url": "/js/find_plan.0402f7e6.js"
  },
  {
    "revision": "67df646ae241abb92c51",
    "url": "/css/logical_page.b1840a87.css"
  },
  {
    "revision": "67df646ae241abb92c51",
    "url": "/js/logical_page.f213e689.js"
  },
  {
    "revision": "93a76913dcec3e218b5f",
    "url": "/css/login.b710a567.css"
  },
  {
    "revision": "93a76913dcec3e218b5f",
    "url": "/js/login.d8794e9d.js"
  },
  {
    "revision": "65e6dcf99baa425c4460",
    "url": "/css/lookup.a0fdfe26.css"
  },
  {
    "revision": "65e6dcf99baa425c4460",
    "url": "/js/lookup.b5026444.js"
  },
  {
    "revision": "3729845ce3a84b6acb1d",
    "url": "/css/mifi_binding.d51dd9ee.css"
  },
  {
    "revision": "3729845ce3a84b6acb1d",
    "url": "/js/mifi_binding.a599835e.js"
  },
  {
    "revision": "9586ce84e88fce556dbe",
    "url": "/css/mifi_card_info.331a32b0.css"
  },
  {
    "revision": "9586ce84e88fce556dbe",
    "url": "/js/mifi_card_info.d778eb0b.js"
  },
  {
    "revision": "b5350b65afdb2ed4a68c",
    "url": "/css/mifi_card_lookup.1216b9dd.css"
  },
  {
    "revision": "b5350b65afdb2ed4a68c",
    "url": "/js/mifi_card_lookup.363ed533.js"
  },
  {
    "revision": "ea0397017a8f773eef8a",
    "url": "/css/mifi_card_wrapper.9134afdd.css"
  },
  {
    "revision": "ea0397017a8f773eef8a",
    "url": "/js/mifi_card_wrapper.8d1acc0c.js"
  },
  {
    "revision": "ef3db805e76570168dd4",
    "url": "/css/mifi_change_network.35493f66.css"
  },
  {
    "revision": "ef3db805e76570168dd4",
    "url": "/js/mifi_change_network.d0581a78.js"
  },
  {
    "revision": "6bb2fd29e466a27f3756",
    "url": "/css/mifi_change_network_explanation.82431f87.css"
  },
  {
    "revision": "6bb2fd29e466a27f3756",
    "url": "/js/mifi_change_network_explanation.80560dc9.js"
  },
  {
    "revision": "f6a3076af748ae60741d",
    "url": "/css/mifi_coupon_index.64e0f7c2.css"
  },
  {
    "revision": "f6a3076af748ae60741d",
    "url": "/js/mifi_coupon_index.29bd576e.js"
  },
  {
    "revision": "ea994b4592c341a64f14",
    "url": "/css/mifi_coupon_wrapper.8b393e56.css"
  },
  {
    "revision": "ea994b4592c341a64f14",
    "url": "/js/mifi_coupon_wrapper.eca902c1.js"
  },
  {
    "revision": "e91e0d212ac6181047c9",
    "url": "/css/mifi_index.f1add01c.css"
  },
  {
    "revision": "e91e0d212ac6181047c9",
    "url": "/js/mifi_index.e52db31b.js"
  },
  {
    "revision": "96aedf723902e0f3438c",
    "url": "/css/mifi_layout.69f1d346.css"
  },
  {
    "revision": "96aedf723902e0f3438c",
    "url": "/js/mifi_layout.f91454ab.js"
  },
  {
    "revision": "9249c060477d4bd519f1",
    "url": "/css/mifi_order.73477860.css"
  },
  {
    "revision": "9249c060477d4bd519f1",
    "url": "/js/mifi_order.817737af.js"
  },
  {
    "revision": "9d35cfac4afd5c4afecf",
    "url": "/css/mifi_order_wrapper.d572d9dd.css"
  },
  {
    "revision": "9d35cfac4afd5c4afecf",
    "url": "/js/mifi_order_wrapper.9f3cb832.js"
  },
  {
    "revision": "0e3374b5b87d7be5ae97",
    "url": "/css/mifi_order~mifi_plan_group.649e1a31.css"
  },
  {
    "revision": "0e3374b5b87d7be5ae97",
    "url": "/js/mifi_order~mifi_plan_group.2b2aed2a.js"
  },
  {
    "revision": "be458a469f448f88b706",
    "url": "/css/mifi_plan_group.dd09ccc7.css"
  },
  {
    "revision": "be458a469f448f88b706",
    "url": "/js/mifi_plan_group.b4c894f6.js"
  },
  {
    "revision": "4a6348b077a62b6c063d",
    "url": "/css/mifi_plan_list.c16e50c4.css"
  },
  {
    "revision": "4a6348b077a62b6c063d",
    "url": "/js/mifi_plan_list.d371c749.js"
  },
  {
    "revision": "b7a1a6681eff2e16a665",
    "url": "/css/mifi_plan_usage.0d8003f8.css"
  },
  {
    "revision": "b7a1a6681eff2e16a665",
    "url": "/js/mifi_plan_usage.15c26dee.js"
  },
  {
    "revision": "2aceb9979f5c7596abba",
    "url": "/css/mifi_plan_wrapper.ad5b72f4.css"
  },
  {
    "revision": "2aceb9979f5c7596abba",
    "url": "/js/mifi_plan_wrapper.fd737b35.js"
  },
  {
    "revision": "139cf8d7765bde2f6eda",
    "url": "/css/new_card_wrapper.907108b0.css"
  },
  {
    "revision": "139cf8d7765bde2f6eda",
    "url": "/js/new_card_wrapper.58d4a208.js"
  },
  {
    "revision": "a383b2942bce3db81e2c",
    "url": "/css/orderRecord.24d697d1.css"
  },
  {
    "revision": "a383b2942bce3db81e2c",
    "url": "/js/orderRecord.62779add.js"
  },
  {
    "revision": "ede93f51ee48b516661c",
    "url": "/css/plan_list.e9caee5a.css"
  },
  {
    "revision": "ede93f51ee48b516661c",
    "url": "/js/plan_list.0067ac48.js"
  },
  {
    "revision": "6fd72ab518e356dba757",
    "url": "/css/question.6faada89.css"
  },
  {
    "revision": "6fd72ab518e356dba757",
    "url": "/js/question.1f41e8a8.js"
  },
  {
    "revision": "a06f700330835789736e",
    "url": "/css/question_wrapper.09148f29.css"
  },
  {
    "revision": "a06f700330835789736e",
    "url": "/js/question_wrapper.e8fa6249.js"
  },
  {
    "revision": "714331461528f3d2deeb",
    "url": "/css/realNameCourse.c4765d59.css"
  },
  {
    "revision": "714331461528f3d2deeb",
    "url": "/js/realNameCourse.d640f54e.js"
  },
  {
    "revision": "7b6021347234afb4eaef",
    "url": "/css/real_name.d1375355.css"
  },
  {
    "revision": "7b6021347234afb4eaef",
    "url": "/js/real_name.7734cc59.js"
  },
  {
    "revision": "25fa84843d1a3e7e2043",
    "url": "/css/recharge.bb20191e.css"
  },
  {
    "revision": "25fa84843d1a3e7e2043",
    "url": "/js/recharge.322b8280.js"
  },
  {
    "revision": "a5243598be8edb3b49c6",
    "url": "/css/rechargeOrder.9649b472.css"
  },
  {
    "revision": "a5243598be8edb3b49c6",
    "url": "/js/rechargeOrder.4553f2b2.js"
  },
  {
    "revision": "bf22d99e9ae3debb876b",
    "url": "/css/recharge_callback.4776b260.css"
  },
  {
    "revision": "685f36a61c6b9388424d",
    "url": "/js/Layout.7e2130a0.js"
  },
  {
    "revision": "be40bca99df105cbae95",
    "url": "/js/Layout~card_usage.bcf0ce41.js"
  },
  {
    "revision": "dde103bffdd71d2acd48",
    "url": "/js/recharge_wrapper.5368934d.js"
  },
  {
    "revision": "73b73fc2e6d8a160b70c",
    "url": "/css/refund_applying.a765fb53.css"
  },
  {
    "revision": "73b73fc2e6d8a160b70c",
    "url": "/js/refund_applying.c1a3a8ed.js"
  },
  {
    "revision": "119ed122586f0e856275",
    "url": "/css/refund_argument.69661661.css"
  },
  {
    "revision": "119ed122586f0e856275",
    "url": "/js/refund_argument.d2227949.js"
  },
  {
    "revision": "11c3ba0e43bbe983179f",
    "url": "/css/refund_plan.d6afc21e.css"
  },
  {
    "revision": "11c3ba0e43bbe983179f",
    "url": "/js/refund_plan.152599b5.js"
  },
  {
    "revision": "18f3a926060dcd5647ed",
    "url": "/css/refund_wrapper.2ce7ebad.css"
  },
  {
    "revision": "18f3a926060dcd5647ed",
    "url": "/js/refund_wrapper.4b26b5da.js"
  },
  {
    "revision": "32fbd9d4b4eb14691fe3",
    "url": "/css/repeatRecharge.72bad739.css"
  },
  {
    "revision": "32fbd9d4b4eb14691fe3",
    "url": "/js/repeatRecharge.7ec1c040.js"
  },
  {
    "revision": "6afdca472e42139a7ea1",
    "url": "/css/revoke_plan.0c04faff.css"
  },
  {
    "revision": "6afdca472e42139a7ea1",
    "url": "/js/revoke_plan.2c96f472.js"
  },
  {
    "revision": "1a7e37aceb6ed4c3e0a1",
    "url": "/css/speedup_500.863f4cd3.css"
  },
  {
    "revision": "1a7e37aceb6ed4c3e0a1",
    "url": "/js/speedup_500.b0e790bf.js"
  },
  {
    "revision": "87e161daca308832a01d",
    "url": "/css/speedup_80.d0292630.css"
  },
  {
    "revision": "87e161daca308832a01d",
    "url": "/js/speedup_80.12b367fb.js"
  },
  {
    "revision": "e8e646590c22cdecfe1f",
    "url": "/css/speedup_wrapper.69b3dda0.css"
  },
  {
    "revision": "e8e646590c22cdecfe1f",
    "url": "/js/speedup_wrapper.27f3dbaf.js"
  },
  {
    "revision": "fe766970aea5c772c011",
    "url": "/css/to_tb.96081c85.css"
  },
  {
    "revision": "fe766970aea5c772c011",
    "url": "/js/to_tb.2f6b2df6.js"
  },
  {
    "revision": "dd7729d0479a4ba01f7f",
    "url": "/css/transfer_url.302c6a25.css"
  },
  {
    "revision": "dd7729d0479a4ba01f7f",
    "url": "/js/transfer_url.16558afa.js"
  },
  {
    "revision": "6d6a245df8993a99a949",
    "url": "/css/userCenter.66615e59.css"
  },
  {
    "revision": "6d6a245df8993a99a949",
    "url": "/js/userCenter.3cff205d.js"
  },
  {
    "revision": "2d274296b35bcd3e9a2a",
    "url": "/css/userCenterWrap.b8d99837.css"
  },
  {
    "revision": "2d274296b35bcd3e9a2a",
    "url": "/js/userCenterWrap.3c78ef04.js"
  },
  {
    "revision": "e4b411644706c29765eea3ffdd85ae39",
    "url": "/fonts/SourceHanSansCNRegular.e4b41164.woff"
  },
  {
    "revision": "834b022ab9ab0e6063904af32274e777",
    "url": "/fonts/SourceHanSansCNRegular.834b022a.eot"
  },
  {
    "revision": "f9509c5a10be7daaf1fa01922a7c6bc2",
    "url": "/fonts/SourceHanSansCNRegular.f9509c5a.ttf"
  },
  {
    "revision": "da0808e9fe85be160aab69c82dd8de1c",
    "url": "/img/SourceHanSansCNRegular.da0808e9.svg"
  },
  {
    "revision": "732389ded34cb9c52dd88271f1345af9",
    "url": "/fonts/element-icons.732389de.ttf"
  },
  {
    "revision": "535877f50039c0cb49a6196a5b7517cd",
    "url": "/fonts/element-icons.535877f5.woff"
  },
  {
    "revision": "91e1d2771efacd45e5e465d9a001f197",
    "url": "/img/liantong.91e1d277.png"
  },
  {
    "revision": "4a0cab0f33beb48ea985714d1b91fef7",
    "url": "/img/dianxin.4a0cab0f.png"
  },
  {
    "revision": "657033323334e91efb0011bbc18f8c04",
    "url": "/img/yidong.65703332.png"
  },
  {
    "revision": "8da3b83b73e44e54d6be4b2522bcb1f2",
    "url": "/img/pkgBg2.8da3b83b.png"
  },
  {
    "revision": "d3b42651f9f5048baeffb50c800913ec",
    "url": "/img/pkgBg1.d3b42651.png"
  },
  {
    "revision": "d461d18e42a310bd709b2ce97d159153",
    "url": "/img/pkgBg3.d461d18e.png"
  },
  {
    "revision": "0078f03c08066d51d64b92a13e194ebb",
    "url": "/img/balanceRefund.0078f03c.png"
  },
  {
    "revision": "af3ed0b3236bbfdbc3ad61b8d41c3dec",
    "url": "/img/changeBg.af3ed0b3.png"
  },
  {
    "revision": "6e5cee7393060b0ec3dcd587c2518b94",
    "url": "/img/bg_test.6e5cee73.png"
  },
  {
    "revision": "fff5af4325410621aeec4e60b3b92d9b",
    "url": "/img/mifi_binding_bg@3x.fff5af43.png"
  },
  {
    "revision": "fff5af4325410621aeec4e60b3b92d9b",
    "url": "/img/mifi_binding_bg@2x.fff5af43.png"
  },
  {
    "revision": "42c0fbd4915870e5e60452fd0ef2cbec",
    "url": "/img/orderTopBg@3x.42c0fbd4.png"
  },
  {
    "revision": "42c0fbd4915870e5e60452fd0ef2cbec",
    "url": "/img/orderTopBg@2x.42c0fbd4.png"
  },
  {
    "revision": "e625229e32d9deeb5f2909c314d8e609",
    "url": "/img/ios@2x.e625229e.png"
  },
  {
    "revision": "af8bbdfa0a90c4eed4563f8c06ce5ff8",
    "url": "/img/android@2x.af8bbdfa.png"
  },
  {
    "revision": "f5f322478286641bd9887a155e35f222",
    "url": "/img/btn.f5f32247.png"
  },
  {
    "revision": "d140650fa64e0f1fc771610dba62aed7",
    "url": "/img/bg.d140650f.png"
  },
  {
    "revision": "2c51a1e53c1ea0b35086d8d7261b4933",
    "url": "/img/bg_network@3x.2c51a1e5.png"
  },
  {
    "revision": "32d70c8fc305e3647098f3de0c71b618",
    "url": "/img/bg_network@2x.32d70c8f.png"
  },
  {
    "revision": "b899232b79ad9962c5ab5572775a0400",
    "url": "/img/card_index_bg@3x.b899232b.png"
  },
  {
    "revision": "b899232b79ad9962c5ab5572775a0400",
    "url": "/img/card_index_bg@2x.b899232b.png"
  },
  {
    "revision": "1d7515ee61c3f659227318b4050955ed",
    "url": "/img/mobile_sim@2x.1d7515ee.png"
  },
  {
    "revision": "0f980b79d9a52702004de9f652a68835",
    "url": "/img/telcom_sim@2x.0f980b79.png"
  },
  {
    "revision": "98141226a7e992e3072a280746a259c4",
    "url": "/img/mobile_sim@3x.98141226.png"
  },
  {
    "revision": "0c88168b284b92c37f3a873f26a97d69",
    "url": "/img/bg.0c88168b.jpg"
  },
  {
    "revision": "9e02095f31a07b972244f1c714c1dfe7",
    "url": "/img/telcom_sim@3x.9e02095f.png"
  },
  {
    "revision": "3f342771b9b81ab929e0fbcbcd0e6533",
    "url": "/img/bg-check-wrap@3x.3f342771.png"
  },
  {
    "revision": "9713b21819c4019befecd095069977df",
    "url": "/img/bg-check-wrap@2x.9713b218.png"
  },
  {
    "revision": "b70eddccd257b21777e71bb64c83b876",
    "url": "/img/bg.b70eddcc.jpeg"
  },
  {
    "revision": "909816c3d34e63a9ad86b8c179ab543c",
    "url": "/img/bar.909816c3.png"
  },
  {
    "revision": "e92f547ba0209da3b4342fa2b56ea9ae",
    "url": "/img/animater.e92f547b.png"
  },
  {
    "revision": "3d0fc424b703032ca595090e99f8354b",
    "url": "/img/login_bg@2x.3d0fc424.png"
  },
  {
    "revision": "11000d4e510a6df565eb69ba6f2c1dfc",
    "url": "/img/login_bg@3x.11000d4e.png"
  },
  {
    "revision": "014d354b9b25b67ae95857ba17e2f4cc",
    "url": "/img/activityPage.014d354b.png"
  },
  {
    "revision": "2a67b73145562669220aa4639e1ad58f",
    "url": "/img/icon3.2a67b731.png"
  },
  {
    "revision": "813b5319e378dafdda952c16ad89906b",
    "url": "/img/icon2.813b5319.png"
  },
  {
    "revision": "6dedd4943e4c5848638196fb6f0c4145",
    "url": "/img/bg.6dedd494.png"
  },
  {
    "revision": "01355f175bd20423ce45a838c1a998a9",
    "url": "/img/bg.01355f17.png"
  },
  {
    "revision": "a859e9ca4606d567c42b9c7bcd4fdce9",
    "url": "/img/iccid_bg@2x.a859e9ca.png"
  },
  {
    "revision": "fa9050c4e9870e8fc0cd184f8515af4a",
    "url": "/img/iccid_bg@3x.fa9050c4.png"
  },
  {
    "revision": "114a6e12b42b9b48586dd341105188fe",
    "url": "/img/usedOrder@2x.114a6e12.png"
  },
  {
    "revision": "c0170ec299b2418256fd515ee7849055",
    "url": "/img/unUsedOrder@2x.c0170ec2.png"
  },
  {
    "revision": "d9e14058d30dd312519fcf2de38d742b",
    "url": "/img/unUsedOrder@3x.d9e14058.png"
  },
  {
    "revision": "4a5b90f8076955f289b3dcda6a5af6ff",
    "url": "/img/invaildedOrder@3x.4a5b90f8.png"
  },
  {
    "revision": "0d5a5158e67bcb7a4604124715ed6fbf",
    "url": "/img/usedOrder@3x.0d5a5158.png"
  },
  {
    "revision": "be0f1e33b2553e71b117d3d3f838d32f",
    "url": "/img/invaildedOrder@2x.be0f1e33.png"
  },
  {
    "revision": "3603a35a49dbb8ad94ec1e57c4dad229",
    "url": "/img/scanTop2.3603a35a.png"
  },
  {
    "revision": "05775dd69c53d7273b27aaa7c6c523f7",
    "url": "/img/04.05775dd6.png"
  },
  {
    "revision": "541375e6bb7db2fba9e415be8045f5fb",
    "url": "/img/1.541375e6.png"
  },
  {
    "revision": "7c28431d304fa4f58f5070c59720683a",
    "url": "/img/2.7c28431d.png"
  },
  {
    "revision": "5a3428653945c17e1c146efeee81c987",
    "url": "/img/scanTop.5a342865.png"
  },
  {
    "revision": "824594523c01e48028f2b7eb4261134d",
    "url": "/img/unicom-logo.82459452.svg"
  },
  {
    "revision": "113f99e2189c2ca49db2168754fc2eb5",
    "url": "/img/mobile-logo.113f99e2.png"
  },
  {
    "revision": "0cba868fa977e09806638b9000636a36",
    "url": "/img/avatar.0cba868f.jpeg"
  },
  {
    "revision": "27158aa79eb0d4b89f317d076a801ca3",
    "url": "/img/coupon-log.27158aa7.png"
  },
  {
    "revision": "55d3f2f09efe17db6485d4c9f8f0c3b1",
    "url": "/img/icon-recharge_20181001.55d3f2f0.svg"
  },
  {
    "revision": "165beb68d8ba0d2b70df0fbb3769787a",
    "url": "/img/03.165beb68.png"
  },
  {
    "revision": "5f1f34037094c0613bccafa2ddd8cb3b",
    "url": "/img/telecom-logo.5f1f3403.svg"
  },
  {
    "revision": "0b3c3297decbd1152a314cce115f9632",
    "url": "/img/09.0b3c3297.png"
  },
  {
    "revision": "644e6e3cf5f33943747b116316694e28",
    "url": "/img/noData@2x.644e6e3c.png"
  },
  {
    "revision": "3e217df4202e41ad9b030aafc8cfcc24",
    "url": "/img/4.3e217df4.png"
  },
  {
    "revision": "aecc9531f2c3b1fd45338e7bf5084384",
    "url": "/img/bg_no_recharge.aecc9531.svg"
  },
  {
    "revision": "b0ffa4a0fd195a110ee4d4dabce3bc32",
    "url": "/img/08.b0ffa4a0.png"
  },
  {
    "revision": "96fab583abd57f2e7118324858fa3080",
    "url": "/img/05.96fab583.png"
  },
  {
    "revision": "9e8ecc7f7b760b55c56bddfab886da10",
    "url": "/img/3.9e8ecc7f.png"
  },
  {
    "revision": "275be51ae57c486bce58257febd6589f",
    "url": "/img/bg_no_plan.275be51a.svg"
  },
  {
    "revision": "a8272d2d742d9d50257e23dfac577def",
    "url": "/img/01.a8272d2d.png"
  },
  {
    "revision": "daa86b540bb9c2a6453ceac9bed77961",
    "url": "/img/07.daa86b54.png"
  },
  {
    "revision": "06385746a7cedb492d5539907631561c",
    "url": "/img/tip.06385746.png"
  },
  {
    "revision": "eacba58f9acf2b87cd801858146b2ba9",
    "url": "/img/02.eacba58f.png"
  },
  {
    "revision": "39d9e849fc1c724525f166646932a24d",
    "url": "/img/safari.39d9e849.png"
  },
  {
    "revision": "999589aae784a460b5e7c6ae9bbaa3d8",
    "url": "/img/06.999589aa.png"
  },
  {
    "revision": "4d71ad88ae11260ee5d58609b82d2759",
    "url": "/index.html"
  },
  {
    "revision": "685f36a61c6b9388424d",
    "url": "/css/Layout.83a36cb0.css"
  },
  {
    "revision": "9ce16f441b39b493af8b96d7e97cce22",
    "url": "/MP_verify_dkzAKjxyVyJvsHMS.txt"
  },
  {
    "revision": "86c422d8c98b247235d04b49fb1c4b05",
    "url": "/MP_verify_bKSdn2qZlUSULliu.txt"
  },
  {
    "revision": "652317b098ca24e4511926c7fd57cbbe",
    "url": "/MP_verify_8JoCCldW78DygS5c.txt"
  },
  {
    "revision": "00bbf6b458bf7ea6bd01f443eb3045d9",
    "url": "/MP_verify_4r3DVk3KUjgWsQsG.txt"
  }
];