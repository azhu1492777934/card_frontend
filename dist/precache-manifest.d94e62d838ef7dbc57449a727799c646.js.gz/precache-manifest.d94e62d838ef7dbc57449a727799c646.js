self.__precacheManifest = [
  {
    "revision": "24165700d1dd5b4bf0bc",
    "url": "/css/refund_applying.7e481c02.css"
  },
  {
    "revision": "b6216d61c03e6ce0c9aea6ca7808f7ca",
    "url": "/robots.txt"
  },
  {
    "revision": "24165700d1dd5b4bf0bc",
    "url": "/js/refund_applying.e9877916.js"
  },
  {
    "revision": "486c88a173afee991629",
    "url": "/css/Layout~card_usage.c5af5c36.css"
  },
  {
    "revision": "f6fe50ccd582c459975e",
    "url": "/js/Layout~card_usage~eqReplaceMent~esim_plan_list~esim_usage~mifi_order~mifi_plan_list~mifi_plan_usage~~3166b5eb.91e2eec6.js"
  },
  {
    "revision": "469ba3f1f3cab05fab8c",
    "url": "/css/Not_fund.5c52a0eb.css"
  },
  {
    "revision": "469ba3f1f3cab05fab8c",
    "url": "/js/Not_fund.0c5ed069.js"
  },
  {
    "revision": "cc8d362882a885752c15",
    "url": "/css/app.2608000f.css"
  },
  {
    "revision": "cc8d362882a885752c15",
    "url": "/js/app.fb9c2ce4.js"
  },
  {
    "revision": "3c9b37d23474580a4fa3",
    "url": "/css/auditFail.7dccd925.css"
  },
  {
    "revision": "3c9b37d23474580a4fa3",
    "url": "/js/auditFail.38835236.js"
  },
  {
    "revision": "fdd0f18aa900f29e3506",
    "url": "/css/auditSuccess.1893dd8f.css"
  },
  {
    "revision": "fdd0f18aa900f29e3506",
    "url": "/js/auditSuccess.0069d166.js"
  },
  {
    "revision": "7d59db403f80f870d5fe",
    "url": "/css/authority_middle.5c8a31a6.css"
  },
  {
    "revision": "7d59db403f80f870d5fe",
    "url": "/js/authority_middle.ffb3fdeb.js"
  },
  {
    "revision": "dcd3b60d9fe7c22085a9",
    "url": "/css/balanceIndex.979a25f6.css"
  },
  {
    "revision": "dcd3b60d9fe7c22085a9",
    "url": "/js/balanceIndex.2c7a47a7.js"
  },
  {
    "revision": "8e827908fb4e8e9c5aa8",
    "url": "/css/balanceRefund.ee7b6283.css"
  },
  {
    "revision": "8e827908fb4e8e9c5aa8",
    "url": "/js/balanceRefund.7c29cb8c.js"
  },
  {
    "revision": "f9d79aa6ed627da64401",
    "url": "/css/cardPackage.b76aaa01.css"
  },
  {
    "revision": "f9d79aa6ed627da64401",
    "url": "/js/cardPackage.576fdc28.js"
  },
  {
    "revision": "42ad546ddecf3a1ed87e",
    "url": "/css/card_check.31896919.css"
  },
  {
    "revision": "42ad546ddecf3a1ed87e",
    "url": "/js/card_check.d954dad3.js"
  },
  {
    "revision": "7d31f6ded25b84869544",
    "url": "/css/card_connection.470ee167.css"
  },
  {
    "revision": "7d31f6ded25b84869544",
    "url": "/js/card_connection.4d510b32.js"
  },
  {
    "revision": "c670da0aca93392978b4",
    "url": "/css/card_lookup.ad8e6d4d.css"
  },
  {
    "revision": "c670da0aca93392978b4",
    "url": "/js/card_lookup.150f283e.js"
  },
  {
    "revision": "2bfb736a46269305c8ce",
    "url": "/css/card_more_flow.a0b7c11f.css"
  },
  {
    "revision": "2bfb736a46269305c8ce",
    "url": "/js/card_more_flow.690f1baa.js"
  },
  {
    "revision": "44a6366fa8ff0763e4ef",
    "url": "/css/card_usage.dea230c8.css"
  },
  {
    "revision": "44a6366fa8ff0763e4ef",
    "url": "/js/card_usage.5aa1f8ad.js"
  },
  {
    "revision": "d1361d5a23bce71ffd66",
    "url": "/css/card_wrapper.3cc70882.css"
  },
  {
    "revision": "d1361d5a23bce71ffd66",
    "url": "/js/card_wrapper.3e026140.js"
  },
  {
    "revision": "7eff4e146822433995be",
    "url": "/css/children_card.97b5125d.css"
  },
  {
    "revision": "7eff4e146822433995be",
    "url": "/js/children_card.5e1ccf74.js"
  },
  {
    "revision": "27fddd223b7edb678fdc",
    "url": "/css/chunk-367f8b92.eb4dbc32.css"
  },
  {
    "revision": "27fddd223b7edb678fdc",
    "url": "/js/chunk-367f8b92.3dd60511.js"
  },
  {
    "revision": "8e08d51a9901a9cdcc99",
    "url": "/css/chunk-43e55775.c493359e.css"
  },
  {
    "revision": "8e08d51a9901a9cdcc99",
    "url": "/js/chunk-43e55775.54f11b00.js"
  },
  {
    "revision": "26be51635e617fc961df",
    "url": "/css/chunk-vendors.187f45a9.css"
  },
  {
    "revision": "26be51635e617fc961df",
    "url": "/js/chunk-vendors.508c8cbc.js"
  },
  {
    "revision": "dbcdb7e0a509ed7642ba",
    "url": "/css/commonProblem.52e28e63.css"
  },
  {
    "revision": "dbcdb7e0a509ed7642ba",
    "url": "/js/commonProblem.37f6a0e1.js"
  },
  {
    "revision": "116bbee33fe3b5ebb03c",
    "url": "/css/consumerRecord.73b81578.css"
  },
  {
    "revision": "116bbee33fe3b5ebb03c",
    "url": "/js/consumerRecord.3777106e.js"
  },
  {
    "revision": "768f6d750bf92e268fc5",
    "url": "/css/coupon_normal.758858d4.css"
  },
  {
    "revision": "768f6d750bf92e268fc5",
    "url": "/js/coupon_normal.0c82ce3b.js"
  },
  {
    "revision": "47f8a3beaa569a39a174",
    "url": "/css/coupon_telcom.1a9a5f5b.css"
  },
  {
    "revision": "47f8a3beaa569a39a174",
    "url": "/js/coupon_telcom.7c3fccdd.js"
  },
  {
    "revision": "849028204c921e6f7dad",
    "url": "/css/coupon_wrapper.7421536f.css"
  },
  {
    "revision": "849028204c921e6f7dad",
    "url": "/js/coupon_wrapper.367387ad.js"
  },
  {
    "revision": "0cf9ba1041666a76a724",
    "url": "/css/currencyConversion.cfbe8dc2.css"
  },
  {
    "revision": "0cf9ba1041666a76a724",
    "url": "/js/currencyConversion.27de6f51.js"
  },
  {
    "revision": "199d20e0e56571171252",
    "url": "/css/eqReplaceMent.b6abffa2.css"
  },
  {
    "revision": "199d20e0e56571171252",
    "url": "/js/eqReplaceMent.43c50092.js"
  },
  {
    "revision": "fdc2bb17199c80df4232",
    "url": "/css/esim_plan_list.5c0100bc.css"
  },
  {
    "revision": "fdc2bb17199c80df4232",
    "url": "/js/esim_plan_list.04d2977e.js"
  },
  {
    "revision": "b8db6529e0ff2e4be87a",
    "url": "/css/esim_usage.c24fc424.css"
  },
  {
    "revision": "b8db6529e0ff2e4be87a",
    "url": "/js/esim_usage.5ce34443.js"
  },
  {
    "revision": "1c821badf1504e28c15b",
    "url": "/css/find_plan.eda17098.css"
  },
  {
    "revision": "1c821badf1504e28c15b",
    "url": "/js/find_plan.0da26570.js"
  },
  {
    "revision": "e85c2cc6a66d16d9c930",
    "url": "/css/logical_page.2c75593d.css"
  },
  {
    "revision": "e85c2cc6a66d16d9c930",
    "url": "/js/logical_page.aaca0f2e.js"
  },
  {
    "revision": "9af44f8dbedf696d523a",
    "url": "/css/login.db6eac3f.css"
  },
  {
    "revision": "9af44f8dbedf696d523a",
    "url": "/js/login.214a37a2.js"
  },
  {
    "revision": "6eb35db5c8070bad4b54",
    "url": "/css/lookup.a84a91e8.css"
  },
  {
    "revision": "6eb35db5c8070bad4b54",
    "url": "/js/lookup.c564a84e.js"
  },
  {
    "revision": "ec499ae51119dc612d03",
    "url": "/css/mifi_binding.41bda0b2.css"
  },
  {
    "revision": "ec499ae51119dc612d03",
    "url": "/js/mifi_binding.967dbdd0.js"
  },
  {
    "revision": "1bdcee658b95eba2ca20",
    "url": "/css/mifi_card_info.060f13e1.css"
  },
  {
    "revision": "1bdcee658b95eba2ca20",
    "url": "/js/mifi_card_info.afe90a6f.js"
  },
  {
    "revision": "db3a1ce3cba9aec687e0",
    "url": "/css/mifi_card_lookup.2b7c9d69.css"
  },
  {
    "revision": "db3a1ce3cba9aec687e0",
    "url": "/js/mifi_card_lookup.32e0e9dc.js"
  },
  {
    "revision": "170c9d70faf50533a612",
    "url": "/css/mifi_card_wrapper.eeb3aab7.css"
  },
  {
    "revision": "170c9d70faf50533a612",
    "url": "/js/mifi_card_wrapper.7a93668a.js"
  },
  {
    "revision": "bc6cb7f3980cc29e0e00",
    "url": "/css/mifi_change_network.ba5d1b06.css"
  },
  {
    "revision": "bc6cb7f3980cc29e0e00",
    "url": "/js/mifi_change_network.44d1cc9a.js"
  },
  {
    "revision": "45666ae0b5f5a9216043",
    "url": "/css/mifi_change_network_explanation.f69e1110.css"
  },
  {
    "revision": "45666ae0b5f5a9216043",
    "url": "/js/mifi_change_network_explanation.27b1ca43.js"
  },
  {
    "revision": "4477357b0ec65da8c711",
    "url": "/css/mifi_coupon_index.9da999d7.css"
  },
  {
    "revision": "4477357b0ec65da8c711",
    "url": "/js/mifi_coupon_index.c0e83ccc.js"
  },
  {
    "revision": "b171d3c5782c4cf2f919",
    "url": "/css/mifi_coupon_wrapper.2bfbaf9a.css"
  },
  {
    "revision": "b171d3c5782c4cf2f919",
    "url": "/js/mifi_coupon_wrapper.6576b10a.js"
  },
  {
    "revision": "735171e1a4cd097db3e1",
    "url": "/css/mifi_index.ad559168.css"
  },
  {
    "revision": "735171e1a4cd097db3e1",
    "url": "/js/mifi_index.17ef2951.js"
  },
  {
    "revision": "d5a9dda1b6a051bb6557",
    "url": "/css/mifi_layout.f1be9149.css"
  },
  {
    "revision": "d5a9dda1b6a051bb6557",
    "url": "/js/mifi_layout.5623ec3c.js"
  },
  {
    "revision": "0e99d3c5b8f12c068d68",
    "url": "/css/mifi_order.9eeb724c.css"
  },
  {
    "revision": "0e99d3c5b8f12c068d68",
    "url": "/js/mifi_order.a6c62b54.js"
  },
  {
    "revision": "69758578002c114500c9",
    "url": "/css/mifi_order_wrapper.56a3339d.css"
  },
  {
    "revision": "69758578002c114500c9",
    "url": "/js/mifi_order_wrapper.9b6be3de.js"
  },
  {
    "revision": "47dd43015500be3f9ac4",
    "url": "/css/mifi_order~mifi_plan_group.9b72222a.css"
  },
  {
    "revision": "47dd43015500be3f9ac4",
    "url": "/js/mifi_order~mifi_plan_group.8b8989db.js"
  },
  {
    "revision": "85307067d405a9e76863",
    "url": "/css/mifi_plan_group.687eef20.css"
  },
  {
    "revision": "85307067d405a9e76863",
    "url": "/js/mifi_plan_group.3b3b888b.js"
  },
  {
    "revision": "2b1522ce138321f50009",
    "url": "/css/mifi_plan_list.05f612fc.css"
  },
  {
    "revision": "2b1522ce138321f50009",
    "url": "/js/mifi_plan_list.38a2d841.js"
  },
  {
    "revision": "266614abb4f270930162",
    "url": "/css/mifi_plan_usage.744521e6.css"
  },
  {
    "revision": "266614abb4f270930162",
    "url": "/js/mifi_plan_usage.0194ac1f.js"
  },
  {
    "revision": "c667e184a88fc64dafb3",
    "url": "/css/mifi_plan_wrapper.80fa7896.css"
  },
  {
    "revision": "c667e184a88fc64dafb3",
    "url": "/js/mifi_plan_wrapper.7fc8c82a.js"
  },
  {
    "revision": "2904cc856e9d9c7f0ad0",
    "url": "/css/new_card_wrapper.06a280b2.css"
  },
  {
    "revision": "2904cc856e9d9c7f0ad0",
    "url": "/js/new_card_wrapper.d31483c4.js"
  },
  {
    "revision": "435167355a0e85f871ac",
    "url": "/css/orderRecord.92fc656c.css"
  },
  {
    "revision": "435167355a0e85f871ac",
    "url": "/js/orderRecord.407c0bf6.js"
  },
  {
    "revision": "4a3f443aec1eb4888d42",
    "url": "/css/plan_list.a57b40ab.css"
  },
  {
    "revision": "4a3f443aec1eb4888d42",
    "url": "/js/plan_list.41ca39a1.js"
  },
  {
    "revision": "4ce6fae9d4942a13deed",
    "url": "/css/question.fe93a574.css"
  },
  {
    "revision": "4ce6fae9d4942a13deed",
    "url": "/js/question.86e92cba.js"
  },
  {
    "revision": "60800012c7c2271123a0",
    "url": "/css/question_wrapper.12696ad3.css"
  },
  {
    "revision": "60800012c7c2271123a0",
    "url": "/js/question_wrapper.b423f2e3.js"
  },
  {
    "revision": "9778fe34faacf803dc8f",
    "url": "/css/realNameCourse.17a25c8d.css"
  },
  {
    "revision": "9778fe34faacf803dc8f",
    "url": "/js/realNameCourse.b961c9d8.js"
  },
  {
    "revision": "6372c05e014e68df0aee",
    "url": "/css/realNameWrapper.d95486e0.css"
  },
  {
    "revision": "6372c05e014e68df0aee",
    "url": "/js/realNameWrapper.5fd829c0.js"
  },
  {
    "revision": "6d05c894841f2e60af48",
    "url": "/css/real_name.2fd595b9.css"
  },
  {
    "revision": "6d05c894841f2e60af48",
    "url": "/js/real_name.d7b46665.js"
  },
  {
    "revision": "a53a9f1b6e5cd3cacfa6",
    "url": "/css/recharge.bf614122.css"
  },
  {
    "revision": "a53a9f1b6e5cd3cacfa6",
    "url": "/js/recharge.c94958d2.js"
  },
  {
    "revision": "c97dcce40d554622a892",
    "url": "/css/rechargeOrder.2a136c19.css"
  },
  {
    "revision": "c97dcce40d554622a892",
    "url": "/js/rechargeOrder.a8d9a6cb.js"
  },
  {
    "revision": "7af2e120c82294519ce2",
    "url": "/css/recharge_callback.1a6cf6aa.css"
  },
  {
    "revision": "7af2e120c82294519ce2",
    "url": "/js/recharge_callback.afc5918d.js"
  },
  {
    "revision": "90e9338c3deb5fd373b6",
    "url": "/css/recharge_wrapper.e8ef40fd.css"
  },
  {
    "revision": "90e9338c3deb5fd373b6",
    "url": "/js/recharge_wrapper.83f14224.js"
  },
  {
    "revision": "7452927d983668107370",
    "url": "/css/refundRules.4bbcf20a.css"
  },
  {
    "revision": "7452927d983668107370",
    "url": "/js/refundRules.d836cc88.js"
  },
  {
    "revision": "d36efe199fa2a3e2c4a6",
    "url": "/js/Layout.cf6be05c.js"
  },
  {
    "revision": "486c88a173afee991629",
    "url": "/js/Layout~card_usage.399408d8.js"
  },
  {
    "revision": "a29cb7fac658093c9997",
    "url": "/css/refund_argument.ea8a95cb.css"
  },
  {
    "revision": "a29cb7fac658093c9997",
    "url": "/js/refund_argument.bfde021f.js"
  },
  {
    "revision": "e1da7822c22480237d85",
    "url": "/css/refund_plan.747c719b.css"
  },
  {
    "revision": "e1da7822c22480237d85",
    "url": "/js/refund_plan.b9643500.js"
  },
  {
    "revision": "4a9aa49f4d70a5bbe990",
    "url": "/css/refund_wrapper.9829766a.css"
  },
  {
    "revision": "4a9aa49f4d70a5bbe990",
    "url": "/js/refund_wrapper.94315a82.js"
  },
  {
    "revision": "d8a3d7a1a19915c8d6a2",
    "url": "/css/repeatRecharge.78555919.css"
  },
  {
    "revision": "d8a3d7a1a19915c8d6a2",
    "url": "/js/repeatRecharge.5d0d0cc1.js"
  },
  {
    "revision": "1c6d0942430622d41c56",
    "url": "/css/revoke_plan.8469d7da.css"
  },
  {
    "revision": "1c6d0942430622d41c56",
    "url": "/js/revoke_plan.5d2bdb38.js"
  },
  {
    "revision": "cf51c74958b866727c96",
    "url": "/css/speedup_500.0b0c3ab6.css"
  },
  {
    "revision": "cf51c74958b866727c96",
    "url": "/js/speedup_500.c8275bed.js"
  },
  {
    "revision": "47f050008c4dd8efdb29",
    "url": "/css/speedup_80.f9c8f705.css"
  },
  {
    "revision": "47f050008c4dd8efdb29",
    "url": "/js/speedup_80.f72b3fb1.js"
  },
  {
    "revision": "3e32ad13b7875319cf2f",
    "url": "/css/speedup_wrapper.31258838.css"
  },
  {
    "revision": "3e32ad13b7875319cf2f",
    "url": "/js/speedup_wrapper.c1f09ef8.js"
  },
  {
    "revision": "97fa8c2d387a74208955",
    "url": "/css/to_tb.03eb33ae.css"
  },
  {
    "revision": "97fa8c2d387a74208955",
    "url": "/js/to_tb.3bf78eab.js"
  },
  {
    "revision": "babf488b295c25e454db",
    "url": "/css/transfer_url.f90dd7e3.css"
  },
  {
    "revision": "babf488b295c25e454db",
    "url": "/js/transfer_url.29f578ea.js"
  },
  {
    "revision": "602a65bac0ebcfcf97dc",
    "url": "/css/uploadIdInfo.c733dc76.css"
  },
  {
    "revision": "602a65bac0ebcfcf97dc",
    "url": "/js/uploadIdInfo.21dfbd3b.js"
  },
  {
    "revision": "c13dfc829bde49e9116a",
    "url": "/css/userCenter.6c2204af.css"
  },
  {
    "revision": "c13dfc829bde49e9116a",
    "url": "/js/userCenter.a1582ab5.js"
  },
  {
    "revision": "33b1b3cb0b52d6515c0e",
    "url": "/css/userCenterWrap.16447e10.css"
  },
  {
    "revision": "33b1b3cb0b52d6515c0e",
    "url": "/js/userCenterWrap.5ca58c25.js"
  },
  {
    "revision": "736d61ff045d6f2e52aa",
    "url": "/css/verifyInfo.5d99ae6b.css"
  },
  {
    "revision": "736d61ff045d6f2e52aa",
    "url": "/js/verifyInfo.aa67f233.js"
  },
  {
    "revision": "e4b411644706c29765eea3ffdd85ae39",
    "url": "/fonts/SourceHanSansCNRegular.e4b41164.woff"
  },
  {
    "revision": "834b022ab9ab0e6063904af32274e777",
    "url": "/fonts/SourceHanSansCNRegular.834b022a.eot"
  },
  {
    "revision": "f9509c5a10be7daaf1fa01922a7c6bc2",
    "url": "/fonts/SourceHanSansCNRegular.f9509c5a.ttf"
  },
  {
    "revision": "da0808e9fe85be160aab69c82dd8de1c",
    "url": "/img/SourceHanSansCNRegular.da0808e9.svg"
  },
  {
    "revision": "732389ded34cb9c52dd88271f1345af9",
    "url": "/fonts/element-icons.732389de.ttf"
  },
  {
    "revision": "535877f50039c0cb49a6196a5b7517cd",
    "url": "/fonts/element-icons.535877f5.woff"
  },
  {
    "revision": "cb28460b38b9de81603addeacf165064",
    "url": "/img/result_success@3x.cb28460b.png"
  },
  {
    "revision": "ab7b6bac5b5d732b2207c49ad3bbf32b",
    "url": "/img/result_error@3x.ab7b6bac.png"
  },
  {
    "revision": "009e0aad44114271651c8859ba2803fb",
    "url": "/img/btn_camera@3x.009e0aad.png"
  },
  {
    "revision": "8053681a09934ec0745117c798770884",
    "url": "/img/card_person@3x.8053681a.png"
  },
  {
    "revision": "a38cf1db1ecb9f0759a551ecc03aa161",
    "url": "/img/card_national_emblem@3x.a38cf1db.png"
  },
  {
    "revision": "171573d0985aafafc274434182a38e06",
    "url": "/img/card_id_photo@2x.171573d0.png"
  },
  {
    "revision": "2b7d8fa5a82581aea8b0edbb0d600f70",
    "url": "/img/card_person@2x.2b7d8fa5.png"
  },
  {
    "revision": "b7a05a33f96811c6b26c47f566201f43",
    "url": "/img/card_id_photo@3x.b7a05a33.png"
  },
  {
    "revision": "f5f322478286641bd9887a155e35f222",
    "url": "/img/btn.f5f32247.png"
  },
  {
    "revision": "d140650fa64e0f1fc771610dba62aed7",
    "url": "/img/bg.d140650f.png"
  },
  {
    "revision": "e625229e32d9deeb5f2909c314d8e609",
    "url": "/img/ios@2x.e625229e.png"
  },
  {
    "revision": "af8bbdfa0a90c4eed4563f8c06ce5ff8",
    "url": "/img/android@2x.af8bbdfa.png"
  },
  {
    "revision": "3f342771b9b81ab929e0fbcbcd0e6533",
    "url": "/img/bg-check-wrap@3x.3f342771.png"
  },
  {
    "revision": "9713b21819c4019befecd095069977df",
    "url": "/img/bg-check-wrap@2x.9713b218.png"
  },
  {
    "revision": "fa855242805b87da42c65763acd64ac0",
    "url": "/img/bg-plan-type@2x.fa855242.png"
  },
  {
    "revision": "4a9ca192485effa8b8f4b5b2df5b9caf",
    "url": "/img/bg-plan-type@3x.4a9ca192.png"
  },
  {
    "revision": "1d7515ee61c3f659227318b4050955ed",
    "url": "/img/mobile_sim@2x.1d7515ee.png"
  },
  {
    "revision": "0f980b79d9a52702004de9f652a68835",
    "url": "/img/telcom_sim@2x.0f980b79.png"
  },
  {
    "revision": "98141226a7e992e3072a280746a259c4",
    "url": "/img/mobile_sim@3x.98141226.png"
  },
  {
    "revision": "0c88168b284b92c37f3a873f26a97d69",
    "url": "/img/bg.0c88168b.jpg"
  },
  {
    "revision": "9e02095f31a07b972244f1c714c1dfe7",
    "url": "/img/telcom_sim@3x.9e02095f.png"
  },
  {
    "revision": "b70eddccd257b21777e71bb64c83b876",
    "url": "/img/bg.b70eddcc.jpeg"
  },
  {
    "revision": "909816c3d34e63a9ad86b8c179ab543c",
    "url": "/img/bar.909816c3.png"
  },
  {
    "revision": "e92f547ba0209da3b4342fa2b56ea9ae",
    "url": "/img/animater.e92f547b.png"
  },
  {
    "revision": "3d0fc424b703032ca595090e99f8354b",
    "url": "/img/login_bg@2x.3d0fc424.png"
  },
  {
    "revision": "11000d4e510a6df565eb69ba6f2c1dfc",
    "url": "/img/login_bg@3x.11000d4e.png"
  },
  {
    "revision": "0f16389ec218c90cf8f657e233b745f2",
    "url": "/img/balanceBg1.0f16389e.png"
  },
  {
    "revision": "565459ef2ee8b71db421144ad21c23e3",
    "url": "/img/balanceBg2.565459ef.png"
  },
  {
    "revision": "91e1d2771efacd45e5e465d9a001f197",
    "url": "/img/liantong.91e1d277.png"
  },
  {
    "revision": "4a0cab0f33beb48ea985714d1b91fef7",
    "url": "/img/dianxin.4a0cab0f.png"
  },
  {
    "revision": "657033323334e91efb0011bbc18f8c04",
    "url": "/img/yidong.65703332.png"
  },
  {
    "revision": "8da3b83b73e44e54d6be4b2522bcb1f2",
    "url": "/img/pkgBg2.8da3b83b.png"
  },
  {
    "revision": "d3b42651f9f5048baeffb50c800913ec",
    "url": "/img/pkgBg1.d3b42651.png"
  },
  {
    "revision": "d461d18e42a310bd709b2ce97d159153",
    "url": "/img/pkgBg3.d461d18e.png"
  },
  {
    "revision": "f40c7e0b20fe25eb78a7658c3ae56312",
    "url": "/img/noData@3x.f40c7e0b.png"
  },
  {
    "revision": "644e6e3cf5f33943747b116316694e28",
    "url": "/img/noData@2x.644e6e3c.png"
  },
  {
    "revision": "0078f03c08066d51d64b92a13e194ebb",
    "url": "/img/balanceRefund.0078f03c.png"
  },
  {
    "revision": "af3ed0b3236bbfdbc3ad61b8d41c3dec",
    "url": "/img/changeBg.af3ed0b3.png"
  },
  {
    "revision": "42c0fbd4915870e5e60452fd0ef2cbec",
    "url": "/img/orderTopBg@3x.42c0fbd4.png"
  },
  {
    "revision": "42c0fbd4915870e5e60452fd0ef2cbec",
    "url": "/img/orderTopBg@2x.42c0fbd4.png"
  },
  {
    "revision": "6dedd4943e4c5848638196fb6f0c4145",
    "url": "/img/bg.6dedd494.png"
  },
  {
    "revision": "6e5cee7393060b0ec3dcd587c2518b94",
    "url": "/img/bg_test.6e5cee73.png"
  },
  {
    "revision": "d0ccbc8a35180bb40e027b44dd26035a",
    "url": "/img/youku.d0ccbc8a.png"
  },
  {
    "revision": "a859e9ca4606d567c42b9c7bcd4fdce9",
    "url": "/img/iccid_bg@2x.a859e9ca.png"
  },
  {
    "revision": "fa9050c4e9870e8fc0cd184f8515af4a",
    "url": "/img/iccid_bg@3x.fa9050c4.png"
  },
  {
    "revision": "2a67b73145562669220aa4639e1ad58f",
    "url": "/img/icon3.2a67b731.png"
  },
  {
    "revision": "813b5319e378dafdda952c16ad89906b",
    "url": "/img/icon2.813b5319.png"
  },
  {
    "revision": "01355f175bd20423ce45a838c1a998a9",
    "url": "/img/bg.01355f17.png"
  },
  {
    "revision": "b899232b79ad9962c5ab5572775a0400",
    "url": "/img/card_index_bg@3x.b899232b.png"
  },
  {
    "revision": "b899232b79ad9962c5ab5572775a0400",
    "url": "/img/card_index_bg@2x.b899232b.png"
  },
  {
    "revision": "2c51a1e53c1ea0b35086d8d7261b4933",
    "url": "/img/bg_network@3x.2c51a1e5.png"
  },
  {
    "revision": "32d70c8fc305e3647098f3de0c71b618",
    "url": "/img/bg_network@2x.32d70c8f.png"
  },
  {
    "revision": "014d354b9b25b67ae95857ba17e2f4cc",
    "url": "/img/activityPage.014d354b.png"
  },
  {
    "revision": "fff5af4325410621aeec4e60b3b92d9b",
    "url": "/img/mifi_binding_bg@3x.fff5af43.png"
  },
  {
    "revision": "fff5af4325410621aeec4e60b3b92d9b",
    "url": "/img/mifi_binding_bg@2x.fff5af43.png"
  },
  {
    "revision": "114a6e12b42b9b48586dd341105188fe",
    "url": "/img/usedOrder@2x.114a6e12.png"
  },
  {
    "revision": "c0170ec299b2418256fd515ee7849055",
    "url": "/img/unUsedOrder@2x.c0170ec2.png"
  },
  {
    "revision": "d9e14058d30dd312519fcf2de38d742b",
    "url": "/img/unUsedOrder@3x.d9e14058.png"
  },
  {
    "revision": "4a5b90f8076955f289b3dcda6a5af6ff",
    "url": "/img/invaildedOrder@3x.4a5b90f8.png"
  },
  {
    "revision": "0d5a5158e67bcb7a4604124715ed6fbf",
    "url": "/img/usedOrder@3x.0d5a5158.png"
  },
  {
    "revision": "be0f1e33b2553e71b117d3d3f838d32f",
    "url": "/img/invaildedOrder@2x.be0f1e33.png"
  },
  {
    "revision": "3603a35a49dbb8ad94ec1e57c4dad229",
    "url": "/img/scanTop2.3603a35a.png"
  },
  {
    "revision": "05775dd69c53d7273b27aaa7c6c523f7",
    "url": "/img/04.05775dd6.png"
  },
  {
    "revision": "541375e6bb7db2fba9e415be8045f5fb",
    "url": "/img/1.541375e6.png"
  },
  {
    "revision": "7c28431d304fa4f58f5070c59720683a",
    "url": "/img/2.7c28431d.png"
  },
  {
    "revision": "5a3428653945c17e1c146efeee81c987",
    "url": "/img/scanTop.5a342865.png"
  },
  {
    "revision": "824594523c01e48028f2b7eb4261134d",
    "url": "/img/unicom-logo.82459452.svg"
  },
  {
    "revision": "113f99e2189c2ca49db2168754fc2eb5",
    "url": "/img/mobile-logo.113f99e2.png"
  },
  {
    "revision": "0cba868fa977e09806638b9000636a36",
    "url": "/img/avatar.0cba868f.jpeg"
  },
  {
    "revision": "27158aa79eb0d4b89f317d076a801ca3",
    "url": "/img/coupon-log.27158aa7.png"
  },
  {
    "revision": "55d3f2f09efe17db6485d4c9f8f0c3b1",
    "url": "/img/icon-recharge_20181001.55d3f2f0.svg"
  },
  {
    "revision": "165beb68d8ba0d2b70df0fbb3769787a",
    "url": "/img/03.165beb68.png"
  },
  {
    "revision": "5f1f34037094c0613bccafa2ddd8cb3b",
    "url": "/img/telecom-logo.5f1f3403.svg"
  },
  {
    "revision": "0b3c3297decbd1152a314cce115f9632",
    "url": "/img/09.0b3c3297.png"
  },
  {
    "revision": "3e217df4202e41ad9b030aafc8cfcc24",
    "url": "/img/4.3e217df4.png"
  },
  {
    "revision": "aecc9531f2c3b1fd45338e7bf5084384",
    "url": "/img/bg_no_recharge.aecc9531.svg"
  },
  {
    "revision": "b0ffa4a0fd195a110ee4d4dabce3bc32",
    "url": "/img/08.b0ffa4a0.png"
  },
  {
    "revision": "96fab583abd57f2e7118324858fa3080",
    "url": "/img/05.96fab583.png"
  },
  {
    "revision": "9e8ecc7f7b760b55c56bddfab886da10",
    "url": "/img/3.9e8ecc7f.png"
  },
  {
    "revision": "275be51ae57c486bce58257febd6589f",
    "url": "/img/bg_no_plan.275be51a.svg"
  },
  {
    "revision": "a8272d2d742d9d50257e23dfac577def",
    "url": "/img/01.a8272d2d.png"
  },
  {
    "revision": "daa86b540bb9c2a6453ceac9bed77961",
    "url": "/img/07.daa86b54.png"
  },
  {
    "revision": "06385746a7cedb492d5539907631561c",
    "url": "/img/tip.06385746.png"
  },
  {
    "revision": "eacba58f9acf2b87cd801858146b2ba9",
    "url": "/img/02.eacba58f.png"
  },
  {
    "revision": "39d9e849fc1c724525f166646932a24d",
    "url": "/img/safari.39d9e849.png"
  },
  {
    "revision": "999589aae784a460b5e7c6ae9bbaa3d8",
    "url": "/img/06.999589aa.png"
  },
  {
    "revision": "0d13643eec370ddd9f4bd6f5592bca23",
    "url": "/index.html"
  },
  {
    "revision": "d36efe199fa2a3e2c4a6",
    "url": "/css/Layout.cb7ba494.css"
  },
  {
    "revision": "9ce16f441b39b493af8b96d7e97cce22",
    "url": "/MP_verify_dkzAKjxyVyJvsHMS.txt"
  },
  {
    "revision": "86c422d8c98b247235d04b49fb1c4b05",
    "url": "/MP_verify_bKSdn2qZlUSULliu.txt"
  },
  {
    "revision": "652317b098ca24e4511926c7fd57cbbe",
    "url": "/MP_verify_8JoCCldW78DygS5c.txt"
  },
  {
    "revision": "00bbf6b458bf7ea6bd01f443eb3045d9",
    "url": "/MP_verify_4r3DVk3KUjgWsQsG.txt"
  }
];