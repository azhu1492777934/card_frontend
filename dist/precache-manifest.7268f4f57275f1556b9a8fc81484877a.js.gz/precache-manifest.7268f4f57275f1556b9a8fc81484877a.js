self.__precacheManifest = [
  {
    "revision": "ec2c3f664fd10a55ca31",
    "url": "/css/recharge_wrapper.1a8d30f5.css"
  },
  {
    "revision": "6fa7b86233c56db3f6f7",
    "url": "/css/Layout.c92f6dbd.css"
  },
  {
    "revision": "cb71e88bd43ec65f574f",
    "url": "/js/Layout~card_usage~eqReplaceMent~esim_plan_list~esim_usage~jdReplaceMent~mifi_order~mifi_plan_list~mi~504954e7.f06824d4.js"
  },
  {
    "revision": "39e7704b426ecec37122",
    "url": "/css/Not_fund.afe02751.css"
  },
  {
    "revision": "39e7704b426ecec37122",
    "url": "/js/Not_fund.34b1afa6.js"
  },
  {
    "revision": "96bb14e47dbb1db8dfc0",
    "url": "/css/app.d1d8428f.css"
  },
  {
    "revision": "96bb14e47dbb1db8dfc0",
    "url": "/js/app.9b855786.js"
  },
  {
    "revision": "779151750c6b90b0ac3a",
    "url": "/css/authority_middle.9e4a863a.css"
  },
  {
    "revision": "779151750c6b90b0ac3a",
    "url": "/js/authority_middle.2e3e650c.js"
  },
  {
    "revision": "32b6ceaa3d81c76560f2",
    "url": "/css/balanceIndex.951e0ba1.css"
  },
  {
    "revision": "32b6ceaa3d81c76560f2",
    "url": "/js/balanceIndex.63201a91.js"
  },
  {
    "revision": "5617b9395e6d70eda09b",
    "url": "/css/balanceRefund.539eb031.css"
  },
  {
    "revision": "5617b9395e6d70eda09b",
    "url": "/js/balanceRefund.fec052ce.js"
  },
  {
    "revision": "e8a8b40c7cb39fb09e0d",
    "url": "/css/cardPackage.69352085.css"
  },
  {
    "revision": "e8a8b40c7cb39fb09e0d",
    "url": "/js/cardPackage.71114667.js"
  },
  {
    "revision": "0e1981b6a0c5208c8df3",
    "url": "/css/card_check.0c40cc40.css"
  },
  {
    "revision": "0e1981b6a0c5208c8df3",
    "url": "/js/card_check.e53bfca5.js"
  },
  {
    "revision": "9a13c03f72602a0d3223",
    "url": "/css/card_connection.a88e086c.css"
  },
  {
    "revision": "9a13c03f72602a0d3223",
    "url": "/js/card_connection.de80de9a.js"
  },
  {
    "revision": "81e9a767bf0d017776c2",
    "url": "/css/card_lookup.bd76bb8d.css"
  },
  {
    "revision": "81e9a767bf0d017776c2",
    "url": "/js/card_lookup.eb07c90b.js"
  },
  {
    "revision": "a14d8414fd51fbd19538",
    "url": "/css/card_lookup_notice.e096305a.css"
  },
  {
    "revision": "a14d8414fd51fbd19538",
    "url": "/js/card_lookup_notice.5d0f2de2.js"
  },
  {
    "revision": "af09bb346e061cc700ba",
    "url": "/css/card_lookup~card_lookup_notice.1672d43e.css"
  },
  {
    "revision": "af09bb346e061cc700ba",
    "url": "/js/card_lookup~card_lookup_notice.02ff088a.js"
  },
  {
    "revision": "660aef352ee0135faee9",
    "url": "/css/card_more_flow.4280b81a.css"
  },
  {
    "revision": "660aef352ee0135faee9",
    "url": "/js/card_more_flow.b47a6db3.js"
  },
  {
    "revision": "a287e2fcdb76f053e152",
    "url": "/css/card_usage.ec7daca6.css"
  },
  {
    "revision": "a287e2fcdb76f053e152",
    "url": "/js/card_usage.3b8dec0f.js"
  },
  {
    "revision": "754e6305d25aaf55da81",
    "url": "/css/card_usage~plan_list.71eabe6e.css"
  },
  {
    "revision": "754e6305d25aaf55da81",
    "url": "/js/card_usage~plan_list.d489950d.js"
  },
  {
    "revision": "1de6908d94a745995e8d",
    "url": "/css/card_wrapper.4208fca5.css"
  },
  {
    "revision": "1de6908d94a745995e8d",
    "url": "/js/card_wrapper.91cfe956.js"
  },
  {
    "revision": "2bf5de0b140282ad6482",
    "url": "/css/children_card.5cce31ab.css"
  },
  {
    "revision": "2bf5de0b140282ad6482",
    "url": "/js/children_card.9a6239df.js"
  },
  {
    "revision": "60dbb832672d68724fff",
    "url": "/css/chunk-4876b288.83ae2819.css"
  },
  {
    "revision": "60dbb832672d68724fff",
    "url": "/js/chunk-4876b288.17ad21ad.js"
  },
  {
    "revision": "b8a3f214808d924aef7a",
    "url": "/css/chunk-bb94a3ce.db5c42da.css"
  },
  {
    "revision": "b8a3f214808d924aef7a",
    "url": "/js/chunk-bb94a3ce.07a1cc59.js"
  },
  {
    "revision": "2fa8d67a06c77fea899d",
    "url": "/css/chunk-vendors.b8da327d.css"
  },
  {
    "revision": "2fa8d67a06c77fea899d",
    "url": "/js/chunk-vendors.4ec2dc53.js"
  },
  {
    "revision": "5ba512b8930c47785378",
    "url": "/css/commonProblem.4770494b.css"
  },
  {
    "revision": "5ba512b8930c47785378",
    "url": "/js/commonProblem.f28a7358.js"
  },
  {
    "revision": "858d03802ab296d8432d",
    "url": "/css/commonQuestion.7dde70f0.css"
  },
  {
    "revision": "858d03802ab296d8432d",
    "url": "/js/commonQuestion.f0ebc467.js"
  },
  {
    "revision": "9254a0c62b6a46e1b845",
    "url": "/css/consumerRecord.979afe5b.css"
  },
  {
    "revision": "9254a0c62b6a46e1b845",
    "url": "/js/consumerRecord.d7b49fa9.js"
  },
  {
    "revision": "080b857943b348986d21",
    "url": "/css/coupon_normal.b9ac90b4.css"
  },
  {
    "revision": "080b857943b348986d21",
    "url": "/js/coupon_normal.de0e7ac3.js"
  },
  {
    "revision": "15bd7b1c9dcf06e0b474",
    "url": "/css/coupon_telcom.15c27d7b.css"
  },
  {
    "revision": "15bd7b1c9dcf06e0b474",
    "url": "/js/coupon_telcom.47e44e37.js"
  },
  {
    "revision": "a84f0dae3d9689acc895",
    "url": "/css/coupon_wrapper.12696ad3.css"
  },
  {
    "revision": "a84f0dae3d9689acc895",
    "url": "/js/coupon_wrapper.d827f700.js"
  },
  {
    "revision": "07cd2e4e3e119b2f4e3e",
    "url": "/css/currencyConversion.31a1da10.css"
  },
  {
    "revision": "07cd2e4e3e119b2f4e3e",
    "url": "/js/currencyConversion.8f97ac4d.js"
  },
  {
    "revision": "a11da91786a001218fc4",
    "url": "/css/customerFeedback.b76bb58f.css"
  },
  {
    "revision": "a11da91786a001218fc4",
    "url": "/js/customerFeedback.e8d2c210.js"
  },
  {
    "revision": "ba42c106cc4820f5ef4d",
    "url": "/css/eqReplaceMent.a990b79c.css"
  },
  {
    "revision": "ba42c106cc4820f5ef4d",
    "url": "/js/eqReplaceMent.3162bb59.js"
  },
  {
    "revision": "77f26eae29ab072a5b09",
    "url": "/css/eqReplaceMent~jdReplaceMent.613c61a7.css"
  },
  {
    "revision": "77f26eae29ab072a5b09",
    "url": "/js/eqReplaceMent~jdReplaceMent.25044f96.js"
  },
  {
    "revision": "9365342f23c6391f7529",
    "url": "/css/eqReplaceMent~jdReplaceMent~recharge.ecb4d199.css"
  },
  {
    "revision": "9365342f23c6391f7529",
    "url": "/js/eqReplaceMent~jdReplaceMent~recharge.02e24ea1.js"
  },
  {
    "revision": "8898ba0e50cf17b35cec",
    "url": "/css/esim_plan_list.d6aee0d8.css"
  },
  {
    "revision": "8898ba0e50cf17b35cec",
    "url": "/js/esim_plan_list.8d5e78aa.js"
  },
  {
    "revision": "40ac2841373212060143",
    "url": "/css/esim_usage.52c6bd7b.css"
  },
  {
    "revision": "40ac2841373212060143",
    "url": "/js/esim_usage.675a851a.js"
  },
  {
    "revision": "e76201cae8c2cbf9dc1a",
    "url": "/css/find_plan.1c804033.css"
  },
  {
    "revision": "e76201cae8c2cbf9dc1a",
    "url": "/js/find_plan.6b914a1d.js"
  },
  {
    "revision": "13ae0077b0f95729b211",
    "url": "/css/guardian.e6badfe1.css"
  },
  {
    "revision": "13ae0077b0f95729b211",
    "url": "/js/guardian.c6641008.js"
  },
  {
    "revision": "57178461aa707a6a58f0",
    "url": "/css/jdReplaceMent.1795b086.css"
  },
  {
    "revision": "57178461aa707a6a58f0",
    "url": "/js/jdReplaceMent.0b375564.js"
  },
  {
    "revision": "a8dfc8d6b619a0c1bc55",
    "url": "/css/jdWrapper.8760757b.css"
  },
  {
    "revision": "a8dfc8d6b619a0c1bc55",
    "url": "/js/jdWrapper.926a6270.js"
  },
  {
    "revision": "93ee66b8aa5b34bdac36",
    "url": "/css/logical_page.a2074deb.css"
  },
  {
    "revision": "93ee66b8aa5b34bdac36",
    "url": "/js/logical_page.8fc16f3f.js"
  },
  {
    "revision": "7c8b700e932f47098e05",
    "url": "/css/login.c488e06a.css"
  },
  {
    "revision": "7c8b700e932f47098e05",
    "url": "/js/login.ad89244c.js"
  },
  {
    "revision": "99c3cdb1197031a952cc",
    "url": "/css/lookup.9de2d9d0.css"
  },
  {
    "revision": "99c3cdb1197031a952cc",
    "url": "/js/lookup.68358bd7.js"
  },
  {
    "revision": "19b13c1a554610d61a37",
    "url": "/css/mifi_binding.6be213dd.css"
  },
  {
    "revision": "19b13c1a554610d61a37",
    "url": "/js/mifi_binding.eadc4be7.js"
  },
  {
    "revision": "cb49f8958475e147d9d6",
    "url": "/css/mifi_card_info.b05314ef.css"
  },
  {
    "revision": "cb49f8958475e147d9d6",
    "url": "/js/mifi_card_info.92687e79.js"
  },
  {
    "revision": "9f711c153abb9862e237",
    "url": "/css/mifi_card_lookup.a93ab904.css"
  },
  {
    "revision": "9f711c153abb9862e237",
    "url": "/js/mifi_card_lookup.baaceec6.js"
  },
  {
    "revision": "e50b8afe2b1a14bef75c",
    "url": "/css/mifi_card_wrapper.f10d3bed.css"
  },
  {
    "revision": "e50b8afe2b1a14bef75c",
    "url": "/js/mifi_card_wrapper.34ec5976.js"
  },
  {
    "revision": "f995f452560a06f6cf61",
    "url": "/css/mifi_change_network.d16b63b2.css"
  },
  {
    "revision": "f995f452560a06f6cf61",
    "url": "/js/mifi_change_network.bee1718c.js"
  },
  {
    "revision": "c047948216d7eaced88b",
    "url": "/css/mifi_change_network_explanation.dac8cf11.css"
  },
  {
    "revision": "c047948216d7eaced88b",
    "url": "/js/mifi_change_network_explanation.3587b77f.js"
  },
  {
    "revision": "f4b1bf4c1f831596081f",
    "url": "/css/mifi_coupon_index.d8366e08.css"
  },
  {
    "revision": "f4b1bf4c1f831596081f",
    "url": "/js/mifi_coupon_index.56dbbe29.js"
  },
  {
    "revision": "d5fa61ebe9912d1fd14c",
    "url": "/css/mifi_coupon_wrapper.2bcf9a83.css"
  },
  {
    "revision": "d5fa61ebe9912d1fd14c",
    "url": "/js/mifi_coupon_wrapper.098a70bd.js"
  },
  {
    "revision": "3014537ee662cf2698fe",
    "url": "/css/mifi_index.92b20949.css"
  },
  {
    "revision": "3014537ee662cf2698fe",
    "url": "/js/mifi_index.8dd2e17e.js"
  },
  {
    "revision": "6d3384b3506e7ac9ee96",
    "url": "/css/mifi_layout.9cfcef76.css"
  },
  {
    "revision": "6d3384b3506e7ac9ee96",
    "url": "/js/mifi_layout.0328aaf2.js"
  },
  {
    "revision": "909c4d36c1fb06572d6e",
    "url": "/css/mifi_order.7beb0300.css"
  },
  {
    "revision": "909c4d36c1fb06572d6e",
    "url": "/js/mifi_order.efcc6871.js"
  },
  {
    "revision": "44f29be597c86a758ccf",
    "url": "/css/mifi_order_wrapper.ecfbd387.css"
  },
  {
    "revision": "44f29be597c86a758ccf",
    "url": "/js/mifi_order_wrapper.cf62594c.js"
  },
  {
    "revision": "e42ade6982376271698e",
    "url": "/css/mifi_plan_group.a93d410c.css"
  },
  {
    "revision": "e42ade6982376271698e",
    "url": "/js/mifi_plan_group.b28515df.js"
  },
  {
    "revision": "d2be4047aac78f261e4b",
    "url": "/css/mifi_plan_list.d4b17f3a.css"
  },
  {
    "revision": "d2be4047aac78f261e4b",
    "url": "/js/mifi_plan_list.bcb89a8e.js"
  },
  {
    "revision": "5c2abf560590cb52bbc7",
    "url": "/css/mifi_plan_usage.0d06e6eb.css"
  },
  {
    "revision": "5c2abf560590cb52bbc7",
    "url": "/js/mifi_plan_usage.5aa17d02.js"
  },
  {
    "revision": "38409b3d9018a6018d0d",
    "url": "/css/mifi_plan_wrapper.3db278e7.css"
  },
  {
    "revision": "38409b3d9018a6018d0d",
    "url": "/js/mifi_plan_wrapper.51657335.js"
  },
  {
    "revision": "149e2779bff727feb91b",
    "url": "/css/new_card_wrapper.98fed2fc.css"
  },
  {
    "revision": "149e2779bff727feb91b",
    "url": "/js/new_card_wrapper.a0734559.js"
  },
  {
    "revision": "1ab54a3f24b8e5a63b1e",
    "url": "/css/official_accounts.26961ede.css"
  },
  {
    "revision": "1ab54a3f24b8e5a63b1e",
    "url": "/js/official_accounts.09b4a133.js"
  },
  {
    "revision": "01cf993b18d97f726109",
    "url": "/css/orderRecord.03cbe61e.css"
  },
  {
    "revision": "01cf993b18d97f726109",
    "url": "/js/orderRecord.6632c401.js"
  },
  {
    "revision": "5244cdcc535735d1ff31",
    "url": "/css/plan_list.90a01e71.css"
  },
  {
    "revision": "5244cdcc535735d1ff31",
    "url": "/js/plan_list.fbd87603.js"
  },
  {
    "revision": "eb4dd99e599233458b3f",
    "url": "/css/question.4b37ef71.css"
  },
  {
    "revision": "eb4dd99e599233458b3f",
    "url": "/js/question.ea383ecf.js"
  },
  {
    "revision": "902669215db2a9add4fc",
    "url": "/css/question_wrapper.eeb3aab7.css"
  },
  {
    "revision": "902669215db2a9add4fc",
    "url": "/js/question_wrapper.76550024.js"
  },
  {
    "revision": "d1cb7e6cd094f19439e7",
    "url": "/css/realNameCourse.9ca9b0f6.css"
  },
  {
    "revision": "d1cb7e6cd094f19439e7",
    "url": "/js/realNameCourse.e4e3501c.js"
  },
  {
    "revision": "f522f8cb1e31c1796cad",
    "url": "/css/real_name.4001841e.css"
  },
  {
    "revision": "f522f8cb1e31c1796cad",
    "url": "/js/real_name.a402d1f1.js"
  },
  {
    "revision": "8701c48b66b985f8fb1e",
    "url": "/css/recharge.d8d2a8ce.css"
  },
  {
    "revision": "8701c48b66b985f8fb1e",
    "url": "/js/recharge.3c2b451d.js"
  },
  {
    "revision": "e49da830c67ccb234ebf",
    "url": "/css/rechargeOrder.fc6e5fdd.css"
  },
  {
    "revision": "e49da830c67ccb234ebf",
    "url": "/js/rechargeOrder.03ed7faf.js"
  },
  {
    "revision": "5aae7f25bed7bf7ee752",
    "url": "/css/rechargeOrder~whiteSearch.9312635a.css"
  },
  {
    "revision": "5aae7f25bed7bf7ee752",
    "url": "/js/rechargeOrder~whiteSearch.eb33013c.js"
  },
  {
    "revision": "60e7aadf0f87a03fbccb",
    "url": "/css/recharge_balance.b69eb50e.css"
  },
  {
    "revision": "60e7aadf0f87a03fbccb",
    "url": "/js/recharge_balance.373ed4de.js"
  },
  {
    "revision": "c420320bf829334845cf",
    "url": "/css/recharge_callback.9c32a9b2.css"
  },
  {
    "revision": "c420320bf829334845cf",
    "url": "/js/recharge_callback.62241034.js"
  },
  {
    "revision": "6fa7b86233c56db3f6f7",
    "url": "/js/Layout.86395816.js"
  },
  {
    "revision": "ec2c3f664fd10a55ca31",
    "url": "/js/recharge_wrapper.b5c1d688.js"
  },
  {
    "revision": "f1158988b0335ac27ba8",
    "url": "/css/refundRules.7d8883fe.css"
  },
  {
    "revision": "f1158988b0335ac27ba8",
    "url": "/js/refundRules.182e7992.js"
  },
  {
    "revision": "94c414fbf95236f16dbf",
    "url": "/css/refund_applying.5e0a9890.css"
  },
  {
    "revision": "94c414fbf95236f16dbf",
    "url": "/js/refund_applying.54a30b80.js"
  },
  {
    "revision": "c5dfb69a5059d8a2341e",
    "url": "/css/refund_argument.55e7517b.css"
  },
  {
    "revision": "c5dfb69a5059d8a2341e",
    "url": "/js/refund_argument.8907a798.js"
  },
  {
    "revision": "e5de643d5c84b4d78fbc",
    "url": "/css/refund_plan.87947d21.css"
  },
  {
    "revision": "e5de643d5c84b4d78fbc",
    "url": "/js/refund_plan.5f29a2ed.js"
  },
  {
    "revision": "66680a90e05d9c1c40d8",
    "url": "/css/refund_wrapper.02a09f97.css"
  },
  {
    "revision": "66680a90e05d9c1c40d8",
    "url": "/js/refund_wrapper.238f980f.js"
  },
  {
    "revision": "ccd5c9cc81cc040d54fb",
    "url": "/css/repeatRecharge.f2bea36d.css"
  },
  {
    "revision": "ccd5c9cc81cc040d54fb",
    "url": "/js/repeatRecharge.f0e4fce7.js"
  },
  {
    "revision": "f25d962248d2d691b842",
    "url": "/css/revoke_plan.0b610632.css"
  },
  {
    "revision": "f25d962248d2d691b842",
    "url": "/js/revoke_plan.2f2f8fd1.js"
  },
  {
    "revision": "c9c5babd23959e1f593e",
    "url": "/css/speedup_500.f46392b8.css"
  },
  {
    "revision": "c9c5babd23959e1f593e",
    "url": "/js/speedup_500.3866840d.js"
  },
  {
    "revision": "ab56d74986d85a78e7ed",
    "url": "/css/speedup_80.8f563437.css"
  },
  {
    "revision": "ab56d74986d85a78e7ed",
    "url": "/js/speedup_80.251e964c.js"
  },
  {
    "revision": "6d7eef8e811cab4a3ab5",
    "url": "/css/speedup_wrapper.09148f29.css"
  },
  {
    "revision": "6d7eef8e811cab4a3ab5",
    "url": "/js/speedup_wrapper.5777af2f.js"
  },
  {
    "revision": "0d9325299169762b4b3d",
    "url": "/css/to_tb.f225e1b1.css"
  },
  {
    "revision": "0d9325299169762b4b3d",
    "url": "/js/to_tb.c9f1b0cc.js"
  },
  {
    "revision": "46b12408493578f4430a",
    "url": "/css/transfer_url.b51702ce.css"
  },
  {
    "revision": "46b12408493578f4430a",
    "url": "/js/transfer_url.b1497d44.js"
  },
  {
    "revision": "c019d8c9519812bbbca7",
    "url": "/css/userCenter.ea0496ce.css"
  },
  {
    "revision": "c019d8c9519812bbbca7",
    "url": "/js/userCenter.3977f400.js"
  },
  {
    "revision": "152c0a36ddadcfc6a97f",
    "url": "/css/userCenterWrap.e1efacf4.css"
  },
  {
    "revision": "152c0a36ddadcfc6a97f",
    "url": "/js/userCenterWrap.08979b42.js"
  },
  {
    "revision": "ec84ea3cd7c00b835148",
    "url": "/css/whiteListsWrapper.de43f5e2.css"
  },
  {
    "revision": "ec84ea3cd7c00b835148",
    "url": "/js/whiteListsWrapper.544dbd29.js"
  },
  {
    "revision": "5ed9bcadbbd00302d6b0",
    "url": "/css/whiteNewlist.9d3e444c.css"
  },
  {
    "revision": "5ed9bcadbbd00302d6b0",
    "url": "/js/whiteNewlist.fb5bdc43.js"
  },
  {
    "revision": "9525e99f347b3fd1eab5",
    "url": "/css/whiteSearch.5439064e.css"
  },
  {
    "revision": "9525e99f347b3fd1eab5",
    "url": "/js/whiteSearch.b5d1a3ee.js"
  },
  {
    "revision": "e4b411644706c29765eea3ffdd85ae39",
    "url": "/fonts/SourceHanSansCNRegular.e4b41164.woff"
  },
  {
    "revision": "834b022ab9ab0e6063904af32274e777",
    "url": "/fonts/SourceHanSansCNRegular.834b022a.eot"
  },
  {
    "revision": "f9509c5a10be7daaf1fa01922a7c6bc2",
    "url": "/fonts/SourceHanSansCNRegular.f9509c5a.ttf"
  },
  {
    "revision": "da0808e9fe85be160aab69c82dd8de1c",
    "url": "/img/SourceHanSansCNRegular.da0808e9.svg"
  },
  {
    "revision": "732389ded34cb9c52dd88271f1345af9",
    "url": "/fonts/element-icons.732389de.ttf"
  },
  {
    "revision": "535877f50039c0cb49a6196a5b7517cd",
    "url": "/fonts/element-icons.535877f5.woff"
  },
  {
    "revision": "0f16389ec218c90cf8f657e233b745f2",
    "url": "/img/balanceBg1.0f16389e.png"
  },
  {
    "revision": "565459ef2ee8b71db421144ad21c23e3",
    "url": "/img/balanceBg2.565459ef.png"
  },
  {
    "revision": "91e1d2771efacd45e5e465d9a001f197",
    "url": "/img/liantong.91e1d277.png"
  },
  {
    "revision": "4a0cab0f33beb48ea985714d1b91fef7",
    "url": "/img/dianxin.4a0cab0f.png"
  },
  {
    "revision": "657033323334e91efb0011bbc18f8c04",
    "url": "/img/yidong.65703332.png"
  },
  {
    "revision": "8da3b83b73e44e54d6be4b2522bcb1f2",
    "url": "/img/pkgBg2.8da3b83b.png"
  },
  {
    "revision": "d3b42651f9f5048baeffb50c800913ec",
    "url": "/img/pkgBg1.d3b42651.png"
  },
  {
    "revision": "d461d18e42a310bd709b2ce97d159153",
    "url": "/img/pkgBg3.d461d18e.png"
  },
  {
    "revision": "0078f03c08066d51d64b92a13e194ebb",
    "url": "/img/balanceRefund.0078f03c.png"
  },
  {
    "revision": "af3ed0b3236bbfdbc3ad61b8d41c3dec",
    "url": "/img/changeBg.af3ed0b3.png"
  },
  {
    "revision": "cc0636ca2944024fd3ebf33a5412ff35",
    "url": "/img/icon-right@3x.cc0636ca.png"
  },
  {
    "revision": "1b983020cfed6b7a8ca5c300c24ca186",
    "url": "/img/icon-left@3x.1b983020.png"
  },
  {
    "revision": "d796d97eb9ebb2e89bb966343e2362e9",
    "url": "/img/icon-left@2x.d796d97e.png"
  },
  {
    "revision": "ccb9865dadbc642b8c4dd0a1abc8e570",
    "url": "/img/recharge-word@2x.ccb9865d.png"
  },
  {
    "revision": "ccb9865dadbc642b8c4dd0a1abc8e570",
    "url": "/img/recharge-word@3x.ccb9865d.png"
  },
  {
    "revision": "41a8c268f703fe646d5d08099eb778ae",
    "url": "/img/icon-right@2x.41a8c268.png"
  },
  {
    "revision": "2d6d06f4da15fc1a748677c49c5f1854",
    "url": "/img/bg.2d6d06f4.png"
  },
  {
    "revision": "e625229e32d9deeb5f2909c314d8e609",
    "url": "/img/ios@2x.e625229e.png"
  },
  {
    "revision": "af8bbdfa0a90c4eed4563f8c06ce5ff8",
    "url": "/img/android@2x.af8bbdfa.png"
  },
  {
    "revision": "8cb139e0169560e725d23c2ab8d8310e",
    "url": "/img/advert.8cb139e0.gif"
  },
  {
    "revision": "e93b8c03293c5b6a311da784f9c19c8f",
    "url": "/img/bg.e93b8c03.jpeg"
  },
  {
    "revision": "ffb1612d9660e2ecd9d3872d57a8a2f9",
    "url": "/img/bar.ffb1612d.png"
  },
  {
    "revision": "1d7515ee61c3f659227318b4050955ed",
    "url": "/img/mobile_sim@2x.1d7515ee.png"
  },
  {
    "revision": "0f980b79d9a52702004de9f652a68835",
    "url": "/img/telcom_sim@2x.0f980b79.png"
  },
  {
    "revision": "98141226a7e992e3072a280746a259c4",
    "url": "/img/mobile_sim@3x.98141226.png"
  },
  {
    "revision": "0c88168b284b92c37f3a873f26a97d69",
    "url": "/img/bg.0c88168b.jpg"
  },
  {
    "revision": "9e02095f31a07b972244f1c714c1dfe7",
    "url": "/img/telcom_sim@3x.9e02095f.png"
  },
  {
    "revision": "3d0fc424b703032ca595090e99f8354b",
    "url": "/img/login_bg@2x.3d0fc424.png"
  },
  {
    "revision": "11000d4e510a6df565eb69ba6f2c1dfc",
    "url": "/img/login_bg@3x.11000d4e.png"
  },
  {
    "revision": "6dedd4943e4c5848638196fb6f0c4145",
    "url": "/img/bg.6dedd494.png"
  },
  {
    "revision": "a859e9ca4606d567c42b9c7bcd4fdce9",
    "url": "/img/iccid_bg@2x.a859e9ca.png"
  },
  {
    "revision": "fa9050c4e9870e8fc0cd184f8515af4a",
    "url": "/img/iccid_bg@3x.fa9050c4.png"
  },
  {
    "revision": "014d354b9b25b67ae95857ba17e2f4cc",
    "url": "/img/activityPage.014d354b.png"
  },
  {
    "revision": "f40c7e0b20fe25eb78a7658c3ae56312",
    "url": "/img/noData@3x.f40c7e0b.png"
  },
  {
    "revision": "644e6e3cf5f33943747b116316694e28",
    "url": "/img/noData@2x.644e6e3c.png"
  },
  {
    "revision": "6e5cee7393060b0ec3dcd587c2518b94",
    "url": "/img/bg_test.6e5cee73.png"
  },
  {
    "revision": "fff5af4325410621aeec4e60b3b92d9b",
    "url": "/img/mifi_binding_bg@3x.fff5af43.png"
  },
  {
    "revision": "fff5af4325410621aeec4e60b3b92d9b",
    "url": "/img/mifi_binding_bg@2x.fff5af43.png"
  },
  {
    "revision": "2c51a1e53c1ea0b35086d8d7261b4933",
    "url": "/img/bg_network@3x.2c51a1e5.png"
  },
  {
    "revision": "32d70c8fc305e3647098f3de0c71b618",
    "url": "/img/bg_network@2x.32d70c8f.png"
  },
  {
    "revision": "42c0fbd4915870e5e60452fd0ef2cbec",
    "url": "/img/orderTopBg@3x.42c0fbd4.png"
  },
  {
    "revision": "42c0fbd4915870e5e60452fd0ef2cbec",
    "url": "/img/orderTopBg@2x.42c0fbd4.png"
  },
  {
    "revision": "b899232b79ad9962c5ab5572775a0400",
    "url": "/img/card_index_bg@3x.b899232b.png"
  },
  {
    "revision": "b899232b79ad9962c5ab5572775a0400",
    "url": "/img/card_index_bg@2x.b899232b.png"
  },
  {
    "revision": "d0ccbc8a35180bb40e027b44dd26035a",
    "url": "/img/youku.d0ccbc8a.png"
  },
  {
    "revision": "3f342771b9b81ab929e0fbcbcd0e6533",
    "url": "/img/bg-check-wrap@3x.3f342771.png"
  },
  {
    "revision": "9713b21819c4019befecd095069977df",
    "url": "/img/bg-check-wrap@2x.9713b218.png"
  },
  {
    "revision": "f5f322478286641bd9887a155e35f222",
    "url": "/img/btn.f5f32247.png"
  },
  {
    "revision": "d140650fa64e0f1fc771610dba62aed7",
    "url": "/img/bg.d140650f.png"
  },
  {
    "revision": "fa855242805b87da42c65763acd64ac0",
    "url": "/img/bg-plan-type@2x.fa855242.png"
  },
  {
    "revision": "4a9ca192485effa8b8f4b5b2df5b9caf",
    "url": "/img/bg-plan-type@3x.4a9ca192.png"
  },
  {
    "revision": "6e5cee7393060b0ec3dcd587c2518b94",
    "url": "/img/bg_test@3x.6e5cee73.png"
  },
  {
    "revision": "114a6e12b42b9b48586dd341105188fe",
    "url": "/img/usedOrder@2x.114a6e12.png"
  },
  {
    "revision": "6e5cee7393060b0ec3dcd587c2518b94",
    "url": "/img/bg_test@2x.6e5cee73.png"
  },
  {
    "revision": "c0170ec299b2418256fd515ee7849055",
    "url": "/img/unUsedOrder@2x.c0170ec2.png"
  },
  {
    "revision": "d9e14058d30dd312519fcf2de38d742b",
    "url": "/img/unUsedOrder@3x.d9e14058.png"
  },
  {
    "revision": "4a5b90f8076955f289b3dcda6a5af6ff",
    "url": "/img/invaildedOrder@3x.4a5b90f8.png"
  },
  {
    "revision": "0d5a5158e67bcb7a4604124715ed6fbf",
    "url": "/img/usedOrder@3x.0d5a5158.png"
  },
  {
    "revision": "be0f1e33b2553e71b117d3d3f838d32f",
    "url": "/img/invaildedOrder@2x.be0f1e33.png"
  },
  {
    "revision": "2a67b73145562669220aa4639e1ad58f",
    "url": "/img/icon3.2a67b731.png"
  },
  {
    "revision": "813b5319e378dafdda952c16ad89906b",
    "url": "/img/icon2.813b5319.png"
  },
  {
    "revision": "01355f175bd20423ce45a838c1a998a9",
    "url": "/img/bg.01355f17.png"
  },
  {
    "revision": "3603a35a49dbb8ad94ec1e57c4dad229",
    "url": "/img/scanTop2.3603a35a.png"
  },
  {
    "revision": "05775dd69c53d7273b27aaa7c6c523f7",
    "url": "/img/04.05775dd6.png"
  },
  {
    "revision": "58a560568b7291ea926c2c7438035308",
    "url": "/img/subscribe@3x.58a56056.png"
  },
  {
    "revision": "541375e6bb7db2fba9e415be8045f5fb",
    "url": "/img/1.541375e6.png"
  },
  {
    "revision": "7c28431d304fa4f58f5070c59720683a",
    "url": "/img/2.7c28431d.png"
  },
  {
    "revision": "5a3428653945c17e1c146efeee81c987",
    "url": "/img/scanTop.5a342865.png"
  },
  {
    "revision": "0b9e0b5f4f28c68416f916ddce3fc7ef",
    "url": "/img/unicom-logo.0b9e0b5f.svg"
  },
  {
    "revision": "113f99e2189c2ca49db2168754fc2eb5",
    "url": "/img/mobile-logo.113f99e2.png"
  },
  {
    "revision": "0cba868fa977e09806638b9000636a36",
    "url": "/img/avatar.0cba868f.jpeg"
  },
  {
    "revision": "27158aa79eb0d4b89f317d076a801ca3",
    "url": "/img/coupon-log.27158aa7.png"
  },
  {
    "revision": "55d3f2f09efe17db6485d4c9f8f0c3b1",
    "url": "/img/icon-recharge_20181001.55d3f2f0.svg"
  },
  {
    "revision": "165beb68d8ba0d2b70df0fbb3769787a",
    "url": "/img/03.165beb68.png"
  },
  {
    "revision": "8c605ac88ca50357355da465f322d10a",
    "url": "/img/telecom-logo.8c605ac8.svg"
  },
  {
    "revision": "f7a51f1c554585b11d61499fd0a7520f",
    "url": "/img/only-box@3x.f7a51f1c.png"
  },
  {
    "revision": "89b99d16dd8a4a56746323a0ffbd754c",
    "url": "/img/migu.89b99d16.png"
  },
  {
    "revision": "0b3c3297decbd1152a314cce115f9632",
    "url": "/img/09.0b3c3297.png"
  },
  {
    "revision": "3e217df4202e41ad9b030aafc8cfcc24",
    "url": "/img/4.3e217df4.png"
  },
  {
    "revision": "34c67f6dfdb0ecc17c7a221aec74706f",
    "url": "/img/bg_no_recharge.34c67f6d.svg"
  },
  {
    "revision": "b0ffa4a0fd195a110ee4d4dabce3bc32",
    "url": "/img/08.b0ffa4a0.png"
  },
  {
    "revision": "96fab583abd57f2e7118324858fa3080",
    "url": "/img/05.96fab583.png"
  },
  {
    "revision": "9e8ecc7f7b760b55c56bddfab886da10",
    "url": "/img/3.9e8ecc7f.png"
  },
  {
    "revision": "f23d9d1f76147bc89b48902c36818f1e",
    "url": "/img/bg_no_plan.f23d9d1f.svg"
  },
  {
    "revision": "a8272d2d742d9d50257e23dfac577def",
    "url": "/img/01.a8272d2d.png"
  },
  {
    "revision": "daa86b540bb9c2a6453ceac9bed77961",
    "url": "/img/07.daa86b54.png"
  },
  {
    "revision": "687b6ce03f134f21173c949d79002960",
    "url": "/img/tip.687b6ce0.png"
  },
  {
    "revision": "a610420eab741be28278e60bc06387aa",
    "url": "/img/box-deco@3x.a610420e.png"
  },
  {
    "revision": "eacba58f9acf2b87cd801858146b2ba9",
    "url": "/img/02.eacba58f.png"
  },
  {
    "revision": "39d9e849fc1c724525f166646932a24d",
    "url": "/img/safari.39d9e849.png"
  },
  {
    "revision": "999589aae784a460b5e7c6ae9bbaa3d8",
    "url": "/img/06.999589aa.png"
  },
  {
    "revision": "f8a8d395b7fb440ba87a9eeb54445baf",
    "url": "/index.html"
  },
  {
    "revision": "735ab4f94fbcd57074377afca324c813",
    "url": "/robots.txt"
  },
  {
    "revision": "9ce16f441b39b493af8b96d7e97cce22",
    "url": "/MP_verify_dkzAKjxyVyJvsHMS.txt"
  },
  {
    "revision": "86c422d8c98b247235d04b49fb1c4b05",
    "url": "/MP_verify_bKSdn2qZlUSULliu.txt"
  },
  {
    "revision": "652317b098ca24e4511926c7fd57cbbe",
    "url": "/MP_verify_8JoCCldW78DygS5c.txt"
  },
  {
    "revision": "00bbf6b458bf7ea6bd01f443eb3045d9",
    "url": "/MP_verify_4r3DVk3KUjgWsQsG.txt"
  }
];