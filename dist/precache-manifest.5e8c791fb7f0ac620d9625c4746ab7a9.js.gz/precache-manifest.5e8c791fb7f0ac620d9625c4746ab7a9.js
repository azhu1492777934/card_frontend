self.__precacheManifest = [
  {
    "revision": "b47da50f055773f43901",
    "url": "/js/refundRules.1030bdf6.js"
  },
  {
    "revision": "663e9f10825114a64de6",
    "url": "/css/Layout.e78f213d.css"
  },
  {
    "revision": "78214ba34c5f1df936aa",
    "url": "/js/Layout~card_usage~eqReplaceMent~esim_plan_list~esim_usage~mifi_order~mifi_plan_list~mifi_plan_usage~~c6f87c36.6241bd21.js"
  },
  {
    "revision": "5c77017d3c8eabccb3ce",
    "url": "/css/Not_fund.a9347abd.css"
  },
  {
    "revision": "5c77017d3c8eabccb3ce",
    "url": "/js/Not_fund.e7e6a73e.js"
  },
  {
    "revision": "3b9d51e6680348f4e20f",
    "url": "/css/app.0ccacaf2.css"
  },
  {
    "revision": "3b9d51e6680348f4e20f",
    "url": "/js/app.a694cbd1.js"
  },
  {
    "revision": "2040e27de8d410cb338b",
    "url": "/css/authority_middle.3236ca46.css"
  },
  {
    "revision": "2040e27de8d410cb338b",
    "url": "/js/authority_middle.33e04443.js"
  },
  {
    "revision": "5a14d933f7ffa891355b",
    "url": "/css/balanceIndex.8d965d1d.css"
  },
  {
    "revision": "5a14d933f7ffa891355b",
    "url": "/js/balanceIndex.cc1b415e.js"
  },
  {
    "revision": "d62df7201c726f709131",
    "url": "/css/balanceRefund.6390149a.css"
  },
  {
    "revision": "d62df7201c726f709131",
    "url": "/js/balanceRefund.24069b99.js"
  },
  {
    "revision": "16500080d12b3fc71f64",
    "url": "/css/cardPackage.26862a57.css"
  },
  {
    "revision": "16500080d12b3fc71f64",
    "url": "/js/cardPackage.a6e81155.js"
  },
  {
    "revision": "a49dad26181415f30ea1",
    "url": "/css/card_check.26276951.css"
  },
  {
    "revision": "a49dad26181415f30ea1",
    "url": "/js/card_check.2a5cab6c.js"
  },
  {
    "revision": "160d1822c55c3c0823d7",
    "url": "/css/card_connection.d3be858c.css"
  },
  {
    "revision": "160d1822c55c3c0823d7",
    "url": "/js/card_connection.3561202a.js"
  },
  {
    "revision": "43cf73f2006ec24ee946",
    "url": "/css/card_lookup.cbd7738f.css"
  },
  {
    "revision": "43cf73f2006ec24ee946",
    "url": "/js/card_lookup.09bea823.js"
  },
  {
    "revision": "7fdb03e371d07afad890",
    "url": "/css/card_more_flow.5ed48686.css"
  },
  {
    "revision": "7fdb03e371d07afad890",
    "url": "/js/card_more_flow.6a1e31ef.js"
  },
  {
    "revision": "84590d7a56706317c43b",
    "url": "/css/card_usage.9c88bb7d.css"
  },
  {
    "revision": "84590d7a56706317c43b",
    "url": "/js/card_usage.9408ae34.js"
  },
  {
    "revision": "b843437e28fa80a9ff6b",
    "url": "/css/card_wrapper.0a3fcc27.css"
  },
  {
    "revision": "b843437e28fa80a9ff6b",
    "url": "/js/card_wrapper.d24a16e9.js"
  },
  {
    "revision": "49605120cb6cefc2b4ba",
    "url": "/css/children_card.db5f5d76.css"
  },
  {
    "revision": "49605120cb6cefc2b4ba",
    "url": "/js/children_card.382ab701.js"
  },
  {
    "revision": "3b63cc99d8f9772bd0ab",
    "url": "/css/chunk-68bb4772.d01d0c9f.css"
  },
  {
    "revision": "3b63cc99d8f9772bd0ab",
    "url": "/js/chunk-68bb4772.9a96c441.js"
  },
  {
    "revision": "5667afe33a550611fbe9",
    "url": "/css/chunk-7a806b55.4282b53d.css"
  },
  {
    "revision": "5667afe33a550611fbe9",
    "url": "/js/chunk-7a806b55.ba65cdc7.js"
  },
  {
    "revision": "7a37f1d32dcf31fafb6d",
    "url": "/css/chunk-vendors.4dda4045.css"
  },
  {
    "revision": "7a37f1d32dcf31fafb6d",
    "url": "/js/chunk-vendors.6a1799b5.js"
  },
  {
    "revision": "9c59e4ee46f41444459b",
    "url": "/css/commonProblem.bcee85f0.css"
  },
  {
    "revision": "9c59e4ee46f41444459b",
    "url": "/js/commonProblem.a27c9de4.js"
  },
  {
    "revision": "40bda42e5d2f7aa42950",
    "url": "/css/commonQuestion.557595f3.css"
  },
  {
    "revision": "40bda42e5d2f7aa42950",
    "url": "/js/commonQuestion.ebb9ebc7.js"
  },
  {
    "revision": "af61e9ba77b9edda772e",
    "url": "/css/consumerRecord.791fa7e8.css"
  },
  {
    "revision": "af61e9ba77b9edda772e",
    "url": "/js/consumerRecord.13fc5419.js"
  },
  {
    "revision": "c9fa4abfdcf8b04a24a5",
    "url": "/css/coupon_normal.dd59f798.css"
  },
  {
    "revision": "c9fa4abfdcf8b04a24a5",
    "url": "/js/coupon_normal.9fe0bd8f.js"
  },
  {
    "revision": "46ccf8865824b48a34ee",
    "url": "/css/coupon_telcom.34e8c6e5.css"
  },
  {
    "revision": "46ccf8865824b48a34ee",
    "url": "/js/coupon_telcom.b25ee42d.js"
  },
  {
    "revision": "bfdaa28b33c708d76347",
    "url": "/css/coupon_wrapper.fb951ea8.css"
  },
  {
    "revision": "bfdaa28b33c708d76347",
    "url": "/js/coupon_wrapper.b7d4521b.js"
  },
  {
    "revision": "9affc1bb87f8685db1a0",
    "url": "/css/currencyConversion.aef5dc98.css"
  },
  {
    "revision": "9affc1bb87f8685db1a0",
    "url": "/js/currencyConversion.31670cc1.js"
  },
  {
    "revision": "54706405fb41646fc48d",
    "url": "/css/customerFeedback.38ef144b.css"
  },
  {
    "revision": "54706405fb41646fc48d",
    "url": "/js/customerFeedback.3858bfa9.js"
  },
  {
    "revision": "3204a78c78b574f60bd5",
    "url": "/css/eqReplaceMent.d2fb3809.css"
  },
  {
    "revision": "3204a78c78b574f60bd5",
    "url": "/js/eqReplaceMent.b395d55b.js"
  },
  {
    "revision": "45f2e57f7f820c9d11aa",
    "url": "/css/eqReplaceMent~recharge.d2dc69b7.css"
  },
  {
    "revision": "45f2e57f7f820c9d11aa",
    "url": "/js/eqReplaceMent~recharge.a9ad22af.js"
  },
  {
    "revision": "3449f05606923bb76e6c",
    "url": "/css/esim_plan_list.3b0e3592.css"
  },
  {
    "revision": "3449f05606923bb76e6c",
    "url": "/js/esim_plan_list.3062d415.js"
  },
  {
    "revision": "2d84eb7ee3fef235a70e",
    "url": "/css/esim_usage.c3ac150c.css"
  },
  {
    "revision": "2d84eb7ee3fef235a70e",
    "url": "/js/esim_usage.695cc2ef.js"
  },
  {
    "revision": "b2b341eee6999b43dbf9",
    "url": "/css/find_plan.70001df5.css"
  },
  {
    "revision": "b2b341eee6999b43dbf9",
    "url": "/js/find_plan.ddbe3632.js"
  },
  {
    "revision": "a0248536d98ed1790b2b",
    "url": "/css/logical_page.581e6d43.css"
  },
  {
    "revision": "a0248536d98ed1790b2b",
    "url": "/js/logical_page.bd642702.js"
  },
  {
    "revision": "1851df0c0a7cdfcc60ce",
    "url": "/css/login.85191a19.css"
  },
  {
    "revision": "1851df0c0a7cdfcc60ce",
    "url": "/js/login.40cccc6a.js"
  },
  {
    "revision": "756268eecfbbbf8d2bc4",
    "url": "/css/lookup.4ddf5191.css"
  },
  {
    "revision": "756268eecfbbbf8d2bc4",
    "url": "/js/lookup.8ccda574.js"
  },
  {
    "revision": "73b67a6749fadde316be",
    "url": "/css/mifi_binding.9e5f8ce9.css"
  },
  {
    "revision": "73b67a6749fadde316be",
    "url": "/js/mifi_binding.7c879138.js"
  },
  {
    "revision": "69bdf3fb96d421ecdfe7",
    "url": "/css/mifi_card_info.672a35bd.css"
  },
  {
    "revision": "69bdf3fb96d421ecdfe7",
    "url": "/js/mifi_card_info.f5f65f96.js"
  },
  {
    "revision": "c07e613766ff217d7d0d",
    "url": "/css/mifi_card_lookup.3fc0625d.css"
  },
  {
    "revision": "c07e613766ff217d7d0d",
    "url": "/js/mifi_card_lookup.977c7b36.js"
  },
  {
    "revision": "b6aa59510bab1691e55a",
    "url": "/css/mifi_card_wrapper.f96feb6a.css"
  },
  {
    "revision": "b6aa59510bab1691e55a",
    "url": "/js/mifi_card_wrapper.0e856f36.js"
  },
  {
    "revision": "ee0a04e85ddcf23d83ee",
    "url": "/css/mifi_change_network.0916e7d9.css"
  },
  {
    "revision": "ee0a04e85ddcf23d83ee",
    "url": "/js/mifi_change_network.742b521e.js"
  },
  {
    "revision": "68936d96668c6591d057",
    "url": "/css/mifi_change_network_explanation.14d7ccfc.css"
  },
  {
    "revision": "68936d96668c6591d057",
    "url": "/js/mifi_change_network_explanation.cffade75.js"
  },
  {
    "revision": "38797ca1a0b465035e3c",
    "url": "/css/mifi_coupon_index.77bf2c8f.css"
  },
  {
    "revision": "38797ca1a0b465035e3c",
    "url": "/js/mifi_coupon_index.694f2eab.js"
  },
  {
    "revision": "d76d36d361947539bb04",
    "url": "/css/mifi_coupon_wrapper.bd47aa9c.css"
  },
  {
    "revision": "d76d36d361947539bb04",
    "url": "/js/mifi_coupon_wrapper.b37e46b4.js"
  },
  {
    "revision": "e3e169b3042695b71d90",
    "url": "/css/mifi_index.30f2de45.css"
  },
  {
    "revision": "e3e169b3042695b71d90",
    "url": "/js/mifi_index.4cec4a8c.js"
  },
  {
    "revision": "1ca86d0ad53e33dde6cb",
    "url": "/css/mifi_layout.4df9ee19.css"
  },
  {
    "revision": "1ca86d0ad53e33dde6cb",
    "url": "/js/mifi_layout.582bc0aa.js"
  },
  {
    "revision": "37c7d6ce9b6faeeebad1",
    "url": "/css/mifi_order.e853c548.css"
  },
  {
    "revision": "37c7d6ce9b6faeeebad1",
    "url": "/js/mifi_order.1d593079.js"
  },
  {
    "revision": "6ced1a626355163af7b1",
    "url": "/css/mifi_order_wrapper.2f115a10.css"
  },
  {
    "revision": "6ced1a626355163af7b1",
    "url": "/js/mifi_order_wrapper.a4d504f8.js"
  },
  {
    "revision": "28322889cb222342df5a",
    "url": "/css/mifi_plan_group.21e09feb.css"
  },
  {
    "revision": "28322889cb222342df5a",
    "url": "/js/mifi_plan_group.4b73198a.js"
  },
  {
    "revision": "8b175bea8a17a2dbdfc2",
    "url": "/css/mifi_plan_list.91b50446.css"
  },
  {
    "revision": "8b175bea8a17a2dbdfc2",
    "url": "/js/mifi_plan_list.680d3efd.js"
  },
  {
    "revision": "7f3d9d897ec2d0df5923",
    "url": "/css/mifi_plan_usage.ba2cccc7.css"
  },
  {
    "revision": "7f3d9d897ec2d0df5923",
    "url": "/js/mifi_plan_usage.5a7e0caf.js"
  },
  {
    "revision": "2c4141890cd45c14e1e8",
    "url": "/css/mifi_plan_wrapper.d9cb9826.css"
  },
  {
    "revision": "2c4141890cd45c14e1e8",
    "url": "/js/mifi_plan_wrapper.f07f3c94.js"
  },
  {
    "revision": "0f74ab1033ebdddd803b",
    "url": "/css/new_card_wrapper.482349c9.css"
  },
  {
    "revision": "0f74ab1033ebdddd803b",
    "url": "/js/new_card_wrapper.367b7af0.js"
  },
  {
    "revision": "426f65b04246e14f173f",
    "url": "/css/orderRecord.d60dd42b.css"
  },
  {
    "revision": "426f65b04246e14f173f",
    "url": "/js/orderRecord.da04d237.js"
  },
  {
    "revision": "689617447994b2191d82",
    "url": "/css/plan_list.5be23c05.css"
  },
  {
    "revision": "689617447994b2191d82",
    "url": "/js/plan_list.b1f4df62.js"
  },
  {
    "revision": "99004e93ec1964d177eb",
    "url": "/css/question.dd51736b.css"
  },
  {
    "revision": "99004e93ec1964d177eb",
    "url": "/js/question.4627e242.js"
  },
  {
    "revision": "a599983f7395aebb61c6",
    "url": "/css/question_wrapper.fd3df4db.css"
  },
  {
    "revision": "a599983f7395aebb61c6",
    "url": "/js/question_wrapper.85cb8874.js"
  },
  {
    "revision": "a735cd41da73b283ca26",
    "url": "/css/realNameCourse.05b14cd2.css"
  },
  {
    "revision": "a735cd41da73b283ca26",
    "url": "/js/realNameCourse.8a8b21a0.js"
  },
  {
    "revision": "11c38f32068b6ea73ba0",
    "url": "/css/real_name.7e98b293.css"
  },
  {
    "revision": "11c38f32068b6ea73ba0",
    "url": "/js/real_name.9877b022.js"
  },
  {
    "revision": "b3c31b8dc078396b5629",
    "url": "/css/recharge.2a13ca8f.css"
  },
  {
    "revision": "b3c31b8dc078396b5629",
    "url": "/js/recharge.736142d8.js"
  },
  {
    "revision": "ecbdc2a310577fbb29b0",
    "url": "/css/rechargeOrder.72cc1c44.css"
  },
  {
    "revision": "ecbdc2a310577fbb29b0",
    "url": "/js/rechargeOrder.7a4027ac.js"
  },
  {
    "revision": "f931970b7c123d67a2d2",
    "url": "/css/recharge_balance.02c61443.css"
  },
  {
    "revision": "f931970b7c123d67a2d2",
    "url": "/js/recharge_balance.213645f4.js"
  },
  {
    "revision": "7a92c74db58d02a6008b",
    "url": "/css/recharge_callback.9a4944a2.css"
  },
  {
    "revision": "7a92c74db58d02a6008b",
    "url": "/js/recharge_callback.4d4600db.js"
  },
  {
    "revision": "092a0febd089a223a706",
    "url": "/css/recharge_wrapper.373da779.css"
  },
  {
    "revision": "092a0febd089a223a706",
    "url": "/js/recharge_wrapper.2b4459a9.js"
  },
  {
    "revision": "b47da50f055773f43901",
    "url": "/css/refundRules.60a3087c.css"
  },
  {
    "revision": "663e9f10825114a64de6",
    "url": "/js/Layout.4719e7e2.js"
  },
  {
    "revision": "f81644adfbfc7c4cdca2",
    "url": "/css/refund_applying.494b8573.css"
  },
  {
    "revision": "f81644adfbfc7c4cdca2",
    "url": "/js/refund_applying.178efd6e.js"
  },
  {
    "revision": "371c05b5b56c28b6f37c",
    "url": "/css/refund_argument.99ed8399.css"
  },
  {
    "revision": "371c05b5b56c28b6f37c",
    "url": "/js/refund_argument.b189e0b7.js"
  },
  {
    "revision": "aa5f556105ca4d876c34",
    "url": "/css/refund_plan.24cffd1a.css"
  },
  {
    "revision": "aa5f556105ca4d876c34",
    "url": "/js/refund_plan.1a712b7c.js"
  },
  {
    "revision": "7a29bce393471a7adeb0",
    "url": "/css/refund_wrapper.c537a243.css"
  },
  {
    "revision": "7a29bce393471a7adeb0",
    "url": "/js/refund_wrapper.da7e9861.js"
  },
  {
    "revision": "aefec259cf08c19567e0",
    "url": "/css/repeatRecharge.3fff9c06.css"
  },
  {
    "revision": "aefec259cf08c19567e0",
    "url": "/js/repeatRecharge.02ba2be3.js"
  },
  {
    "revision": "8f853d80dbf4b0089bcb",
    "url": "/css/revoke_plan.0ae10738.css"
  },
  {
    "revision": "8f853d80dbf4b0089bcb",
    "url": "/js/revoke_plan.3ecf3b1d.js"
  },
  {
    "revision": "b92341c0863dce9f3587",
    "url": "/css/speedup_500.51fe9728.css"
  },
  {
    "revision": "b92341c0863dce9f3587",
    "url": "/js/speedup_500.098de47e.js"
  },
  {
    "revision": "fa52664aee883ab7e53b",
    "url": "/css/speedup_80.f69a7633.css"
  },
  {
    "revision": "fa52664aee883ab7e53b",
    "url": "/js/speedup_80.b3b34434.js"
  },
  {
    "revision": "caef79234b389fdbb91a",
    "url": "/css/speedup_wrapper.016d9434.css"
  },
  {
    "revision": "caef79234b389fdbb91a",
    "url": "/js/speedup_wrapper.f9bf09e9.js"
  },
  {
    "revision": "b5c207ecd5896cf09238",
    "url": "/css/to_tb.8169aeee.css"
  },
  {
    "revision": "b5c207ecd5896cf09238",
    "url": "/js/to_tb.07228027.js"
  },
  {
    "revision": "ca5b7d0e625c6d09b3ca",
    "url": "/css/transfer_url.f5aabf1d.css"
  },
  {
    "revision": "ca5b7d0e625c6d09b3ca",
    "url": "/js/transfer_url.d0e2f5bb.js"
  },
  {
    "revision": "c4283452e70232f0e54e",
    "url": "/css/userCenter.63f51fec.css"
  },
  {
    "revision": "c4283452e70232f0e54e",
    "url": "/js/userCenter.b6d16efa.js"
  },
  {
    "revision": "2b40de105dbcc37bf184",
    "url": "/css/userCenterWrap.7b926a3e.css"
  },
  {
    "revision": "2b40de105dbcc37bf184",
    "url": "/js/userCenterWrap.6660e30d.js"
  },
  {
    "revision": "e4b411644706c29765eea3ffdd85ae39",
    "url": "/fonts/SourceHanSansCNRegular.e4b41164.woff"
  },
  {
    "revision": "834b022ab9ab0e6063904af32274e777",
    "url": "/fonts/SourceHanSansCNRegular.834b022a.eot"
  },
  {
    "revision": "f9509c5a10be7daaf1fa01922a7c6bc2",
    "url": "/fonts/SourceHanSansCNRegular.f9509c5a.ttf"
  },
  {
    "revision": "da0808e9fe85be160aab69c82dd8de1c",
    "url": "/img/SourceHanSansCNRegular.da0808e9.svg"
  },
  {
    "revision": "732389ded34cb9c52dd88271f1345af9",
    "url": "/fonts/element-icons.732389de.ttf"
  },
  {
    "revision": "535877f50039c0cb49a6196a5b7517cd",
    "url": "/fonts/element-icons.535877f5.woff"
  },
  {
    "revision": "0f16389ec218c90cf8f657e233b745f2",
    "url": "/img/balanceBg1.0f16389e.png"
  },
  {
    "revision": "565459ef2ee8b71db421144ad21c23e3",
    "url": "/img/balanceBg2.565459ef.png"
  },
  {
    "revision": "0078f03c08066d51d64b92a13e194ebb",
    "url": "/img/balanceRefund.0078f03c.png"
  },
  {
    "revision": "af3ed0b3236bbfdbc3ad61b8d41c3dec",
    "url": "/img/changeBg.af3ed0b3.png"
  },
  {
    "revision": "6dedd4943e4c5848638196fb6f0c4145",
    "url": "/img/bg.6dedd494.png"
  },
  {
    "revision": "fff5af4325410621aeec4e60b3b92d9b",
    "url": "/img/mifi_binding_bg@3x.fff5af43.png"
  },
  {
    "revision": "fff5af4325410621aeec4e60b3b92d9b",
    "url": "/img/mifi_binding_bg@2x.fff5af43.png"
  },
  {
    "revision": "91e1d2771efacd45e5e465d9a001f197",
    "url": "/img/liantong.91e1d277.png"
  },
  {
    "revision": "4a0cab0f33beb48ea985714d1b91fef7",
    "url": "/img/dianxin.4a0cab0f.png"
  },
  {
    "revision": "657033323334e91efb0011bbc18f8c04",
    "url": "/img/yidong.65703332.png"
  },
  {
    "revision": "8da3b83b73e44e54d6be4b2522bcb1f2",
    "url": "/img/pkgBg2.8da3b83b.png"
  },
  {
    "revision": "d3b42651f9f5048baeffb50c800913ec",
    "url": "/img/pkgBg1.d3b42651.png"
  },
  {
    "revision": "d461d18e42a310bd709b2ce97d159153",
    "url": "/img/pkgBg3.d461d18e.png"
  },
  {
    "revision": "fa855242805b87da42c65763acd64ac0",
    "url": "/img/bg-plan-type@2x.fa855242.png"
  },
  {
    "revision": "4a9ca192485effa8b8f4b5b2df5b9caf",
    "url": "/img/bg-plan-type@3x.4a9ca192.png"
  },
  {
    "revision": "cc0636ca2944024fd3ebf33a5412ff35",
    "url": "/img/icon-right@3x.cc0636ca.png"
  },
  {
    "revision": "1b983020cfed6b7a8ca5c300c24ca186",
    "url": "/img/icon-left@3x.1b983020.png"
  },
  {
    "revision": "d796d97eb9ebb2e89bb966343e2362e9",
    "url": "/img/icon-left@2x.d796d97e.png"
  },
  {
    "revision": "ccb9865dadbc642b8c4dd0a1abc8e570",
    "url": "/img/recharge-word@2x.ccb9865d.png"
  },
  {
    "revision": "ccb9865dadbc642b8c4dd0a1abc8e570",
    "url": "/img/recharge-word@3x.ccb9865d.png"
  },
  {
    "revision": "41a8c268f703fe646d5d08099eb778ae",
    "url": "/img/icon-right@2x.41a8c268.png"
  },
  {
    "revision": "2d6d06f4da15fc1a748677c49c5f1854",
    "url": "/img/bg.2d6d06f4.png"
  },
  {
    "revision": "b899232b79ad9962c5ab5572775a0400",
    "url": "/img/card_index_bg@3x.b899232b.png"
  },
  {
    "revision": "b899232b79ad9962c5ab5572775a0400",
    "url": "/img/card_index_bg@2x.b899232b.png"
  },
  {
    "revision": "f5f322478286641bd9887a155e35f222",
    "url": "/img/btn.f5f32247.png"
  },
  {
    "revision": "d140650fa64e0f1fc771610dba62aed7",
    "url": "/img/bg.d140650f.png"
  },
  {
    "revision": "e625229e32d9deeb5f2909c314d8e609",
    "url": "/img/ios@2x.e625229e.png"
  },
  {
    "revision": "af8bbdfa0a90c4eed4563f8c06ce5ff8",
    "url": "/img/android@2x.af8bbdfa.png"
  },
  {
    "revision": "1d7515ee61c3f659227318b4050955ed",
    "url": "/img/mobile_sim@2x.1d7515ee.png"
  },
  {
    "revision": "0f980b79d9a52702004de9f652a68835",
    "url": "/img/telcom_sim@2x.0f980b79.png"
  },
  {
    "revision": "98141226a7e992e3072a280746a259c4",
    "url": "/img/mobile_sim@3x.98141226.png"
  },
  {
    "revision": "0c88168b284b92c37f3a873f26a97d69",
    "url": "/img/bg.0c88168b.jpg"
  },
  {
    "revision": "9e02095f31a07b972244f1c714c1dfe7",
    "url": "/img/telcom_sim@3x.9e02095f.png"
  },
  {
    "revision": "6e5cee7393060b0ec3dcd587c2518b94",
    "url": "/img/bg_test.6e5cee73.png"
  },
  {
    "revision": "2a67b73145562669220aa4639e1ad58f",
    "url": "/img/icon3.2a67b731.png"
  },
  {
    "revision": "813b5319e378dafdda952c16ad89906b",
    "url": "/img/icon2.813b5319.png"
  },
  {
    "revision": "014d354b9b25b67ae95857ba17e2f4cc",
    "url": "/img/activityPage.014d354b.png"
  },
  {
    "revision": "3f342771b9b81ab929e0fbcbcd0e6533",
    "url": "/img/bg-check-wrap@3x.3f342771.png"
  },
  {
    "revision": "9713b21819c4019befecd095069977df",
    "url": "/img/bg-check-wrap@2x.9713b218.png"
  },
  {
    "revision": "3d0fc424b703032ca595090e99f8354b",
    "url": "/img/login_bg@2x.3d0fc424.png"
  },
  {
    "revision": "11000d4e510a6df565eb69ba6f2c1dfc",
    "url": "/img/login_bg@3x.11000d4e.png"
  },
  {
    "revision": "f40c7e0b20fe25eb78a7658c3ae56312",
    "url": "/img/noData@3x.f40c7e0b.png"
  },
  {
    "revision": "644e6e3cf5f33943747b116316694e28",
    "url": "/img/noData@2x.644e6e3c.png"
  },
  {
    "revision": "42c0fbd4915870e5e60452fd0ef2cbec",
    "url": "/img/orderTopBg@3x.42c0fbd4.png"
  },
  {
    "revision": "42c0fbd4915870e5e60452fd0ef2cbec",
    "url": "/img/orderTopBg@2x.42c0fbd4.png"
  },
  {
    "revision": "01355f175bd20423ce45a838c1a998a9",
    "url": "/img/bg.01355f17.png"
  },
  {
    "revision": "d0ccbc8a35180bb40e027b44dd26035a",
    "url": "/img/youku.d0ccbc8a.png"
  },
  {
    "revision": "a859e9ca4606d567c42b9c7bcd4fdce9",
    "url": "/img/iccid_bg@2x.a859e9ca.png"
  },
  {
    "revision": "fa9050c4e9870e8fc0cd184f8515af4a",
    "url": "/img/iccid_bg@3x.fa9050c4.png"
  },
  {
    "revision": "2c51a1e53c1ea0b35086d8d7261b4933",
    "url": "/img/bg_network@3x.2c51a1e5.png"
  },
  {
    "revision": "32d70c8fc305e3647098f3de0c71b618",
    "url": "/img/bg_network@2x.32d70c8f.png"
  },
  {
    "revision": "114a6e12b42b9b48586dd341105188fe",
    "url": "/img/usedOrder@2x.114a6e12.png"
  },
  {
    "revision": "c0170ec299b2418256fd515ee7849055",
    "url": "/img/unUsedOrder@2x.c0170ec2.png"
  },
  {
    "revision": "d9e14058d30dd312519fcf2de38d742b",
    "url": "/img/unUsedOrder@3x.d9e14058.png"
  },
  {
    "revision": "4a5b90f8076955f289b3dcda6a5af6ff",
    "url": "/img/invaildedOrder@3x.4a5b90f8.png"
  },
  {
    "revision": "0d5a5158e67bcb7a4604124715ed6fbf",
    "url": "/img/usedOrder@3x.0d5a5158.png"
  },
  {
    "revision": "be0f1e33b2553e71b117d3d3f838d32f",
    "url": "/img/invaildedOrder@2x.be0f1e33.png"
  },
  {
    "revision": "3603a35a49dbb8ad94ec1e57c4dad229",
    "url": "/img/scanTop2.3603a35a.png"
  },
  {
    "revision": "05775dd69c53d7273b27aaa7c6c523f7",
    "url": "/img/04.05775dd6.png"
  },
  {
    "revision": "58a560568b7291ea926c2c7438035308",
    "url": "/img/subscribe@3x.58a56056.png"
  },
  {
    "revision": "541375e6bb7db2fba9e415be8045f5fb",
    "url": "/img/1.541375e6.png"
  },
  {
    "revision": "7c28431d304fa4f58f5070c59720683a",
    "url": "/img/2.7c28431d.png"
  },
  {
    "revision": "5a3428653945c17e1c146efeee81c987",
    "url": "/img/scanTop.5a342865.png"
  },
  {
    "revision": "824594523c01e48028f2b7eb4261134d",
    "url": "/img/unicom-logo.82459452.svg"
  },
  {
    "revision": "113f99e2189c2ca49db2168754fc2eb5",
    "url": "/img/mobile-logo.113f99e2.png"
  },
  {
    "revision": "0cba868fa977e09806638b9000636a36",
    "url": "/img/avatar.0cba868f.jpeg"
  },
  {
    "revision": "27158aa79eb0d4b89f317d076a801ca3",
    "url": "/img/coupon-log.27158aa7.png"
  },
  {
    "revision": "55d3f2f09efe17db6485d4c9f8f0c3b1",
    "url": "/img/icon-recharge_20181001.55d3f2f0.svg"
  },
  {
    "revision": "165beb68d8ba0d2b70df0fbb3769787a",
    "url": "/img/03.165beb68.png"
  },
  {
    "revision": "5f1f34037094c0613bccafa2ddd8cb3b",
    "url": "/img/telecom-logo.5f1f3403.svg"
  },
  {
    "revision": "f7a51f1c554585b11d61499fd0a7520f",
    "url": "/img/only-box@3x.f7a51f1c.png"
  },
  {
    "revision": "0b3c3297decbd1152a314cce115f9632",
    "url": "/img/09.0b3c3297.png"
  },
  {
    "revision": "3e217df4202e41ad9b030aafc8cfcc24",
    "url": "/img/4.3e217df4.png"
  },
  {
    "revision": "aecc9531f2c3b1fd45338e7bf5084384",
    "url": "/img/bg_no_recharge.aecc9531.svg"
  },
  {
    "revision": "b0ffa4a0fd195a110ee4d4dabce3bc32",
    "url": "/img/08.b0ffa4a0.png"
  },
  {
    "revision": "96fab583abd57f2e7118324858fa3080",
    "url": "/img/05.96fab583.png"
  },
  {
    "revision": "9e8ecc7f7b760b55c56bddfab886da10",
    "url": "/img/3.9e8ecc7f.png"
  },
  {
    "revision": "275be51ae57c486bce58257febd6589f",
    "url": "/img/bg_no_plan.275be51a.svg"
  },
  {
    "revision": "a8272d2d742d9d50257e23dfac577def",
    "url": "/img/01.a8272d2d.png"
  },
  {
    "revision": "daa86b540bb9c2a6453ceac9bed77961",
    "url": "/img/07.daa86b54.png"
  },
  {
    "revision": "687b6ce03f134f21173c949d79002960",
    "url": "/img/tip.687b6ce0.png"
  },
  {
    "revision": "a610420eab741be28278e60bc06387aa",
    "url": "/img/box-deco@3x.a610420e.png"
  },
  {
    "revision": "eacba58f9acf2b87cd801858146b2ba9",
    "url": "/img/02.eacba58f.png"
  },
  {
    "revision": "39d9e849fc1c724525f166646932a24d",
    "url": "/img/safari.39d9e849.png"
  },
  {
    "revision": "999589aae784a460b5e7c6ae9bbaa3d8",
    "url": "/img/06.999589aa.png"
  },
  {
    "revision": "d5440bbd6de6ae8508126daf0557cd8a",
    "url": "/index.html"
  },
  {
    "revision": "b6216d61c03e6ce0c9aea6ca7808f7ca",
    "url": "/robots.txt"
  },
  {
    "revision": "9ce16f441b39b493af8b96d7e97cce22",
    "url": "/MP_verify_dkzAKjxyVyJvsHMS.txt"
  },
  {
    "revision": "86c422d8c98b247235d04b49fb1c4b05",
    "url": "/MP_verify_bKSdn2qZlUSULliu.txt"
  },
  {
    "revision": "652317b098ca24e4511926c7fd57cbbe",
    "url": "/MP_verify_8JoCCldW78DygS5c.txt"
  },
  {
    "revision": "00bbf6b458bf7ea6bd01f443eb3045d9",
    "url": "/MP_verify_4r3DVk3KUjgWsQsG.txt"
  }
];