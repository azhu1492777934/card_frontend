self.__precacheManifest = [
  {
    "revision": "81f6884079aa36b007e7",
    "url": "/css/refund_argument.69661661.css"
  },
  {
    "revision": "b6216d61c03e6ce0c9aea6ca7808f7ca",
    "url": "/robots.txt"
  },
  {
    "revision": "81f6884079aa36b007e7",
    "url": "/js/refund_argument.350e4fa4.js"
  },
  {
    "revision": "027792dc829adca5c107",
    "url": "/css/Layout~card_usage.b14570df.css"
  },
  {
    "revision": "78214ba34c5f1df936aa",
    "url": "/js/Layout~card_usage~eqReplaceMent~esim_plan_list~esim_usage~mifi_order~mifi_plan_list~mifi_plan_usage~~c6f87c36.6241bd21.js"
  },
  {
    "revision": "33bc8d7c0421214121c0",
    "url": "/css/Not_fund.441b338e.css"
  },
  {
    "revision": "33bc8d7c0421214121c0",
    "url": "/js/Not_fund.a6629d31.js"
  },
  {
    "revision": "622f873b241cc0cbf6ff",
    "url": "/css/addSalesRecords.6d02243a.css"
  },
  {
    "revision": "622f873b241cc0cbf6ff",
    "url": "/js/addSalesRecords.f9603965.js"
  },
  {
    "revision": "68d4a2e20d6fec4d5384",
    "url": "/css/app.9569c332.css"
  },
  {
    "revision": "68d4a2e20d6fec4d5384",
    "url": "/js/app.9b016f05.js"
  },
  {
    "revision": "a618aa5c3728c6857cea",
    "url": "/css/authority_middle.4be2bf2b.css"
  },
  {
    "revision": "a618aa5c3728c6857cea",
    "url": "/js/authority_middle.04ea2933.js"
  },
  {
    "revision": "1833f1382804bd785f33",
    "url": "/css/card_check.821d897a.css"
  },
  {
    "revision": "1833f1382804bd785f33",
    "url": "/js/card_check.ffdce633.js"
  },
  {
    "revision": "6abfec697671e6b3bf69",
    "url": "/css/card_connection.0c0041ec.css"
  },
  {
    "revision": "6abfec697671e6b3bf69",
    "url": "/js/card_connection.5047064d.js"
  },
  {
    "revision": "83cc55bffeb772dcda73",
    "url": "/css/card_lookup.c51a6e31.css"
  },
  {
    "revision": "83cc55bffeb772dcda73",
    "url": "/js/card_lookup.c7a130e1.js"
  },
  {
    "revision": "fb29146502cb28005030",
    "url": "/css/card_usage.f4f44e8c.css"
  },
  {
    "revision": "fb29146502cb28005030",
    "url": "/js/card_usage.eec65574.js"
  },
  {
    "revision": "a55e48fcda6c116400b4",
    "url": "/css/card_wrapper.ab43c2ce.css"
  },
  {
    "revision": "a55e48fcda6c116400b4",
    "url": "/js/card_wrapper.e6eee6c6.js"
  },
  {
    "revision": "81fa1d4a47137c2c6185",
    "url": "/css/children_card.3914f072.css"
  },
  {
    "revision": "81fa1d4a47137c2c6185",
    "url": "/js/children_card.e44de455.js"
  },
  {
    "revision": "45a590ab44d9ddb8ab46",
    "url": "/css/chunk-369468f2.950f239c.css"
  },
  {
    "revision": "45a590ab44d9ddb8ab46",
    "url": "/js/chunk-369468f2.fcb318e7.js"
  },
  {
    "revision": "36ad47a07c94f5d86454",
    "url": "/css/chunk-67169821.479f5e40.css"
  },
  {
    "revision": "36ad47a07c94f5d86454",
    "url": "/js/chunk-67169821.27319cc5.js"
  },
  {
    "revision": "87b50cb548f53f31c0b3",
    "url": "/css/chunk-vendors.65b4eea2.css"
  },
  {
    "revision": "87b50cb548f53f31c0b3",
    "url": "/js/chunk-vendors.300e6fcf.js"
  },
  {
    "revision": "7d92b54cc15ed0ae222b",
    "url": "/css/commonProblem.a6a75547.css"
  },
  {
    "revision": "7d92b54cc15ed0ae222b",
    "url": "/js/commonProblem.d5097fca.js"
  },
  {
    "revision": "df085814535c3e934719",
    "url": "/css/contactUs.6dd443fe.css"
  },
  {
    "revision": "df085814535c3e934719",
    "url": "/js/contactUs.522cac33.js"
  },
  {
    "revision": "23352b7d285a7565d120",
    "url": "/css/coupon_normal.94c7ba55.css"
  },
  {
    "revision": "23352b7d285a7565d120",
    "url": "/js/coupon_normal.e40ac141.js"
  },
  {
    "revision": "1c3ce6b90affe1918295",
    "url": "/css/coupon_telcom.72ee0bc0.css"
  },
  {
    "revision": "1c3ce6b90affe1918295",
    "url": "/js/coupon_telcom.c3c3f0a6.js"
  },
  {
    "revision": "3d29be284addf9ff5036",
    "url": "/css/coupon_wrapper.31258838.css"
  },
  {
    "revision": "3d29be284addf9ff5036",
    "url": "/js/coupon_wrapper.c1c14448.js"
  },
  {
    "revision": "c98aec8a3bcdd1168605",
    "url": "/css/eqReplaceMent.b89ff1f1.css"
  },
  {
    "revision": "c98aec8a3bcdd1168605",
    "url": "/js/eqReplaceMent.5106f0e2.js"
  },
  {
    "revision": "3678ad90ed35a5b72396",
    "url": "/css/esim_plan_list.dd5ebe89.css"
  },
  {
    "revision": "3678ad90ed35a5b72396",
    "url": "/js/esim_plan_list.b094d728.js"
  },
  {
    "revision": "f1a6f5b687604e532203",
    "url": "/css/esim_usage.12335cce.css"
  },
  {
    "revision": "f1a6f5b687604e532203",
    "url": "/js/esim_usage.e570e70c.js"
  },
  {
    "revision": "0e12283a2a360fe66a4a",
    "url": "/css/find_plan.76e7741d.css"
  },
  {
    "revision": "0e12283a2a360fe66a4a",
    "url": "/js/find_plan.4efe677a.js"
  },
  {
    "revision": "bb5d7744ceaa97aa5622",
    "url": "/css/helpCenter.f896daa5.css"
  },
  {
    "revision": "bb5d7744ceaa97aa5622",
    "url": "/js/helpCenter.9e562127.js"
  },
  {
    "revision": "ebf281747123702454db",
    "url": "/css/logical_page.b1840a87.css"
  },
  {
    "revision": "ebf281747123702454db",
    "url": "/js/logical_page.63a74246.js"
  },
  {
    "revision": "e818d84bf7e1d8165cd1",
    "url": "/css/login.4264115c.css"
  },
  {
    "revision": "e818d84bf7e1d8165cd1",
    "url": "/js/login.b33c53d6.js"
  },
  {
    "revision": "726343e8119cce824826",
    "url": "/css/lookup.a0fdfe26.css"
  },
  {
    "revision": "726343e8119cce824826",
    "url": "/js/lookup.9003e5be.js"
  },
  {
    "revision": "1cd69af4e65da644a0ed",
    "url": "/css/mifi_binding.cdce645f.css"
  },
  {
    "revision": "1cd69af4e65da644a0ed",
    "url": "/js/mifi_binding.588aa456.js"
  },
  {
    "revision": "696e2ffb04c13325bf0b",
    "url": "/css/mifi_card_info.85a16a58.css"
  },
  {
    "revision": "696e2ffb04c13325bf0b",
    "url": "/js/mifi_card_info.491b1b60.js"
  },
  {
    "revision": "02e9b92a99f82ed3ed5c",
    "url": "/css/mifi_card_lookup.e452473b.css"
  },
  {
    "revision": "02e9b92a99f82ed3ed5c",
    "url": "/js/mifi_card_lookup.dbf3668b.js"
  },
  {
    "revision": "ea0397017a8f773eef8a",
    "url": "/css/mifi_card_wrapper.9134afdd.css"
  },
  {
    "revision": "ea0397017a8f773eef8a",
    "url": "/js/mifi_card_wrapper.8d1acc0c.js"
  },
  {
    "revision": "df75349bb9a041b46d6b",
    "url": "/css/mifi_change_network.d9e7e832.css"
  },
  {
    "revision": "df75349bb9a041b46d6b",
    "url": "/js/mifi_change_network.835de2d1.js"
  },
  {
    "revision": "ebe11284316f8b38e1df",
    "url": "/css/mifi_coupon_index.64e0f7c2.css"
  },
  {
    "revision": "ebe11284316f8b38e1df",
    "url": "/js/mifi_coupon_index.c2406973.js"
  },
  {
    "revision": "ea994b4592c341a64f14",
    "url": "/css/mifi_coupon_wrapper.8b393e56.css"
  },
  {
    "revision": "ea994b4592c341a64f14",
    "url": "/js/mifi_coupon_wrapper.eca902c1.js"
  },
  {
    "revision": "1df65be0b6c27865e27b",
    "url": "/css/mifi_index.8a6bbcdc.css"
  },
  {
    "revision": "1df65be0b6c27865e27b",
    "url": "/js/mifi_index.2d6bc016.js"
  },
  {
    "revision": "5e889995031badf5b78e",
    "url": "/css/mifi_layout.f4f77616.css"
  },
  {
    "revision": "5e889995031badf5b78e",
    "url": "/js/mifi_layout.9d347e7d.js"
  },
  {
    "revision": "505070a31448ed69be34",
    "url": "/css/mifi_order.73477860.css"
  },
  {
    "revision": "505070a31448ed69be34",
    "url": "/js/mifi_order.d61b805d.js"
  },
  {
    "revision": "9d35cfac4afd5c4afecf",
    "url": "/css/mifi_order_wrapper.d572d9dd.css"
  },
  {
    "revision": "9d35cfac4afd5c4afecf",
    "url": "/js/mifi_order_wrapper.9f3cb832.js"
  },
  {
    "revision": "4e21badea30efdb29b2b",
    "url": "/css/mifi_order~mifi_plan_group.87f23bce.css"
  },
  {
    "revision": "4e21badea30efdb29b2b",
    "url": "/js/mifi_order~mifi_plan_group.c2d4e515.js"
  },
  {
    "revision": "6123f54b833fc298f016",
    "url": "/css/mifi_plan_group.a48c0f41.css"
  },
  {
    "revision": "6123f54b833fc298f016",
    "url": "/js/mifi_plan_group.73f6439c.js"
  },
  {
    "revision": "b7c14daf48db4f5d0d33",
    "url": "/css/mifi_plan_list.fc75e35a.css"
  },
  {
    "revision": "b7c14daf48db4f5d0d33",
    "url": "/js/mifi_plan_list.877c0a62.js"
  },
  {
    "revision": "7b69dece28a21fa2d2ab",
    "url": "/css/mifi_plan_usage.e81e492c.css"
  },
  {
    "revision": "7b69dece28a21fa2d2ab",
    "url": "/js/mifi_plan_usage.a39137c4.js"
  },
  {
    "revision": "2aceb9979f5c7596abba",
    "url": "/css/mifi_plan_wrapper.ad5b72f4.css"
  },
  {
    "revision": "2aceb9979f5c7596abba",
    "url": "/js/mifi_plan_wrapper.fd737b35.js"
  },
  {
    "revision": "139cf8d7765bde2f6eda",
    "url": "/css/new_card_wrapper.907108b0.css"
  },
  {
    "revision": "139cf8d7765bde2f6eda",
    "url": "/js/new_card_wrapper.58d4a208.js"
  },
  {
    "revision": "32b7f8f45c062b1acfcc",
    "url": "/css/plan_list.066e233a.css"
  },
  {
    "revision": "32b7f8f45c062b1acfcc",
    "url": "/js/plan_list.c90b2974.js"
  },
  {
    "revision": "d21af5c92edcf062279a",
    "url": "/css/question.a71b7295.css"
  },
  {
    "revision": "d21af5c92edcf062279a",
    "url": "/js/question.265a60c9.js"
  },
  {
    "revision": "a06f700330835789736e",
    "url": "/css/question_wrapper.09148f29.css"
  },
  {
    "revision": "a06f700330835789736e",
    "url": "/js/question_wrapper.e8fa6249.js"
  },
  {
    "revision": "040d771adb33de82bfed",
    "url": "/css/realName.8aaacb67.css"
  },
  {
    "revision": "040d771adb33de82bfed",
    "url": "/js/realName.aa4bee56.js"
  },
  {
    "revision": "c0a890d6e174659de255",
    "url": "/css/realNameCourse.c4765d59.css"
  },
  {
    "revision": "c0a890d6e174659de255",
    "url": "/js/realNameCourse.1f2f7c45.js"
  },
  {
    "revision": "684bfee52e0e8e58b2aa",
    "url": "/css/real_name.a085e3fd.css"
  },
  {
    "revision": "684bfee52e0e8e58b2aa",
    "url": "/js/real_name.e2a029ab.js"
  },
  {
    "revision": "44c2939414b1a7100282",
    "url": "/css/recharge.a51e2c50.css"
  },
  {
    "revision": "44c2939414b1a7100282",
    "url": "/js/recharge.d4a468c5.js"
  },
  {
    "revision": "f8c1d8d14ab2be8ce496",
    "url": "/css/rechargeRecord.04310af2.css"
  },
  {
    "revision": "f8c1d8d14ab2be8ce496",
    "url": "/js/rechargeRecord.3c0d72b3.js"
  },
  {
    "revision": "e713484558d26387b6b2",
    "url": "/css/recharge_callback.4776b260.css"
  },
  {
    "revision": "e713484558d26387b6b2",
    "url": "/js/recharge_callback.d8d3feaa.js"
  },
  {
    "revision": "9feffacd2b7a96a33fbf",
    "url": "/css/recharge_wrapper.61f8e218.css"
  },
  {
    "revision": "9feffacd2b7a96a33fbf",
    "url": "/js/recharge_wrapper.9aba0f17.js"
  },
  {
    "revision": "3522f10ed5d1f896680b",
    "url": "/css/refund_applying.061bfa50.css"
  },
  {
    "revision": "3522f10ed5d1f896680b",
    "url": "/js/refund_applying.70359a0f.js"
  },
  {
    "revision": "cd23e78acef76fcea996",
    "url": "/js/Layout.ee58c60a.js"
  },
  {
    "revision": "027792dc829adca5c107",
    "url": "/js/Layout~card_usage.93dd209b.js"
  },
  {
    "revision": "2fcbfc4de2f2ceae0a60",
    "url": "/css/refund_plan.f7233d6c.css"
  },
  {
    "revision": "2fcbfc4de2f2ceae0a60",
    "url": "/js/refund_plan.e5b40bb4.js"
  },
  {
    "revision": "18f3a926060dcd5647ed",
    "url": "/css/refund_wrapper.2ce7ebad.css"
  },
  {
    "revision": "18f3a926060dcd5647ed",
    "url": "/js/refund_wrapper.4b26b5da.js"
  },
  {
    "revision": "ae5c8a90a8a3ffc80817",
    "url": "/css/repeatRecharge.2680328c.css"
  },
  {
    "revision": "ae5c8a90a8a3ffc80817",
    "url": "/js/repeatRecharge.db6ae8fd.js"
  },
  {
    "revision": "403a5ad965f9e0da4024",
    "url": "/css/revoke_plan.a3113be3.css"
  },
  {
    "revision": "403a5ad965f9e0da4024",
    "url": "/js/revoke_plan.eca5dc8c.js"
  },
  {
    "revision": "46bfbeb3c30a5a2edde8",
    "url": "/css/salesRecords.08560fe2.css"
  },
  {
    "revision": "46bfbeb3c30a5a2edde8",
    "url": "/js/salesRecords.b20967b1.js"
  },
  {
    "revision": "21455d3cdd4ff0482ed3",
    "url": "/css/speedup_500.863f4cd3.css"
  },
  {
    "revision": "21455d3cdd4ff0482ed3",
    "url": "/js/speedup_500.e4aa6107.js"
  },
  {
    "revision": "a02f135fce033bd09d69",
    "url": "/css/speedup_80.d0292630.css"
  },
  {
    "revision": "a02f135fce033bd09d69",
    "url": "/js/speedup_80.0712a5e5.js"
  },
  {
    "revision": "e8e646590c22cdecfe1f",
    "url": "/css/speedup_wrapper.69b3dda0.css"
  },
  {
    "revision": "e8e646590c22cdecfe1f",
    "url": "/js/speedup_wrapper.27f3dbaf.js"
  },
  {
    "revision": "be25eba308641ea1c4e4",
    "url": "/css/to_tb.96081c85.css"
  },
  {
    "revision": "be25eba308641ea1c4e4",
    "url": "/js/to_tb.9319ee92.js"
  },
  {
    "revision": "e2b72f801eed907c247c",
    "url": "/css/transfer_url.3a93c9e6.css"
  },
  {
    "revision": "e2b72f801eed907c247c",
    "url": "/js/transfer_url.ae00fbcb.js"
  },
  {
    "revision": "48cbfe519e5c27339a7d",
    "url": "/css/userCenter.a6850530.css"
  },
  {
    "revision": "48cbfe519e5c27339a7d",
    "url": "/js/userCenter.f22c3a1e.js"
  },
  {
    "revision": "52d2acbdcfc5e17c2cbf",
    "url": "/css/userCenterAddress.6487c368.css"
  },
  {
    "revision": "52d2acbdcfc5e17c2cbf",
    "url": "/js/userCenterAddress.3b236656.js"
  },
  {
    "revision": "0a99800e56433deba8a1",
    "url": "/css/userCenterWrap.a2d7e1e3.css"
  },
  {
    "revision": "0a99800e56433deba8a1",
    "url": "/js/userCenterWrap.e36f77df.js"
  },
  {
    "revision": "e4b411644706c29765eea3ffdd85ae39",
    "url": "/fonts/SourceHanSansCNRegular.e4b41164.woff"
  },
  {
    "revision": "834b022ab9ab0e6063904af32274e777",
    "url": "/fonts/SourceHanSansCNRegular.834b022a.eot"
  },
  {
    "revision": "f9509c5a10be7daaf1fa01922a7c6bc2",
    "url": "/fonts/SourceHanSansCNRegular.f9509c5a.ttf"
  },
  {
    "revision": "da0808e9fe85be160aab69c82dd8de1c",
    "url": "/img/SourceHanSansCNRegular.da0808e9.svg"
  },
  {
    "revision": "732389ded34cb9c52dd88271f1345af9",
    "url": "/fonts/element-icons.732389de.ttf"
  },
  {
    "revision": "535877f50039c0cb49a6196a5b7517cd",
    "url": "/fonts/element-icons.535877f5.woff"
  },
  {
    "revision": "ad4acc3d7da28ce6f33925b83bae2c94",
    "url": "/img/arrow1.ad4acc3d.png"
  },
  {
    "revision": "42c0fbd4915870e5e60452fd0ef2cbec",
    "url": "/img/orderTopBg@3x.42c0fbd4.png"
  },
  {
    "revision": "42c0fbd4915870e5e60452fd0ef2cbec",
    "url": "/img/orderTopBg@2x.42c0fbd4.png"
  },
  {
    "revision": "fff5af4325410621aeec4e60b3b92d9b",
    "url": "/img/mifi_binding_bg@3x.fff5af43.png"
  },
  {
    "revision": "fff5af4325410621aeec4e60b3b92d9b",
    "url": "/img/mifi_binding_bg@2x.fff5af43.png"
  },
  {
    "revision": "a1386d312938b126d701a6841fb742e8",
    "url": "/img/addressIcon.a1386d31.png"
  },
  {
    "revision": "83d0cd2dc163e83ef26f6bad98661da8",
    "url": "/img/addressBg.83d0cd2d.png"
  },
  {
    "revision": "a859e9ca4606d567c42b9c7bcd4fdce9",
    "url": "/img/iccid_bg@2x.a859e9ca.png"
  },
  {
    "revision": "fa9050c4e9870e8fc0cd184f8515af4a",
    "url": "/img/iccid_bg@3x.fa9050c4.png"
  },
  {
    "revision": "f5f322478286641bd9887a155e35f222",
    "url": "/img/btn.f5f32247.png"
  },
  {
    "revision": "d140650fa64e0f1fc771610dba62aed7",
    "url": "/img/bg.d140650f.png"
  },
  {
    "revision": "6e5cee7393060b0ec3dcd587c2518b94",
    "url": "/img/bg_test.6e5cee73.png"
  },
  {
    "revision": "b899232b79ad9962c5ab5572775a0400",
    "url": "/img/card_index_bg@3x.b899232b.png"
  },
  {
    "revision": "b899232b79ad9962c5ab5572775a0400",
    "url": "/img/card_index_bg@2x.b899232b.png"
  },
  {
    "revision": "2c51a1e53c1ea0b35086d8d7261b4933",
    "url": "/img/bg_network@3x.2c51a1e5.png"
  },
  {
    "revision": "32d70c8fc305e3647098f3de0c71b618",
    "url": "/img/bg_network@2x.32d70c8f.png"
  },
  {
    "revision": "e625229e32d9deeb5f2909c314d8e609",
    "url": "/img/ios@2x.e625229e.png"
  },
  {
    "revision": "af8bbdfa0a90c4eed4563f8c06ce5ff8",
    "url": "/img/android@2x.af8bbdfa.png"
  },
  {
    "revision": "d32e5dc3875f1afd2be29aad1cfd0382",
    "url": "/img/contactBg.d32e5dc3.png"
  },
  {
    "revision": "3f342771b9b81ab929e0fbcbcd0e6533",
    "url": "/img/bg-check-wrap@3x.3f342771.png"
  },
  {
    "revision": "9713b21819c4019befecd095069977df",
    "url": "/img/bg-check-wrap@2x.9713b218.png"
  },
  {
    "revision": "1d7515ee61c3f659227318b4050955ed",
    "url": "/img/mobile_sim@2x.1d7515ee.png"
  },
  {
    "revision": "0f980b79d9a52702004de9f652a68835",
    "url": "/img/telcom_sim@2x.0f980b79.png"
  },
  {
    "revision": "98141226a7e992e3072a280746a259c4",
    "url": "/img/mobile_sim@3x.98141226.png"
  },
  {
    "revision": "0c88168b284b92c37f3a873f26a97d69",
    "url": "/img/bg.0c88168b.jpg"
  },
  {
    "revision": "9e02095f31a07b972244f1c714c1dfe7",
    "url": "/img/telcom_sim@3x.9e02095f.png"
  },
  {
    "revision": "b70eddccd257b21777e71bb64c83b876",
    "url": "/img/bg.b70eddcc.jpeg"
  },
  {
    "revision": "909816c3d34e63a9ad86b8c179ab543c",
    "url": "/img/bar.909816c3.png"
  },
  {
    "revision": "e92f547ba0209da3b4342fa2b56ea9ae",
    "url": "/img/animater.e92f547b.png"
  },
  {
    "revision": "114a6e12b42b9b48586dd341105188fe",
    "url": "/img/usedOrder@2x.114a6e12.png"
  },
  {
    "revision": "c0170ec299b2418256fd515ee7849055",
    "url": "/img/unUsedOrder@2x.c0170ec2.png"
  },
  {
    "revision": "d9e14058d30dd312519fcf2de38d742b",
    "url": "/img/unUsedOrder@3x.d9e14058.png"
  },
  {
    "revision": "4a5b90f8076955f289b3dcda6a5af6ff",
    "url": "/img/invaildedOrder@3x.4a5b90f8.png"
  },
  {
    "revision": "0d5a5158e67bcb7a4604124715ed6fbf",
    "url": "/img/usedOrder@3x.0d5a5158.png"
  },
  {
    "revision": "be0f1e33b2553e71b117d3d3f838d32f",
    "url": "/img/invaildedOrder@2x.be0f1e33.png"
  },
  {
    "revision": "3d0fc424b703032ca595090e99f8354b",
    "url": "/img/login_bg@2x.3d0fc424.png"
  },
  {
    "revision": "11000d4e510a6df565eb69ba6f2c1dfc",
    "url": "/img/login_bg@3x.11000d4e.png"
  },
  {
    "revision": "014d354b9b25b67ae95857ba17e2f4cc",
    "url": "/img/activityPage.014d354b.png"
  },
  {
    "revision": "2a67b73145562669220aa4639e1ad58f",
    "url": "/img/icon3.2a67b731.png"
  },
  {
    "revision": "813b5319e378dafdda952c16ad89906b",
    "url": "/img/icon2.813b5319.png"
  },
  {
    "revision": "01355f175bd20423ce45a838c1a998a9",
    "url": "/img/bg.01355f17.png"
  },
  {
    "revision": "6eb1cce5bab9ec1cb25d71e8f3110a15",
    "url": "/img/real7.6eb1cce5.jpeg"
  },
  {
    "revision": "3603a35a49dbb8ad94ec1e57c4dad229",
    "url": "/img/scanTop2.3603a35a.png"
  },
  {
    "revision": "b74ee4a485ffa8d4339c3412ac6659be",
    "url": "/img/real6.b74ee4a4.jpeg"
  },
  {
    "revision": "05775dd69c53d7273b27aaa7c6c523f7",
    "url": "/img/04.05775dd6.png"
  },
  {
    "revision": "5a3428653945c17e1c146efeee81c987",
    "url": "/img/scanTop.5a342865.png"
  },
  {
    "revision": "824594523c01e48028f2b7eb4261134d",
    "url": "/img/unicom-logo.82459452.svg"
  },
  {
    "revision": "113f99e2189c2ca49db2168754fc2eb5",
    "url": "/img/mobile-logo.113f99e2.png"
  },
  {
    "revision": "0cba868fa977e09806638b9000636a36",
    "url": "/img/avatar.0cba868f.jpeg"
  },
  {
    "revision": "a5b636104342050950abea60fb65f9cd",
    "url": "/img/qrImg.a5b63610.png"
  },
  {
    "revision": "27158aa79eb0d4b89f317d076a801ca3",
    "url": "/img/coupon-log.27158aa7.png"
  },
  {
    "revision": "55d3f2f09efe17db6485d4c9f8f0c3b1",
    "url": "/img/icon-recharge_20181001.55d3f2f0.svg"
  },
  {
    "revision": "165beb68d8ba0d2b70df0fbb3769787a",
    "url": "/img/03.165beb68.png"
  },
  {
    "revision": "5f1f34037094c0613bccafa2ddd8cb3b",
    "url": "/img/telecom-logo.5f1f3403.svg"
  },
  {
    "revision": "0b3c3297decbd1152a314cce115f9632",
    "url": "/img/09.0b3c3297.png"
  },
  {
    "revision": "644e6e3cf5f33943747b116316694e28",
    "url": "/img/noData@2x.644e6e3c.png"
  },
  {
    "revision": "4bdbe7dbdb6587c886a8290593100145",
    "url": "/img/recharge_callback_20181126.4bdbe7db.jpg"
  },
  {
    "revision": "aecc9531f2c3b1fd45338e7bf5084384",
    "url": "/img/bg_no_recharge.aecc9531.svg"
  },
  {
    "revision": "b0ffa4a0fd195a110ee4d4dabce3bc32",
    "url": "/img/08.b0ffa4a0.png"
  },
  {
    "revision": "96fab583abd57f2e7118324858fa3080",
    "url": "/img/05.96fab583.png"
  },
  {
    "revision": "3af1a9430facd73c667ba61919fc414e",
    "url": "/img/real5.3af1a943.jpeg"
  },
  {
    "revision": "275be51ae57c486bce58257febd6589f",
    "url": "/img/bg_no_plan.275be51a.svg"
  },
  {
    "revision": "1cf937a060cb282e8b60ed6a7ec78604",
    "url": "/img/real3.1cf937a0.jpeg"
  },
  {
    "revision": "45fb414691fd8f78628e3e94f9db1ad4",
    "url": "/img/real2.45fb4146.jpeg"
  },
  {
    "revision": "a8272d2d742d9d50257e23dfac577def",
    "url": "/img/01.a8272d2d.png"
  },
  {
    "revision": "daa86b540bb9c2a6453ceac9bed77961",
    "url": "/img/07.daa86b54.png"
  },
  {
    "revision": "06385746a7cedb492d5539907631561c",
    "url": "/img/tip.06385746.png"
  },
  {
    "revision": "a6d17ceb63edb524e63c9bbc7c671fec",
    "url": "/img/real4.a6d17ceb.jpeg"
  },
  {
    "revision": "eacba58f9acf2b87cd801858146b2ba9",
    "url": "/img/02.eacba58f.png"
  },
  {
    "revision": "39d9e849fc1c724525f166646932a24d",
    "url": "/img/safari.39d9e849.png"
  },
  {
    "revision": "999589aae784a460b5e7c6ae9bbaa3d8",
    "url": "/img/06.999589aa.png"
  },
  {
    "revision": "1cc77fe95a0f28837ecea2300db5756d",
    "url": "/img/real1.1cc77fe9.jpeg"
  },
  {
    "revision": "018b5f611723dcd170b93822b6dfc48d",
    "url": "/img/real8.018b5f61.jpeg"
  },
  {
    "revision": "7419ab08739c7184b119e09caa4809cb",
    "url": "/index.html"
  },
  {
    "revision": "cd23e78acef76fcea996",
    "url": "/css/Layout.c4f4a25d.css"
  },
  {
    "revision": "9ce16f441b39b493af8b96d7e97cce22",
    "url": "/MP_verify_dkzAKjxyVyJvsHMS.txt"
  },
  {
    "revision": "86c422d8c98b247235d04b49fb1c4b05",
    "url": "/MP_verify_bKSdn2qZlUSULliu.txt"
  },
  {
    "revision": "652317b098ca24e4511926c7fd57cbbe",
    "url": "/MP_verify_8JoCCldW78DygS5c.txt"
  },
  {
    "revision": "00bbf6b458bf7ea6bd01f443eb3045d9",
    "url": "/MP_verify_4r3DVk3KUjgWsQsG.txt"
  }
];