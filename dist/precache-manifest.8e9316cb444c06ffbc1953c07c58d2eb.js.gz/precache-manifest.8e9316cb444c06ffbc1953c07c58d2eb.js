self.__precacheManifest = [
  {
    "revision": "75035cbb7720d711c30c",
    "url": "/css/refund_argument.a0fc719c.css"
  },
  {
    "revision": "b6216d61c03e6ce0c9aea6ca7808f7ca",
    "url": "/robots.txt"
  },
  {
    "revision": "75035cbb7720d711c30c",
    "url": "/js/refund_argument.86e50b98.js"
  },
  {
    "revision": "ebff1aa716de58cc1d18",
    "url": "/css/_404.b9a49c55.css"
  },
  {
    "revision": "d295a796a5aecd51c6ef",
    "url": "/css/app.f82b8cea.css"
  },
  {
    "revision": "d295a796a5aecd51c6ef",
    "url": "/js/app.cb416f01.js"
  },
  {
    "revision": "23dccb788e2731615a4c",
    "url": "/css/card_check.dd32678e.css"
  },
  {
    "revision": "23dccb788e2731615a4c",
    "url": "/js/card_check.abad9e79.js"
  },
  {
    "revision": "5a41ff3d608dd149cc58",
    "url": "/css/card_connection.b6854faf.css"
  },
  {
    "revision": "5a41ff3d608dd149cc58",
    "url": "/js/card_connection.4314e90a.js"
  },
  {
    "revision": "292a1a82b9c30b3c3fb9",
    "url": "/css/card_lookup.b873a2be.css"
  },
  {
    "revision": "292a1a82b9c30b3c3fb9",
    "url": "/js/card_lookup.49c42046.js"
  },
  {
    "revision": "c059b328e37c287c7c28",
    "url": "/css/card_usage.3e77570d.css"
  },
  {
    "revision": "c059b328e37c287c7c28",
    "url": "/js/card_usage.52251174.js"
  },
  {
    "revision": "d3f049492d62da009875",
    "url": "/css/children_card.681cace8.css"
  },
  {
    "revision": "d3f049492d62da009875",
    "url": "/js/children_card.124397db.js"
  },
  {
    "revision": "de8bf5d4e57b8a73b3d5",
    "url": "/css/chunk-vendors.0a14d1e9.css"
  },
  {
    "revision": "de8bf5d4e57b8a73b3d5",
    "url": "/js/chunk-vendors.4cb3f68e.js"
  },
  {
    "revision": "475a28990032a32e60ed",
    "url": "/css/coupon_normal.c4d7b922.css"
  },
  {
    "revision": "475a28990032a32e60ed",
    "url": "/js/coupon_normal.bd643d45.js"
  },
  {
    "revision": "977e264aa02dc9be56b8",
    "url": "/css/coupon_telcom.a3657161.css"
  },
  {
    "revision": "977e264aa02dc9be56b8",
    "url": "/js/coupon_telcom.a6c85ff2.js"
  },
  {
    "revision": "0dc4d2dc41084b47dc4c",
    "url": "/css/find_plan.3e9f1792.css"
  },
  {
    "revision": "0dc4d2dc41084b47dc4c",
    "url": "/js/find_plan.5e90b2c4.js"
  },
  {
    "revision": "6418eba369dfcdf27142",
    "url": "/css/login.bee5c676.css"
  },
  {
    "revision": "6418eba369dfcdf27142",
    "url": "/js/login.a321b725.js"
  },
  {
    "revision": "3e0c0aeb2500b3b124f1",
    "url": "/css/lookup.c8cec05f.css"
  },
  {
    "revision": "3e0c0aeb2500b3b124f1",
    "url": "/js/lookup.6c6778be.js"
  },
  {
    "revision": "b166b1d22f51d5a4a10a",
    "url": "/css/plan_list.42cd3831.css"
  },
  {
    "revision": "b166b1d22f51d5a4a10a",
    "url": "/js/plan_list.0eca86c7.js"
  },
  {
    "revision": "c1ab2fa7ec103461df2e",
    "url": "/css/question.12ea8f73.css"
  },
  {
    "revision": "c1ab2fa7ec103461df2e",
    "url": "/js/question.bb7cf273.js"
  },
  {
    "revision": "541593b2e35999185c8b",
    "url": "/css/real_name.84a42d52.css"
  },
  {
    "revision": "541593b2e35999185c8b",
    "url": "/js/real_name.e629a4d3.js"
  },
  {
    "revision": "c657d62f723afff08cb4",
    "url": "/css/recharge.034e3e1c.css"
  },
  {
    "revision": "c657d62f723afff08cb4",
    "url": "/js/recharge.c1130e4c.js"
  },
  {
    "revision": "d7a1ce6a57f8f8755e49",
    "url": "/css/recharge_callback.6da998f5.css"
  },
  {
    "revision": "d7a1ce6a57f8f8755e49",
    "url": "/js/recharge_callback.32dbf408.js"
  },
  {
    "revision": "9fe8656b817dd7b655e3",
    "url": "/css/refund_applying.141e797c.css"
  },
  {
    "revision": "9fe8656b817dd7b655e3",
    "url": "/js/refund_applying.054266fd.js"
  },
  {
    "revision": "0e27bba49fb2cc006349",
    "url": "/js/Layout.daeff944.js"
  },
  {
    "revision": "ebff1aa716de58cc1d18",
    "url": "/js/_404.fe333f4c.js"
  },
  {
    "revision": "0f1f28550f5c4a0f7189",
    "url": "/css/refund_plan.b92606d3.css"
  },
  {
    "revision": "0f1f28550f5c4a0f7189",
    "url": "/js/refund_plan.080856a0.js"
  },
  {
    "revision": "db57c5d2c0f621490fd1",
    "url": "/css/revoke_plan.634ee312.css"
  },
  {
    "revision": "db57c5d2c0f621490fd1",
    "url": "/js/revoke_plan.df1fb119.js"
  },
  {
    "revision": "e2c5e2e4574d999d4a3c",
    "url": "/css/speedup_500.a73b936a.css"
  },
  {
    "revision": "e2c5e2e4574d999d4a3c",
    "url": "/js/speedup_500.c105d1fa.js"
  },
  {
    "revision": "a3c56f37bb68d2f3ee7e",
    "url": "/css/speedup_80.57ab75d5.css"
  },
  {
    "revision": "a3c56f37bb68d2f3ee7e",
    "url": "/js/speedup_80.1d7dc00b.js"
  },
  {
    "revision": "2edbdfaa13a9a5eb9e1f",
    "url": "/css/to_tb.f061ab91.css"
  },
  {
    "revision": "2edbdfaa13a9a5eb9e1f",
    "url": "/js/to_tb.cf4c19f6.js"
  },
  {
    "revision": "e4b411644706c29765eea3ffdd85ae39",
    "url": "/fonts/SourceHanSansCNRegular.e4b41164.woff"
  },
  {
    "revision": "834b022ab9ab0e6063904af32274e777",
    "url": "/fonts/SourceHanSansCNRegular.834b022a.eot"
  },
  {
    "revision": "f9509c5a10be7daaf1fa01922a7c6bc2",
    "url": "/fonts/SourceHanSansCNRegular.f9509c5a.ttf"
  },
  {
    "revision": "da0808e9fe85be160aab69c82dd8de1c",
    "url": "/img/SourceHanSansCNRegular.da0808e9.svg"
  },
  {
    "revision": "f5f322478286641bd9887a155e35f222",
    "url": "/img/btn.f5f32247.png"
  },
  {
    "revision": "d140650fa64e0f1fc771610dba62aed7",
    "url": "/img/bg.d140650f.png"
  },
  {
    "revision": "3f342771b9b81ab929e0fbcbcd0e6533",
    "url": "/img/bg-check-wrap@3x.3f342771.png"
  },
  {
    "revision": "9713b21819c4019befecd095069977df",
    "url": "/img/bg-check-wrap@2x.9713b218.png"
  },
  {
    "revision": "1d7515ee61c3f659227318b4050955ed",
    "url": "/img/mobile_sim@2x.1d7515ee.png"
  },
  {
    "revision": "0f980b79d9a52702004de9f652a68835",
    "url": "/img/telcom_sim@2x.0f980b79.png"
  },
  {
    "revision": "98141226a7e992e3072a280746a259c4",
    "url": "/img/mobile_sim@3x.98141226.png"
  },
  {
    "revision": "0c88168b284b92c37f3a873f26a97d69",
    "url": "/img/bg.0c88168b.jpg"
  },
  {
    "revision": "9e02095f31a07b972244f1c714c1dfe7",
    "url": "/img/telcom_sim@3x.9e02095f.png"
  },
  {
    "revision": "3d0fc424b703032ca595090e99f8354b",
    "url": "/img/login_bg@2x.3d0fc424.png"
  },
  {
    "revision": "11000d4e510a6df565eb69ba6f2c1dfc",
    "url": "/img/login_bg@3x.11000d4e.png"
  },
  {
    "revision": "5a3428653945c17e1c146efeee81c987",
    "url": "/img/scanTop.5a342865.png"
  },
  {
    "revision": "824594523c01e48028f2b7eb4261134d",
    "url": "/img/unicom-logo.82459452.svg"
  },
  {
    "revision": "113f99e2189c2ca49db2168754fc2eb5",
    "url": "/img/mobile-logo.113f99e2.png"
  },
  {
    "revision": "27158aa79eb0d4b89f317d076a801ca3",
    "url": "/img/coupon-log.27158aa7.png"
  },
  {
    "revision": "55d3f2f09efe17db6485d4c9f8f0c3b1",
    "url": "/img/icon-recharge_20181001.55d3f2f0.svg"
  },
  {
    "revision": "5f1f34037094c0613bccafa2ddd8cb3b",
    "url": "/img/telecom-logo.5f1f3403.svg"
  },
  {
    "revision": "4bdbe7dbdb6587c886a8290593100145",
    "url": "/img/recharge_callback_20181126.4bdbe7db.jpg"
  },
  {
    "revision": "aecc9531f2c3b1fd45338e7bf5084384",
    "url": "/img/bg_no_recharge.aecc9531.svg"
  },
  {
    "revision": "275be51ae57c486bce58257febd6589f",
    "url": "/img/bg_no_plan.275be51a.svg"
  },
  {
    "revision": "a1ea3ea3528b5800a7877b22461e150a",
    "url": "/index.html"
  },
  {
    "revision": "0e27bba49fb2cc006349",
    "url": "/css/Layout.9dcfdb79.css"
  },
  {
    "revision": "86c422d8c98b247235d04b49fb1c4b05",
    "url": "/MP_verify_bKSdn2qZlUSULliu.txt"
  },
  {
    "revision": "652317b098ca24e4511926c7fd57cbbe",
    "url": "/MP_verify_8JoCCldW78DygS5c.txt"
  },
  {
    "revision": "00bbf6b458bf7ea6bd01f443eb3045d9",
    "url": "/MP_verify_4r3DVk3KUjgWsQsG.txt"
  }
];