self.__precacheManifest = [
  {
    "revision": "0959dee89a0557fd7066",
    "url": "/css/refund_applying.604524da.css"
  },
  {
    "revision": "b6216d61c03e6ce0c9aea6ca7808f7ca",
    "url": "/robots.txt"
  },
  {
    "revision": "0959dee89a0557fd7066",
    "url": "/js/refund_applying.affc4a2c.js"
  },
  {
    "revision": "486c88a173afee991629",
    "url": "/css/Layout~card_usage.c5af5c36.css"
  },
  {
    "revision": "f6fe50ccd582c459975e",
    "url": "/js/Layout~card_usage~eqReplaceMent~esim_plan_list~esim_usage~mifi_order~mifi_plan_list~mifi_plan_usage~~3166b5eb.91e2eec6.js"
  },
  {
    "revision": "5b38a8c38c9c2befd0ea",
    "url": "/css/Not_fund.27889525.css"
  },
  {
    "revision": "5b38a8c38c9c2befd0ea",
    "url": "/js/Not_fund.5f1e548c.js"
  },
  {
    "revision": "a832028568870b633dcf",
    "url": "/css/app.2608000f.css"
  },
  {
    "revision": "a832028568870b633dcf",
    "url": "/js/app.a9a44947.js"
  },
  {
    "revision": "f98389ad2a162aff6999",
    "url": "/css/auditFail.a06be683.css"
  },
  {
    "revision": "f98389ad2a162aff6999",
    "url": "/js/auditFail.9015db63.js"
  },
  {
    "revision": "abed0a12ec2c668468ee",
    "url": "/css/auditSuccess.d2da8e0d.css"
  },
  {
    "revision": "abed0a12ec2c668468ee",
    "url": "/js/auditSuccess.d70af3c1.js"
  },
  {
    "revision": "acf777f84a98f5bf7ecc",
    "url": "/css/authority_middle.c167ffdc.css"
  },
  {
    "revision": "acf777f84a98f5bf7ecc",
    "url": "/js/authority_middle.1df38b8a.js"
  },
  {
    "revision": "08146c7f12a043c9c4a4",
    "url": "/css/balanceIndex.3a3d3e38.css"
  },
  {
    "revision": "08146c7f12a043c9c4a4",
    "url": "/js/balanceIndex.60f7c802.js"
  },
  {
    "revision": "1e773f508264914384da",
    "url": "/css/balanceRefund.254d8bdb.css"
  },
  {
    "revision": "1e773f508264914384da",
    "url": "/js/balanceRefund.35734051.js"
  },
  {
    "revision": "13d02029e1c3abb65f57",
    "url": "/css/cardPackage.286a04b0.css"
  },
  {
    "revision": "13d02029e1c3abb65f57",
    "url": "/js/cardPackage.677f3012.js"
  },
  {
    "revision": "3793f57602555c572d7e",
    "url": "/css/card_check.3a0d1310.css"
  },
  {
    "revision": "3793f57602555c572d7e",
    "url": "/js/card_check.498ffb20.js"
  },
  {
    "revision": "b3aa208caf78c9b5aa9a",
    "url": "/css/card_connection.1df8f6d6.css"
  },
  {
    "revision": "b3aa208caf78c9b5aa9a",
    "url": "/js/card_connection.0d103d6f.js"
  },
  {
    "revision": "2b21c41de01dd06032c9",
    "url": "/css/card_lookup.0683b75a.css"
  },
  {
    "revision": "2b21c41de01dd06032c9",
    "url": "/js/card_lookup.51b86039.js"
  },
  {
    "revision": "1e124aa4a1e0aba0f857",
    "url": "/css/card_more_flow.2e596a78.css"
  },
  {
    "revision": "1e124aa4a1e0aba0f857",
    "url": "/js/card_more_flow.9dbac677.js"
  },
  {
    "revision": "83cea0bba712a4ae53cc",
    "url": "/css/card_usage.f6f75021.css"
  },
  {
    "revision": "83cea0bba712a4ae53cc",
    "url": "/js/card_usage.d3f2c3bf.js"
  },
  {
    "revision": "27feb98bc67253469828",
    "url": "/css/card_wrapper.c3676c82.css"
  },
  {
    "revision": "27feb98bc67253469828",
    "url": "/js/card_wrapper.f4efeda6.js"
  },
  {
    "revision": "16e9754de8a4ff0a903c",
    "url": "/css/children_card.29214a5e.css"
  },
  {
    "revision": "16e9754de8a4ff0a903c",
    "url": "/js/children_card.9e83a929.js"
  },
  {
    "revision": "d871bb7c011f8678f42e",
    "url": "/css/chunk-42307ed6.b4d2c24b.css"
  },
  {
    "revision": "d871bb7c011f8678f42e",
    "url": "/js/chunk-42307ed6.4cf1ae8b.js"
  },
  {
    "revision": "0fcc1b719002f576e737",
    "url": "/css/chunk-54edadb3.5c5416b5.css"
  },
  {
    "revision": "0fcc1b719002f576e737",
    "url": "/js/chunk-54edadb3.1d38372c.js"
  },
  {
    "revision": "26be51635e617fc961df",
    "url": "/css/chunk-vendors.187f45a9.css"
  },
  {
    "revision": "26be51635e617fc961df",
    "url": "/js/chunk-vendors.508c8cbc.js"
  },
  {
    "revision": "d926b0d6eb633180ec0b",
    "url": "/css/commonProblem.754408e2.css"
  },
  {
    "revision": "d926b0d6eb633180ec0b",
    "url": "/js/commonProblem.f1b56173.js"
  },
  {
    "revision": "6df7420c82bc4d18080d",
    "url": "/css/consumerRecord.0a81edd2.css"
  },
  {
    "revision": "6df7420c82bc4d18080d",
    "url": "/js/consumerRecord.a81f25c8.js"
  },
  {
    "revision": "17f3c018c878d80ce063",
    "url": "/css/coupon_normal.c97d76cf.css"
  },
  {
    "revision": "17f3c018c878d80ce063",
    "url": "/js/coupon_normal.caa5acfe.js"
  },
  {
    "revision": "244a033b0ff73162e3e5",
    "url": "/css/coupon_telcom.758858d4.css"
  },
  {
    "revision": "244a033b0ff73162e3e5",
    "url": "/js/coupon_telcom.f6f880b1.js"
  },
  {
    "revision": "17f81ab66586ac3d84a4",
    "url": "/css/coupon_wrapper.fbadfe48.css"
  },
  {
    "revision": "17f81ab66586ac3d84a4",
    "url": "/js/coupon_wrapper.d5148a7e.js"
  },
  {
    "revision": "9661d13a6dfe9c9f810f",
    "url": "/css/currencyConversion.ef04e5f4.css"
  },
  {
    "revision": "9661d13a6dfe9c9f810f",
    "url": "/js/currencyConversion.252893da.js"
  },
  {
    "revision": "261fb62ade4d7aaa0f5d",
    "url": "/css/eqReplaceMent.e6117fca.css"
  },
  {
    "revision": "261fb62ade4d7aaa0f5d",
    "url": "/js/eqReplaceMent.6145b771.js"
  },
  {
    "revision": "f5af0f3a04107286a34a",
    "url": "/css/esim_plan_list.c03c6af3.css"
  },
  {
    "revision": "f5af0f3a04107286a34a",
    "url": "/js/esim_plan_list.e3b36259.js"
  },
  {
    "revision": "009f9eddb86ab2a775a8",
    "url": "/css/esim_usage.0bd70d04.css"
  },
  {
    "revision": "009f9eddb86ab2a775a8",
    "url": "/js/esim_usage.dc32d875.js"
  },
  {
    "revision": "0dbece3fe97c31064d37",
    "url": "/css/find_plan.61a19168.css"
  },
  {
    "revision": "0dbece3fe97c31064d37",
    "url": "/js/find_plan.5b245ba2.js"
  },
  {
    "revision": "1e633b22a42e0f94aa41",
    "url": "/css/logical_page.e34d6ba3.css"
  },
  {
    "revision": "1e633b22a42e0f94aa41",
    "url": "/js/logical_page.c71f9646.js"
  },
  {
    "revision": "30e6fd3fb1d7d09d9cc9",
    "url": "/css/login.96c40e5c.css"
  },
  {
    "revision": "30e6fd3fb1d7d09d9cc9",
    "url": "/js/login.2273b9d9.js"
  },
  {
    "revision": "f0eebac4f58552f2018b",
    "url": "/css/lookup.ca3ad503.css"
  },
  {
    "revision": "f0eebac4f58552f2018b",
    "url": "/js/lookup.a20952f0.js"
  },
  {
    "revision": "1430685eb188b00001fc",
    "url": "/css/mifi_binding.d38f2a9f.css"
  },
  {
    "revision": "1430685eb188b00001fc",
    "url": "/js/mifi_binding.41aff313.js"
  },
  {
    "revision": "0d9e1680253537fb83d6",
    "url": "/css/mifi_card_info.5d40456c.css"
  },
  {
    "revision": "0d9e1680253537fb83d6",
    "url": "/js/mifi_card_info.6ad96450.js"
  },
  {
    "revision": "b789914ae31218df5974",
    "url": "/css/mifi_card_lookup.15288e3b.css"
  },
  {
    "revision": "b789914ae31218df5974",
    "url": "/js/mifi_card_lookup.c526efbe.js"
  },
  {
    "revision": "15e10cbb1769d568b968",
    "url": "/css/mifi_card_wrapper.b777319b.css"
  },
  {
    "revision": "15e10cbb1769d568b968",
    "url": "/js/mifi_card_wrapper.74548d11.js"
  },
  {
    "revision": "2423315be85e96b83e69",
    "url": "/css/mifi_change_network.611ba104.css"
  },
  {
    "revision": "2423315be85e96b83e69",
    "url": "/js/mifi_change_network.01de26f8.js"
  },
  {
    "revision": "1db7da412e865e6232b7",
    "url": "/css/mifi_change_network_explanation.22920937.css"
  },
  {
    "revision": "1db7da412e865e6232b7",
    "url": "/js/mifi_change_network_explanation.bd2277c5.js"
  },
  {
    "revision": "cd571e2ef7d4c47a24d0",
    "url": "/css/mifi_coupon_index.fd84900d.css"
  },
  {
    "revision": "cd571e2ef7d4c47a24d0",
    "url": "/js/mifi_coupon_index.10c35ee0.js"
  },
  {
    "revision": "576ae88c8afb457a126f",
    "url": "/css/mifi_coupon_wrapper.a2d7e1e3.css"
  },
  {
    "revision": "576ae88c8afb457a126f",
    "url": "/js/mifi_coupon_wrapper.8eb5ab75.js"
  },
  {
    "revision": "0139ba2f039b26bef529",
    "url": "/css/mifi_index.f06fbcbf.css"
  },
  {
    "revision": "0139ba2f039b26bef529",
    "url": "/js/mifi_index.f5c8122f.js"
  },
  {
    "revision": "ff7289eb0667e562b477",
    "url": "/css/mifi_layout.0a7c17e3.css"
  },
  {
    "revision": "ff7289eb0667e562b477",
    "url": "/js/mifi_layout.ad46e897.js"
  },
  {
    "revision": "04433f1b0ef4bfe3d350",
    "url": "/css/mifi_order.c7b5683d.css"
  },
  {
    "revision": "04433f1b0ef4bfe3d350",
    "url": "/js/mifi_order.f6a570ed.js"
  },
  {
    "revision": "3d001b54adcdcc26b1f5",
    "url": "/css/mifi_order_wrapper.ad5b72f4.css"
  },
  {
    "revision": "3d001b54adcdcc26b1f5",
    "url": "/js/mifi_order_wrapper.fffc6baf.js"
  },
  {
    "revision": "47dd43015500be3f9ac4",
    "url": "/css/mifi_order~mifi_plan_group.9b72222a.css"
  },
  {
    "revision": "47dd43015500be3f9ac4",
    "url": "/js/mifi_order~mifi_plan_group.8b8989db.js"
  },
  {
    "revision": "a9c84138316bd204ea3f",
    "url": "/css/mifi_plan_group.959d2055.css"
  },
  {
    "revision": "a9c84138316bd204ea3f",
    "url": "/js/mifi_plan_group.ecd2cf87.js"
  },
  {
    "revision": "ecdd2f4172551a21b84f",
    "url": "/css/mifi_plan_list.fd7a79be.css"
  },
  {
    "revision": "ecdd2f4172551a21b84f",
    "url": "/js/mifi_plan_list.ebd09eb4.js"
  },
  {
    "revision": "57db1b9bb29145f872f0",
    "url": "/css/mifi_plan_usage.33d730ba.css"
  },
  {
    "revision": "57db1b9bb29145f872f0",
    "url": "/js/mifi_plan_usage.7bb69e9e.js"
  },
  {
    "revision": "46d843e57831f393c0ed",
    "url": "/css/mifi_plan_wrapper.c537a243.css"
  },
  {
    "revision": "46d843e57831f393c0ed",
    "url": "/js/mifi_plan_wrapper.cfeb696b.js"
  },
  {
    "revision": "9fe9b70dedfef1ba3922",
    "url": "/css/new_card_wrapper.552c75ad.css"
  },
  {
    "revision": "9fe9b70dedfef1ba3922",
    "url": "/js/new_card_wrapper.ba92a897.js"
  },
  {
    "revision": "2106be91056df11c6af1",
    "url": "/css/orderRecord.77dbd36f.css"
  },
  {
    "revision": "2106be91056df11c6af1",
    "url": "/js/orderRecord.bee04cb4.js"
  },
  {
    "revision": "25e1c851449d7b5a3692",
    "url": "/css/plan_list.f2234e3f.css"
  },
  {
    "revision": "25e1c851449d7b5a3692",
    "url": "/js/plan_list.1a232efa.js"
  },
  {
    "revision": "5c6865531d3c252203ae",
    "url": "/css/question.3b3a072c.css"
  },
  {
    "revision": "5c6865531d3c252203ae",
    "url": "/js/question.7a19baec.js"
  },
  {
    "revision": "675b0f327314071bd598",
    "url": "/css/question_wrapper.38318263.css"
  },
  {
    "revision": "675b0f327314071bd598",
    "url": "/js/question_wrapper.7c075ef1.js"
  },
  {
    "revision": "b54c1f7afd20815c8b02",
    "url": "/css/realNameCourse.2784b5ad.css"
  },
  {
    "revision": "b54c1f7afd20815c8b02",
    "url": "/js/realNameCourse.08c7348a.js"
  },
  {
    "revision": "f8940c8b0c30f42d51fe",
    "url": "/css/realNameWrapper.ecfbd387.css"
  },
  {
    "revision": "f8940c8b0c30f42d51fe",
    "url": "/js/realNameWrapper.7bf81d9a.js"
  },
  {
    "revision": "697a264b98b8b95e3c09",
    "url": "/css/real_name.6fb4f04a.css"
  },
  {
    "revision": "697a264b98b8b95e3c09",
    "url": "/js/real_name.a1d4d6c4.js"
  },
  {
    "revision": "3ba4f6c73a285156a2bc",
    "url": "/css/recharge.f7369c56.css"
  },
  {
    "revision": "3ba4f6c73a285156a2bc",
    "url": "/js/recharge.ad67cee7.js"
  },
  {
    "revision": "9048e6af59823a6027d7",
    "url": "/css/rechargeOrder.4cf9e650.css"
  },
  {
    "revision": "9048e6af59823a6027d7",
    "url": "/js/rechargeOrder.3867cf8b.js"
  },
  {
    "revision": "f2b53b7ae4397a2cbb2a",
    "url": "/css/recharge_callback.db4a7d6c.css"
  },
  {
    "revision": "f2b53b7ae4397a2cbb2a",
    "url": "/js/recharge_callback.e4a45183.js"
  },
  {
    "revision": "619b660c124be1285778",
    "url": "/css/recharge_wrapper.a4f6c950.css"
  },
  {
    "revision": "619b660c124be1285778",
    "url": "/js/recharge_wrapper.bd609ed7.js"
  },
  {
    "revision": "99868cf46dacea171b00",
    "url": "/css/refundRules.1bf2644d.css"
  },
  {
    "revision": "99868cf46dacea171b00",
    "url": "/js/refundRules.a0328c06.js"
  },
  {
    "revision": "d36efe199fa2a3e2c4a6",
    "url": "/js/Layout.cf6be05c.js"
  },
  {
    "revision": "486c88a173afee991629",
    "url": "/js/Layout~card_usage.399408d8.js"
  },
  {
    "revision": "7715c9c1c93ea9a04a7e",
    "url": "/css/refund_argument.c24fb18f.css"
  },
  {
    "revision": "7715c9c1c93ea9a04a7e",
    "url": "/js/refund_argument.68aafbcf.js"
  },
  {
    "revision": "c19c1fb3f96f9d66373e",
    "url": "/css/refund_plan.27d101d2.css"
  },
  {
    "revision": "c19c1fb3f96f9d66373e",
    "url": "/js/refund_plan.bdee71e2.js"
  },
  {
    "revision": "0667c99de3a8ae37b070",
    "url": "/css/refund_wrapper.3d9190f2.css"
  },
  {
    "revision": "0667c99de3a8ae37b070",
    "url": "/js/refund_wrapper.a90eef0b.js"
  },
  {
    "revision": "ac761cae6bf373cb18e3",
    "url": "/css/repeatRecharge.fb0f9620.css"
  },
  {
    "revision": "ac761cae6bf373cb18e3",
    "url": "/js/repeatRecharge.11c6325b.js"
  },
  {
    "revision": "a973f1a8b6eb21aa7895",
    "url": "/css/revoke_plan.eda17098.css"
  },
  {
    "revision": "a973f1a8b6eb21aa7895",
    "url": "/js/revoke_plan.13ed3211.js"
  },
  {
    "revision": "d9cfb6e8313c3d16b167",
    "url": "/css/speedup_500.f9c8f705.css"
  },
  {
    "revision": "d9cfb6e8313c3d16b167",
    "url": "/js/speedup_500.61e0c435.js"
  },
  {
    "revision": "da103fedc77ee7ebec89",
    "url": "/css/speedup_80.24158936.css"
  },
  {
    "revision": "da103fedc77ee7ebec89",
    "url": "/js/speedup_80.99880d9f.js"
  },
  {
    "revision": "22700bbd28b47c0a472d",
    "url": "/css/speedup_wrapper.482349c9.css"
  },
  {
    "revision": "22700bbd28b47c0a472d",
    "url": "/js/speedup_wrapper.6989ee0d.js"
  },
  {
    "revision": "a2602e3bd9883df507db",
    "url": "/css/to_tb.1a98473a.css"
  },
  {
    "revision": "a2602e3bd9883df507db",
    "url": "/js/to_tb.68795442.js"
  },
  {
    "revision": "d097249eafb331954875",
    "url": "/css/transfer_url.b2e02a2b.css"
  },
  {
    "revision": "d097249eafb331954875",
    "url": "/js/transfer_url.712ebdce.js"
  },
  {
    "revision": "bb05f60e667e4c353438",
    "url": "/css/uploadIdInfo.4e186041.css"
  },
  {
    "revision": "bb05f60e667e4c353438",
    "url": "/js/uploadIdInfo.7668fd7c.js"
  },
  {
    "revision": "2b27b44d345003297252",
    "url": "/css/userCenter.57bbd29e.css"
  },
  {
    "revision": "2b27b44d345003297252",
    "url": "/js/userCenter.cdf2963c.js"
  },
  {
    "revision": "3e943eb8daf5ecddb52d",
    "url": "/css/userCenterWrap.03ef8201.css"
  },
  {
    "revision": "3e943eb8daf5ecddb52d",
    "url": "/js/userCenterWrap.ab3103bd.js"
  },
  {
    "revision": "8c5ce3f5737b4c4f9747",
    "url": "/css/verifyInfo.98d7b964.css"
  },
  {
    "revision": "8c5ce3f5737b4c4f9747",
    "url": "/js/verifyInfo.43e264ce.js"
  },
  {
    "revision": "e4b411644706c29765eea3ffdd85ae39",
    "url": "/fonts/SourceHanSansCNRegular.e4b41164.woff"
  },
  {
    "revision": "834b022ab9ab0e6063904af32274e777",
    "url": "/fonts/SourceHanSansCNRegular.834b022a.eot"
  },
  {
    "revision": "f9509c5a10be7daaf1fa01922a7c6bc2",
    "url": "/fonts/SourceHanSansCNRegular.f9509c5a.ttf"
  },
  {
    "revision": "da0808e9fe85be160aab69c82dd8de1c",
    "url": "/img/SourceHanSansCNRegular.da0808e9.svg"
  },
  {
    "revision": "732389ded34cb9c52dd88271f1345af9",
    "url": "/fonts/element-icons.732389de.ttf"
  },
  {
    "revision": "535877f50039c0cb49a6196a5b7517cd",
    "url": "/fonts/element-icons.535877f5.woff"
  },
  {
    "revision": "cb28460b38b9de81603addeacf165064",
    "url": "/img/result_success@3x.cb28460b.png"
  },
  {
    "revision": "ab7b6bac5b5d732b2207c49ad3bbf32b",
    "url": "/img/result_error@3x.ab7b6bac.png"
  },
  {
    "revision": "009e0aad44114271651c8859ba2803fb",
    "url": "/img/btn_camera@3x.009e0aad.png"
  },
  {
    "revision": "8053681a09934ec0745117c798770884",
    "url": "/img/card_person@3x.8053681a.png"
  },
  {
    "revision": "a38cf1db1ecb9f0759a551ecc03aa161",
    "url": "/img/card_national_emblem@3x.a38cf1db.png"
  },
  {
    "revision": "171573d0985aafafc274434182a38e06",
    "url": "/img/card_id_photo@2x.171573d0.png"
  },
  {
    "revision": "2b7d8fa5a82581aea8b0edbb0d600f70",
    "url": "/img/card_person@2x.2b7d8fa5.png"
  },
  {
    "revision": "b7a05a33f96811c6b26c47f566201f43",
    "url": "/img/card_id_photo@3x.b7a05a33.png"
  },
  {
    "revision": "0f16389ec218c90cf8f657e233b745f2",
    "url": "/img/balanceBg1.0f16389e.png"
  },
  {
    "revision": "565459ef2ee8b71db421144ad21c23e3",
    "url": "/img/balanceBg2.565459ef.png"
  },
  {
    "revision": "f5f322478286641bd9887a155e35f222",
    "url": "/img/btn.f5f32247.png"
  },
  {
    "revision": "d140650fa64e0f1fc771610dba62aed7",
    "url": "/img/bg.d140650f.png"
  },
  {
    "revision": "91e1d2771efacd45e5e465d9a001f197",
    "url": "/img/liantong.91e1d277.png"
  },
  {
    "revision": "4a0cab0f33beb48ea985714d1b91fef7",
    "url": "/img/dianxin.4a0cab0f.png"
  },
  {
    "revision": "657033323334e91efb0011bbc18f8c04",
    "url": "/img/yidong.65703332.png"
  },
  {
    "revision": "8da3b83b73e44e54d6be4b2522bcb1f2",
    "url": "/img/pkgBg2.8da3b83b.png"
  },
  {
    "revision": "d3b42651f9f5048baeffb50c800913ec",
    "url": "/img/pkgBg1.d3b42651.png"
  },
  {
    "revision": "d461d18e42a310bd709b2ce97d159153",
    "url": "/img/pkgBg3.d461d18e.png"
  },
  {
    "revision": "fff5af4325410621aeec4e60b3b92d9b",
    "url": "/img/mifi_binding_bg@3x.fff5af43.png"
  },
  {
    "revision": "fff5af4325410621aeec4e60b3b92d9b",
    "url": "/img/mifi_binding_bg@2x.fff5af43.png"
  },
  {
    "revision": "6dedd4943e4c5848638196fb6f0c4145",
    "url": "/img/bg.6dedd494.png"
  },
  {
    "revision": "b899232b79ad9962c5ab5572775a0400",
    "url": "/img/card_index_bg@3x.b899232b.png"
  },
  {
    "revision": "b899232b79ad9962c5ab5572775a0400",
    "url": "/img/card_index_bg@2x.b899232b.png"
  },
  {
    "revision": "0078f03c08066d51d64b92a13e194ebb",
    "url": "/img/balanceRefund.0078f03c.png"
  },
  {
    "revision": "a859e9ca4606d567c42b9c7bcd4fdce9",
    "url": "/img/iccid_bg@2x.a859e9ca.png"
  },
  {
    "revision": "fa9050c4e9870e8fc0cd184f8515af4a",
    "url": "/img/iccid_bg@3x.fa9050c4.png"
  },
  {
    "revision": "af3ed0b3236bbfdbc3ad61b8d41c3dec",
    "url": "/img/changeBg.af3ed0b3.png"
  },
  {
    "revision": "e625229e32d9deeb5f2909c314d8e609",
    "url": "/img/ios@2x.e625229e.png"
  },
  {
    "revision": "af8bbdfa0a90c4eed4563f8c06ce5ff8",
    "url": "/img/android@2x.af8bbdfa.png"
  },
  {
    "revision": "3f342771b9b81ab929e0fbcbcd0e6533",
    "url": "/img/bg-check-wrap@3x.3f342771.png"
  },
  {
    "revision": "9713b21819c4019befecd095069977df",
    "url": "/img/bg-check-wrap@2x.9713b218.png"
  },
  {
    "revision": "b70eddccd257b21777e71bb64c83b876",
    "url": "/img/bg.b70eddcc.jpeg"
  },
  {
    "revision": "909816c3d34e63a9ad86b8c179ab543c",
    "url": "/img/bar.909816c3.png"
  },
  {
    "revision": "e92f547ba0209da3b4342fa2b56ea9ae",
    "url": "/img/animater.e92f547b.png"
  },
  {
    "revision": "fa855242805b87da42c65763acd64ac0",
    "url": "/img/bg-plan-type@2x.fa855242.png"
  },
  {
    "revision": "4a9ca192485effa8b8f4b5b2df5b9caf",
    "url": "/img/bg-plan-type@3x.4a9ca192.png"
  },
  {
    "revision": "014d354b9b25b67ae95857ba17e2f4cc",
    "url": "/img/activityPage.014d354b.png"
  },
  {
    "revision": "1d7515ee61c3f659227318b4050955ed",
    "url": "/img/mobile_sim@2x.1d7515ee.png"
  },
  {
    "revision": "0f980b79d9a52702004de9f652a68835",
    "url": "/img/telcom_sim@2x.0f980b79.png"
  },
  {
    "revision": "98141226a7e992e3072a280746a259c4",
    "url": "/img/mobile_sim@3x.98141226.png"
  },
  {
    "revision": "0c88168b284b92c37f3a873f26a97d69",
    "url": "/img/bg.0c88168b.jpg"
  },
  {
    "revision": "9e02095f31a07b972244f1c714c1dfe7",
    "url": "/img/telcom_sim@3x.9e02095f.png"
  },
  {
    "revision": "3d0fc424b703032ca595090e99f8354b",
    "url": "/img/login_bg@2x.3d0fc424.png"
  },
  {
    "revision": "11000d4e510a6df565eb69ba6f2c1dfc",
    "url": "/img/login_bg@3x.11000d4e.png"
  },
  {
    "revision": "42c0fbd4915870e5e60452fd0ef2cbec",
    "url": "/img/orderTopBg@3x.42c0fbd4.png"
  },
  {
    "revision": "42c0fbd4915870e5e60452fd0ef2cbec",
    "url": "/img/orderTopBg@2x.42c0fbd4.png"
  },
  {
    "revision": "2a67b73145562669220aa4639e1ad58f",
    "url": "/img/icon3.2a67b731.png"
  },
  {
    "revision": "813b5319e378dafdda952c16ad89906b",
    "url": "/img/icon2.813b5319.png"
  },
  {
    "revision": "2c51a1e53c1ea0b35086d8d7261b4933",
    "url": "/img/bg_network@3x.2c51a1e5.png"
  },
  {
    "revision": "32d70c8fc305e3647098f3de0c71b618",
    "url": "/img/bg_network@2x.32d70c8f.png"
  },
  {
    "revision": "01355f175bd20423ce45a838c1a998a9",
    "url": "/img/bg.01355f17.png"
  },
  {
    "revision": "6e5cee7393060b0ec3dcd587c2518b94",
    "url": "/img/bg_test.6e5cee73.png"
  },
  {
    "revision": "d0ccbc8a35180bb40e027b44dd26035a",
    "url": "/img/youku.d0ccbc8a.png"
  },
  {
    "revision": "f40c7e0b20fe25eb78a7658c3ae56312",
    "url": "/img/noData@3x.f40c7e0b.png"
  },
  {
    "revision": "644e6e3cf5f33943747b116316694e28",
    "url": "/img/noData@2x.644e6e3c.png"
  },
  {
    "revision": "114a6e12b42b9b48586dd341105188fe",
    "url": "/img/usedOrder@2x.114a6e12.png"
  },
  {
    "revision": "c0170ec299b2418256fd515ee7849055",
    "url": "/img/unUsedOrder@2x.c0170ec2.png"
  },
  {
    "revision": "d9e14058d30dd312519fcf2de38d742b",
    "url": "/img/unUsedOrder@3x.d9e14058.png"
  },
  {
    "revision": "4a5b90f8076955f289b3dcda6a5af6ff",
    "url": "/img/invaildedOrder@3x.4a5b90f8.png"
  },
  {
    "revision": "0d5a5158e67bcb7a4604124715ed6fbf",
    "url": "/img/usedOrder@3x.0d5a5158.png"
  },
  {
    "revision": "be0f1e33b2553e71b117d3d3f838d32f",
    "url": "/img/invaildedOrder@2x.be0f1e33.png"
  },
  {
    "revision": "3603a35a49dbb8ad94ec1e57c4dad229",
    "url": "/img/scanTop2.3603a35a.png"
  },
  {
    "revision": "05775dd69c53d7273b27aaa7c6c523f7",
    "url": "/img/04.05775dd6.png"
  },
  {
    "revision": "541375e6bb7db2fba9e415be8045f5fb",
    "url": "/img/1.541375e6.png"
  },
  {
    "revision": "7c28431d304fa4f58f5070c59720683a",
    "url": "/img/2.7c28431d.png"
  },
  {
    "revision": "5a3428653945c17e1c146efeee81c987",
    "url": "/img/scanTop.5a342865.png"
  },
  {
    "revision": "824594523c01e48028f2b7eb4261134d",
    "url": "/img/unicom-logo.82459452.svg"
  },
  {
    "revision": "113f99e2189c2ca49db2168754fc2eb5",
    "url": "/img/mobile-logo.113f99e2.png"
  },
  {
    "revision": "0cba868fa977e09806638b9000636a36",
    "url": "/img/avatar.0cba868f.jpeg"
  },
  {
    "revision": "27158aa79eb0d4b89f317d076a801ca3",
    "url": "/img/coupon-log.27158aa7.png"
  },
  {
    "revision": "55d3f2f09efe17db6485d4c9f8f0c3b1",
    "url": "/img/icon-recharge_20181001.55d3f2f0.svg"
  },
  {
    "revision": "165beb68d8ba0d2b70df0fbb3769787a",
    "url": "/img/03.165beb68.png"
  },
  {
    "revision": "5f1f34037094c0613bccafa2ddd8cb3b",
    "url": "/img/telecom-logo.5f1f3403.svg"
  },
  {
    "revision": "0b3c3297decbd1152a314cce115f9632",
    "url": "/img/09.0b3c3297.png"
  },
  {
    "revision": "3e217df4202e41ad9b030aafc8cfcc24",
    "url": "/img/4.3e217df4.png"
  },
  {
    "revision": "aecc9531f2c3b1fd45338e7bf5084384",
    "url": "/img/bg_no_recharge.aecc9531.svg"
  },
  {
    "revision": "b0ffa4a0fd195a110ee4d4dabce3bc32",
    "url": "/img/08.b0ffa4a0.png"
  },
  {
    "revision": "96fab583abd57f2e7118324858fa3080",
    "url": "/img/05.96fab583.png"
  },
  {
    "revision": "9e8ecc7f7b760b55c56bddfab886da10",
    "url": "/img/3.9e8ecc7f.png"
  },
  {
    "revision": "275be51ae57c486bce58257febd6589f",
    "url": "/img/bg_no_plan.275be51a.svg"
  },
  {
    "revision": "a8272d2d742d9d50257e23dfac577def",
    "url": "/img/01.a8272d2d.png"
  },
  {
    "revision": "daa86b540bb9c2a6453ceac9bed77961",
    "url": "/img/07.daa86b54.png"
  },
  {
    "revision": "06385746a7cedb492d5539907631561c",
    "url": "/img/tip.06385746.png"
  },
  {
    "revision": "eacba58f9acf2b87cd801858146b2ba9",
    "url": "/img/02.eacba58f.png"
  },
  {
    "revision": "39d9e849fc1c724525f166646932a24d",
    "url": "/img/safari.39d9e849.png"
  },
  {
    "revision": "999589aae784a460b5e7c6ae9bbaa3d8",
    "url": "/img/06.999589aa.png"
  },
  {
    "revision": "27d6074d477f6db7f611cdca2ac158a2",
    "url": "/index.html"
  },
  {
    "revision": "d36efe199fa2a3e2c4a6",
    "url": "/css/Layout.cb7ba494.css"
  },
  {
    "revision": "9ce16f441b39b493af8b96d7e97cce22",
    "url": "/MP_verify_dkzAKjxyVyJvsHMS.txt"
  },
  {
    "revision": "86c422d8c98b247235d04b49fb1c4b05",
    "url": "/MP_verify_bKSdn2qZlUSULliu.txt"
  },
  {
    "revision": "652317b098ca24e4511926c7fd57cbbe",
    "url": "/MP_verify_8JoCCldW78DygS5c.txt"
  },
  {
    "revision": "00bbf6b458bf7ea6bd01f443eb3045d9",
    "url": "/MP_verify_4r3DVk3KUjgWsQsG.txt"
  }
];