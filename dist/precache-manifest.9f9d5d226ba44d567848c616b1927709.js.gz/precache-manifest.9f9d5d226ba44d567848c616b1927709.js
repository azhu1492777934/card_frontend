self.__precacheManifest = [
  {
    "revision": "c89c0139fe8d266942f8",
    "url": "/css/refund_applying.682a7c2d.css"
  },
  {
    "revision": "29d6ffaba503adcb763e",
    "url": "/css/Layout.c59a8b7e.css"
  },
  {
    "revision": "f30c648f214675497967",
    "url": "/css/_404.0aa83713.css"
  },
  {
    "revision": "f30c648f214675497967",
    "url": "/js/_404.f24126b9.js"
  },
  {
    "revision": "16ce3145e5ac9ff3f8d9",
    "url": "/css/app.f82b8cea.css"
  },
  {
    "revision": "16ce3145e5ac9ff3f8d9",
    "url": "/js/app.45d59a23.js"
  },
  {
    "revision": "5d011b7b727e6a94d476",
    "url": "/css/authority_middle.0ad27e56.css"
  },
  {
    "revision": "5d011b7b727e6a94d476",
    "url": "/js/authority_middle.98ec8952.js"
  },
  {
    "revision": "28bfa8ffb4fcedf0eaa8",
    "url": "/css/card_check.b700e0a6.css"
  },
  {
    "revision": "28bfa8ffb4fcedf0eaa8",
    "url": "/js/card_check.1dff6783.js"
  },
  {
    "revision": "0ad2a62f21b78143306f",
    "url": "/css/card_connection.1dcd9e95.css"
  },
  {
    "revision": "0ad2a62f21b78143306f",
    "url": "/js/card_connection.09f5935c.js"
  },
  {
    "revision": "12cf1541b875c918200e",
    "url": "/css/card_lookup.6c93b6fc.css"
  },
  {
    "revision": "12cf1541b875c918200e",
    "url": "/js/card_lookup.819b65c5.js"
  },
  {
    "revision": "373acd6855753bc66f93",
    "url": "/css/card_usage.c7591460.css"
  },
  {
    "revision": "373acd6855753bc66f93",
    "url": "/js/card_usage.73b6bcf4.js"
  },
  {
    "revision": "272e6b3875c5e6a0bab4",
    "url": "/css/card_usage~plan_list.092deafd.css"
  },
  {
    "revision": "272e6b3875c5e6a0bab4",
    "url": "/js/card_usage~plan_list.1ce848e9.js"
  },
  {
    "revision": "8dbac5081bd234a58e5c",
    "url": "/css/children_card.11ccd174.css"
  },
  {
    "revision": "8dbac5081bd234a58e5c",
    "url": "/js/children_card.0c05ae37.js"
  },
  {
    "revision": "10e41839005319d30e44",
    "url": "/css/chunk-2e1540ad.d6faae95.css"
  },
  {
    "revision": "10e41839005319d30e44",
    "url": "/js/chunk-2e1540ad.5a1b095b.js"
  },
  {
    "revision": "63de0ab575a673481bfa",
    "url": "/css/chunk-58757bc8.f6365c21.css"
  },
  {
    "revision": "63de0ab575a673481bfa",
    "url": "/js/chunk-58757bc8.0452ef10.js"
  },
  {
    "revision": "de8bf5d4e57b8a73b3d5",
    "url": "/css/chunk-vendors.0a14d1e9.css"
  },
  {
    "revision": "de8bf5d4e57b8a73b3d5",
    "url": "/js/chunk-vendors.4cb3f68e.js"
  },
  {
    "revision": "065e36fe0c715b14b469",
    "url": "/css/coupon_normal.34b21aaf.css"
  },
  {
    "revision": "065e36fe0c715b14b469",
    "url": "/js/coupon_normal.6d00820b.js"
  },
  {
    "revision": "9c727afc9156aa02a1e3",
    "url": "/css/coupon_telcom.c4d7b922.css"
  },
  {
    "revision": "9c727afc9156aa02a1e3",
    "url": "/js/coupon_telcom.5a7f0920.js"
  },
  {
    "revision": "e290f27c095909124159",
    "url": "/css/find_plan.13ea77b9.css"
  },
  {
    "revision": "e290f27c095909124159",
    "url": "/js/find_plan.78302121.js"
  },
  {
    "revision": "a801bcb5be009edc892a",
    "url": "/css/login.6509ca6e.css"
  },
  {
    "revision": "a801bcb5be009edc892a",
    "url": "/js/login.869a90fa.js"
  },
  {
    "revision": "cba4592a6774e09faecf",
    "url": "/css/lookup.324c73c2.css"
  },
  {
    "revision": "cba4592a6774e09faecf",
    "url": "/js/lookup.a43d494e.js"
  },
  {
    "revision": "e267d2a0094dfe2faa2f",
    "url": "/css/plan_list.3c827c4a.css"
  },
  {
    "revision": "e267d2a0094dfe2faa2f",
    "url": "/js/plan_list.a4120c2d.js"
  },
  {
    "revision": "4d20de6e37813fb4b551",
    "url": "/css/question.9573b0b5.css"
  },
  {
    "revision": "4d20de6e37813fb4b551",
    "url": "/js/question.8a1242fd.js"
  },
  {
    "revision": "c11b9d07a7d11a1265d9",
    "url": "/css/real_name.49362bec.css"
  },
  {
    "revision": "c11b9d07a7d11a1265d9",
    "url": "/js/real_name.7de71996.js"
  },
  {
    "revision": "af1ad98d3d51730a1341",
    "url": "/css/recharge.8e95f6f6.css"
  },
  {
    "revision": "af1ad98d3d51730a1341",
    "url": "/js/recharge.f1863abd.js"
  },
  {
    "revision": "93d0de102dc5644a53da",
    "url": "/css/recharge_callback.a107fbe0.css"
  },
  {
    "revision": "93d0de102dc5644a53da",
    "url": "/js/recharge_callback.dee0271e.js"
  },
  {
    "revision": "29d6ffaba503adcb763e",
    "url": "/js/Layout.97e8614f.js"
  },
  {
    "revision": "c89c0139fe8d266942f8",
    "url": "/js/refund_applying.b79bec05.js"
  },
  {
    "revision": "22a85c3a58d7b582dd04",
    "url": "/css/refund_argument.7c09adfe.css"
  },
  {
    "revision": "22a85c3a58d7b582dd04",
    "url": "/js/refund_argument.c77d00ec.js"
  },
  {
    "revision": "d8be617c22c5d7ed666a",
    "url": "/css/refund_plan.803875a9.css"
  },
  {
    "revision": "d8be617c22c5d7ed666a",
    "url": "/js/refund_plan.c27c5da7.js"
  },
  {
    "revision": "f618ddb9f848c7799725",
    "url": "/css/revoke_plan.12a985f9.css"
  },
  {
    "revision": "f618ddb9f848c7799725",
    "url": "/js/revoke_plan.c93bfb9d.js"
  },
  {
    "revision": "e64c6123a69a8341d0c4",
    "url": "/css/speedup_500.3b61fe01.css"
  },
  {
    "revision": "e64c6123a69a8341d0c4",
    "url": "/js/speedup_500.d093aeb8.js"
  },
  {
    "revision": "e8872cd35a554b2034c2",
    "url": "/css/speedup_80.df2b44fb.css"
  },
  {
    "revision": "e8872cd35a554b2034c2",
    "url": "/js/speedup_80.31c9a4ec.js"
  },
  {
    "revision": "e9b0b91d76e26e7b28d5",
    "url": "/css/to_tb.dc082224.css"
  },
  {
    "revision": "e9b0b91d76e26e7b28d5",
    "url": "/js/to_tb.3504c687.js"
  },
  {
    "revision": "e4b411644706c29765eea3ffdd85ae39",
    "url": "/fonts/SourceHanSansCNRegular.e4b41164.woff"
  },
  {
    "revision": "834b022ab9ab0e6063904af32274e777",
    "url": "/fonts/SourceHanSansCNRegular.834b022a.eot"
  },
  {
    "revision": "f9509c5a10be7daaf1fa01922a7c6bc2",
    "url": "/fonts/SourceHanSansCNRegular.f9509c5a.ttf"
  },
  {
    "revision": "da0808e9fe85be160aab69c82dd8de1c",
    "url": "/img/SourceHanSansCNRegular.da0808e9.svg"
  },
  {
    "revision": "e625229e32d9deeb5f2909c314d8e609",
    "url": "/img/ios@2x.e625229e.png"
  },
  {
    "revision": "af8bbdfa0a90c4eed4563f8c06ce5ff8",
    "url": "/img/android@2x.af8bbdfa.png"
  },
  {
    "revision": "f5f322478286641bd9887a155e35f222",
    "url": "/img/btn.f5f32247.png"
  },
  {
    "revision": "d140650fa64e0f1fc771610dba62aed7",
    "url": "/img/bg.d140650f.png"
  },
  {
    "revision": "1d7515ee61c3f659227318b4050955ed",
    "url": "/img/mobile_sim@2x.1d7515ee.png"
  },
  {
    "revision": "0f980b79d9a52702004de9f652a68835",
    "url": "/img/telcom_sim@2x.0f980b79.png"
  },
  {
    "revision": "98141226a7e992e3072a280746a259c4",
    "url": "/img/mobile_sim@3x.98141226.png"
  },
  {
    "revision": "0c88168b284b92c37f3a873f26a97d69",
    "url": "/img/bg.0c88168b.jpg"
  },
  {
    "revision": "9e02095f31a07b972244f1c714c1dfe7",
    "url": "/img/telcom_sim@3x.9e02095f.png"
  },
  {
    "revision": "3f342771b9b81ab929e0fbcbcd0e6533",
    "url": "/img/bg-check-wrap@3x.3f342771.png"
  },
  {
    "revision": "9713b21819c4019befecd095069977df",
    "url": "/img/bg-check-wrap@2x.9713b218.png"
  },
  {
    "revision": "3d0fc424b703032ca595090e99f8354b",
    "url": "/img/login_bg@2x.3d0fc424.png"
  },
  {
    "revision": "11000d4e510a6df565eb69ba6f2c1dfc",
    "url": "/img/login_bg@3x.11000d4e.png"
  },
  {
    "revision": "5a3428653945c17e1c146efeee81c987",
    "url": "/img/scanTop.5a342865.png"
  },
  {
    "revision": "824594523c01e48028f2b7eb4261134d",
    "url": "/img/unicom-logo.82459452.svg"
  },
  {
    "revision": "113f99e2189c2ca49db2168754fc2eb5",
    "url": "/img/mobile-logo.113f99e2.png"
  },
  {
    "revision": "27158aa79eb0d4b89f317d076a801ca3",
    "url": "/img/coupon-log.27158aa7.png"
  },
  {
    "revision": "55d3f2f09efe17db6485d4c9f8f0c3b1",
    "url": "/img/icon-recharge_20181001.55d3f2f0.svg"
  },
  {
    "revision": "5f1f34037094c0613bccafa2ddd8cb3b",
    "url": "/img/telecom-logo.5f1f3403.svg"
  },
  {
    "revision": "4bdbe7dbdb6587c886a8290593100145",
    "url": "/img/recharge_callback_20181126.4bdbe7db.jpg"
  },
  {
    "revision": "aecc9531f2c3b1fd45338e7bf5084384",
    "url": "/img/bg_no_recharge.aecc9531.svg"
  },
  {
    "revision": "275be51ae57c486bce58257febd6589f",
    "url": "/img/bg_no_plan.275be51a.svg"
  },
  {
    "revision": "39d9e849fc1c724525f166646932a24d",
    "url": "/img/safari.39d9e849.png"
  },
  {
    "revision": "04120b620de941e9c4fa4c5badd4df52",
    "url": "/index.html"
  },
  {
    "revision": "b6216d61c03e6ce0c9aea6ca7808f7ca",
    "url": "/robots.txt"
  },
  {
    "revision": "86c422d8c98b247235d04b49fb1c4b05",
    "url": "/MP_verify_bKSdn2qZlUSULliu.txt"
  },
  {
    "revision": "652317b098ca24e4511926c7fd57cbbe",
    "url": "/MP_verify_8JoCCldW78DygS5c.txt"
  },
  {
    "revision": "00bbf6b458bf7ea6bd01f443eb3045d9",
    "url": "/MP_verify_4r3DVk3KUjgWsQsG.txt"
  }
];