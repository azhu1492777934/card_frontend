self.__precacheManifest = [
  {
    "revision": "a786d56f0743664780c8",
    "url": "/css/refund_argument.8d4ee041.css"
  },
  {
    "revision": "aeb56096965082ce3628",
    "url": "/css/Layout.a3c868d6.css"
  },
  {
    "revision": "aefd537b47331781b655",
    "url": "/css/Not_fund.a69db8bb.css"
  },
  {
    "revision": "aefd537b47331781b655",
    "url": "/js/Not_fund.f1920b41.js"
  },
  {
    "revision": "3108b15bcd055ed5d01b",
    "url": "/css/addSalesRecords.e4efcbee.css"
  },
  {
    "revision": "3108b15bcd055ed5d01b",
    "url": "/js/addSalesRecords.d21cf16d.js"
  },
  {
    "revision": "513922044cd905eb4d2d",
    "url": "/css/app.97457166.css"
  },
  {
    "revision": "513922044cd905eb4d2d",
    "url": "/js/app.d08dd60b.js"
  },
  {
    "revision": "c5a3e8a22ef734a29222",
    "url": "/css/authority_middle.28729a5d.css"
  },
  {
    "revision": "c5a3e8a22ef734a29222",
    "url": "/js/authority_middle.a88b707f.js"
  },
  {
    "revision": "19d1e24d9315160755cd",
    "url": "/css/card_check.64e8abc4.css"
  },
  {
    "revision": "19d1e24d9315160755cd",
    "url": "/js/card_check.4ad0dc93.js"
  },
  {
    "revision": "0811cf3b2551d0304708",
    "url": "/css/card_connection.31f60d31.css"
  },
  {
    "revision": "0811cf3b2551d0304708",
    "url": "/js/card_connection.48bcdb89.js"
  },
  {
    "revision": "bc68d8f973e2dc393915",
    "url": "/css/card_lookup.cc7ff0b9.css"
  },
  {
    "revision": "bc68d8f973e2dc393915",
    "url": "/js/card_lookup.20f7a3e9.js"
  },
  {
    "revision": "26b53775f09fe459fa24",
    "url": "/css/card_usage.3b5a4c5b.css"
  },
  {
    "revision": "26b53775f09fe459fa24",
    "url": "/js/card_usage.50ee2acc.js"
  },
  {
    "revision": "e3de9fe9350508cb8bdd",
    "url": "/js/card_usage~eqReplaceMent~esim_plan_list~esim_usage~mifi_order~mifi_plan_list~mifi_plan_usage~plan_li~f915d233.7f59822f.js"
  },
  {
    "revision": "8b1bb404ad39295b2eee",
    "url": "/css/card_wrapper.707898e1.css"
  },
  {
    "revision": "8b1bb404ad39295b2eee",
    "url": "/js/card_wrapper.a9bca990.js"
  },
  {
    "revision": "9f6353f3edef58e8f9a5",
    "url": "/css/children_card.755f465c.css"
  },
  {
    "revision": "9f6353f3edef58e8f9a5",
    "url": "/js/children_card.93bc71c4.js"
  },
  {
    "revision": "060658975ad4a96509b5",
    "url": "/css/chunk-332ab7b4.71b82256.css"
  },
  {
    "revision": "060658975ad4a96509b5",
    "url": "/js/chunk-332ab7b4.ea5eb667.js"
  },
  {
    "revision": "e7a074765a02a25bb99c",
    "url": "/css/chunk-b81a473a.f068f9c3.css"
  },
  {
    "revision": "e7a074765a02a25bb99c",
    "url": "/js/chunk-b81a473a.c9245e2c.js"
  },
  {
    "revision": "269e27b4a18d38c07113",
    "url": "/css/chunk-vendors.845797cf.css"
  },
  {
    "revision": "269e27b4a18d38c07113",
    "url": "/js/chunk-vendors.0c664671.js"
  },
  {
    "revision": "bbefa34ca6dbfe653c6f",
    "url": "/css/commonProblem.bcbe0d09.css"
  },
  {
    "revision": "bbefa34ca6dbfe653c6f",
    "url": "/js/commonProblem.9c3ec0f0.js"
  },
  {
    "revision": "8ff1d549847c28f36207",
    "url": "/css/contactUs.0e40ee62.css"
  },
  {
    "revision": "8ff1d549847c28f36207",
    "url": "/js/contactUs.33716177.js"
  },
  {
    "revision": "d9df96aaaade3958b932",
    "url": "/css/coupon_normal.19461797.css"
  },
  {
    "revision": "d9df96aaaade3958b932",
    "url": "/js/coupon_normal.6da29e49.js"
  },
  {
    "revision": "f0f723b9deb3fbfc37fe",
    "url": "/css/coupon_telcom.e5235056.css"
  },
  {
    "revision": "f0f723b9deb3fbfc37fe",
    "url": "/js/coupon_telcom.28c4d9a3.js"
  },
  {
    "revision": "5fe57dc44a4acdba3313",
    "url": "/css/coupon_wrapper.69b3dda0.css"
  },
  {
    "revision": "5fe57dc44a4acdba3313",
    "url": "/js/coupon_wrapper.36c73f27.js"
  },
  {
    "revision": "f1726f0eb381d23a251a",
    "url": "/css/eqReplaceMent.2446be05.css"
  },
  {
    "revision": "f1726f0eb381d23a251a",
    "url": "/js/eqReplaceMent.186be4ef.js"
  },
  {
    "revision": "38256901bc2786fc9425",
    "url": "/css/esim_plan_list.1c95eefc.css"
  },
  {
    "revision": "38256901bc2786fc9425",
    "url": "/js/esim_plan_list.7826bc8c.js"
  },
  {
    "revision": "74368f6f37e0ab13fd59",
    "url": "/css/esim_usage.121db160.css"
  },
  {
    "revision": "74368f6f37e0ab13fd59",
    "url": "/js/esim_usage.8c8fd878.js"
  },
  {
    "revision": "f1cdc70257da326f283b",
    "url": "/css/find_plan.569cf52d.css"
  },
  {
    "revision": "f1cdc70257da326f283b",
    "url": "/js/find_plan.afff209b.js"
  },
  {
    "revision": "10cecb15a56767749fe9",
    "url": "/css/helpCenter.12dc6f4f.css"
  },
  {
    "revision": "10cecb15a56767749fe9",
    "url": "/js/helpCenter.5f4d288c.js"
  },
  {
    "revision": "6d84bdc43d1c6e325034",
    "url": "/css/logical_page.354b4dd2.css"
  },
  {
    "revision": "6d84bdc43d1c6e325034",
    "url": "/js/logical_page.e97e3108.js"
  },
  {
    "revision": "0416d44710bcc59e76f5",
    "url": "/css/login.3283a847.css"
  },
  {
    "revision": "0416d44710bcc59e76f5",
    "url": "/js/login.91885b8b.js"
  },
  {
    "revision": "365e640c755dfe167872",
    "url": "/css/lookup.d5c92cab.css"
  },
  {
    "revision": "365e640c755dfe167872",
    "url": "/js/lookup.e365fcab.js"
  },
  {
    "revision": "0140f18cad14c7ca6b39",
    "url": "/css/mifi_binding.9828ee94.css"
  },
  {
    "revision": "0140f18cad14c7ca6b39",
    "url": "/js/mifi_binding.868b7d29.js"
  },
  {
    "revision": "d23377994dd52c44c9e7",
    "url": "/css/mifi_card_info.15e32b72.css"
  },
  {
    "revision": "d23377994dd52c44c9e7",
    "url": "/js/mifi_card_info.0e302917.js"
  },
  {
    "revision": "fa7529f7f75acf5e880d",
    "url": "/css/mifi_card_lookup.f5d71f6f.css"
  },
  {
    "revision": "fa7529f7f75acf5e880d",
    "url": "/js/mifi_card_lookup.b4d483b5.js"
  },
  {
    "revision": "887c196fc4c57f6736fc",
    "url": "/css/mifi_card_wrapper.dc61eb75.css"
  },
  {
    "revision": "887c196fc4c57f6736fc",
    "url": "/js/mifi_card_wrapper.473da171.js"
  },
  {
    "revision": "085cbc45079576fc7652",
    "url": "/css/mifi_change_network.8499b8ef.css"
  },
  {
    "revision": "085cbc45079576fc7652",
    "url": "/js/mifi_change_network.f6826381.js"
  },
  {
    "revision": "40178698f03dae7a28bd",
    "url": "/css/mifi_coupon_index.28ea82de.css"
  },
  {
    "revision": "40178698f03dae7a28bd",
    "url": "/js/mifi_coupon_index.1e398f82.js"
  },
  {
    "revision": "70f4d23c95a17c5e73b2",
    "url": "/css/mifi_coupon_wrapper.c537a243.css"
  },
  {
    "revision": "70f4d23c95a17c5e73b2",
    "url": "/js/mifi_coupon_wrapper.05dda88a.js"
  },
  {
    "revision": "ff76f129d03faa6dad22",
    "url": "/css/mifi_index.349a2c30.css"
  },
  {
    "revision": "ff76f129d03faa6dad22",
    "url": "/js/mifi_index.2540902a.js"
  },
  {
    "revision": "eb5de8b8f88ec13bff7f",
    "url": "/css/mifi_layout.4ae65286.css"
  },
  {
    "revision": "eb5de8b8f88ec13bff7f",
    "url": "/js/mifi_layout.089c12db.js"
  },
  {
    "revision": "a3fa3d1eea1762577436",
    "url": "/css/mifi_order.e2c84ebf.css"
  },
  {
    "revision": "a3fa3d1eea1762577436",
    "url": "/js/mifi_order.12499696.js"
  },
  {
    "revision": "bd5de4ec3d2dade64090",
    "url": "/css/mifi_order_wrapper.b777319b.css"
  },
  {
    "revision": "bd5de4ec3d2dade64090",
    "url": "/js/mifi_order_wrapper.6bfa2d39.js"
  },
  {
    "revision": "0e3374b5b87d7be5ae97",
    "url": "/css/mifi_order~mifi_plan_group.649e1a31.css"
  },
  {
    "revision": "0e3374b5b87d7be5ae97",
    "url": "/js/mifi_order~mifi_plan_group.2b2aed2a.js"
  },
  {
    "revision": "7db109fedd40877ebc1b",
    "url": "/css/mifi_plan_group.e84edb2b.css"
  },
  {
    "revision": "7db109fedd40877ebc1b",
    "url": "/js/mifi_plan_group.c74fee7c.js"
  },
  {
    "revision": "8e36f89e20912348980c",
    "url": "/css/mifi_plan_list.445101b0.css"
  },
  {
    "revision": "8e36f89e20912348980c",
    "url": "/js/mifi_plan_list.a2a47506.js"
  },
  {
    "revision": "df900c42eb888b50bdab",
    "url": "/css/mifi_plan_usage.1b8858c9.css"
  },
  {
    "revision": "df900c42eb888b50bdab",
    "url": "/js/mifi_plan_usage.61a535e9.js"
  },
  {
    "revision": "716beb1c2e080d331ae7",
    "url": "/css/mifi_plan_wrapper.d572d9dd.css"
  },
  {
    "revision": "716beb1c2e080d331ae7",
    "url": "/js/mifi_plan_wrapper.e033b06d.js"
  },
  {
    "revision": "bc498f424731584619ee",
    "url": "/css/new_card_wrapper.7ce9b2af.css"
  },
  {
    "revision": "bc498f424731584619ee",
    "url": "/js/new_card_wrapper.b4269277.js"
  },
  {
    "revision": "d74e6b33148159eb3647",
    "url": "/css/plan_list.6283cbb0.css"
  },
  {
    "revision": "d74e6b33148159eb3647",
    "url": "/js/plan_list.2f48b8e1.js"
  },
  {
    "revision": "19b08d3bb95eaf806406",
    "url": "/css/question.ab2841f4.css"
  },
  {
    "revision": "19b08d3bb95eaf806406",
    "url": "/js/question.d475ef10.js"
  },
  {
    "revision": "e6b3febce34d1a403174",
    "url": "/css/question_wrapper.fb951ea8.css"
  },
  {
    "revision": "e6b3febce34d1a403174",
    "url": "/js/question_wrapper.ae475647.js"
  },
  {
    "revision": "58d57f53838f92a8e16f",
    "url": "/css/realName.254ab213.css"
  },
  {
    "revision": "58d57f53838f92a8e16f",
    "url": "/js/realName.f48d17ac.js"
  },
  {
    "revision": "8ba052bde3bd0dd7bca8",
    "url": "/css/realNameCourse.4e173a00.css"
  },
  {
    "revision": "8ba052bde3bd0dd7bca8",
    "url": "/js/realNameCourse.d02afa8a.js"
  },
  {
    "revision": "78004afa691d54281b93",
    "url": "/css/real_name.8d8f4438.css"
  },
  {
    "revision": "78004afa691d54281b93",
    "url": "/js/real_name.e28eac22.js"
  },
  {
    "revision": "4d630191bf80998d3b15",
    "url": "/css/recharge.a7af8b92.css"
  },
  {
    "revision": "4d630191bf80998d3b15",
    "url": "/js/recharge.a1818c8a.js"
  },
  {
    "revision": "a7b4833309f667a71279",
    "url": "/css/rechargeRecord.c05f1cec.css"
  },
  {
    "revision": "a7b4833309f667a71279",
    "url": "/js/rechargeRecord.759c7f0f.js"
  },
  {
    "revision": "d0264a8402bc3a4702be",
    "url": "/css/recharge_callback.7abff9e8.css"
  },
  {
    "revision": "d0264a8402bc3a4702be",
    "url": "/js/recharge_callback.c9fd94f7.js"
  },
  {
    "revision": "d86fff4aae7f027f927f",
    "url": "/css/recharge_wrapper.552c75ad.css"
  },
  {
    "revision": "d86fff4aae7f027f927f",
    "url": "/js/recharge_wrapper.384d637f.js"
  },
  {
    "revision": "e95a0d924d550cbd95c9",
    "url": "/css/refund_applying.70348ea1.css"
  },
  {
    "revision": "e95a0d924d550cbd95c9",
    "url": "/js/refund_applying.48d7f6b4.js"
  },
  {
    "revision": "aeb56096965082ce3628",
    "url": "/js/Layout.8580c85a.js"
  },
  {
    "revision": "a786d56f0743664780c8",
    "url": "/js/refund_argument.597ae08e.js"
  },
  {
    "revision": "318c01eeb15834d4cf43",
    "url": "/css/refund_plan.679b618b.css"
  },
  {
    "revision": "318c01eeb15834d4cf43",
    "url": "/js/refund_plan.bd706b20.js"
  },
  {
    "revision": "7c33953b25d4b5b0fea1",
    "url": "/css/refund_wrapper.80b62e54.css"
  },
  {
    "revision": "7c33953b25d4b5b0fea1",
    "url": "/js/refund_wrapper.1dd5702a.js"
  },
  {
    "revision": "2629ed1944d8b610804e",
    "url": "/css/repeatRecharge.f7d7d7e7.css"
  },
  {
    "revision": "2629ed1944d8b610804e",
    "url": "/js/repeatRecharge.c3375c18.js"
  },
  {
    "revision": "a094bcc99c608be70dc5",
    "url": "/css/revoke_plan.56a01abf.css"
  },
  {
    "revision": "a094bcc99c608be70dc5",
    "url": "/js/revoke_plan.7b42f345.js"
  },
  {
    "revision": "df5164d2b8cd294d2595",
    "url": "/css/salesRecords.30b881c1.css"
  },
  {
    "revision": "df5164d2b8cd294d2595",
    "url": "/js/salesRecords.5175b2c7.js"
  },
  {
    "revision": "00ed2baa242c648fef0d",
    "url": "/css/speedup_500.e76fed0c.css"
  },
  {
    "revision": "00ed2baa242c648fef0d",
    "url": "/js/speedup_500.45bf30c6.js"
  },
  {
    "revision": "67e37d5735d311baa7ee",
    "url": "/css/speedup_80.073b7a81.css"
  },
  {
    "revision": "67e37d5735d311baa7ee",
    "url": "/js/speedup_80.b235039a.js"
  },
  {
    "revision": "0850365cc6448acb352f",
    "url": "/css/speedup_wrapper.61f8e218.css"
  },
  {
    "revision": "0850365cc6448acb352f",
    "url": "/js/speedup_wrapper.c900b254.js"
  },
  {
    "revision": "c99ed421a8ff91e625be",
    "url": "/css/to_tb.364d7c88.css"
  },
  {
    "revision": "c99ed421a8ff91e625be",
    "url": "/js/to_tb.a3c70189.js"
  },
  {
    "revision": "d36abd1d1defeeb41cf5",
    "url": "/css/transfer_url.a1777203.css"
  },
  {
    "revision": "d36abd1d1defeeb41cf5",
    "url": "/js/transfer_url.87bbe104.js"
  },
  {
    "revision": "7e9778b8beff9cb167b6",
    "url": "/css/userCenter.73a0abc1.css"
  },
  {
    "revision": "7e9778b8beff9cb167b6",
    "url": "/js/userCenter.72d22d75.js"
  },
  {
    "revision": "924a7f70254c00704c41",
    "url": "/css/userCenterAddress.147ff67b.css"
  },
  {
    "revision": "924a7f70254c00704c41",
    "url": "/js/userCenterAddress.00744c48.js"
  },
  {
    "revision": "a20deba3fc5f12387a4f",
    "url": "/css/userCenterWrap.8b393e56.css"
  },
  {
    "revision": "a20deba3fc5f12387a4f",
    "url": "/js/userCenterWrap.c7898448.js"
  },
  {
    "revision": "e4b411644706c29765eea3ffdd85ae39",
    "url": "/fonts/SourceHanSansCNRegular.e4b41164.woff"
  },
  {
    "revision": "834b022ab9ab0e6063904af32274e777",
    "url": "/fonts/SourceHanSansCNRegular.834b022a.eot"
  },
  {
    "revision": "f9509c5a10be7daaf1fa01922a7c6bc2",
    "url": "/fonts/SourceHanSansCNRegular.f9509c5a.ttf"
  },
  {
    "revision": "da0808e9fe85be160aab69c82dd8de1c",
    "url": "/img/SourceHanSansCNRegular.da0808e9.svg"
  },
  {
    "revision": "732389ded34cb9c52dd88271f1345af9",
    "url": "/fonts/element-icons.732389de.ttf"
  },
  {
    "revision": "535877f50039c0cb49a6196a5b7517cd",
    "url": "/fonts/element-icons.535877f5.woff"
  },
  {
    "revision": "ad4acc3d7da28ce6f33925b83bae2c94",
    "url": "/img/arrow1.ad4acc3d.png"
  },
  {
    "revision": "fff5af4325410621aeec4e60b3b92d9b",
    "url": "/img/mifi_binding_bg@3x.fff5af43.png"
  },
  {
    "revision": "fff5af4325410621aeec4e60b3b92d9b",
    "url": "/img/mifi_binding_bg@2x.fff5af43.png"
  },
  {
    "revision": "b899232b79ad9962c5ab5572775a0400",
    "url": "/img/card_index_bg@3x.b899232b.png"
  },
  {
    "revision": "b899232b79ad9962c5ab5572775a0400",
    "url": "/img/card_index_bg@2x.b899232b.png"
  },
  {
    "revision": "a859e9ca4606d567c42b9c7bcd4fdce9",
    "url": "/img/iccid_bg@2x.a859e9ca.png"
  },
  {
    "revision": "fa9050c4e9870e8fc0cd184f8515af4a",
    "url": "/img/iccid_bg@3x.fa9050c4.png"
  },
  {
    "revision": "42c0fbd4915870e5e60452fd0ef2cbec",
    "url": "/img/orderTopBg@3x.42c0fbd4.png"
  },
  {
    "revision": "42c0fbd4915870e5e60452fd0ef2cbec",
    "url": "/img/orderTopBg@2x.42c0fbd4.png"
  },
  {
    "revision": "a1386d312938b126d701a6841fb742e8",
    "url": "/img/addressIcon.a1386d31.png"
  },
  {
    "revision": "83d0cd2dc163e83ef26f6bad98661da8",
    "url": "/img/addressBg.83d0cd2d.png"
  },
  {
    "revision": "6e5cee7393060b0ec3dcd587c2518b94",
    "url": "/img/bg_test.6e5cee73.png"
  },
  {
    "revision": "2c51a1e53c1ea0b35086d8d7261b4933",
    "url": "/img/bg_network@3x.2c51a1e5.png"
  },
  {
    "revision": "32d70c8fc305e3647098f3de0c71b618",
    "url": "/img/bg_network@2x.32d70c8f.png"
  },
  {
    "revision": "f5f322478286641bd9887a155e35f222",
    "url": "/img/btn.f5f32247.png"
  },
  {
    "revision": "d140650fa64e0f1fc771610dba62aed7",
    "url": "/img/bg.d140650f.png"
  },
  {
    "revision": "3f342771b9b81ab929e0fbcbcd0e6533",
    "url": "/img/bg-check-wrap@3x.3f342771.png"
  },
  {
    "revision": "9713b21819c4019befecd095069977df",
    "url": "/img/bg-check-wrap@2x.9713b218.png"
  },
  {
    "revision": "e625229e32d9deeb5f2909c314d8e609",
    "url": "/img/ios@2x.e625229e.png"
  },
  {
    "revision": "af8bbdfa0a90c4eed4563f8c06ce5ff8",
    "url": "/img/android@2x.af8bbdfa.png"
  },
  {
    "revision": "1d7515ee61c3f659227318b4050955ed",
    "url": "/img/mobile_sim@2x.1d7515ee.png"
  },
  {
    "revision": "0f980b79d9a52702004de9f652a68835",
    "url": "/img/telcom_sim@2x.0f980b79.png"
  },
  {
    "revision": "98141226a7e992e3072a280746a259c4",
    "url": "/img/mobile_sim@3x.98141226.png"
  },
  {
    "revision": "0c88168b284b92c37f3a873f26a97d69",
    "url": "/img/bg.0c88168b.jpg"
  },
  {
    "revision": "9e02095f31a07b972244f1c714c1dfe7",
    "url": "/img/telcom_sim@3x.9e02095f.png"
  },
  {
    "revision": "d32e5dc3875f1afd2be29aad1cfd0382",
    "url": "/img/contactBg.d32e5dc3.png"
  },
  {
    "revision": "b70eddccd257b21777e71bb64c83b876",
    "url": "/img/bg.b70eddcc.jpeg"
  },
  {
    "revision": "909816c3d34e63a9ad86b8c179ab543c",
    "url": "/img/bar.909816c3.png"
  },
  {
    "revision": "e92f547ba0209da3b4342fa2b56ea9ae",
    "url": "/img/animater.e92f547b.png"
  },
  {
    "revision": "114a6e12b42b9b48586dd341105188fe",
    "url": "/img/usedOrder@2x.114a6e12.png"
  },
  {
    "revision": "c0170ec299b2418256fd515ee7849055",
    "url": "/img/unUsedOrder@2x.c0170ec2.png"
  },
  {
    "revision": "d9e14058d30dd312519fcf2de38d742b",
    "url": "/img/unUsedOrder@3x.d9e14058.png"
  },
  {
    "revision": "4a5b90f8076955f289b3dcda6a5af6ff",
    "url": "/img/invaildedOrder@3x.4a5b90f8.png"
  },
  {
    "revision": "0d5a5158e67bcb7a4604124715ed6fbf",
    "url": "/img/usedOrder@3x.0d5a5158.png"
  },
  {
    "revision": "be0f1e33b2553e71b117d3d3f838d32f",
    "url": "/img/invaildedOrder@2x.be0f1e33.png"
  },
  {
    "revision": "3d0fc424b703032ca595090e99f8354b",
    "url": "/img/login_bg@2x.3d0fc424.png"
  },
  {
    "revision": "11000d4e510a6df565eb69ba6f2c1dfc",
    "url": "/img/login_bg@3x.11000d4e.png"
  },
  {
    "revision": "014d354b9b25b67ae95857ba17e2f4cc",
    "url": "/img/activityPage.014d354b.png"
  },
  {
    "revision": "2a67b73145562669220aa4639e1ad58f",
    "url": "/img/icon3.2a67b731.png"
  },
  {
    "revision": "813b5319e378dafdda952c16ad89906b",
    "url": "/img/icon2.813b5319.png"
  },
  {
    "revision": "01355f175bd20423ce45a838c1a998a9",
    "url": "/img/bg.01355f17.png"
  },
  {
    "revision": "6eb1cce5bab9ec1cb25d71e8f3110a15",
    "url": "/img/real7.6eb1cce5.jpeg"
  },
  {
    "revision": "3603a35a49dbb8ad94ec1e57c4dad229",
    "url": "/img/scanTop2.3603a35a.png"
  },
  {
    "revision": "b74ee4a485ffa8d4339c3412ac6659be",
    "url": "/img/real6.b74ee4a4.jpeg"
  },
  {
    "revision": "05775dd69c53d7273b27aaa7c6c523f7",
    "url": "/img/04.05775dd6.png"
  },
  {
    "revision": "5a3428653945c17e1c146efeee81c987",
    "url": "/img/scanTop.5a342865.png"
  },
  {
    "revision": "824594523c01e48028f2b7eb4261134d",
    "url": "/img/unicom-logo.82459452.svg"
  },
  {
    "revision": "113f99e2189c2ca49db2168754fc2eb5",
    "url": "/img/mobile-logo.113f99e2.png"
  },
  {
    "revision": "0cba868fa977e09806638b9000636a36",
    "url": "/img/avatar.0cba868f.jpeg"
  },
  {
    "revision": "a5b636104342050950abea60fb65f9cd",
    "url": "/img/qrImg.a5b63610.png"
  },
  {
    "revision": "27158aa79eb0d4b89f317d076a801ca3",
    "url": "/img/coupon-log.27158aa7.png"
  },
  {
    "revision": "55d3f2f09efe17db6485d4c9f8f0c3b1",
    "url": "/img/icon-recharge_20181001.55d3f2f0.svg"
  },
  {
    "revision": "165beb68d8ba0d2b70df0fbb3769787a",
    "url": "/img/03.165beb68.png"
  },
  {
    "revision": "5f1f34037094c0613bccafa2ddd8cb3b",
    "url": "/img/telecom-logo.5f1f3403.svg"
  },
  {
    "revision": "0b3c3297decbd1152a314cce115f9632",
    "url": "/img/09.0b3c3297.png"
  },
  {
    "revision": "644e6e3cf5f33943747b116316694e28",
    "url": "/img/noData@2x.644e6e3c.png"
  },
  {
    "revision": "4bdbe7dbdb6587c886a8290593100145",
    "url": "/img/recharge_callback_20181126.4bdbe7db.jpg"
  },
  {
    "revision": "aecc9531f2c3b1fd45338e7bf5084384",
    "url": "/img/bg_no_recharge.aecc9531.svg"
  },
  {
    "revision": "b0ffa4a0fd195a110ee4d4dabce3bc32",
    "url": "/img/08.b0ffa4a0.png"
  },
  {
    "revision": "96fab583abd57f2e7118324858fa3080",
    "url": "/img/05.96fab583.png"
  },
  {
    "revision": "3af1a9430facd73c667ba61919fc414e",
    "url": "/img/real5.3af1a943.jpeg"
  },
  {
    "revision": "275be51ae57c486bce58257febd6589f",
    "url": "/img/bg_no_plan.275be51a.svg"
  },
  {
    "revision": "1cf937a060cb282e8b60ed6a7ec78604",
    "url": "/img/real3.1cf937a0.jpeg"
  },
  {
    "revision": "45fb414691fd8f78628e3e94f9db1ad4",
    "url": "/img/real2.45fb4146.jpeg"
  },
  {
    "revision": "a8272d2d742d9d50257e23dfac577def",
    "url": "/img/01.a8272d2d.png"
  },
  {
    "revision": "daa86b540bb9c2a6453ceac9bed77961",
    "url": "/img/07.daa86b54.png"
  },
  {
    "revision": "a6d17ceb63edb524e63c9bbc7c671fec",
    "url": "/img/real4.a6d17ceb.jpeg"
  },
  {
    "revision": "eacba58f9acf2b87cd801858146b2ba9",
    "url": "/img/02.eacba58f.png"
  },
  {
    "revision": "39d9e849fc1c724525f166646932a24d",
    "url": "/img/safari.39d9e849.png"
  },
  {
    "revision": "999589aae784a460b5e7c6ae9bbaa3d8",
    "url": "/img/06.999589aa.png"
  },
  {
    "revision": "1cc77fe95a0f28837ecea2300db5756d",
    "url": "/img/real1.1cc77fe9.jpeg"
  },
  {
    "revision": "018b5f611723dcd170b93822b6dfc48d",
    "url": "/img/real8.018b5f61.jpeg"
  },
  {
    "revision": "720fcdf2d24c8a89e4670e39dd2ee4f7",
    "url": "/index.html"
  },
  {
    "revision": "b6216d61c03e6ce0c9aea6ca7808f7ca",
    "url": "/robots.txt"
  },
  {
    "revision": "9ce16f441b39b493af8b96d7e97cce22",
    "url": "/MP_verify_dkzAKjxyVyJvsHMS.txt"
  },
  {
    "revision": "86c422d8c98b247235d04b49fb1c4b05",
    "url": "/MP_verify_bKSdn2qZlUSULliu.txt"
  },
  {
    "revision": "652317b098ca24e4511926c7fd57cbbe",
    "url": "/MP_verify_8JoCCldW78DygS5c.txt"
  },
  {
    "revision": "00bbf6b458bf7ea6bd01f443eb3045d9",
    "url": "/MP_verify_4r3DVk3KUjgWsQsG.txt"
  }
];