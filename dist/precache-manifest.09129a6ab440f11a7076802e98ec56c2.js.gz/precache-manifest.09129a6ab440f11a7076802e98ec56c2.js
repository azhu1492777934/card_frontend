self.__precacheManifest = [
  {
    "revision": "f20d28789c842811b5d7",
    "url": "/css/refundRules.e033034d.css"
  },
  {
    "revision": "735ab4f94fbcd57074377afca324c813",
    "url": "/robots.txt"
  },
  {
    "revision": "f20d28789c842811b5d7",
    "url": "/js/refundRules.fb0af78a.js"
  },
  {
    "revision": "78214ba34c5f1df936aa",
    "url": "/js/Layout~card_usage~eqReplaceMent~esim_plan_list~esim_usage~mifi_order~mifi_plan_list~mifi_plan_usage~~c6f87c36.6241bd21.js"
  },
  {
    "revision": "94d7cc9826a7aff7eaf5",
    "url": "/js/Not_fund.0696a0b9.js"
  },
  {
    "revision": "8c07452345639aa69f6b",
    "url": "/js/userCenterWrap.140f6840.js"
  },
  {
    "revision": "77e0b4266f161c6f404e",
    "url": "/js/app.caefc7ea.js"
  },
  {
    "revision": "52b3b5a4ba6b408f336d",
    "url": "/js/userCenter.fe07152f.js"
  },
  {
    "revision": "08e5d6aa5ae6faf55563",
    "url": "/js/authority_middle.447bf68b.js"
  },
  {
    "revision": "5e0b8e263e3358780729",
    "url": "/js/transfer_url.635542d1.js"
  },
  {
    "revision": "26b3b8de15366856a236",
    "url": "/js/balanceIndex.7c6bb93a.js"
  },
  {
    "revision": "6220ec282add6e8a956a",
    "url": "/js/to_tb.75c2618d.js"
  },
  {
    "revision": "29779da8111ecac86885",
    "url": "/js/balanceRefund.228b5f9a.js"
  },
  {
    "revision": "9aecd45e2dbe1fc1c467",
    "url": "/js/speedup_wrapper.b2187980.js"
  },
  {
    "revision": "f70d4db296a515aa41e1",
    "url": "/js/cardPackage.310dcc34.js"
  },
  {
    "revision": "6485d987f175d8193c2a",
    "url": "/js/speedup_80.041d21dd.js"
  },
  {
    "revision": "4c7ed2f0a5e47935aac5",
    "url": "/js/card_check.8e375806.js"
  },
  {
    "revision": "67e8f98672bbf2f1c66d",
    "url": "/js/speedup_500.903991ac.js"
  },
  {
    "revision": "85daa599a0701ed1bc2a",
    "url": "/js/card_connection.057c20eb.js"
  },
  {
    "revision": "425d01de29f4759bf04f",
    "url": "/js/revoke_plan.83db99ae.js"
  },
  {
    "revision": "aefcfe0a2b59d3971153",
    "url": "/js/card_lookup.9322e146.js"
  },
  {
    "revision": "a6d2f6d408d68be11fba",
    "url": "/js/repeatRecharge.d626981b.js"
  },
  {
    "revision": "10f74952de0e5761b581",
    "url": "/js/card_more_flow.7a943666.js"
  },
  {
    "revision": "5b7d3881e77be3b32e2c",
    "url": "/js/refund_wrapper.1956a715.js"
  },
  {
    "revision": "aea396e27a90e9974231",
    "url": "/js/card_usage.fc2e0ac2.js"
  },
  {
    "revision": "591cf34dcd9474c52011",
    "url": "/js/refund_plan.13f9d182.js"
  },
  {
    "revision": "4921167410515a5741cb",
    "url": "/js/card_usage~plan_list.51b48b1e.js"
  },
  {
    "revision": "c68275179d4da086c3a4",
    "url": "/js/refund_argument.c8d5b216.js"
  },
  {
    "revision": "35fc4bb4981ba93fc75f",
    "url": "/js/card_wrapper.c4722014.js"
  },
  {
    "revision": "df6c814d7f806117b83b",
    "url": "/js/refund_applying.2d7183be.js"
  },
  {
    "revision": "f76ad0595869f6aeba2f",
    "url": "/js/children_card.79ec5dcf.js"
  },
  {
    "revision": "f90b38eb237146125733",
    "url": "/js/recharge_wrapper.f0719096.js"
  },
  {
    "revision": "ff67e270e5771893b826",
    "url": "/js/chunk-4a4d2551.ca00c238.js"
  },
  {
    "revision": "43e99993ba300aeba308",
    "url": "/js/recharge_callback.00df4fc4.js"
  },
  {
    "revision": "b36389d36c8637a3c2be",
    "url": "/js/chunk-7c3543f4.ed44cc4c.js"
  },
  {
    "revision": "c406a6dfeaeff80dbd02",
    "url": "/js/recharge_balance.7a9f02f3.js"
  },
  {
    "revision": "7a37f1d32dcf31fafb6d",
    "url": "/js/chunk-vendors.6a1799b5.js"
  },
  {
    "revision": "3fdf035789d3eae2e0f7",
    "url": "/js/rechargeOrder.a7c106d8.js"
  },
  {
    "revision": "ecae8e24008591a64fe8",
    "url": "/js/commonProblem.061f6270.js"
  },
  {
    "revision": "d45c3b12268489a7cfd3",
    "url": "/js/recharge.8d483684.js"
  },
  {
    "revision": "d37d7b70e74302c1c36d",
    "url": "/js/commonQuestion.7452ca55.js"
  },
  {
    "revision": "3c255c32286450f77bc6",
    "url": "/js/real_name.229dbd4c.js"
  },
  {
    "revision": "b21a748e92ec2a667d57",
    "url": "/js/consumerRecord.b7980b8b.js"
  },
  {
    "revision": "3ee81bbab16cf8e81b75",
    "url": "/js/realNameCourse.55a5fb89.js"
  },
  {
    "revision": "c3a364d2b4c50a9b7f87",
    "url": "/js/coupon_normal.a8df4ddf.js"
  },
  {
    "revision": "9d665f8bc559a47b23e4",
    "url": "/js/question_wrapper.6c869f53.js"
  },
  {
    "revision": "e2233f860809839047ba",
    "url": "/js/coupon_telcom.771a8a10.js"
  },
  {
    "revision": "1842c8f7aca0d41c8d4a",
    "url": "/js/question.e26e7810.js"
  },
  {
    "revision": "edf4d4b3ec379c8f2bcc",
    "url": "/js/coupon_wrapper.9ce5324a.js"
  },
  {
    "revision": "c5edf8eed58c4637a105",
    "url": "/js/plan_list.10e18dee.js"
  },
  {
    "revision": "a0b64b5c134bd135738e",
    "url": "/js/currencyConversion.c22cd70d.js"
  },
  {
    "revision": "11c186a5e42ccfc9736d",
    "url": "/js/orderRecord.a584d65d.js"
  },
  {
    "revision": "dae822416c4faeb29494",
    "url": "/js/customerFeedback.97a1190b.js"
  },
  {
    "revision": "055b7c4182fba1d67ddc",
    "url": "/js/new_card_wrapper.ad57fb91.js"
  },
  {
    "revision": "19ca512ca8d8050f79ad",
    "url": "/js/eqReplaceMent.cfa6bda8.js"
  },
  {
    "revision": "605ee770177ff6d189f1",
    "url": "/js/mifi_plan_wrapper.999361e8.js"
  },
  {
    "revision": "b1124b16093a74dc5550",
    "url": "/js/eqReplaceMent~recharge.3e20714b.js"
  },
  {
    "revision": "01f47a24728aa334c7d2",
    "url": "/js/mifi_plan_usage.afc0f4af.js"
  },
  {
    "revision": "33216fd534f67c353478",
    "url": "/js/esim_plan_list.0def067f.js"
  },
  {
    "revision": "9989163319b42a255160",
    "url": "/js/mifi_plan_list.4eabd155.js"
  },
  {
    "revision": "e26739b6d3afa4100c8b",
    "url": "/js/esim_usage.0fa45536.js"
  },
  {
    "revision": "85fc9106b320e748dc74",
    "url": "/js/mifi_plan_group.49d897a1.js"
  },
  {
    "revision": "197728809d922026138a",
    "url": "/js/find_plan.92fa20a6.js"
  },
  {
    "revision": "67a45ce3cad58d52d976",
    "url": "/js/mifi_order_wrapper.b8adcae4.js"
  },
  {
    "revision": "00ebc59e4b3dfd45c81d",
    "url": "/js/logical_page.9f8fea40.js"
  },
  {
    "revision": "d64d1f291ea8dc945223",
    "url": "/js/mifi_order.11caab18.js"
  },
  {
    "revision": "f720095b72f048f53996",
    "url": "/js/login.7383c7a6.js"
  },
  {
    "revision": "0d1bf2d086f945b42d8a",
    "url": "/js/mifi_layout.b4bc7ec3.js"
  },
  {
    "revision": "c2b67257b7b9ada74416",
    "url": "/js/lookup.73fcb051.js"
  },
  {
    "revision": "81c2da2f094912e4b07f",
    "url": "/js/mifi_index.7223da06.js"
  },
  {
    "revision": "91995c56d38d4ebbe546",
    "url": "/js/mifi_binding.076f2f12.js"
  },
  {
    "revision": "64e08f25cb1ec85619c9",
    "url": "/js/mifi_coupon_wrapper.6a597257.js"
  },
  {
    "revision": "7c00860238426c812665",
    "url": "/js/mifi_card_info.9736f8ed.js"
  },
  {
    "revision": "a60de7abc2d82557247f",
    "url": "/js/mifi_coupon_index.ac1f4bf5.js"
  },
  {
    "revision": "1ed7d0b07de9e6ad6b98",
    "url": "/js/mifi_card_lookup.16d8ee17.js"
  },
  {
    "revision": "4019fa5ae3b19d9d2872",
    "url": "/js/mifi_change_network_explanation.08e07e2a.js"
  },
  {
    "revision": "dd0c13b253b862702252",
    "url": "/js/mifi_card_wrapper.4b911f1e.js"
  },
  {
    "revision": "1a355c8ae9c9ca437a23",
    "url": "/js/mifi_change_network.edb1b104.js"
  },
  {
    "revision": "fff5af4325410621aeec4e60b3b92d9b",
    "url": "/img/mifi_binding_bg@2x.fff5af43.png"
  },
  {
    "revision": "1a355c8ae9c9ca437a23",
    "url": "/css/mifi_change_network.3299a9ba.css"
  },
  {
    "revision": "f1e25d18d12d687014d2fb54ca92594a",
    "url": "/index.html"
  },
  {
    "revision": "a60de7abc2d82557247f",
    "url": "/css/mifi_coupon_index.12917432.css"
  },
  {
    "revision": "999589aae784a460b5e7c6ae9bbaa3d8",
    "url": "/img/06.999589aa.png"
  },
  {
    "revision": "64e08f25cb1ec85619c9",
    "url": "/css/mifi_coupon_wrapper.034f9976.css"
  },
  {
    "revision": "39d9e849fc1c724525f166646932a24d",
    "url": "/img/safari.39d9e849.png"
  },
  {
    "revision": "81c2da2f094912e4b07f",
    "url": "/css/mifi_index.8a8969f9.css"
  },
  {
    "revision": "eacba58f9acf2b87cd801858146b2ba9",
    "url": "/img/02.eacba58f.png"
  },
  {
    "revision": "0d1bf2d086f945b42d8a",
    "url": "/css/mifi_layout.4d5939c7.css"
  },
  {
    "revision": "a610420eab741be28278e60bc06387aa",
    "url": "/img/box-deco@3x.a610420e.png"
  },
  {
    "revision": "d64d1f291ea8dc945223",
    "url": "/css/mifi_order.e477f019.css"
  },
  {
    "revision": "687b6ce03f134f21173c949d79002960",
    "url": "/img/tip.687b6ce0.png"
  },
  {
    "revision": "67a45ce3cad58d52d976",
    "url": "/css/mifi_order_wrapper.9e98768f.css"
  },
  {
    "revision": "daa86b540bb9c2a6453ceac9bed77961",
    "url": "/img/07.daa86b54.png"
  },
  {
    "revision": "85fc9106b320e748dc74",
    "url": "/css/mifi_plan_group.20a3cdec.css"
  },
  {
    "revision": "a8272d2d742d9d50257e23dfac577def",
    "url": "/img/01.a8272d2d.png"
  },
  {
    "revision": "9989163319b42a255160",
    "url": "/css/mifi_plan_list.79575d4e.css"
  },
  {
    "revision": "f23d9d1f76147bc89b48902c36818f1e",
    "url": "/img/bg_no_plan.f23d9d1f.svg"
  },
  {
    "revision": "01f47a24728aa334c7d2",
    "url": "/css/mifi_plan_usage.38a645b2.css"
  },
  {
    "revision": "9e8ecc7f7b760b55c56bddfab886da10",
    "url": "/img/3.9e8ecc7f.png"
  },
  {
    "revision": "605ee770177ff6d189f1",
    "url": "/css/mifi_plan_wrapper.bb17a37b.css"
  },
  {
    "revision": "96fab583abd57f2e7118324858fa3080",
    "url": "/img/05.96fab583.png"
  },
  {
    "revision": "055b7c4182fba1d67ddc",
    "url": "/css/new_card_wrapper.31258838.css"
  },
  {
    "revision": "b0ffa4a0fd195a110ee4d4dabce3bc32",
    "url": "/img/08.b0ffa4a0.png"
  },
  {
    "revision": "11c186a5e42ccfc9736d",
    "url": "/css/orderRecord.8ba37cf6.css"
  },
  {
    "revision": "34c67f6dfdb0ecc17c7a221aec74706f",
    "url": "/img/bg_no_recharge.34c67f6d.svg"
  },
  {
    "revision": "c5edf8eed58c4637a105",
    "url": "/css/plan_list.c8f445bb.css"
  },
  {
    "revision": "3e217df4202e41ad9b030aafc8cfcc24",
    "url": "/img/4.3e217df4.png"
  },
  {
    "revision": "1842c8f7aca0d41c8d4a",
    "url": "/css/question.f381841c.css"
  },
  {
    "revision": "0b3c3297decbd1152a314cce115f9632",
    "url": "/img/09.0b3c3297.png"
  },
  {
    "revision": "9d665f8bc559a47b23e4",
    "url": "/css/question_wrapper.f7ae0bf9.css"
  },
  {
    "revision": "89b99d16dd8a4a56746323a0ffbd754c",
    "url": "/img/migu.89b99d16.png"
  },
  {
    "revision": "3ee81bbab16cf8e81b75",
    "url": "/css/realNameCourse.45285408.css"
  },
  {
    "revision": "f7a51f1c554585b11d61499fd0a7520f",
    "url": "/img/only-box@3x.f7a51f1c.png"
  },
  {
    "revision": "3c255c32286450f77bc6",
    "url": "/css/real_name.77c7a19d.css"
  },
  {
    "revision": "8c605ac88ca50357355da465f322d10a",
    "url": "/img/telecom-logo.8c605ac8.svg"
  },
  {
    "revision": "d45c3b12268489a7cfd3",
    "url": "/css/recharge.d20b97b9.css"
  },
  {
    "revision": "165beb68d8ba0d2b70df0fbb3769787a",
    "url": "/img/03.165beb68.png"
  },
  {
    "revision": "3fdf035789d3eae2e0f7",
    "url": "/css/rechargeOrder.69857186.css"
  },
  {
    "revision": "55d3f2f09efe17db6485d4c9f8f0c3b1",
    "url": "/img/icon-recharge_20181001.55d3f2f0.svg"
  },
  {
    "revision": "c406a6dfeaeff80dbd02",
    "url": "/css/recharge_balance.5ea8dd99.css"
  },
  {
    "revision": "27158aa79eb0d4b89f317d076a801ca3",
    "url": "/img/coupon-log.27158aa7.png"
  },
  {
    "revision": "43e99993ba300aeba308",
    "url": "/css/recharge_callback.83d9f3b7.css"
  },
  {
    "revision": "0cba868fa977e09806638b9000636a36",
    "url": "/img/avatar.0cba868f.jpeg"
  },
  {
    "revision": "f90b38eb237146125733",
    "url": "/css/recharge_wrapper.770742b7.css"
  },
  {
    "revision": "113f99e2189c2ca49db2168754fc2eb5",
    "url": "/img/mobile-logo.113f99e2.png"
  },
  {
    "revision": "4a10cfc2b1c56cd457fb",
    "url": "/js/Layout.12330839.js"
  },
  {
    "revision": "0b9e0b5f4f28c68416f916ddce3fc7ef",
    "url": "/img/unicom-logo.0b9e0b5f.svg"
  },
  {
    "revision": "df6c814d7f806117b83b",
    "url": "/css/refund_applying.72abc82b.css"
  },
  {
    "revision": "5a3428653945c17e1c146efeee81c987",
    "url": "/img/scanTop.5a342865.png"
  },
  {
    "revision": "c68275179d4da086c3a4",
    "url": "/css/refund_argument.97c8d922.css"
  },
  {
    "revision": "7c28431d304fa4f58f5070c59720683a",
    "url": "/img/2.7c28431d.png"
  },
  {
    "revision": "591cf34dcd9474c52011",
    "url": "/css/refund_plan.04b37d38.css"
  },
  {
    "revision": "541375e6bb7db2fba9e415be8045f5fb",
    "url": "/img/1.541375e6.png"
  },
  {
    "revision": "5b7d3881e77be3b32e2c",
    "url": "/css/refund_wrapper.80fa7896.css"
  },
  {
    "revision": "58a560568b7291ea926c2c7438035308",
    "url": "/img/subscribe@3x.58a56056.png"
  },
  {
    "revision": "a6d2f6d408d68be11fba",
    "url": "/css/repeatRecharge.d600ced8.css"
  },
  {
    "revision": "05775dd69c53d7273b27aaa7c6c523f7",
    "url": "/img/04.05775dd6.png"
  },
  {
    "revision": "425d01de29f4759bf04f",
    "url": "/css/revoke_plan.e130cf54.css"
  },
  {
    "revision": "3603a35a49dbb8ad94ec1e57c4dad229",
    "url": "/img/scanTop2.3603a35a.png"
  },
  {
    "revision": "67e8f98672bbf2f1c66d",
    "url": "/css/speedup_500.76da9141.css"
  },
  {
    "revision": "be0f1e33b2553e71b117d3d3f838d32f",
    "url": "/img/invaildedOrder@2x.be0f1e33.png"
  },
  {
    "revision": "6485d987f175d8193c2a",
    "url": "/css/speedup_80.51fe9728.css"
  },
  {
    "revision": "0d5a5158e67bcb7a4604124715ed6fbf",
    "url": "/img/usedOrder@3x.0d5a5158.png"
  },
  {
    "revision": "9aecd45e2dbe1fc1c467",
    "url": "/css/speedup_wrapper.60be0825.css"
  },
  {
    "revision": "4a5b90f8076955f289b3dcda6a5af6ff",
    "url": "/img/invaildedOrder@3x.4a5b90f8.png"
  },
  {
    "revision": "6220ec282add6e8a956a",
    "url": "/css/to_tb.630d4cca.css"
  },
  {
    "revision": "d9e14058d30dd312519fcf2de38d742b",
    "url": "/img/unUsedOrder@3x.d9e14058.png"
  },
  {
    "revision": "5e0b8e263e3358780729",
    "url": "/css/transfer_url.4be7520f.css"
  },
  {
    "revision": "c0170ec299b2418256fd515ee7849055",
    "url": "/img/unUsedOrder@2x.c0170ec2.png"
  },
  {
    "revision": "52b3b5a4ba6b408f336d",
    "url": "/css/userCenter.7c6534b4.css"
  },
  {
    "revision": "114a6e12b42b9b48586dd341105188fe",
    "url": "/img/usedOrder@2x.114a6e12.png"
  },
  {
    "revision": "8c07452345639aa69f6b",
    "url": "/css/userCenterWrap.87e05186.css"
  },
  {
    "revision": "fa9050c4e9870e8fc0cd184f8515af4a",
    "url": "/img/iccid_bg@3x.fa9050c4.png"
  },
  {
    "revision": "e4b411644706c29765eea3ffdd85ae39",
    "url": "/fonts/SourceHanSansCNRegular.e4b41164.woff"
  },
  {
    "revision": "834b022ab9ab0e6063904af32274e777",
    "url": "/fonts/SourceHanSansCNRegular.834b022a.eot"
  },
  {
    "revision": "f9509c5a10be7daaf1fa01922a7c6bc2",
    "url": "/fonts/SourceHanSansCNRegular.f9509c5a.ttf"
  },
  {
    "revision": "da0808e9fe85be160aab69c82dd8de1c",
    "url": "/img/SourceHanSansCNRegular.da0808e9.svg"
  },
  {
    "revision": "732389ded34cb9c52dd88271f1345af9",
    "url": "/fonts/element-icons.732389de.ttf"
  },
  {
    "revision": "535877f50039c0cb49a6196a5b7517cd",
    "url": "/fonts/element-icons.535877f5.woff"
  },
  {
    "revision": "0f16389ec218c90cf8f657e233b745f2",
    "url": "/img/balanceBg1.0f16389e.png"
  },
  {
    "revision": "565459ef2ee8b71db421144ad21c23e3",
    "url": "/img/balanceBg2.565459ef.png"
  },
  {
    "revision": "42c0fbd4915870e5e60452fd0ef2cbec",
    "url": "/img/orderTopBg@3x.42c0fbd4.png"
  },
  {
    "revision": "42c0fbd4915870e5e60452fd0ef2cbec",
    "url": "/img/orderTopBg@2x.42c0fbd4.png"
  },
  {
    "revision": "fff5af4325410621aeec4e60b3b92d9b",
    "url": "/img/mifi_binding_bg@3x.fff5af43.png"
  },
  {
    "revision": "4019fa5ae3b19d9d2872",
    "url": "/css/mifi_change_network_explanation.f0a09fde.css"
  },
  {
    "revision": "b899232b79ad9962c5ab5572775a0400",
    "url": "/img/card_index_bg@3x.b899232b.png"
  },
  {
    "revision": "b899232b79ad9962c5ab5572775a0400",
    "url": "/img/card_index_bg@2x.b899232b.png"
  },
  {
    "revision": "2c51a1e53c1ea0b35086d8d7261b4933",
    "url": "/img/bg_network@3x.2c51a1e5.png"
  },
  {
    "revision": "32d70c8fc305e3647098f3de0c71b618",
    "url": "/img/bg_network@2x.32d70c8f.png"
  },
  {
    "revision": "f5f322478286641bd9887a155e35f222",
    "url": "/img/btn.f5f32247.png"
  },
  {
    "revision": "d140650fa64e0f1fc771610dba62aed7",
    "url": "/img/bg.d140650f.png"
  },
  {
    "revision": "e625229e32d9deeb5f2909c314d8e609",
    "url": "/img/ios@2x.e625229e.png"
  },
  {
    "revision": "af8bbdfa0a90c4eed4563f8c06ce5ff8",
    "url": "/img/android@2x.af8bbdfa.png"
  },
  {
    "revision": "cc0636ca2944024fd3ebf33a5412ff35",
    "url": "/img/icon-right@3x.cc0636ca.png"
  },
  {
    "revision": "1b983020cfed6b7a8ca5c300c24ca186",
    "url": "/img/icon-left@3x.1b983020.png"
  },
  {
    "revision": "d796d97eb9ebb2e89bb966343e2362e9",
    "url": "/img/icon-left@2x.d796d97e.png"
  },
  {
    "revision": "ccb9865dadbc642b8c4dd0a1abc8e570",
    "url": "/img/recharge-word@2x.ccb9865d.png"
  },
  {
    "revision": "ccb9865dadbc642b8c4dd0a1abc8e570",
    "url": "/img/recharge-word@3x.ccb9865d.png"
  },
  {
    "revision": "41a8c268f703fe646d5d08099eb778ae",
    "url": "/img/icon-right@2x.41a8c268.png"
  },
  {
    "revision": "2d6d06f4da15fc1a748677c49c5f1854",
    "url": "/img/bg.2d6d06f4.png"
  },
  {
    "revision": "3f342771b9b81ab929e0fbcbcd0e6533",
    "url": "/img/bg-check-wrap@3x.3f342771.png"
  },
  {
    "revision": "9713b21819c4019befecd095069977df",
    "url": "/img/bg-check-wrap@2x.9713b218.png"
  },
  {
    "revision": "fa855242805b87da42c65763acd64ac0",
    "url": "/img/bg-plan-type@2x.fa855242.png"
  },
  {
    "revision": "4a9ca192485effa8b8f4b5b2df5b9caf",
    "url": "/img/bg-plan-type@3x.4a9ca192.png"
  },
  {
    "revision": "1d7515ee61c3f659227318b4050955ed",
    "url": "/img/mobile_sim@2x.1d7515ee.png"
  },
  {
    "revision": "0f980b79d9a52702004de9f652a68835",
    "url": "/img/telcom_sim@2x.0f980b79.png"
  },
  {
    "revision": "98141226a7e992e3072a280746a259c4",
    "url": "/img/mobile_sim@3x.98141226.png"
  },
  {
    "revision": "0c88168b284b92c37f3a873f26a97d69",
    "url": "/img/bg.0c88168b.jpg"
  },
  {
    "revision": "9e02095f31a07b972244f1c714c1dfe7",
    "url": "/img/telcom_sim@3x.9e02095f.png"
  },
  {
    "revision": "3d0fc424b703032ca595090e99f8354b",
    "url": "/img/login_bg@2x.3d0fc424.png"
  },
  {
    "revision": "11000d4e510a6df565eb69ba6f2c1dfc",
    "url": "/img/login_bg@3x.11000d4e.png"
  },
  {
    "revision": "014d354b9b25b67ae95857ba17e2f4cc",
    "url": "/img/activityPage.014d354b.png"
  },
  {
    "revision": "2a67b73145562669220aa4639e1ad58f",
    "url": "/img/icon3.2a67b731.png"
  },
  {
    "revision": "813b5319e378dafdda952c16ad89906b",
    "url": "/img/icon2.813b5319.png"
  },
  {
    "revision": "01355f175bd20423ce45a838c1a998a9",
    "url": "/img/bg.01355f17.png"
  },
  {
    "revision": "f40c7e0b20fe25eb78a7658c3ae56312",
    "url": "/img/noData@3x.f40c7e0b.png"
  },
  {
    "revision": "644e6e3cf5f33943747b116316694e28",
    "url": "/img/noData@2x.644e6e3c.png"
  },
  {
    "revision": "91e1d2771efacd45e5e465d9a001f197",
    "url": "/img/liantong.91e1d277.png"
  },
  {
    "revision": "4a0cab0f33beb48ea985714d1b91fef7",
    "url": "/img/dianxin.4a0cab0f.png"
  },
  {
    "revision": "657033323334e91efb0011bbc18f8c04",
    "url": "/img/yidong.65703332.png"
  },
  {
    "revision": "8da3b83b73e44e54d6be4b2522bcb1f2",
    "url": "/img/pkgBg2.8da3b83b.png"
  },
  {
    "revision": "d3b42651f9f5048baeffb50c800913ec",
    "url": "/img/pkgBg1.d3b42651.png"
  },
  {
    "revision": "d461d18e42a310bd709b2ce97d159153",
    "url": "/img/pkgBg3.d461d18e.png"
  },
  {
    "revision": "6e5cee7393060b0ec3dcd587c2518b94",
    "url": "/img/bg_test.6e5cee73.png"
  },
  {
    "revision": "6dedd4943e4c5848638196fb6f0c4145",
    "url": "/img/bg.6dedd494.png"
  },
  {
    "revision": "0078f03c08066d51d64b92a13e194ebb",
    "url": "/img/balanceRefund.0078f03c.png"
  },
  {
    "revision": "af3ed0b3236bbfdbc3ad61b8d41c3dec",
    "url": "/img/changeBg.af3ed0b3.png"
  },
  {
    "revision": "d0ccbc8a35180bb40e027b44dd26035a",
    "url": "/img/youku.d0ccbc8a.png"
  },
  {
    "revision": "a859e9ca4606d567c42b9c7bcd4fdce9",
    "url": "/img/iccid_bg@2x.a859e9ca.png"
  },
  {
    "revision": "e2233f860809839047ba",
    "url": "/css/coupon_telcom.0749aa31.css"
  },
  {
    "revision": "77e0b4266f161c6f404e",
    "url": "/css/app.15f7a604.css"
  },
  {
    "revision": "26b3b8de15366856a236",
    "url": "/css/balanceIndex.7a56af75.css"
  },
  {
    "revision": "29779da8111ecac86885",
    "url": "/css/balanceRefund.9786d2b0.css"
  },
  {
    "revision": "f70d4db296a515aa41e1",
    "url": "/css/cardPackage.972d4cd7.css"
  },
  {
    "revision": "4c7ed2f0a5e47935aac5",
    "url": "/css/card_check.ac37fada.css"
  },
  {
    "revision": "85daa599a0701ed1bc2a",
    "url": "/css/card_connection.a284fb1d.css"
  },
  {
    "revision": "aefcfe0a2b59d3971153",
    "url": "/css/card_lookup.66a74d15.css"
  },
  {
    "revision": "10f74952de0e5761b581",
    "url": "/css/card_more_flow.91833569.css"
  },
  {
    "revision": "aea396e27a90e9974231",
    "url": "/css/card_usage.19c4d050.css"
  },
  {
    "revision": "4921167410515a5741cb",
    "url": "/css/card_usage~plan_list.c0e200ee.css"
  },
  {
    "revision": "35fc4bb4981ba93fc75f",
    "url": "/css/card_wrapper.57946dac.css"
  },
  {
    "revision": "f76ad0595869f6aeba2f",
    "url": "/css/children_card.9c71b5bf.css"
  },
  {
    "revision": "dd0c13b253b862702252",
    "url": "/css/mifi_card_wrapper.6ed40a32.css"
  },
  {
    "revision": "ff67e270e5771893b826",
    "url": "/css/chunk-4a4d2551.c74ec2b8.css"
  },
  {
    "revision": "b36389d36c8637a3c2be",
    "url": "/css/chunk-7c3543f4.36e67b84.css"
  },
  {
    "revision": "7a37f1d32dcf31fafb6d",
    "url": "/css/chunk-vendors.4dda4045.css"
  },
  {
    "revision": "ecae8e24008591a64fe8",
    "url": "/css/commonProblem.d1777633.css"
  },
  {
    "revision": "d37d7b70e74302c1c36d",
    "url": "/css/commonQuestion.5da74062.css"
  },
  {
    "revision": "b21a748e92ec2a667d57",
    "url": "/css/consumerRecord.41a75160.css"
  },
  {
    "revision": "c3a364d2b4c50a9b7f87",
    "url": "/css/coupon_normal.34e8c6e5.css"
  },
  {
    "revision": "08e5d6aa5ae6faf55563",
    "url": "/css/authority_middle.f2c167a9.css"
  },
  {
    "revision": "edf4d4b3ec379c8f2bcc",
    "url": "/css/coupon_wrapper.bdf706e3.css"
  },
  {
    "revision": "a0b64b5c134bd135738e",
    "url": "/css/currencyConversion.29ba4fc2.css"
  },
  {
    "revision": "dae822416c4faeb29494",
    "url": "/css/customerFeedback.81103f78.css"
  },
  {
    "revision": "19ca512ca8d8050f79ad",
    "url": "/css/eqReplaceMent.2bc7c758.css"
  },
  {
    "revision": "b1124b16093a74dc5550",
    "url": "/css/eqReplaceMent~recharge.1395966c.css"
  },
  {
    "revision": "33216fd534f67c353478",
    "url": "/css/esim_plan_list.a09d6e78.css"
  },
  {
    "revision": "e26739b6d3afa4100c8b",
    "url": "/css/esim_usage.3a894732.css"
  },
  {
    "revision": "197728809d922026138a",
    "url": "/css/find_plan.0ae10738.css"
  },
  {
    "revision": "00ebc59e4b3dfd45c81d",
    "url": "/css/logical_page.738e621a.css"
  },
  {
    "revision": "f720095b72f048f53996",
    "url": "/css/login.0c61d3a0.css"
  },
  {
    "revision": "c2b67257b7b9ada74416",
    "url": "/css/lookup.f188f57a.css"
  },
  {
    "revision": "91995c56d38d4ebbe546",
    "url": "/css/mifi_binding.4d63be72.css"
  },
  {
    "revision": "7c00860238426c812665",
    "url": "/css/mifi_card_info.fe8abd93.css"
  },
  {
    "revision": "1ed7d0b07de9e6ad6b98",
    "url": "/css/mifi_card_lookup.6c8c9ae4.css"
  },
  {
    "revision": "94d7cc9826a7aff7eaf5",
    "url": "/css/Not_fund.335e4433.css"
  },
  {
    "revision": "4a10cfc2b1c56cd457fb",
    "url": "/css/Layout.43b3cc9d.css"
  },
  {
    "revision": "9ce16f441b39b493af8b96d7e97cce22",
    "url": "/MP_verify_dkzAKjxyVyJvsHMS.txt"
  },
  {
    "revision": "86c422d8c98b247235d04b49fb1c4b05",
    "url": "/MP_verify_bKSdn2qZlUSULliu.txt"
  },
  {
    "revision": "652317b098ca24e4511926c7fd57cbbe",
    "url": "/MP_verify_8JoCCldW78DygS5c.txt"
  },
  {
    "revision": "00bbf6b458bf7ea6bd01f443eb3045d9",
    "url": "/MP_verify_4r3DVk3KUjgWsQsG.txt"
  }
];