self.__precacheManifest = [
  {
    "revision": "515e24164832387a94e7",
    "url": "/css/refund_argument.a0fc719c.css"
  },
  {
    "revision": "b6216d61c03e6ce0c9aea6ca7808f7ca",
    "url": "/robots.txt"
  },
  {
    "revision": "515e24164832387a94e7",
    "url": "/js/refund_argument.3988f5c5.js"
  },
  {
    "revision": "ebff1aa716de58cc1d18",
    "url": "/css/_404.b9a49c55.css"
  },
  {
    "revision": "318ba6429b1b7190cc9f",
    "url": "/css/app.f82b8cea.css"
  },
  {
    "revision": "318ba6429b1b7190cc9f",
    "url": "/js/app.226e3252.js"
  },
  {
    "revision": "8e0b7e530ac60ac96646",
    "url": "/css/card_check.dd32678e.css"
  },
  {
    "revision": "8e0b7e530ac60ac96646",
    "url": "/js/card_check.dca6aeb2.js"
  },
  {
    "revision": "8efe7d7845d814e35ee7",
    "url": "/css/card_connection.b6854faf.css"
  },
  {
    "revision": "8efe7d7845d814e35ee7",
    "url": "/js/card_connection.d785b102.js"
  },
  {
    "revision": "aacf72d66a3eb84d11c1",
    "url": "/css/card_lookup.b873a2be.css"
  },
  {
    "revision": "aacf72d66a3eb84d11c1",
    "url": "/js/card_lookup.a283bfeb.js"
  },
  {
    "revision": "c6718ee480edf0b990f2",
    "url": "/css/card_usage.3e77570d.css"
  },
  {
    "revision": "c6718ee480edf0b990f2",
    "url": "/js/card_usage.c27aee43.js"
  },
  {
    "revision": "40d038fa1607d0978297",
    "url": "/css/children_card.681cace8.css"
  },
  {
    "revision": "40d038fa1607d0978297",
    "url": "/js/children_card.1d901592.js"
  },
  {
    "revision": "de8bf5d4e57b8a73b3d5",
    "url": "/css/chunk-vendors.0a14d1e9.css"
  },
  {
    "revision": "de8bf5d4e57b8a73b3d5",
    "url": "/js/chunk-vendors.4cb3f68e.js"
  },
  {
    "revision": "065e36fe0c715b14b469",
    "url": "/css/coupon_normal.34b21aaf.css"
  },
  {
    "revision": "065e36fe0c715b14b469",
    "url": "/js/coupon_normal.6d00820b.js"
  },
  {
    "revision": "9c727afc9156aa02a1e3",
    "url": "/css/coupon_telcom.c4d7b922.css"
  },
  {
    "revision": "9c727afc9156aa02a1e3",
    "url": "/js/coupon_telcom.5a7f0920.js"
  },
  {
    "revision": "c803c3a024239c32195e",
    "url": "/css/find_plan.3e9f1792.css"
  },
  {
    "revision": "c803c3a024239c32195e",
    "url": "/js/find_plan.655e9716.js"
  },
  {
    "revision": "116d864b50a110768440",
    "url": "/css/login.6509ca6e.css"
  },
  {
    "revision": "116d864b50a110768440",
    "url": "/js/login.2e2407b0.js"
  },
  {
    "revision": "cba4592a6774e09faecf",
    "url": "/css/lookup.324c73c2.css"
  },
  {
    "revision": "cba4592a6774e09faecf",
    "url": "/js/lookup.a43d494e.js"
  },
  {
    "revision": "b5714ed524556f6dcc1b",
    "url": "/css/plan_list.cdd2509c.css"
  },
  {
    "revision": "b5714ed524556f6dcc1b",
    "url": "/js/plan_list.9bee7bc1.js"
  },
  {
    "revision": "ffcb41bddeef92870c25",
    "url": "/css/question.12ea8f73.css"
  },
  {
    "revision": "ffcb41bddeef92870c25",
    "url": "/js/question.c1f4a2b7.js"
  },
  {
    "revision": "77021589fa6b3d19f374",
    "url": "/css/real_name.49362bec.css"
  },
  {
    "revision": "77021589fa6b3d19f374",
    "url": "/js/real_name.c07fd5af.js"
  },
  {
    "revision": "277fa2e746e72e67c9cf",
    "url": "/css/recharge.d049f50c.css"
  },
  {
    "revision": "277fa2e746e72e67c9cf",
    "url": "/js/recharge.5b442c40.js"
  },
  {
    "revision": "93d0de102dc5644a53da",
    "url": "/css/recharge_callback.a107fbe0.css"
  },
  {
    "revision": "93d0de102dc5644a53da",
    "url": "/js/recharge_callback.dee0271e.js"
  },
  {
    "revision": "ea60fc18e33fc7eee7a1",
    "url": "/css/refund_applying.141e797c.css"
  },
  {
    "revision": "ea60fc18e33fc7eee7a1",
    "url": "/js/refund_applying.3c3e117c.js"
  },
  {
    "revision": "65a8897a369c98aabd9a",
    "url": "/js/Layout.582bc91b.js"
  },
  {
    "revision": "ebff1aa716de58cc1d18",
    "url": "/js/_404.fe333f4c.js"
  },
  {
    "revision": "6eba8ce2d6ac6a3c8e0f",
    "url": "/css/refund_plan.b92606d3.css"
  },
  {
    "revision": "6eba8ce2d6ac6a3c8e0f",
    "url": "/js/refund_plan.f0aa0404.js"
  },
  {
    "revision": "661f78a00633105509cd",
    "url": "/css/revoke_plan.634ee312.css"
  },
  {
    "revision": "661f78a00633105509cd",
    "url": "/js/revoke_plan.af4a993a.js"
  },
  {
    "revision": "325ef7aa1c7c0d668603",
    "url": "/css/speedup_500.a635a9da.css"
  },
  {
    "revision": "325ef7aa1c7c0d668603",
    "url": "/js/speedup_500.ea5943ba.js"
  },
  {
    "revision": "42e49f74859c0c282e83",
    "url": "/css/speedup_80.57269c45.css"
  },
  {
    "revision": "42e49f74859c0c282e83",
    "url": "/js/speedup_80.77f65413.js"
  },
  {
    "revision": "7d71dfa29a8771ae2ebf",
    "url": "/css/to_tb.5f146892.css"
  },
  {
    "revision": "7d71dfa29a8771ae2ebf",
    "url": "/js/to_tb.5f6c3d05.js"
  },
  {
    "revision": "e4b411644706c29765eea3ffdd85ae39",
    "url": "/fonts/SourceHanSansCNRegular.e4b41164.woff"
  },
  {
    "revision": "834b022ab9ab0e6063904af32274e777",
    "url": "/fonts/SourceHanSansCNRegular.834b022a.eot"
  },
  {
    "revision": "f9509c5a10be7daaf1fa01922a7c6bc2",
    "url": "/fonts/SourceHanSansCNRegular.f9509c5a.ttf"
  },
  {
    "revision": "da0808e9fe85be160aab69c82dd8de1c",
    "url": "/img/SourceHanSansCNRegular.da0808e9.svg"
  },
  {
    "revision": "f5f322478286641bd9887a155e35f222",
    "url": "/img/btn.f5f32247.png"
  },
  {
    "revision": "d140650fa64e0f1fc771610dba62aed7",
    "url": "/img/bg.d140650f.png"
  },
  {
    "revision": "3f342771b9b81ab929e0fbcbcd0e6533",
    "url": "/img/bg-check-wrap@3x.3f342771.png"
  },
  {
    "revision": "9713b21819c4019befecd095069977df",
    "url": "/img/bg-check-wrap@2x.9713b218.png"
  },
  {
    "revision": "1d7515ee61c3f659227318b4050955ed",
    "url": "/img/mobile_sim@2x.1d7515ee.png"
  },
  {
    "revision": "0f980b79d9a52702004de9f652a68835",
    "url": "/img/telcom_sim@2x.0f980b79.png"
  },
  {
    "revision": "98141226a7e992e3072a280746a259c4",
    "url": "/img/mobile_sim@3x.98141226.png"
  },
  {
    "revision": "0c88168b284b92c37f3a873f26a97d69",
    "url": "/img/bg.0c88168b.jpg"
  },
  {
    "revision": "9e02095f31a07b972244f1c714c1dfe7",
    "url": "/img/telcom_sim@3x.9e02095f.png"
  },
  {
    "revision": "3d0fc424b703032ca595090e99f8354b",
    "url": "/img/login_bg@2x.3d0fc424.png"
  },
  {
    "revision": "11000d4e510a6df565eb69ba6f2c1dfc",
    "url": "/img/login_bg@3x.11000d4e.png"
  },
  {
    "revision": "5a3428653945c17e1c146efeee81c987",
    "url": "/img/scanTop.5a342865.png"
  },
  {
    "revision": "824594523c01e48028f2b7eb4261134d",
    "url": "/img/unicom-logo.82459452.svg"
  },
  {
    "revision": "27158aa79eb0d4b89f317d076a801ca3",
    "url": "/img/coupon-log.27158aa7.png"
  },
  {
    "revision": "55d3f2f09efe17db6485d4c9f8f0c3b1",
    "url": "/img/icon-recharge_20181001.55d3f2f0.svg"
  },
  {
    "revision": "5f1f34037094c0613bccafa2ddd8cb3b",
    "url": "/img/telecom-logo.5f1f3403.svg"
  },
  {
    "revision": "113f99e2189c2ca49db2168754fc2eb5",
    "url": "/img/mobile-logo.113f99e2.png"
  },
  {
    "revision": "4bdbe7dbdb6587c886a8290593100145",
    "url": "/img/recharge_callback_20181126.4bdbe7db.jpg"
  },
  {
    "revision": "aecc9531f2c3b1fd45338e7bf5084384",
    "url": "/img/bg_no_recharge.aecc9531.svg"
  },
  {
    "revision": "275be51ae57c486bce58257febd6589f",
    "url": "/img/bg_no_plan.275be51a.svg"
  },
  {
    "revision": "75cb14e32d06ea86f75e24f5ec244730",
    "url": "/index.html"
  },
  {
    "revision": "65a8897a369c98aabd9a",
    "url": "/css/Layout.c59a8b7e.css"
  },
  {
    "revision": "86c422d8c98b247235d04b49fb1c4b05",
    "url": "/MP_verify_bKSdn2qZlUSULliu.txt"
  },
  {
    "revision": "652317b098ca24e4511926c7fd57cbbe",
    "url": "/MP_verify_8JoCCldW78DygS5c.txt"
  },
  {
    "revision": "00bbf6b458bf7ea6bd01f443eb3045d9",
    "url": "/MP_verify_4r3DVk3KUjgWsQsG.txt"
  }
];