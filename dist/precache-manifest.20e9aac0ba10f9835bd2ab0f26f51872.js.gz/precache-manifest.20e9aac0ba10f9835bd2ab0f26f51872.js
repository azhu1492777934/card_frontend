self.__precacheManifest = [
  {
    "revision": "3cfd503e2ccd228598dd",
    "url": "/css/Layout.49e22972.css"
  },
  {
    "revision": "3cfd503e2ccd228598dd",
    "url": "/js/Layout.14ed971a.js"
  },
  {
    "revision": "78214ba34c5f1df936aa",
    "url": "/js/Layout~card_usage~eqReplaceMent~esim_plan_list~esim_usage~mifi_order~mifi_plan_list~mifi_plan_usage~~c6f87c36.6241bd21.js"
  },
  {
    "revision": "bebf236814a177833788",
    "url": "/css/Not_fund.e732a7c9.css"
  },
  {
    "revision": "bebf236814a177833788",
    "url": "/js/Not_fund.b1098bb1.js"
  },
  {
    "revision": "14d5ce7884b442698e50",
    "url": "/css/app.0ccacaf2.css"
  },
  {
    "revision": "14d5ce7884b442698e50",
    "url": "/js/app.6c05da70.js"
  },
  {
    "revision": "904a960d2f8cd17a14ae",
    "url": "/css/authority_middle.3e84aa6f.css"
  },
  {
    "revision": "904a960d2f8cd17a14ae",
    "url": "/js/authority_middle.82e98e92.js"
  },
  {
    "revision": "c32f019b937ac1635fd0",
    "url": "/css/balanceIndex.8d965d1d.css"
  },
  {
    "revision": "c32f019b937ac1635fd0",
    "url": "/js/balanceIndex.16ea9da5.js"
  },
  {
    "revision": "597f57b1cbdff5987a5f",
    "url": "/css/balanceRefund.6390149a.css"
  },
  {
    "revision": "597f57b1cbdff5987a5f",
    "url": "/js/balanceRefund.9bde3c27.js"
  },
  {
    "revision": "b24ab1485666d7f566fb",
    "url": "/css/cardPackage.148104cb.css"
  },
  {
    "revision": "b24ab1485666d7f566fb",
    "url": "/js/cardPackage.522cbf13.js"
  },
  {
    "revision": "f05c3155a65d26cdf090",
    "url": "/css/card_check.d552e4f3.css"
  },
  {
    "revision": "f05c3155a65d26cdf090",
    "url": "/js/card_check.127999f4.js"
  },
  {
    "revision": "f4756e715edc7505bf71",
    "url": "/css/card_connection.39d25408.css"
  },
  {
    "revision": "f4756e715edc7505bf71",
    "url": "/js/card_connection.12c6eead.js"
  },
  {
    "revision": "20007cdc2e9e3b65a48c",
    "url": "/css/card_lookup.0dd7583e.css"
  },
  {
    "revision": "20007cdc2e9e3b65a48c",
    "url": "/js/card_lookup.84ed9707.js"
  },
  {
    "revision": "9efef219ad2dfeafa0e2",
    "url": "/css/card_more_flow.9df15305.css"
  },
  {
    "revision": "9efef219ad2dfeafa0e2",
    "url": "/js/card_more_flow.e5d884c7.js"
  },
  {
    "revision": "b683ffa7eccf63638cd2",
    "url": "/css/card_usage.8a568881.css"
  },
  {
    "revision": "b683ffa7eccf63638cd2",
    "url": "/js/card_usage.f040f5d3.js"
  },
  {
    "revision": "054aa7dfaca9cce03f3c",
    "url": "/css/card_wrapper.192c4d2a.css"
  },
  {
    "revision": "054aa7dfaca9cce03f3c",
    "url": "/js/card_wrapper.d0eb31db.js"
  },
  {
    "revision": "33a15dbf4f7aa0a23f11",
    "url": "/css/children_card.1775f585.css"
  },
  {
    "revision": "33a15dbf4f7aa0a23f11",
    "url": "/js/children_card.57453d15.js"
  },
  {
    "revision": "3eb82a263346c45c980c",
    "url": "/css/chunk-3527d1c0.36e67b84.css"
  },
  {
    "revision": "3eb82a263346c45c980c",
    "url": "/js/chunk-3527d1c0.3e67c7c7.js"
  },
  {
    "revision": "c88eb8ac3911259d9cba",
    "url": "/css/chunk-4a4d2551.c74ec2b8.css"
  },
  {
    "revision": "c88eb8ac3911259d9cba",
    "url": "/js/chunk-4a4d2551.1eaec513.js"
  },
  {
    "revision": "42076e74994a14476813",
    "url": "/css/chunk-vendors.1db0edb8.css"
  },
  {
    "revision": "42076e74994a14476813",
    "url": "/js/chunk-vendors.b2d2dce4.js"
  },
  {
    "revision": "499e73bc6e0ad2a29e2f",
    "url": "/css/commonProblem.5e8824ed.css"
  },
  {
    "revision": "499e73bc6e0ad2a29e2f",
    "url": "/js/commonProblem.0d41a4a7.js"
  },
  {
    "revision": "2ffd20d9d4bffdfc6304",
    "url": "/css/commonQuestion.73b98bd3.css"
  },
  {
    "revision": "2ffd20d9d4bffdfc6304",
    "url": "/js/commonQuestion.7ce20cb2.js"
  },
  {
    "revision": "6de74fd617097ffc04b4",
    "url": "/css/consumerRecord.791fa7e8.css"
  },
  {
    "revision": "6de74fd617097ffc04b4",
    "url": "/js/consumerRecord.2f74f674.js"
  },
  {
    "revision": "b04926488412c3fd8f62",
    "url": "/css/coupon_normal.e093da77.css"
  },
  {
    "revision": "b04926488412c3fd8f62",
    "url": "/js/coupon_normal.fbe0391b.js"
  },
  {
    "revision": "04241a9d80346a8b437a",
    "url": "/css/coupon_telcom.dd59f798.css"
  },
  {
    "revision": "04241a9d80346a8b437a",
    "url": "/js/coupon_telcom.e96f40ad.js"
  },
  {
    "revision": "5342361134c2b540401b",
    "url": "/css/coupon_wrapper.50c34f6c.css"
  },
  {
    "revision": "5342361134c2b540401b",
    "url": "/js/coupon_wrapper.c7352882.js"
  },
  {
    "revision": "2e01c65dc21c0f683026",
    "url": "/css/currencyConversion.aef5dc98.css"
  },
  {
    "revision": "2e01c65dc21c0f683026",
    "url": "/js/currencyConversion.e0208fa5.js"
  },
  {
    "revision": "79174c2890faaba9e02e",
    "url": "/css/customerFeedback.b0c6b1e1.css"
  },
  {
    "revision": "79174c2890faaba9e02e",
    "url": "/js/customerFeedback.7bab8be4.js"
  },
  {
    "revision": "4fa49eaa8eddca46cbfb",
    "url": "/css/eqReplaceMent.d2fb3809.css"
  },
  {
    "revision": "4fa49eaa8eddca46cbfb",
    "url": "/js/eqReplaceMent.c4613cf8.js"
  },
  {
    "revision": "06afb61799b6a589f943",
    "url": "/css/eqReplaceMent~recharge.d2dc69b7.css"
  },
  {
    "revision": "06afb61799b6a589f943",
    "url": "/js/eqReplaceMent~recharge.654e6b53.js"
  },
  {
    "revision": "246cfe66281f22dbeef7",
    "url": "/css/esim_plan_list.847ee0f5.css"
  },
  {
    "revision": "246cfe66281f22dbeef7",
    "url": "/js/esim_plan_list.d6a0ebfd.js"
  },
  {
    "revision": "5e83b8cfc9124e3f6369",
    "url": "/css/esim_usage.04997451.css"
  },
  {
    "revision": "5e83b8cfc9124e3f6369",
    "url": "/js/esim_usage.a9671d57.js"
  },
  {
    "revision": "abb023fec561a22cbaa1",
    "url": "/css/find_plan.e1ccaf2f.css"
  },
  {
    "revision": "abb023fec561a22cbaa1",
    "url": "/js/find_plan.5548a7c8.js"
  },
  {
    "revision": "b8834c11bd6eb18e875c",
    "url": "/css/logical_page.e4446a97.css"
  },
  {
    "revision": "b8834c11bd6eb18e875c",
    "url": "/js/logical_page.e33e2ea1.js"
  },
  {
    "revision": "fd1deb006ed0f69a4c58",
    "url": "/css/login.c8ea4d93.css"
  },
  {
    "revision": "fd1deb006ed0f69a4c58",
    "url": "/js/login.fe2a9819.js"
  },
  {
    "revision": "f5e0b4b1a1747d0b85be",
    "url": "/css/lookup.5b2812e1.css"
  },
  {
    "revision": "f5e0b4b1a1747d0b85be",
    "url": "/js/lookup.e8016c27.js"
  },
  {
    "revision": "478e49d4aea80cd77355",
    "url": "/css/mifi_binding.7386ab19.css"
  },
  {
    "revision": "478e49d4aea80cd77355",
    "url": "/js/mifi_binding.714b0bc2.js"
  },
  {
    "revision": "b939a7b861697959908a",
    "url": "/css/mifi_card_info.ccfed337.css"
  },
  {
    "revision": "b939a7b861697959908a",
    "url": "/js/mifi_card_info.63619582.js"
  },
  {
    "revision": "ad3547ca7e0063a71442",
    "url": "/css/mifi_card_lookup.321bb0cb.css"
  },
  {
    "revision": "ad3547ca7e0063a71442",
    "url": "/js/mifi_card_lookup.a003d40e.js"
  },
  {
    "revision": "2cbf76e31147215d809c",
    "url": "/css/mifi_card_wrapper.02a09f97.css"
  },
  {
    "revision": "2cbf76e31147215d809c",
    "url": "/js/mifi_card_wrapper.12249149.js"
  },
  {
    "revision": "16f8ff5333f789bcea84",
    "url": "/css/mifi_change_network.6a65b098.css"
  },
  {
    "revision": "16f8ff5333f789bcea84",
    "url": "/js/mifi_change_network.f37de05f.js"
  },
  {
    "revision": "42ba66178ad397ad8243",
    "url": "/css/mifi_change_network_explanation.14d7ccfc.css"
  },
  {
    "revision": "42ba66178ad397ad8243",
    "url": "/js/mifi_change_network_explanation.1381070b.js"
  },
  {
    "revision": "656033b689d8d8c3a59f",
    "url": "/css/mifi_coupon_index.77bf2c8f.css"
  },
  {
    "revision": "656033b689d8d8c3a59f",
    "url": "/js/mifi_coupon_index.f8337f95.js"
  },
  {
    "revision": "d76d36d361947539bb04",
    "url": "/css/mifi_coupon_wrapper.bd47aa9c.css"
  },
  {
    "revision": "d76d36d361947539bb04",
    "url": "/js/mifi_coupon_wrapper.b37e46b4.js"
  },
  {
    "revision": "afac342222f32b46360a",
    "url": "/css/mifi_index.6440bda3.css"
  },
  {
    "revision": "afac342222f32b46360a",
    "url": "/js/mifi_index.401330a4.js"
  },
  {
    "revision": "a92c3ccc11381526faa2",
    "url": "/css/mifi_layout.e07adb32.css"
  },
  {
    "revision": "a92c3ccc11381526faa2",
    "url": "/js/mifi_layout.baf316a9.js"
  },
  {
    "revision": "3bada0982c3c637d0386",
    "url": "/css/mifi_order.8e6ccafc.css"
  },
  {
    "revision": "3bada0982c3c637d0386",
    "url": "/js/mifi_order.06bcc746.js"
  },
  {
    "revision": "82e60e007c77e060983a",
    "url": "/css/mifi_order_wrapper.cfb1fd47.css"
  },
  {
    "revision": "82e60e007c77e060983a",
    "url": "/js/mifi_order_wrapper.26f361ad.js"
  },
  {
    "revision": "92fb5c4e4dddf2c12e6d",
    "url": "/css/mifi_plan_group.b03fe0e7.css"
  },
  {
    "revision": "92fb5c4e4dddf2c12e6d",
    "url": "/js/mifi_plan_group.ccebd36b.js"
  },
  {
    "revision": "03ec967c4828e614892e",
    "url": "/css/mifi_plan_list.91b50446.css"
  },
  {
    "revision": "03ec967c4828e614892e",
    "url": "/js/mifi_plan_list.8ae74c25.js"
  },
  {
    "revision": "14164e61ac3fa3498297",
    "url": "/css/mifi_plan_usage.8eb1d0a1.css"
  },
  {
    "revision": "14164e61ac3fa3498297",
    "url": "/js/mifi_plan_usage.42660e08.js"
  },
  {
    "revision": "794f53e3d3c3b9c50cb3",
    "url": "/css/mifi_plan_wrapper.9e98768f.css"
  },
  {
    "revision": "794f53e3d3c3b9c50cb3",
    "url": "/js/mifi_plan_wrapper.d229a202.js"
  },
  {
    "revision": "8c775cd0625532dea33c",
    "url": "/css/new_card_wrapper.b45520a3.css"
  },
  {
    "revision": "8c775cd0625532dea33c",
    "url": "/js/new_card_wrapper.2a89b90d.js"
  },
  {
    "revision": "e69536df8a68abc1be1c",
    "url": "/css/orderRecord.9df131f3.css"
  },
  {
    "revision": "e69536df8a68abc1be1c",
    "url": "/js/orderRecord.44e0fa59.js"
  },
  {
    "revision": "72126cf297d21d514cc0",
    "url": "/css/plan_list.491fef59.css"
  },
  {
    "revision": "72126cf297d21d514cc0",
    "url": "/js/plan_list.1b8c8a09.js"
  },
  {
    "revision": "9eae5655f07d1a43ede5",
    "url": "/css/question.af8e1b9f.css"
  },
  {
    "revision": "9eae5655f07d1a43ede5",
    "url": "/js/question.c8822b1f.js"
  },
  {
    "revision": "cb24dd64b19c3a35e058",
    "url": "/css/question_wrapper.f2324655.css"
  },
  {
    "revision": "cb24dd64b19c3a35e058",
    "url": "/js/question_wrapper.e0d321ab.js"
  },
  {
    "revision": "d1b85390ebbfc23be1bf",
    "url": "/css/realNameCourse.a069652c.css"
  },
  {
    "revision": "d1b85390ebbfc23be1bf",
    "url": "/js/realNameCourse.60da9eb8.js"
  },
  {
    "revision": "ac702567ad44b5c42585",
    "url": "/css/real_name.c849c204.css"
  },
  {
    "revision": "ac702567ad44b5c42585",
    "url": "/js/real_name.69a1c613.js"
  },
  {
    "revision": "057552e4cbd739dbbe3d",
    "url": "/css/recharge.f0d89eef.css"
  },
  {
    "revision": "057552e4cbd739dbbe3d",
    "url": "/js/recharge.0ce5d7ab.js"
  },
  {
    "revision": "d518e68dd9f3f45fba7b",
    "url": "/css/rechargeOrder.72cc1c44.css"
  },
  {
    "revision": "d518e68dd9f3f45fba7b",
    "url": "/js/rechargeOrder.ba51d889.js"
  },
  {
    "revision": "d70b34e4801b01625d3b",
    "url": "/css/recharge_balance.890b9b10.css"
  },
  {
    "revision": "d70b34e4801b01625d3b",
    "url": "/js/recharge_balance.8ec888bb.js"
  },
  {
    "revision": "065d64b8a63e6a9f8f49",
    "url": "/css/recharge_callback.5b466417.css"
  },
  {
    "revision": "065d64b8a63e6a9f8f49",
    "url": "/js/recharge_callback.e17b05db.js"
  },
  {
    "revision": "ee9ad9efd89797fd5b10",
    "url": "/css/recharge_wrapper.b10840ae.css"
  },
  {
    "revision": "ee9ad9efd89797fd5b10",
    "url": "/js/recharge_wrapper.0e67576f.js"
  },
  {
    "revision": "626a2895236e6d85efe9",
    "url": "/css/refundRules.60a3087c.css"
  },
  {
    "revision": "626a2895236e6d85efe9",
    "url": "/js/refundRules.edb0fa28.js"
  },
  {
    "revision": "517260f49df180ab884e",
    "url": "/css/refund_applying.ff016f1b.css"
  },
  {
    "revision": "517260f49df180ab884e",
    "url": "/js/refund_applying.77ade9c9.js"
  },
  {
    "revision": "05dc5fe6fcd0f30d353e",
    "url": "/css/refund_argument.c341d992.css"
  },
  {
    "revision": "05dc5fe6fcd0f30d353e",
    "url": "/js/refund_argument.6f642467.js"
  },
  {
    "revision": "cff0c5c50f1e29a40a2b",
    "url": "/css/refund_plan.b28dcdaa.css"
  },
  {
    "revision": "cff0c5c50f1e29a40a2b",
    "url": "/js/refund_plan.80c958bc.js"
  },
  {
    "revision": "e9257c3a4c5758c32332",
    "url": "/css/refund_wrapper.56a3339d.css"
  },
  {
    "revision": "e9257c3a4c5758c32332",
    "url": "/js/refund_wrapper.5a4cb80b.js"
  },
  {
    "revision": "76fbb14bb81d60d90ddc",
    "url": "/css/repeatRecharge.49498668.css"
  },
  {
    "revision": "76fbb14bb81d60d90ddc",
    "url": "/js/repeatRecharge.68cb6207.js"
  },
  {
    "revision": "89b4e94622d3f3a8c6e1",
    "url": "/css/revoke_plan.70001df5.css"
  },
  {
    "revision": "89b4e94622d3f3a8c6e1",
    "url": "/js/revoke_plan.f2eba7ad.js"
  },
  {
    "revision": "9613dd76f06cbd516465",
    "url": "/css/speedup_500.f69a7633.css"
  },
  {
    "revision": "9613dd76f06cbd516465",
    "url": "/js/speedup_500.3610a354.js"
  },
  {
    "revision": "6285276631db7dbd8715",
    "url": "/css/speedup_80.dfe6eff5.css"
  },
  {
    "revision": "6285276631db7dbd8715",
    "url": "/js/speedup_80.ce8f9ce3.js"
  },
  {
    "revision": "3c2c10448e1c8334004b",
    "url": "/css/speedup_wrapper.8710c11d.css"
  },
  {
    "revision": "3c2c10448e1c8334004b",
    "url": "/js/speedup_wrapper.c81ee763.js"
  },
  {
    "revision": "92c5a2fe9221d3fdd0d5",
    "url": "/css/to_tb.3b475e88.css"
  },
  {
    "revision": "92c5a2fe9221d3fdd0d5",
    "url": "/js/to_tb.52a7dbe3.js"
  },
  {
    "revision": "121fa80335de324c2f27",
    "url": "/css/transfer_url.3e9efb9e.css"
  },
  {
    "revision": "121fa80335de324c2f27",
    "url": "/js/transfer_url.648355d5.js"
  },
  {
    "revision": "ed642c65630ee8dc85fd",
    "url": "/css/userCenter.63f51fec.css"
  },
  {
    "revision": "ed642c65630ee8dc85fd",
    "url": "/js/userCenter.2238a67d.js"
  },
  {
    "revision": "2b40de105dbcc37bf184",
    "url": "/css/userCenterWrap.7b926a3e.css"
  },
  {
    "revision": "2b40de105dbcc37bf184",
    "url": "/js/userCenterWrap.6660e30d.js"
  },
  {
    "revision": "1270abe610e71403006c",
    "url": "/css/wifi_management.f10c6d38.css"
  },
  {
    "revision": "1270abe610e71403006c",
    "url": "/js/wifi_management.64ed14e6.js"
  },
  {
    "revision": "e4b411644706c29765eea3ffdd85ae39",
    "url": "/fonts/SourceHanSansCNRegular.e4b41164.woff"
  },
  {
    "revision": "834b022ab9ab0e6063904af32274e777",
    "url": "/fonts/SourceHanSansCNRegular.834b022a.eot"
  },
  {
    "revision": "f9509c5a10be7daaf1fa01922a7c6bc2",
    "url": "/fonts/SourceHanSansCNRegular.f9509c5a.ttf"
  },
  {
    "revision": "da0808e9fe85be160aab69c82dd8de1c",
    "url": "/img/SourceHanSansCNRegular.da0808e9.svg"
  },
  {
    "revision": "732389ded34cb9c52dd88271f1345af9",
    "url": "/fonts/element-icons.732389de.ttf"
  },
  {
    "revision": "535877f50039c0cb49a6196a5b7517cd",
    "url": "/fonts/element-icons.535877f5.woff"
  },
  {
    "revision": "fff5af4325410621aeec4e60b3b92d9b",
    "url": "/img/mifi_binding_bg@3x.fff5af43.png"
  },
  {
    "revision": "fff5af4325410621aeec4e60b3b92d9b",
    "url": "/img/mifi_binding_bg@2x.fff5af43.png"
  },
  {
    "revision": "a859e9ca4606d567c42b9c7bcd4fdce9",
    "url": "/img/iccid_bg@2x.a859e9ca.png"
  },
  {
    "revision": "fa9050c4e9870e8fc0cd184f8515af4a",
    "url": "/img/iccid_bg@3x.fa9050c4.png"
  },
  {
    "revision": "6e5cee7393060b0ec3dcd587c2518b94",
    "url": "/img/bg_test.6e5cee73.png"
  },
  {
    "revision": "d0ccbc8a35180bb40e027b44dd26035a",
    "url": "/img/youku.d0ccbc8a.png"
  },
  {
    "revision": "42c0fbd4915870e5e60452fd0ef2cbec",
    "url": "/img/orderTopBg@3x.42c0fbd4.png"
  },
  {
    "revision": "42c0fbd4915870e5e60452fd0ef2cbec",
    "url": "/img/orderTopBg@2x.42c0fbd4.png"
  },
  {
    "revision": "b899232b79ad9962c5ab5572775a0400",
    "url": "/img/card_index_bg@3x.b899232b.png"
  },
  {
    "revision": "b899232b79ad9962c5ab5572775a0400",
    "url": "/img/card_index_bg@2x.b899232b.png"
  },
  {
    "revision": "2c51a1e53c1ea0b35086d8d7261b4933",
    "url": "/img/bg_network@3x.2c51a1e5.png"
  },
  {
    "revision": "32d70c8fc305e3647098f3de0c71b618",
    "url": "/img/bg_network@2x.32d70c8f.png"
  },
  {
    "revision": "f5f322478286641bd9887a155e35f222",
    "url": "/img/btn.f5f32247.png"
  },
  {
    "revision": "d140650fa64e0f1fc771610dba62aed7",
    "url": "/img/bg.d140650f.png"
  },
  {
    "revision": "e625229e32d9deeb5f2909c314d8e609",
    "url": "/img/ios@2x.e625229e.png"
  },
  {
    "revision": "af8bbdfa0a90c4eed4563f8c06ce5ff8",
    "url": "/img/android@2x.af8bbdfa.png"
  },
  {
    "revision": "1d7515ee61c3f659227318b4050955ed",
    "url": "/img/mobile_sim@2x.1d7515ee.png"
  },
  {
    "revision": "0f980b79d9a52702004de9f652a68835",
    "url": "/img/telcom_sim@2x.0f980b79.png"
  },
  {
    "revision": "98141226a7e992e3072a280746a259c4",
    "url": "/img/mobile_sim@3x.98141226.png"
  },
  {
    "revision": "0c88168b284b92c37f3a873f26a97d69",
    "url": "/img/bg.0c88168b.jpg"
  },
  {
    "revision": "9e02095f31a07b972244f1c714c1dfe7",
    "url": "/img/telcom_sim@3x.9e02095f.png"
  },
  {
    "revision": "3d0fc424b703032ca595090e99f8354b",
    "url": "/img/login_bg@2x.3d0fc424.png"
  },
  {
    "revision": "11000d4e510a6df565eb69ba6f2c1dfc",
    "url": "/img/login_bg@3x.11000d4e.png"
  },
  {
    "revision": "3f342771b9b81ab929e0fbcbcd0e6533",
    "url": "/img/bg-check-wrap@3x.3f342771.png"
  },
  {
    "revision": "9713b21819c4019befecd095069977df",
    "url": "/img/bg-check-wrap@2x.9713b218.png"
  },
  {
    "revision": "014d354b9b25b67ae95857ba17e2f4cc",
    "url": "/img/activityPage.014d354b.png"
  },
  {
    "revision": "fa855242805b87da42c65763acd64ac0",
    "url": "/img/bg-plan-type@2x.fa855242.png"
  },
  {
    "revision": "4a9ca192485effa8b8f4b5b2df5b9caf",
    "url": "/img/bg-plan-type@3x.4a9ca192.png"
  },
  {
    "revision": "cc0636ca2944024fd3ebf33a5412ff35",
    "url": "/img/icon-right@3x.cc0636ca.png"
  },
  {
    "revision": "1b983020cfed6b7a8ca5c300c24ca186",
    "url": "/img/icon-left@3x.1b983020.png"
  },
  {
    "revision": "d796d97eb9ebb2e89bb966343e2362e9",
    "url": "/img/icon-left@2x.d796d97e.png"
  },
  {
    "revision": "ccb9865dadbc642b8c4dd0a1abc8e570",
    "url": "/img/recharge-word@2x.ccb9865d.png"
  },
  {
    "revision": "ccb9865dadbc642b8c4dd0a1abc8e570",
    "url": "/img/recharge-word@3x.ccb9865d.png"
  },
  {
    "revision": "41a8c268f703fe646d5d08099eb778ae",
    "url": "/img/icon-right@2x.41a8c268.png"
  },
  {
    "revision": "2d6d06f4da15fc1a748677c49c5f1854",
    "url": "/img/bg.2d6d06f4.png"
  },
  {
    "revision": "114a6e12b42b9b48586dd341105188fe",
    "url": "/img/usedOrder@2x.114a6e12.png"
  },
  {
    "revision": "c0170ec299b2418256fd515ee7849055",
    "url": "/img/unUsedOrder@2x.c0170ec2.png"
  },
  {
    "revision": "d9e14058d30dd312519fcf2de38d742b",
    "url": "/img/unUsedOrder@3x.d9e14058.png"
  },
  {
    "revision": "4a5b90f8076955f289b3dcda6a5af6ff",
    "url": "/img/invaildedOrder@3x.4a5b90f8.png"
  },
  {
    "revision": "0d5a5158e67bcb7a4604124715ed6fbf",
    "url": "/img/usedOrder@3x.0d5a5158.png"
  },
  {
    "revision": "be0f1e33b2553e71b117d3d3f838d32f",
    "url": "/img/invaildedOrder@2x.be0f1e33.png"
  },
  {
    "revision": "0f16389ec218c90cf8f657e233b745f2",
    "url": "/img/balanceBg1.0f16389e.png"
  },
  {
    "revision": "565459ef2ee8b71db421144ad21c23e3",
    "url": "/img/balanceBg2.565459ef.png"
  },
  {
    "revision": "af3ed0b3236bbfdbc3ad61b8d41c3dec",
    "url": "/img/changeBg.af3ed0b3.png"
  },
  {
    "revision": "0078f03c08066d51d64b92a13e194ebb",
    "url": "/img/balanceRefund.0078f03c.png"
  },
  {
    "revision": "91e1d2771efacd45e5e465d9a001f197",
    "url": "/img/liantong.91e1d277.png"
  },
  {
    "revision": "4a0cab0f33beb48ea985714d1b91fef7",
    "url": "/img/dianxin.4a0cab0f.png"
  },
  {
    "revision": "657033323334e91efb0011bbc18f8c04",
    "url": "/img/yidong.65703332.png"
  },
  {
    "revision": "8da3b83b73e44e54d6be4b2522bcb1f2",
    "url": "/img/pkgBg2.8da3b83b.png"
  },
  {
    "revision": "d3b42651f9f5048baeffb50c800913ec",
    "url": "/img/pkgBg1.d3b42651.png"
  },
  {
    "revision": "d461d18e42a310bd709b2ce97d159153",
    "url": "/img/pkgBg3.d461d18e.png"
  },
  {
    "revision": "6dedd4943e4c5848638196fb6f0c4145",
    "url": "/img/bg.6dedd494.png"
  },
  {
    "revision": "f40c7e0b20fe25eb78a7658c3ae56312",
    "url": "/img/noData@3x.f40c7e0b.png"
  },
  {
    "revision": "644e6e3cf5f33943747b116316694e28",
    "url": "/img/noData@2x.644e6e3c.png"
  },
  {
    "revision": "01355f175bd20423ce45a838c1a998a9",
    "url": "/img/bg.01355f17.png"
  },
  {
    "revision": "2a67b73145562669220aa4639e1ad58f",
    "url": "/img/icon3.2a67b731.png"
  },
  {
    "revision": "813b5319e378dafdda952c16ad89906b",
    "url": "/img/icon2.813b5319.png"
  },
  {
    "revision": "3603a35a49dbb8ad94ec1e57c4dad229",
    "url": "/img/scanTop2.3603a35a.png"
  },
  {
    "revision": "05775dd69c53d7273b27aaa7c6c523f7",
    "url": "/img/04.05775dd6.png"
  },
  {
    "revision": "58a560568b7291ea926c2c7438035308",
    "url": "/img/subscribe@3x.58a56056.png"
  },
  {
    "revision": "541375e6bb7db2fba9e415be8045f5fb",
    "url": "/img/1.541375e6.png"
  },
  {
    "revision": "5a3428653945c17e1c146efeee81c987",
    "url": "/img/scanTop.5a342865.png"
  },
  {
    "revision": "824594523c01e48028f2b7eb4261134d",
    "url": "/img/unicom-logo.82459452.svg"
  },
  {
    "revision": "113f99e2189c2ca49db2168754fc2eb5",
    "url": "/img/mobile-logo.113f99e2.png"
  },
  {
    "revision": "0cba868fa977e09806638b9000636a36",
    "url": "/img/avatar.0cba868f.jpeg"
  },
  {
    "revision": "27158aa79eb0d4b89f317d076a801ca3",
    "url": "/img/coupon-log.27158aa7.png"
  },
  {
    "revision": "55d3f2f09efe17db6485d4c9f8f0c3b1",
    "url": "/img/icon-recharge_20181001.55d3f2f0.svg"
  },
  {
    "revision": "165beb68d8ba0d2b70df0fbb3769787a",
    "url": "/img/03.165beb68.png"
  },
  {
    "revision": "5f1f34037094c0613bccafa2ddd8cb3b",
    "url": "/img/telecom-logo.5f1f3403.svg"
  },
  {
    "revision": "f7a51f1c554585b11d61499fd0a7520f",
    "url": "/img/only-box@3x.f7a51f1c.png"
  },
  {
    "revision": "0b3c3297decbd1152a314cce115f9632",
    "url": "/img/09.0b3c3297.png"
  },
  {
    "revision": "aecc9531f2c3b1fd45338e7bf5084384",
    "url": "/img/bg_no_recharge.aecc9531.svg"
  },
  {
    "revision": "b0ffa4a0fd195a110ee4d4dabce3bc32",
    "url": "/img/08.b0ffa4a0.png"
  },
  {
    "revision": "96fab583abd57f2e7118324858fa3080",
    "url": "/img/05.96fab583.png"
  },
  {
    "revision": "9e8ecc7f7b760b55c56bddfab886da10",
    "url": "/img/3.9e8ecc7f.png"
  },
  {
    "revision": "275be51ae57c486bce58257febd6589f",
    "url": "/img/bg_no_plan.275be51a.svg"
  },
  {
    "revision": "a8272d2d742d9d50257e23dfac577def",
    "url": "/img/01.a8272d2d.png"
  },
  {
    "revision": "daa86b540bb9c2a6453ceac9bed77961",
    "url": "/img/07.daa86b54.png"
  },
  {
    "revision": "687b6ce03f134f21173c949d79002960",
    "url": "/img/tip.687b6ce0.png"
  },
  {
    "revision": "a610420eab741be28278e60bc06387aa",
    "url": "/img/box-deco@3x.a610420e.png"
  },
  {
    "revision": "eacba58f9acf2b87cd801858146b2ba9",
    "url": "/img/02.eacba58f.png"
  },
  {
    "revision": "39d9e849fc1c724525f166646932a24d",
    "url": "/img/safari.39d9e849.png"
  },
  {
    "revision": "999589aae784a460b5e7c6ae9bbaa3d8",
    "url": "/img/06.999589aa.png"
  },
  {
    "revision": "7c28431d304fa4f58f5070c59720683a",
    "url": "/img/2.7c28431d.png"
  },
  {
    "revision": "3e217df4202e41ad9b030aafc8cfcc24",
    "url": "/img/4.3e217df4.png"
  },
  {
    "revision": "6e24b0a3d94176c4f3696eb1ed057f67",
    "url": "/index.html"
  },
  {
    "revision": "00bbf6b458bf7ea6bd01f443eb3045d9",
    "url": "/MP_verify_4r3DVk3KUjgWsQsG.txt"
  },
  {
    "revision": "652317b098ca24e4511926c7fd57cbbe",
    "url": "/MP_verify_8JoCCldW78DygS5c.txt"
  },
  {
    "revision": "86c422d8c98b247235d04b49fb1c4b05",
    "url": "/MP_verify_bKSdn2qZlUSULliu.txt"
  },
  {
    "revision": "9ce16f441b39b493af8b96d7e97cce22",
    "url": "/MP_verify_dkzAKjxyVyJvsHMS.txt"
  },
  {
    "revision": "b6216d61c03e6ce0c9aea6ca7808f7ca",
    "url": "/robots.txt"
  }
];